package Shinobi.Blocks;

import java.util.Random;

import Shinobi.References;
import Shinobi.ShinobiMod;
import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;
import net.minecraft.block.Block;
import net.minecraft.block.BlockFalling;
import net.minecraft.block.BlockFire;
import net.minecraft.block.material.Material;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.texture.IIconRegister;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.potion.PotionEffect;
import net.minecraft.util.AxisAlignedBB;
import net.minecraft.util.IIcon;
import net.minecraft.world.World;

public class BlockBlackFlame extends Block {
	
	IIcon gor = null, dol = null, st1 = null, st2 = null, st3 = null, st4 = null;

	
	private IIcon[] field_149850_M;

	public BlockBlackFlame(Material material) {
		super(material);
		//this.setBlockUnbreakable();
		this.setResistance(5);
		this.setHardness(0.1F);
		this.setLightLevel(2);
		this.setBlockBounds(0F, 0F, 0F, 1F, 2F, 1F);
		//tix--;
		//this.setBlockTextureName("blackflame");
	}
	
	public int quantityDropped(Random p_149745_1_)
    {
        return 0;
    }

	public void onEntityCollidedWithBlock(World world, int i, int j, int k, Entity entity) {
		if (true) {
			if (entity instanceof EntityLivingBase)
				((EntityLivingBase) entity).addPotionEffect(new PotionEffect(20, 1200, 5));
		}
		
	}
	
	
	public void updateTick(World world, int i, int j, int k, Random random) {
		
		if (true) {
			world.playSoundEffect((double) i + 0.5D, (double) j + 0.5D, (double) k + 0.5D, "fire.fire", 1.0F, 1.0F);
		}
		
		world.scheduleBlockUpdate(i, j, k, this, this.tickRate(world));
	}
	
	public void randomDisplayTick(World world, int i, int j, int k, Random random) {
		EntityPlayer entity = Minecraft.getMinecraft().thePlayer;
		World par1World = world;
		int par2 = i;
		int par3 = j;
		int par4 = k;
		Random par5Random = random;
		
		if (true)
			for (int l = 0; l < 7; ++l) {
				double d0 = (double) ((float) par2 + par5Random.nextFloat());
				double d1 = (double) ((float) par3 + par5Random.nextFloat());
				double d2 = (double) ((float) par4 + par5Random.nextFloat());
				double d3 = 0.0D;
				double d4 = 0.0D;
				double d5 = 0.0D;
				int i1 = par5Random.nextInt(2) * 2 - 1;
				d3 = ((double) par5Random.nextFloat() - 0.5D) * 0.7000000014901161D;
				d4 = ((double) par5Random.nextFloat() - 0.5D) * 0.7000000014901161D;
				d5 = ((double) par5Random.nextFloat() - 0.5D) * 0.7000000014901161D;
				par1World.spawnParticle("smoke", d0, d1, d2, d3, d4, d5);
				par1World.spawnParticle("reddust", d0, d1, d2, d3, d4, d5);
				par1World.spawnParticle("dragonbreath", d0, d1, d2, d3, d4, d5);
			}
	

	
	}
	
	public int tickRate(World p_149738_1_)
    {
        return 30;
    }
	
	@Override
	public boolean isOpaqueCube() {
		return false;
	}
	
	public AxisAlignedBB getCollisionBoundingBoxFromPool(World world, int i, int j, int k) {
		return null;
	}
		
	@Override
	public IIcon getIcon(int i, int par2) {

		if (i == 0)
			return gor;

		else if (i == 1)
			return dol;

		else if (i == 2)
			return st1;

		else if (i == 3)
			return st2;

		else if (i == 4)
			return st4;

		else if (i == 5)
			return st3;

		else
			return gor;

	}

	@Override
	public void registerBlockIcons(IIconRegister reg) {
		this.gor = reg.registerIcon("ninja:notexture");
		this.dol = reg.registerIcon("ninja:notexture");
		this.st1 = reg.registerIcon("ninja:blackflame_layer_1");
		this.st2 = reg.registerIcon("ninja:blackflame_layer_0");
		this.st3 = reg.registerIcon("ninja:blackflame_layer_1");
		this.st4 = reg.registerIcon("ninja:blackflame_layer_0");
	}
    
	
}
