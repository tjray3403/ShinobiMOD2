package Shinobi.Blocks;

import java.util.Random;

import Shinobi.Blocks.TileEntity.DeathPoss;
import Shinobi.Entitys.Entitys.EntityHidan;
import net.minecraft.block.Block;
import net.minecraft.block.BlockContainer;
import net.minecraft.block.material.Material;
import net.minecraft.client.Minecraft;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.potion.PotionEffect;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.AxisAlignedBB;
import net.minecraft.util.MathHelper;
import net.minecraft.world.World;

public class BlockDeathPos extends BlockContainer {
	
	public static double x;
	public static double y;
	public static double z;

	public BlockDeathPos(Material material) {
		super(material);
		
		this.setBlockBounds(0.0F, 0.0F, 0.0F, 1F, 0.1F, 1F);	
		
	}
	
	public boolean isOpaqueCube() {
		return false;
	}

	public boolean renderAsNormalBlock()
    {
        return false;
    }
	public AxisAlignedBB getCollisionBoundingBoxFromPool(World world, int i, int j, int k) {
		return null;
	}
	
	public int getRenderType() {
		return 0;
	}
	
	public int onBlockPlaced(World world, double i, double j, double k, int l, float a, float b, float c, int d){
		int retVal = super.onBlockPlaced(world, (int) i, (int) j, (int) k, l, a, b, c, d);

		
		
		

		return retVal;
		}
	
	public void updateTick(World world, int i, int j, int k, Random random) {
		x = i;
		y = j;
		z = k;
	}
	
	public void onEntityCollidedWithBlock(World world, int i, int j, int k, EntityHidan entityH) {
		entityH.addPotionEffect(new PotionEffect(2, 10, 10));
	}

	@Override
	public TileEntity createNewTileEntity(World p_149915_1_, int p_149915_2_) {
		// TODO Auto-generated method stub
		return new DeathPoss(p_149915_2_, p_149915_2_, p_149915_2_);
	}

	public float getBlockPathWeight(int j1, int i2, int k1) {
		// TODO Auto-generated method stub
		return 0;
	}

	public Random getRNG() {
		// TODO Auto-generated method stub
		return null;
	}
	public double getDistanceSqToEntity(EntityHidan entityH) {
		
        return 0;
	}



}