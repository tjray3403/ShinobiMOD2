package Shinobi.Blocks;

import java.util.Random;

import Shinobi.ShinobiDS;
import Shinobi.ShinobiMod;
import net.minecraft.block.Block;
import net.minecraft.block.material.Material;
import net.minecraft.client.Minecraft;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.util.AxisAlignedBB;
import net.minecraft.util.DamageSource;
import net.minecraft.util.MathHelper;
import net.minecraft.world.World;

public class BlockMagnetRelease extends Block {


	public BlockMagnetRelease(Material mat) {
		super(mat);
		this.setResistance(7);
		this.setHardness(7);

	}
	
	public void onEntityCollidedWithBlock(World w, int i, int j, int k, Entity ent)
    {
        ent.attackEntityFrom(DamageSource.magic, 15.0F);
    }
	
	

	public AxisAlignedBB getCollisionBoundingBoxFromPool(World world, int i, int j, int k) {
		return null;
	}
    public boolean isOpaqueCube()
    {
        return false;
    }
	
    public void updateTick(World world, int i, int j, int k, Random random) {
		EntityPlayer entity = Minecraft.getMinecraft().thePlayer;

		if (true) {
			world.setBlockToAir(i, j, k);
		}

		world.scheduleBlockUpdate(i, j, k, this, this.tickRate(world));
	}

    @Override
	public int tickRate(World world) {
		return 13;
	}
    
    public void onBlockAdded(World world, int i, int j, int k) {
		EntityPlayer entity = Minecraft.getMinecraft().thePlayer;
		if (entity != null && world != null) {
			int le = MathHelper.floor_double((double) (entity.rotationYaw * 4.0F / 360.0F) + 0.5D) & 3;
			world.setBlockMetadataWithNotify(i, j, k, le, 2);
		}

		world.scheduleBlockUpdate(i, j, k, this, this.tickRate(world));

	}

	
	
	
	

}
