package Shinobi.Blocks;

import java.util.Random;

import Shinobi.ShinobiMod;
import net.minecraft.block.Block;
import net.minecraft.block.material.Material;
import net.minecraft.client.Minecraft;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.potion.PotionEffect;
import net.minecraft.util.AxisAlignedBB;
import net.minecraft.world.World;

public class BlockSharinganGenjutsu extends Block {

	private static Block block;
	public BlockSharinganGenjutsu(Material material) {
		super(material);
		this.setResistance(5);
		this.setHardness(5);
		this.setLightLevel(2);
		
	}
	

	public void onEntityCollidedWithBlock(World world, int i, int j, int k, Entity entity) {

		if (true) {
			if (entity instanceof EntityLivingBase)
				((EntityLivingBase) entity).addPotionEffect(new PotionEffect(18, 600, 5));
			if (entity instanceof EntityLivingBase)
				((EntityLivingBase) entity).addPotionEffect(new PotionEffect(15, 600, 5));
			if (entity instanceof EntityLivingBase)
				((EntityLivingBase) entity).addPotionEffect(new PotionEffect(9, 600, 5));
			if (entity instanceof EntityLivingBase)
				((EntityLivingBase) entity).addPotionEffect(new PotionEffect(4, 600, 5));
			if (world.getBlock(i, j, k) == ShinobiMod.blockSharinganGenjustu) {
				world.setBlockToAir(i, j, k);
			}
		}

}
	public void updateTick(World world, int i, int j, int k, Random random) {
		EntityPlayer entity = Minecraft.getMinecraft().thePlayer;

		if (world.getBlock(i, j, k) == ShinobiMod.blockSharinganGenjustu) {
			world.setBlockToAir(i, j, k);
		}

		world.scheduleBlockUpdate(i, j, k, this, this.tickRate(world));
	}
	
	@Override
	public boolean isOpaqueCube() {
		return false;
	}
	
	public AxisAlignedBB getCollisionBoundingBoxFromPool(World world, int i, int j, int k) {
		return null;
	}
}
