package Shinobi.Blocks;

import java.util.Random;

import net.minecraft.block.BlockLiquid;
import net.minecraft.block.material.Material;
import net.minecraft.client.renderer.texture.IIconRegister;
import net.minecraft.util.IIcon;
import net.minecraft.world.World;
import net.minecraftforge.fluids.BlockFluidClassic;
import net.minecraftforge.fluids.Fluid;

public class BlockWaterr extends BlockFluidClassic {

	public BlockWaterr(Fluid fluid, Material material) {
		super(fluid, material);
	
		// TODO Auto-generated constructor stub
	}
	
	protected IIcon stillIcon;
	
	protected IIcon flowingIcon;

	@Override
	public IIcon getIcon(int side, int meta) {
		IIcon result = stillIcon;
		if (side == 1) {
			result = flowingIcon;
		}
		return result;
	}

	
	@Override
	public void registerBlockIcons(IIconRegister iir) {
		stillIcon = iir.registerIcon("ninja:magnet1");
		flowingIcon = iir.registerIcon("ninja:magnet1");
	}
	
	public void updateTick(World world, int i, int j, int k, Random random){
		
	}

}
