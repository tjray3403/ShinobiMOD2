package Shinobi.Blocks.TileEntity;

import net.minecraft.pathfinding.PathNavigate;
import net.minecraft.tileentity.TileEntity;

public class DeathPoss extends TileEntity {
	
	 private PathNavigate navigator;
	
	public DeathPoss(int x, int y, int z) {
		
		
		
		
	}

	public PathNavigate getNavigator() {
		// TODO Auto-generated method stub
		return this.navigator;
	}

}
