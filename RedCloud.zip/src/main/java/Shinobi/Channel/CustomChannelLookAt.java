package Shinobi.Channel;

public class CustomChannelLookAt {

}
