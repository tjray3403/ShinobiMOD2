package Shinobi.Effects.Events;

import java.util.UUID;

import Shinobi.ShinobiDS;
import Shinobi.ShinobiMod;
import cpw.mods.fml.common.eventhandler.SubscribeEvent;
import net.minecraft.entity.SharedMonsterAttributes;
import net.minecraft.entity.ai.attributes.AttributeModifier;
import net.minecraft.util.DamageSource;
import net.minecraftforge.event.entity.living.LivingEvent.LivingUpdateEvent;

public class PotionEffect {
	
	private int counter;

	

	@SubscribeEvent
	public void onEntityUpdate(LivingUpdateEvent e){
	if(e.entityLiving.isPotionActive(ShinobiMod.SPoison)){
	if(e.entityLiving.getActivePotionEffect(ShinobiMod.SPoison).getDuration() == 0){
	e.entityLiving.removePotionEffect(ShinobiMod.SPoison.id);
	return;
	}
	else if(e.entityLiving.worldObj.rand.nextInt(30) == 0) {
		
	e.entityLiving.attackEntityFrom(ShinobiDS.sPosionn, 1);
	
	
	}
	}
	}
	}
	


