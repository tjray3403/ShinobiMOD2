package Shinobi.EntityHandlers;

import java.util.Random;

import Shinobi.ShinobiMod;
import Shinobi.Entitys.EntityDeathPos;
import Shinobi.Entitys.Entitys.EntityHidanHurt;
import Shinobi.Entitys.Entitys.EntityShadowClone;
import cpw.mods.fml.common.registry.EntityRegistry;
import net.minecraft.entity.EntityList;
import net.minecraft.entity.EnumCreatureType;
import net.minecraft.world.biome.BiomeGenBase;

public class DpEntityHandler 
{

	public static void registerEntities()
	{
		
		registerEntity(EntityDeathPos.class, "34Dp");
		registerEntity(EntityHidanHurt.class, "34HurtHidan");


	}

	private static void registerEntity(Class entityClass, String name)
	{
		int entityID = EntityRegistry.findGlobalUniqueEntityId();
		long seed = name.hashCode();
		Random rand = new Random(seed);

		EntityRegistry.registerGlobalEntityID(entityClass, name, entityID);
		EntityRegistry.registerModEntity(entityClass, name, entityID, ShinobiMod.Instance, 64, 3, true);
	}

}
