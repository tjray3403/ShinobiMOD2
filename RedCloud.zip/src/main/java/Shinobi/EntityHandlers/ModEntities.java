package Shinobi.EntityHandlers;

import java.util.Random;

import Shinobi.ShinobiMod;
import Shinobi.Entitys.EntityDeathPos;
import Shinobi.Entitys.Entitys.Entity3rdKazekagePuppet;
import Shinobi.Entitys.Entitys.EntityClayBird;
import Shinobi.Entitys.Entitys.EntityClayDragon;
import Shinobi.Entitys.Entitys.EntityClaySpider;
import Shinobi.Entitys.Entitys.EntityCrow;
import Shinobi.Entitys.Entitys.EntityDeidara;
import Shinobi.Entitys.Entitys.EntityFire;
import Shinobi.Entitys.Entitys.EntityHidan;
import Shinobi.Entitys.Entitys.EntityHidanCurse;
import Shinobi.Entitys.Entitys.EntityHidanHurt;
import Shinobi.Entitys.Entitys.EntityItachi;
import Shinobi.Entitys.Entitys.EntityKakuzu;
import Shinobi.Entitys.Entitys.EntityKakuzu2;
import Shinobi.Entitys.Entitys.EntityKakuzu3;
import Shinobi.Entitys.Entitys.EntityKisame;
import Shinobi.Entitys.Entitys.EntityKonan;
import Shinobi.Entitys.Entitys.EntityLightning;
import Shinobi.Entitys.Entitys.EntityPainAnimal;
import Shinobi.Entitys.Entitys.EntityPainAsura;
import Shinobi.Entitys.Entitys.EntityPainDeva;
import Shinobi.Entitys.Entitys.EntityPainHuman;
import Shinobi.Entitys.Entitys.EntityPainNaraka;
import Shinobi.Entitys.Entitys.EntityPainPreta;
import Shinobi.Entitys.Entitys.EntityPaperWings;
import Shinobi.Entitys.Entitys.EntityPuppetSasori;
import Shinobi.Entitys.Entitys.EntitySMChameleon;
import Shinobi.Entitys.Entitys.EntitySMChimera;
import Shinobi.Entitys.Entitys.EntitySMChimera3;
import Shinobi.Entitys.Entitys.EntitySMDrillBird;
import Shinobi.Entitys.Entitys.EntitySMKoH;
import Shinobi.Entitys.Entitys.EntitySMRhino;
import Shinobi.Entitys.Entitys.EntitySasori;
import Shinobi.Entitys.Entitys.EntitySasoriHiruko;
import Shinobi.Entitys.Entitys.EntityShadowClone;
import Shinobi.Entitys.Entitys.EntityShinUchiha;
import Shinobi.Entitys.Entitys.EntityShuriken;
import Shinobi.Entitys.Entitys.EntitySusanoo;
import Shinobi.Entitys.Entitys.EntitySusanooItachi;
import Shinobi.Entitys.Entitys.EntityTobi;
import Shinobi.Entitys.Entitys.EntityUchihaShin;
import Shinobi.Entitys.Entitys.EntityUchihaclone;
import Shinobi.Entitys.Entitys.EntityWater;
import Shinobi.Entitys.Entitys.EntityWhiteZetsu;
import Shinobi.Entitys.Entitys.EntityWind;
import Shinobi.Entitys.Entitys.EntityZetsu;
import Shinobi.Entitys.Projectiles.EntityPlanetaryDev;
import cpw.mods.fml.common.registry.EntityRegistry;
import net.minecraft.entity.EntityList;
import net.minecraft.entity.EnumCreatureType;
import net.minecraft.world.biome.BiomeGenBase;

public class ModEntities 
{

	public static void registerEntities()
	{
		registerEntity(EntityHidan.class, "34Hidan");
		registerEntity(EntityKakuzu.class, "34KakuzuFirst");
		//registerEntity(EntityKakuzu2.class, "34Kakuzusecond");
		//registerEntity(EntityShuriken.class, "34KnifeShuriken");
		registerEntity(EntitySasoriHiruko.class, "34SasoriHirukoForm");
		registerEntity(EntitySasori.class, "34Sasori");
		registerEntity(EntityDeidara.class, "34Deidara");
		registerEntity(EntityKisame.class, "34Kisame");
		registerEntity(EntityItachi.class, "34Itachi");
		registerEntity(EntityKonan.class, "34Konan");
		registerEntity(EntityPainDeva.class, "34PainDeva");
		registerEntity(EntityPainAnimal.class, "34PainAnimal");
		registerEntity(EntityPainPreta.class, "34PainPreta");
		registerEntity(EntityPainHuman.class, "34PainHuman");
		registerEntity(EntityPainNaraka.class, "34PainNaraka");
		registerEntity(EntityPainAsura.class, "34PainAsura");
		registerEntity(EntityTobi.class, "34Tobi");
		registerEntity(EntityZetsu.class, "34Zetsu");
		registerEntity(EntityWhiteZetsu.class, "34WhiteZetsu");






	}

	private static void registerEntity(Class entityClass, String name)
	{
		int entityID = EntityRegistry.findGlobalUniqueEntityId();
		long seed = name.hashCode();
		Random rand = new Random(seed);
		int primaryColor = rand.nextInt() * 16777215;
		int secondaryColor = rand.nextInt() * 16777215;

		EntityRegistry.registerGlobalEntityID(entityClass, name, entityID);
		EntityRegistry.registerModEntity(entityClass, name, entityID, ShinobiMod.Instance, 64, 3, true);
		EntityList.entityEggs.put(Integer.valueOf(entityID), new EntityList.EntityEggInfo(entityID, primaryColor, secondaryColor));
		EntityRegistry.addSpawn(entityClass, 50, 1, 1, EnumCreatureType.monster, BiomeGenBase.roofedForest);
	}

}
