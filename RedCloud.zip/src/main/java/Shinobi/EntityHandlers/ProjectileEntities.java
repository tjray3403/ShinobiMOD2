package Shinobi.EntityHandlers;

import Shinobi.ShinobiMod;
import Shinobi.Entitys.Entitys.Entity3rdKazekagePuppet;
import Shinobi.Entitys.Entitys.EntityClayBird;
import Shinobi.Entitys.Entitys.EntityClayDragon;
import Shinobi.Entitys.Entitys.EntityClaySpider;
import Shinobi.Entitys.Entitys.EntityCrow;
import Shinobi.Entitys.Entitys.EntityFire;
import Shinobi.Entitys.Entitys.EntityKakuzu3;
import Shinobi.Entitys.Entitys.EntityLightning;
import Shinobi.Entitys.Entitys.EntityPaperWings;
import Shinobi.Entitys.Entitys.EntityPuppetSasori;
import Shinobi.Entitys.Entitys.EntitySMChameleon;
import Shinobi.Entitys.Entitys.EntitySMChimera;
import Shinobi.Entitys.Entitys.EntitySMChimera3;
import Shinobi.Entitys.Entitys.EntitySMDrillBird;
import Shinobi.Entitys.Entitys.EntitySMKoH;
import Shinobi.Entitys.Entitys.EntitySMRhino;
import Shinobi.Entitys.Entitys.EntityShadowClone;
import Shinobi.Entitys.Entitys.EntityShinUchiha;
import Shinobi.Entitys.Entitys.EntitySusanooItachi;
import Shinobi.Entitys.Entitys.EntityUchihaShin;
import Shinobi.Entitys.Entitys.EntityUchihaclone;
import Shinobi.Entitys.Entitys.EntityWater;
import Shinobi.Entitys.Entitys.EntityWind;
import Shinobi.Entitys.Projectiles.EntityAsuraHand;
import Shinobi.Entitys.Projectiles.EntityC2;
import Shinobi.Entitys.Projectiles.EntityC3;
import Shinobi.Entitys.Projectiles.EntityC4;
import Shinobi.Entitys.Projectiles.EntityChakraRod;
import Shinobi.Entitys.Projectiles.EntityFireBlast;
import Shinobi.Entitys.Projectiles.EntityFireJet;
import Shinobi.Entitys.Projectiles.EntityGreatFireball;
import Shinobi.Entitys.Projectiles.EntityKunai;
import Shinobi.Entitys.Projectiles.EntityLShark;
import Shinobi.Entitys.Projectiles.EntityLightningBlast;
import Shinobi.Entitys.Projectiles.EntityMShark;
import Shinobi.Entitys.Projectiles.EntityMagnetCube;
import Shinobi.Entitys.Projectiles.EntityMagnetSpread;
import Shinobi.Entitys.Projectiles.EntityMagnetTriangle;
import Shinobi.Entitys.Projectiles.EntityNeedles;
import Shinobi.Entitys.Projectiles.EntityPaperBomb;
import Shinobi.Entitys.Projectiles.EntityPaperChakram;
import Shinobi.Entitys.Projectiles.EntityPaperPerson;
import Shinobi.Entitys.Projectiles.EntityPaperTwister;
import Shinobi.Entitys.Projectiles.EntityParticleX;
import Shinobi.Entitys.Projectiles.EntityPlanetaryDev;
import Shinobi.Entitys.Projectiles.EntityPuppetArmattack;
import Shinobi.Entitys.Projectiles.EntityRinneBullet;
import Shinobi.Entitys.Projectiles.EntitySShark;
import Shinobi.Entitys.Projectiles.EntityWaterBlast;
import Shinobi.Entitys.Projectiles.EntityWaterJet;
import Shinobi.Entitys.Projectiles.EntityWindBlast;
import Shinobi.Entitys.Projectiles.EntityWoodVines;
import Shinobi.Entitys.Projectiles.EntityYasaka;
import cpw.mods.fml.common.registry.EntityRegistry;

public class ProjectileEntities 
{

	public static void registerEntities()
	{
		
		registerEntity(EntityLightningBlast.class, "34LightningBlast");
		registerEntity(EntityWindBlast.class, "34WindBlast");
		registerEntity(EntityNeedles.class, "34Needles");
		registerEntity(EntityFireBlast.class, "34FireBlast");
		registerEntity(EntityWaterBlast.class, "34Waterblast");
		registerEntity(EntityPuppetArmattack.class, "34PuppetArmsAttack");
		registerEntity(EntityMagnetCube.class, "34MagnetCube");
		registerEntity(EntityMagnetTriangle.class, "34MagnetTriangle");
		registerEntity(EntityMagnetSpread.class, "34MagnetSpread");
		registerEntity(EntityWaterJet.class, "34WaterJet");
		registerEntity(EntityFireJet.class, "34FireJet");
		registerEntity(EntityC2.class, "34C2");
		registerEntity(EntityC3.class, "34C3");
		registerEntity(EntityC4.class, "34C4");
		registerEntity(EntitySShark.class, "34SShark");
		registerEntity(EntityMShark.class, "34MShark");
		registerEntity(EntityLShark.class, "34LShark");
		registerEntity(EntityGreatFireball.class, "34GreatFireball");
		registerEntity(EntityKunai.class, "34Kunai");
		registerEntity(EntityYasaka.class, "34Yasaka");
		registerEntity(EntityPaperBomb.class, "34PaperBomb");
		registerEntity(EntityPaperChakram.class, "34PaperChakram");
		registerEntity(EntityPaperTwister.class, "34PaperTwister");
		registerEntity(EntityPaperPerson.class, "34PaperPerson");
		registerEntity(EntityChakraRod.class, "34ChakraRod");
		registerEntity(EntityRinneBullet.class, "34RinneBullet");
		registerEntity(EntityParticleX.class, "34ParticleX");
		registerEntity(EntityAsuraHand.class, "34AsuraHand");
		registerEntity(EntityPlanetaryDev.class, "34ChibakuTensei");
		registerEntity(EntityWoodVines.class, "34WoodVines");


		
		
		//EnititiesWithout Egg
		registerEntity(EntityCrow.class, "34Crow");
		registerEntity(EntityPaperWings.class, "34PaperWings");
		registerEntity(Entity3rdKazekagePuppet.class, "343rdKazekagePuppet");
		registerEntity(EntityPuppetSasori.class, "34Puppet");
		registerEntity(EntityClayDragon.class, "34ClayDragon");
		registerEntity(EntityClaySpider.class, "34ClaySpider");
		registerEntity(EntityClayBird.class, "34ClayBird");
		registerEntity(EntityShinUchiha.class, "34ShinUchiha");
		registerEntity(EntityUchihaShin.class, "34UchihaShin");
		registerEntity(EntityUchihaclone.class, "34ShinUchihaClone");
		registerEntity(EntitySusanooItachi.class, "34ItachiSusanoo");
		registerEntity(EntitySMChimera.class, "34SMChimera");
		registerEntity(EntitySMChimera3.class, "34SMChimera3");
		registerEntity(EntitySMChameleon.class, "34SMChameleon");
		registerEntity(EntitySMDrillBird.class, "34SMDrillBeakBird");
		registerEntity(EntitySMRhino.class, "34SMRhino");
		registerEntity(EntitySMKoH.class, "34SMKingzofHell");
		registerEntity(EntityKakuzu3.class, "34Kakuzuthird");
		registerEntity(EntityFire.class, "34Fire");
		registerEntity(EntityWater.class, "34Water");
		registerEntity(EntityLightning.class, "34Lightning");
		registerEntity(EntityWind.class, "34Wind");
		registerEntity(EntityShadowClone.class, "34Bunshin");

	}

	private static void registerEntity(Class entityClass, String name) {
			int entityID = EntityRegistry.findGlobalUniqueEntityId();
		EntityRegistry.registerGlobalEntityID(entityClass, name, entityID);
		EntityRegistry.registerModEntity(entityClass, name, entityID, ShinobiMod.Instance, 64, 3, true);
	}
	}
