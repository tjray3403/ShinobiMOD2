package Shinobi.Entitys;

import java.util.List;

import Shinobi.Entitys.Entitys.EntityDeidara;
import net.minecraft.entity.EntityLiving;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.world.World;

public class EntityClayBomb extends EntityLiving {

	public EntityClayBomb(World w) {
		super(w);
		
	}
	
	protected void updateEntityActionState()
    {
		
		if(this.getAttackTarget() != null) {
			this.getNavigator().tryMoveToEntityLiving(getAttackTarget(), 0.3);
		}
		double offsetX = Math.cos(this.rotationYaw) * 2;
		double offsetZ = Math.sin(this.rotationYaw) * 2;
		List<EntityLivingBase> Entities = this.worldObj.getEntitiesWithinAABB(EntityDeidara.class, this.boundingBox.getOffsetBoundingBox(offsetX, 0, offsetZ).expand(10, 10, 10));
		for (EntityLivingBase ent : Entities){
			if (ent == this) continue;
		EntityLivingBase elb = ((EntityLiving)ent).getAttackTarget();
			this.setAttackTarget(elb);
		
    }
	
    }
}
