package Shinobi.Entitys;

import Shinobi.Entitys.Entitys.EntityDeidara;
import net.minecraft.command.IEntitySelector;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.EnumCreatureAttribute;

public class EntityClySelector implements IEntitySelector{

	public static final EntityClySelector instance = new EntityClySelector();

	private EntityClySelector(){
	}

	@Override
	public boolean isEntityApplicable(Entity entity){
		if (entity instanceof EntityDeidara)
			return false;
		return true;
	}

}
