package Shinobi.Entitys;

import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLiving;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.pathfinding.PathNavigate;
import net.minecraft.util.ResourceLocation;
import net.minecraft.world.World;

public class EntityDeathPos extends EntityLiving {

	public int te = 700;


	public EntityDeathPos(World world) {
		super(world);
		// TODO Auto-generated constructor stub
	}
	
	public void onUpdate() {
		te--;
		
		if(te==0) {
			this.setDead();
		}
	}
	
	public boolean canBeCollidedWith() {
		return false;
	}


	

}
