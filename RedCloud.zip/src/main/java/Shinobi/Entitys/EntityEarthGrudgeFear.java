package Shinobi.Entitys;

import java.util.List;
import java.util.UUID;

import Shinobi.Entitys.Entitys.Entity3rdKazekagePuppet;
import Shinobi.Entitys.Entitys.EntityFire;
import Shinobi.Entitys.Entitys.EntityKakuzu;
import Shinobi.Entitys.Entitys.EntityLightning;
import Shinobi.Entitys.Entitys.EntityWater;
import Shinobi.Entitys.Entitys.EntityWind;
import Shinobi.Entitys.Entitys.AI.AIAttackableTarget;
import Shinobi.Entitys.Entitys.AI.AIFollowOwner;
import Shinobi.Entitys.Projectiles.EntityFireBlast;
import Shinobi.Entitys.Projectiles.EntityLightningBlast;
import Shinobi.Entitys.Projectiles.EntityWaterBlast;
import Shinobi.Entitys.Projectiles.EntityWindBlast;
import net.minecraft.command.IEntitySelector;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityCreature;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.EnumCreatureAttribute;
import net.minecraft.entity.SharedMonsterAttributes;
import net.minecraft.entity.ai.EntityAIAttackOnCollide;
import net.minecraft.entity.ai.EntityAIHurtByTarget;
import net.minecraft.entity.ai.EntityAILookIdle;
import net.minecraft.entity.ai.EntityAIMoveTowardsTarget;
import net.minecraft.entity.ai.EntityAINearestAttackableTarget;
import net.minecraft.entity.ai.EntityAISwimming;
import net.minecraft.entity.ai.EntityAIWander;
import net.minecraft.entity.monster.EntityMob;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.server.management.PreYggdrasilConverter;
import net.minecraft.util.DamageSource;
import net.minecraft.world.World;
import thehippomasterAPI.AnimationAPI.IAnimatedEntity;

public class EntityEarthGrudgeFear extends EntityMob implements IAnimatedEntity {
	
	private int animID;
	private int animTick;

	//public int cooldown = 55;
	
	
	public EntityEarthGrudgeFear(World w) {
		super(w);
		animID = 0;
		animTick = 0;
		this.getNavigator().setBreakDoors(true);
		this.tasks.addTask(0, new EntityAISwimming(this));
		this.tasks.addTask(0, new EntityAIWander(this, 0.8F));
		
		this.tasks.addTask(5, new EntityAIHurtByTarget(this, false));
		this.targetTasks.addTask(5, new EntityAINearestAttackableTarget(this, EntityPlayer.class, 0, true));

		//this.targetTasks.addTask(5, new AIAttackableTarget(this, 0.3F));
	

		this.tasks.addTask(5, new EntityAILookIdle(this));
		this.tasks.addTask(10, new EntityAIAttackOnCollide(this, EntityPlayer.class, 1.0D, false));// TODO Auto-generated constructor stub
	}

	
	@Override
	public boolean isAIEnabled(){
		return true;
	}

	@Override
	protected void applyEntityAttributes(){
		super.applyEntityAttributes();
		this.getEntityAttribute(SharedMonsterAttributes.followRange).setBaseValue(48);
	}

	/**
	 * This contains the default AI tasks.  To add new ones, override {@link #initSpecificAI()}
	 */
	
	public void onLivingUpdate() {
		super.onLivingUpdate();
		int i = (int) this.posX;
		int j = (int) this.posY;
		int k = (int) this.posZ;
		Entity entity = this;
	
		if(true) {
			this.stepHeight = 50f;
			this.fallDistance = 0f;
			
		}
		
		if(this.inWater) {
			this.motionY = 0.1;
			this.onGround = true;
		}
		
		
		
	
	}
	
	 public boolean attackEntityFrom(DamageSource dmg, float flt)
	    {
		Entity ent = dmg.getSourceOfDamage();
		 
		 //EntityKakuzu entk = new EntityKakuzu(worldObj);
		if (ent instanceof EntityEarthGrudgeFear){
			 return false;
		 }
		
		if (ent instanceof EntityFireBlast){
			 return false;
		 }
		if (ent instanceof EntityLightningBlast){
			 return false;
		 }
		if (ent instanceof EntityWaterBlast){
			 return false;
		 }
		if (ent instanceof EntityWindBlast){
			 return false;
		 }
		//EntityEarthGrudgeFear entf = new EntityEarthGrudgeFear(worldObj);
		if (ent instanceof EntityKakuzu){
			 return false;
		 }
		 
		 
			return super.attackEntityFrom(dmg, flt);
			}
	        /**
	        {
	            Entity entity = dmg.getEntity();

	            if (true)
	            {
	                List list = this.worldObj.getEntitiesWithinAABBExcludingEntity(this, this.boundingBox.expand(32.0D, 32.0D, 32.0D));

	                for (int i = 0; i < list.size(); ++i)
	                {
	                    Entity entity1 = (Entity)list.get(i);

	                    if (entity1 instanceof EntityEarthGrudgeFear)
	                    {
	                        EntityEarthGrudgeFear e3rd = (EntityEarthGrudgeFear)entity1;
	                        e3rd.becomeAngryAt(entity);
	                    }
	                }

	                this.becomeAngryAt(entity);
	            }

	            return super.attackEntityFrom(dmg, flt);
	        }
	   */ 
		
	

	public void onUpdate() {
		super.onUpdate();
		if(animID!=0)animTick++;
		
		
		//cooldown--;
		//if(cooldown==0){
		//	cooldown = 55;
		//}
	}
	
	/**
	 * Initializer for class-specific AI
	 */
	
	


	@Override
	protected boolean canDespawn(){
		return false;
	}

	@Override
	public void setAnimID(int id) {
		animID = id;
		
	}

	@Override
	public void setAnimTick(int tick) {
		animTick = tick;
		
	}

	@Override
	public int getAnimID() {
		// TODO Auto-generated method stub
		return animID;
	}

	@Override
	public int getAnimTick() {
		// TODO Auto-generated method stub
		return animTick;
	}

	//public void attackEntityasmob(Entity e) {
		// TODO Auto-generated method stub
		
	//}
	
}

	

	