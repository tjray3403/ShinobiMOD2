package Shinobi.Entitys;

import net.minecraft.entity.Entity;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.world.World;

public class EntityNin extends Entity {

	public EntityNin(World w) {
		super(w);
	}

	
	protected void entityInit() {
			
	}

	@Override
	protected void readEntityFromNBT(NBTTagCompound nbt) {
		
	}

	@Override
	protected void writeEntityToNBT(NBTTagCompound nbtt) {
		
	}

}
