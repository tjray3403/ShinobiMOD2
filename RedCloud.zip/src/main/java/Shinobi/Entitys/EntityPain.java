package Shinobi.Entitys;

import net.minecraft.world.World;

public abstract class EntityPain extends EntityNinja {

	public EntityPain(World var1) {
		super(var1);
		// TODO Auto-generated constructor stub
	}

}
