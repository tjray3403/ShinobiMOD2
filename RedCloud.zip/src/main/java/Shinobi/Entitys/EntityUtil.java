package Shinobi.Entitys;


import cpw.mods.fml.relauncher.ReflectionHelper;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityCreature;
import net.minecraft.entity.EntityLiving;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.ai.EntityAIAttackOnCollide;
import net.minecraft.entity.ai.EntityAIHurtByTarget;
import net.minecraft.entity.ai.EntityAIMoveTowardsTarget;
import net.minecraft.entity.ai.EntityAINearestAttackableTarget;
import net.minecraft.entity.ai.EntityAITasks.EntityAITaskEntry;
import net.minecraft.entity.boss.IBossDisplayData;
import net.minecraft.entity.monster.EntityGhast;
import net.minecraft.entity.monster.EntityMob;
import net.minecraft.entity.monster.EntitySlime;
import net.minecraft.entity.monster.IMob;
import net.minecraft.entity.passive.EntityTameable;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTBase;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.nbt.NBTTagInt;
import net.minecraft.server.MinecraftServer;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.world.World;
import net.minecraft.world.WorldServer;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.HashMap;

import Shinobi.ShinobiMod;
import Shinobi.Entitys.Entitys.AI.AIFollowOwner;

public class EntityUtil{
	private static final HashMap<Integer, ArrayList> storedTasks = new HashMap<Integer, ArrayList>();
	private static final HashMap<Integer, ArrayList> storedAITasks = new HashMap<Integer, ArrayList>();
	private static final String isSummonKey = "_Entity_Is_Made_Summon";
	private static final String summonEntityIDs = "_Summon_Entity_IDs";
	private static final String summonDurationKey = "_Summon_Duration";
	private static final String summonOwnerKey = "_Summon_Owner";
	

	private static Method ptrSetSize = null;

	public static boolean isAIEnabled(EntityCreature ent){
		Method m = null;
		try{
			m = EntityLiving.class.getDeclaredMethod("func_70650_aV");
		}catch (NoSuchMethodException nex){
			try{
				m = EntityLiving.class.getDeclaredMethod("isAIEnabled");
			}catch (Throwable t){
				t.printStackTrace();
				return false;
			}
		}catch (Throwable t){
			t.printStackTrace();
			return false;
		}
		m.setAccessible(true);
		boolean b;
		try{
			b = (Boolean)m.invoke(ent);
		}catch (Throwable e){
			e.printStackTrace();
			return false;
		}
		m.setAccessible(false);
		return b;
	}

	



	public static void makeSummon_MonsterFaction(EntityCreature entityliving, boolean storeForRevert){
		///if (isAIEnabled(entityliving) && !(entityliving instanceof IBossDisplayData)){
			if (storeForRevert)
				storedTasks.put(entityliving.getEntityId(), new ArrayList(entityliving.targetTasks.taskEntries));
			//entityliving.targetTasks.taskEntries.clear();
			entityliving.targetTasks.addTask(1, new EntityAIHurtByTarget(entityliving, true));
			entityliving.targetTasks.addTask(2, new EntityAINearestAttackableTarget(entityliving, EntityPlayer.class, 0, true));
			

			entityliving.getEntityData().setBoolean(isSummonKey, true);
	//	}
	
			NBTTagCompound tag = entityliving.getEntityData();
			tag.getString(isSummonKey);
			tag.getString(summonOwnerKey);
			tag.getString(summonDurationKey);
			tag.getString(summonEntityIDs);
			tag.setString(summonOwnerKey, "_Summon_Owner");
			tag.setString(isSummonKey, "_Entity_Is_Made_Summon");
			tag.setString(summonEntityIDs, "_Summon_Entity_IDs");
			tag.setString(summonDurationKey, "_Summon_Duration");
			
			
			
	}
	
	public static boolean revertAI(EntityCreature entityliving){

		int ownerID = getOwner(entityliving);
		Entity owner = entityliving.worldObj.getEntityByID(ownerID);

		entityliving.getEntityData().setBoolean(isSummonKey, false);
		setOwner(entityliving, null);

		if (storedTasks.containsKey(entityliving.getEntityId())){
			entityliving.targetTasks.taskEntries.clear();
			entityliving.targetTasks.taskEntries.addAll(storedTasks.get(entityliving.getEntityId()));
			storedTasks.remove(entityliving.getEntityId());

			if (storedAITasks.get(entityliving.getEntityId()) != null){
				ArrayList<EntityAITaskEntry> toRemove = new ArrayList<EntityAITaskEntry>();
				for (Object task : entityliving.tasks.taskEntries){
					EntityAITaskEntry base = (EntityAITaskEntry)task;
					if (base.action instanceof EntityAIAttackOnCollide || base.action instanceof AIFollowOwner){
						toRemove.add(base);
					}
				}

				entityliving.tasks.taskEntries.removeAll(toRemove);

				entityliving.tasks.taskEntries.addAll(storedAITasks.get(entityliving.getEntityId()));
				storedAITasks.remove(entityliving.getEntityId());
			}
		}

		return false;
	}
	
	public static boolean isSummon(EntityLivingBase entityliving){
		return entityliving.getEntityData().getBoolean(isSummonKey);
	}

	public static void setOwner(EntityLivingBase entityliving, EntityLivingBase owner){
		if (owner == null){
			entityliving.getEntityData().removeTag(summonOwnerKey);
			return;
		}
		

		entityliving.getEntityData().setInteger(summonOwnerKey, owner.getEntityId());
		if (entityliving instanceof EntityCreature){
			float speed = entityliving.getAIMoveSpeed();
			if (speed <= 0) speed = 1.0f;
			((EntityCreature)entityliving).tasks.addTask(1, new AIFollowOwner((EntityCreature)entityliving, speed, 10, 20));
		}
	}

	

	

	public static int getOwner(EntityLivingBase entityliving){
		if (!isSummon(entityliving)) return -1;
		Integer ownerID = entityliving.getEntityData().getInteger(summonOwnerKey);
		return ownerID == null ? -1 : ownerID;
	}

	

	public static void setSummonDuration(EntityLivingBase entity, int duration){
		entity.getEntityData().setInteger(summonDurationKey, duration);
	}

	/**
	 * If returns true, the summon has more duration and can continue to exist
	 */
	public static boolean decrementSummonDuration(EntityLivingBase ent){
			int duration = ent.getEntityData().getInteger(summonDurationKey);
			if (duration == -1)
				return true;
			duration--;
			setSummonDuration(ent, duration);
			return duration > 0;
		}





	
		
	
	
	}
	
