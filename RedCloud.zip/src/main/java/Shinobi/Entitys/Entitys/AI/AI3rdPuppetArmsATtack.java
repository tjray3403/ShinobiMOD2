package Shinobi.Entitys.Entitys.AI;

import Shinobi.Entitys.EntityNinja;
import Shinobi.Entitys.Entitys.Entity3rdKazekagePuppet;
import Shinobi.Entitys.Entitys.EntitySasoriHiruko;
import Shinobi.Entitys.Projectiles.EntityFireBlast;
import Shinobi.Entitys.Projectiles.EntityNeedles;
import Shinobi.Entitys.Projectiles.EntityPuppetArmattack;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.util.MathHelper;
import thehippomasterAPI.AnimationAPI.AIAnimation;

public class AI3rdPuppetArmsATtack extends AIAnimation {

    private Entity3rdKazekagePuppet entity;
    private EntityLivingBase attackTarget;
   // int cooldown = 75;

    public AI3rdPuppetArmsATtack(Entity3rdKazekagePuppet third)
    {
        super(third);
        entity = third;
        attackTarget = null;
    }

    public int getAnimID()
    {
        return 2;
    }

    public boolean isAutomatic()
    {
        return false;
    }

    public int getDuration()
    {
        return 30;
    }
    
    public boolean shouldAnimate(){
		EntityLivingBase AITarget = entity.getAttackTarget();
		if (AITarget == null || AITarget.isDead) return false;
		if(entity.getHealth() < 1750D) return false;
		if (entity.getDistanceSqToEntity(AITarget) < 3D){
				return false;
		}
		return true;
		
	}

    public void startExecuting()
    {
        super.startExecuting();
        attackTarget = entity.getAttackTarget();
    }
    
    

    public void updateTask()
    {
        if(entity.getAnimTick() < 10 && attackTarget != null)
            entity.getLookHelper().setLookPositionWithEntity(attackTarget, 20F,20F);
        if(entity.getAnimTick() < 5 && attackTarget != null)
        {
            EntityPuppetArmattack efb = new EntityPuppetArmattack(entity.worldObj, entity, 0.8F);
            double d0 = attackTarget.posX - entity.posX;
            double d1 = attackTarget.posY + (double)attackTarget.getEyeHeight() - 1.100000023841858D - efb.posY;
            double d2 = attackTarget.posZ - entity.posZ;
            float f1 = MathHelper.sqrt_double(d0 * d0 + d2 * d2) * 0.2F;
            efb.setHeading(d0, d1 + (double)f1, d2, 1.6F, 12.0F);
            entity.worldObj.spawnEntityInWorld(efb);
        }
        if(entity.getAnimTick() > 10)
			entity.setAnimID(0);
        
        
        
    }
    
   

}
