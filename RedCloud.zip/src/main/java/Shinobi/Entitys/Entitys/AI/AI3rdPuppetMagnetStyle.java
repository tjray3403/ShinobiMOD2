package Shinobi.Entitys.Entitys.AI;

import java.util.Random;

import Shinobi.ShinobiMod;
import Shinobi.Entitys.EntityNinja;
import Shinobi.Entitys.Entitys.Entity3rdKazekagePuppet;
import Shinobi.Entitys.Entitys.EntitySasoriHiruko;
import Shinobi.Entitys.Projectiles.EntityFireBlast;
import Shinobi.Entitys.Projectiles.EntityMagnetCube;
import Shinobi.Entitys.Projectiles.EntityMagnetSpread;
import Shinobi.Entitys.Projectiles.EntityMagnetTriangle;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityList;
import net.minecraft.entity.EntityLiving;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.util.MathHelper;
import thehippomasterAPI.AnimationAPI.AIAnimation;

public class AI3rdPuppetMagnetStyle extends AIAnimation {

    private Entity3rdKazekagePuppet entity;
    private EntityLivingBase attackTarget;
    private int cooldown = 45;

    public AI3rdPuppetMagnetStyle(Entity3rdKazekagePuppet third)
    {
        super(third);
        entity = third;
        attackTarget = null;
        
    }

    public int getAnimID()
    {
        return 3;
    }

    public boolean isAutomatic()
    {
        return false;
    }

    public int getDuration()
    {
        return 30;
    }
    
    
    public boolean shouldAnimate(){
		EntityLivingBase AITarget = entity.getAttackTarget();
		if (AITarget == null || AITarget.isDead) return false;
		if(entity.getHealth() > 1750D) return false;
		if(entity.counter<35)return false;
		//if ( entity.getDistanceSqToEntity(AITarget) < 3D){
		//		return false;
		//}
		return true;
		
	}

    public void startExecuting()
    {
        super.startExecuting();
        attackTarget = entity.getAttackTarget();
    }
    
    

    public void updateTask()
    {
    	Random rand = new Random();
        if(entity.getAnimTick() < 10 && attackTarget != null)
            entity.getLookHelper().setLookPositionWithEntity(attackTarget, 20F,20F);
        if(entity.getAnimTick() < 1 && attackTarget != null)
        {
        	
        	
        	switch(rand.nextInt(3))
        	{
        	case 0:
            EntityMagnetCube emc = new EntityMagnetCube (entity.worldObj, attackTarget, 0.5F);
            double d0 = attackTarget.posX - entity.posX;
            double d1 = attackTarget.posY + 7;
            double d2 = attackTarget.posZ - entity.posZ;
            float f1 = MathHelper.sqrt_double(d0 * d0 + d2 * d2) * 0.2F;
            emc.setHeading(d0, d1 + (double)f1, d2, 1.6F, 12.0F);
            entity.worldObj.spawnEntityInWorld(emc);
            break;
            
        	case 1:
        	EntityMagnetTriangle emt = new EntityMagnetTriangle (entity.worldObj, attackTarget, 0.8F);
            double c0 = attackTarget.posX - entity.posX;
            double c1 = attackTarget.posY + 7;
            double c2 = attackTarget.posZ - entity.posZ;
            float w1 = MathHelper.sqrt_double(c0 * c0 + c2 * c2) * 0.2F;
            emt.setHeading(c0, c1 + (double)w1, c2, 1.6F, 12.0F);
            entity.worldObj.spawnEntityInWorld(emt);
        	break;
        	
        	case 2:
        	Random rr = new Random();
        	int	x = (int) attackTarget.posX;
        	int	y = (int) attackTarget.posY;
        	int	z = (int) attackTarget.posZ;
        	int t = rr.nextInt(7);
        	if (!entity.worldObj.isRemote) {
    			Entity sentity = EntityList.createEntityByName("34MagnetSpread", entity.worldObj);
    			if (sentity != null) {
    				sentity.setLocationAndAngles(x, y, z, entity.worldObj.rand.nextFloat() * 360F, 0.0F);
    				entity.worldObj.spawnEntityInWorld(sentity);
    			}
    		} 
        	/**
        	attackTarget.worldObj.setBlock(x + 4, y + 0, z + 0, ShinobiMod.blockMagnetRelease );
			attackTarget.worldObj.setBlock(x + 6, y + 0, z + 0, ShinobiMod.blockMagnetRelease );
			attackTarget.worldObj.setBlock(x + 2, y + 0, z + 2, ShinobiMod.blockMagnetRelease );
			attackTarget.worldObj.setBlock(x + 5, y + 0, z + 2, ShinobiMod.blockMagnetRelease );
			attackTarget.worldObj.setBlock(x + 8, y + 0, z + 2, ShinobiMod.blockMagnetRelease );
			attackTarget.worldObj.setBlock(x + 4, y + 0, z + 4, ShinobiMod.blockMagnetRelease );
			attackTarget.worldObj.setBlock(x + 5, y + 0, z + 4, ShinobiMod.blockMagnetRelease );
			attackTarget.worldObj.setBlock(x + 6, y + 0, z + 4, ShinobiMod.blockMagnetRelease );
			attackTarget.worldObj.setBlock(x + 0, y + 0, z + 5, ShinobiMod.blockMagnetRelease );
			attackTarget.worldObj.setBlock(x + 2, y + 0, z + 5, ShinobiMod.blockMagnetRelease );
			attackTarget.worldObj.setBlock(x + 4, y + 0, z + 5, ShinobiMod.blockMagnetRelease );
			attackTarget.worldObj.setBlock(x + 5, y + 0, z + 5, ShinobiMod.blockMagnetRelease );
			attackTarget.worldObj.setBlock(x + 6, y + 0, z + 5, ShinobiMod.blockMagnetRelease );
			attackTarget.worldObj.setBlock(x + 8, y + 0, z + 5, ShinobiMod.blockMagnetRelease );
			attackTarget.worldObj.setBlock(x + 10, y + 0, z + 5, ShinobiMod.blockMagnetRelease );
			attackTarget.worldObj.setBlock(x + 4, y + 0, z + 6, ShinobiMod.blockMagnetRelease );
			attackTarget.worldObj.setBlock(x + 5, y + 0, z + 6, ShinobiMod.blockMagnetRelease );
			attackTarget.worldObj.setBlock(x + 6, y + 0, z + 6, ShinobiMod.blockMagnetRelease );
			attackTarget.worldObj.setBlock(x + 2, y + 0, z + 8, ShinobiMod.blockMagnetRelease );
			attackTarget.worldObj.setBlock(x + 5, y + 0, z + 8, ShinobiMod.blockMagnetRelease );
			attackTarget.worldObj.setBlock(x + 8, y + 0, z + 8, ShinobiMod.blockMagnetRelease );
			attackTarget.worldObj.setBlock(x + 4, y + 0, z + 10, ShinobiMod.blockMagnetRelease );
			attackTarget.worldObj.setBlock(x + 6, y + 0, z + 10, ShinobiMod.blockMagnetRelease );
			attackTarget.worldObj.setBlock(x + 2, y + 1, z + 1, ShinobiMod.blockMagnetRelease );
			attackTarget.worldObj.setBlock(x + 5, y + 1, z + 1, ShinobiMod.blockMagnetRelease );
			attackTarget.worldObj.setBlock(x + 8, y + 1, z + 1, ShinobiMod.blockMagnetRelease );
			attackTarget.worldObj.setBlock(x + 1, y + 1, z + 2, ShinobiMod.blockMagnetRelease );
			attackTarget.worldObj.setBlock(x + 2, y + 1, z + 2, ShinobiMod.blockMagnetRelease );
			attackTarget.worldObj.setBlock(x + 4, y + 1, z + 2, ShinobiMod.blockMagnetRelease );
			attackTarget.worldObj.setBlock(x + 6, y + 1, z + 2, ShinobiMod.blockMagnetRelease );
			attackTarget.worldObj.setBlock(x + 8, y + 1, z + 2, ShinobiMod.blockMagnetRelease );
			attackTarget.worldObj.setBlock(x + 9, y + 1, z + 2, ShinobiMod.blockMagnetRelease );
			attackTarget.worldObj.setBlock(x + 4, y + 1, z + 3, ShinobiMod.blockMagnetRelease );
			attackTarget.worldObj.setBlock(x + 6, y + 1, z + 3, ShinobiMod.blockMagnetRelease );
			attackTarget.worldObj.setBlock(x + 2, y + 1, z + 4, ShinobiMod.blockMagnetRelease );
			attackTarget.worldObj.setBlock(x + 3, y + 1, z + 4, ShinobiMod.blockMagnetRelease );
			attackTarget.worldObj.setBlock(x + 5, y + 1, z + 4, ShinobiMod.blockMagnetRelease );
			attackTarget.worldObj.setBlock(x + 7, y + 1, z + 4, ShinobiMod.blockMagnetRelease );
			attackTarget.worldObj.setBlock(x + 8, y + 1, z + 4, ShinobiMod.blockMagnetRelease );
			attackTarget.worldObj.setBlock(x + 1, y + 1, z + 5, ShinobiMod.blockMagnetRelease );
			attackTarget.worldObj.setBlock(x + 9, y + 1, z + 5, ShinobiMod.blockMagnetRelease );
			attackTarget.worldObj.setBlock(x + 2, y + 1, z + 6, ShinobiMod.blockMagnetRelease );
			attackTarget.worldObj.setBlock(x + 3, y + 1, z + 6, ShinobiMod.blockMagnetRelease );
			attackTarget.worldObj.setBlock(x + 5, y + 1, z + 6, ShinobiMod.blockMagnetRelease );
			attackTarget.worldObj.setBlock(x + 7, y + 1, z + 6, ShinobiMod.blockMagnetRelease );
			attackTarget.worldObj.setBlock(x + 8, y + 1, z + 6, ShinobiMod.blockMagnetRelease );
			attackTarget.worldObj.setBlock(x + 4, y + 1, z + 7, ShinobiMod.blockMagnetRelease );
			attackTarget.worldObj.setBlock(x + 6, y + 1, z + 7, ShinobiMod.blockMagnetRelease );
			attackTarget.worldObj.setBlock(x + 1, y + 1, z + 8, ShinobiMod.blockMagnetRelease );
			attackTarget.worldObj.setBlock(x + 2, y + 1, z + 8, ShinobiMod.blockMagnetRelease );
			attackTarget.worldObj.setBlock(x + 4, y + 1, z + 8, ShinobiMod.blockMagnetRelease );
			attackTarget.worldObj.setBlock(x + 6, y + 1, z + 8, ShinobiMod.blockMagnetRelease );
			attackTarget.worldObj.setBlock(x + 8, y + 1, z + 8, ShinobiMod.blockMagnetRelease );
			attackTarget.worldObj.setBlock(x + 9, y + 1, z + 8, ShinobiMod.blockMagnetRelease );
			attackTarget.worldObj.setBlock(x + 2, y + 1, z + 9, ShinobiMod.blockMagnetRelease );
			attackTarget.worldObj.setBlock(x + 5, y + 1, z + 9, ShinobiMod.blockMagnetRelease );
			attackTarget.worldObj.setBlock(x + 8, y + 1, z + 9, ShinobiMod.blockMagnetRelease );
			attackTarget.worldObj.setBlock(x + 5, y + 2, z + 1, ShinobiMod.blockMagnetRelease );
			attackTarget.worldObj.setBlock(x + 3, y + 2, z + 3, ShinobiMod.blockMagnetRelease );
			attackTarget.worldObj.setBlock(x + 7, y + 2, z + 3, ShinobiMod.blockMagnetRelease );
			attackTarget.worldObj.setBlock(x + 5, y + 2, z + 4, ShinobiMod.blockMagnetRelease );
			attackTarget.worldObj.setBlock(x + 4, y + 2, z + 5, ShinobiMod.blockMagnetRelease );
			attackTarget.worldObj.setBlock(x + 5, y + 2, z + 5, ShinobiMod.blockMagnetRelease );
			attackTarget.worldObj.setBlock(x + 6, y + 2, z + 5, ShinobiMod.blockMagnetRelease );
			attackTarget.worldObj.setBlock(x + 5, y + 2, z + 6, ShinobiMod.blockMagnetRelease );
			attackTarget.worldObj.setBlock(x + 3, y + 2, z + 7, ShinobiMod.blockMagnetRelease );
			attackTarget.worldObj.setBlock(x + 7, y + 2, z + 7, ShinobiMod.blockMagnetRelease );
			attackTarget.worldObj.setBlock(x + 5, y + 2, z + 9, ShinobiMod.blockMagnetRelease );
			attackTarget.worldObj.setBlock(x + 2, y + 3, z + 2, ShinobiMod.blockMagnetRelease );
			attackTarget.worldObj.setBlock(x + 8, y + 3, z + 2, ShinobiMod.blockMagnetRelease );
			attackTarget.worldObj.setBlock(x + 5, y + 3, z + 3, ShinobiMod.blockMagnetRelease );
			attackTarget.worldObj.setBlock(x + 3, y + 3, z + 5, ShinobiMod.blockMagnetRelease );
			attackTarget.worldObj.setBlock(x + 7, y + 3, z + 5, ShinobiMod.blockMagnetRelease );
			attackTarget.worldObj.setBlock(x + 5, y + 3, z + 7, ShinobiMod.blockMagnetRelease );
			attackTarget.worldObj.setBlock(x + 2, y + 3, z + 8, ShinobiMod.blockMagnetRelease );
			attackTarget.worldObj.setBlock(x + 8, y + 3, z + 8, ShinobiMod.blockMagnetRelease );
		*/
        	break; 
        		
        		default:
        			break;
            
            
            
        	}
        }
        if(entity.getAnimTick() > 10)
			entity.setAnimID(0);
        
        
        
    }
    
    
   

}
