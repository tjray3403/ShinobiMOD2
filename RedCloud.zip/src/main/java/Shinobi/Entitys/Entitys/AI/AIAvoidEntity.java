package Shinobi.Entitys.Entitys.AI;

public class AIAvoidEntity {

}
