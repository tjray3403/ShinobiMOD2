package Shinobi.Entitys.Entitys.AI;

import Shinobi.Entitys.Entitys.EntityDeidara;
import Shinobi.Entitys.Projectiles.EntityC4;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityList;
import net.minecraft.entity.EntityLiving;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.util.MathHelper;
import thehippomasterAPI.AnimationAPI.AIAnimation;

public class AIC4 extends AIAnimation {

    private EntityDeidara entity;
    private EntityLivingBase attackTarget;
   // int cooldown = 75;

    public AIC4(EntityDeidara third)
    {
        super(third);
        entity = third;
        attackTarget = null;
    }

    public int getAnimID()
    {
        return 2;
    }

    public boolean isAutomatic()
    {
        return false;
    }

    public int getDuration()
    {
        return 20;
    }
    
    public boolean shouldAnimate(){
		if(entity.C4==30)return true;
		return false;
		
	}

    public void startExecuting()
    {
        super.startExecuting();
        attackTarget = entity.getAttackTarget();
    }
    
    

    public void updateTask()
    {
        if(entity.getAnimTick() < 10 && attackTarget != null)
            entity.getLookHelper().setLookPositionWithEntity(attackTarget, 20F,20F);
        if(entity.getAnimTick() == 5 && attackTarget != null)
        {
        	if (!entity.worldObj.isRemote) {
				Entity sentity = EntityList.createEntityByName("34C4", entity.worldObj);
				if (sentity != null) {
					sentity.setLocationAndAngles(entity.posX, entity.posY, entity.posZ, entity.worldObj.rand.nextFloat() * 360F, 0.0F);
					entity.worldObj.spawnEntityInWorld(sentity);
				}
			} 
        }
        if(entity.getAnimTick() > 10)
			entity.setAnimID(0);
        
        
        
    }
    
   

}
