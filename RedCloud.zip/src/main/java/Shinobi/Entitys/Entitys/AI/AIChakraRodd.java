package Shinobi.Entitys.Entitys.AI;

import java.util.Random;

import Shinobi.Entitys.EntityNinja;
import Shinobi.Entitys.Entitys.EntityKakuzu3;
import Shinobi.Entitys.Entitys.EntityPainAsura;
import Shinobi.Entitys.Projectiles.EntityAsuraHand;
import Shinobi.Entitys.Projectiles.EntityChakraRod;
import Shinobi.Entitys.Projectiles.EntityFireBlast;
import Shinobi.Entitys.Projectiles.EntityRinneBullet;
import Shinobi.Entitys.Projectiles.EntityWindBlast;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.util.MathHelper;
import thehippomasterAPI.AnimationAPI.AIAnimation;

public class AIChakraRodd extends AIAnimation {

    private EntityNinja entity;
    private EntityLivingBase attackTarget;

    public AIChakraRodd(EntityNinja ef)
    {
        super(ef);
        entity = ef;
        attackTarget = null;
    }


	public int getAnimID()
    {
        return 10;
    }

    public boolean isAutomatic()
    {
        return false;
    }

    public int getDuration()
    {
        return 40;
    }

    
    public boolean shouldAnimate() {
    	EntityLivingBase AITarget = entity.getAttackTarget();
		if (AITarget == null || AITarget.isDead) return false;
		if(entity.getDistanceSqToEntity(AITarget)<4)return false;
		if(entity.getDistanceSqToEntity(AITarget)>10)return false;
		return true;
    	
    }

    public void startExecuting()
    {
        super.startExecuting();
        attackTarget = entity.getAttackTarget();
    }

    public void updateTask()
    {
        if(entity.getAnimTick() < 10 && attackTarget != null)
            entity.getLookHelper().setLookPositionWithEntity(attackTarget, 20F,20F);
        if(entity.getAnimTick() < 10 && attackTarget != null) {
            EntityChakraRod efb = new EntityChakraRod(entity.worldObj, entity, 0.7F);
            double d0 = attackTarget.posX - entity.posX;
            double d1 = attackTarget.posY + (double)attackTarget.getEyeHeight() - 1.100000023841858D - efb.posY;
            double d2 = attackTarget.posZ - entity.posZ;
            float f1 = MathHelper.sqrt_double(d0 * d0 + d2 * d2) * 0.2F;
            efb.setHeading(d0, d1 + (double)f1, d2, 1.6F, 12.0F);
            entity.worldObj.spawnEntityInWorld(efb);
            	
            }
        
        
    
    }

}
