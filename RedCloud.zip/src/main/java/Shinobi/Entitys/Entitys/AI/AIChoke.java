package Shinobi.Entitys.Entitys.AI;

import java.util.List;

import Shinobi.Entitys.Entitys.EntityKakuzu3;
import Shinobi.Entitys.Entitys.EntityPainAsura;
import Shinobi.Entitys.Entitys.EntityPainNaraka;
import Shinobi.Entitys.Entitys.EntitySMKoH;
import Shinobi.Entitys.Projectiles.EntityAsuraHand;
import Shinobi.Entitys.Projectiles.EntityFireBlast;
import Shinobi.Entitys.Projectiles.EntityRinneBullet;
import Shinobi.Entitys.Projectiles.EntityWindBlast;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityList;
import net.minecraft.entity.EntityLiving;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.potion.Potion;
import net.minecraft.potion.PotionEffect;
import net.minecraft.util.DamageSource;
import net.minecraft.util.MathHelper;
import thehippomasterAPI.AnimationAPI.AIAnimation;

public class AIChoke extends AIAnimation {

    private EntityPainNaraka entity;
    private EntityLivingBase attackTarget;

    public AIChoke(EntityPainNaraka ef)
    {
        super(ef);
        entity = ef;
        attackTarget = null;
    }

   

	public int getAnimID()
    {
        return 7;
    }

    public boolean isAutomatic()
    {
        return false;
    }

    public int getDuration()
    {
        return 90;
    }

    
    public boolean shouldAnimate() {
    	EntityLivingBase AITarget = entity.getAttackTarget();
		if (AITarget == null || AITarget.isDead) return false;
    	if(entity.getDistanceSqToEntity(AITarget)>2)return false;
    	
		return true;
    	
    }

    public void startExecuting()
    {
        super.startExecuting();
        attackTarget = entity.getAttackTarget();
    }

    public void updateTask()
    {
        if(entity.getAnimTick() < 10 && attackTarget != null)
            entity.getLookHelper().setLookPositionWithEntity(attackTarget, 20F,20F);
        
        if(entity.getAnimTick() > 2 && attackTarget != null) {
        	attackTarget.addPotionEffect(new PotionEffect(2, 2, 10));

        }
        
        if(entity.getAnimTick() == 20 && attackTarget != null) {
        	attackTarget.attackEntityFrom(DamageSource.generic, 10);
        }
        if(entity.getAnimTick() == 40 && attackTarget != null) {
        	attackTarget.attackEntityFrom(DamageSource.generic, 10);
        }
        if(entity.getAnimTick() == 60 && attackTarget != null) {
        	attackTarget.attackEntityFrom(DamageSource.generic, 10);
        }
        if(entity.getAnimTick() == 80 && attackTarget != null) {
        	attackTarget.attackEntityFrom(DamageSource.generic, 10);
        }
        
        double offsetX = Math.cos(entity.rotationYaw) * 2;
		double offsetZ = Math.sin(entity.rotationYaw) * 2;
		List<EntityLivingBase> Entities = entity.worldObj.getEntitiesWithinAABB(EntitySMKoH.class, entity.boundingBox.getOffsetBoundingBox(offsetX, 0, offsetZ).expand(5, 5, 5));
		for (EntityLivingBase ent : Entities){
			if (ent == entity) continue;
			
       /// if(entity.getAnimTick() == 89 && attackTarget != null) {
        //	ent.setDead();
       /// 	}
        	
        }
        
        
    
    }

}
