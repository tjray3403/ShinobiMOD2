package Shinobi.Entitys.Entitys.AI;

import Shinobi.Entitys.EntityDeathPos;
import Shinobi.Entitys.Entitys.EntityHidan;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.ai.EntityAIBase;
import net.minecraft.util.DamageSource;

public class AIDeathpos extends EntityAIBase {

	private int cooldown = 30;
	private EntityHidan entityH;
    private EntityDeathPos ent;
    private EntityLivingBase elb;

	public AIDeathpos(EntityHidan eh) {
		entityH = eh;
	}

	@Override
	public boolean shouldExecute() {
		EntityDeathPos edp = ent;
		if(!entityH.cursed==true)return false;
		return cooldown -- >0;
	}
	
	public void resetTask() {
		cooldown = 30;
	}
	
	public void startExecuting() {
		EntityLivingBase elbb = entityH.getAttackTarget();
		if (entityH.cursed==true)	{
        elbb.attackEntityFrom(DamageSource.causeMobDamage(entityH), 30);
	}

}
}