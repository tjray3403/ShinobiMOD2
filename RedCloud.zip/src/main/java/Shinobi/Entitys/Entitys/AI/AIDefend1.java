package Shinobi.Entitys.Entitys.AI;

import Shinobi.Entitys.Entitys.EntityShadowClone;
import Shinobi.Entitys.Entitys.EntitySusanoo;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.ai.EntityAITarget;

public class AIDefend1 extends EntityAITarget {
    EntitySusanoo theDefendingClone;
    EntityLivingBase theOwnerAttacker;
    private int field_142051_e;

    public AIDefend1(EntitySusanoo par1Entity) {
        super(par1Entity, false);
        this.theDefendingClone = par1Entity;
        this.setMutexBits(1);
    }

    /**
     * Returns whether the EntityAIBase should begin execution.
     */
    public boolean shouldExecute() {
        EntityLivingBase entitylivingbase = this.theDefendingClone.func_130012_q();

        if (entitylivingbase == null) {
            return false;
        } else {
            this.theOwnerAttacker = entitylivingbase.getAITarget();
            int i = entitylivingbase.func_142015_aE();
            return i != this.field_142051_e && this.isSuitableTarget(this.theOwnerAttacker, false);
        }
    }

    /**
     * Execute a one shot task or start executing a continuous task
     */
    public void startExecuting() {
        this.taskOwner.setAttackTarget(this.theOwnerAttacker);
        EntityLivingBase entitylivingbase = this.theDefendingClone.func_130012_q();

        if (entitylivingbase != null) {
            this.field_142051_e = entitylivingbase.func_142015_aE();
        }

        super.startExecuting();
    }
}