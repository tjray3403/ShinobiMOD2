package Shinobi.Entitys.Entitys.AI;

import Shinobi.Entitys.EntityUtil;
import Shinobi.Entitys.Entitys.EntityFire;
import Shinobi.Entitys.Entitys.EntityKakuzu;
import Shinobi.Entitys.Entitys.EntityLightning;
import Shinobi.Entitys.Entitys.EntityWater;
import Shinobi.Entitys.Entitys.EntityWind;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityCreature;
import net.minecraft.entity.EntityList;
import net.minecraft.entity.EntityLiving;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.util.Vec3;
import thehippomasterAPI.AnimationAPI.AIAnimation;

public class AIEarthGrudgeFear extends AIAnimation {
	
	private EntityKakuzu entityKakuzu;
	private EntityLivingBase attackTarget;
	private int counter = 20;
	private boolean hasUsed;
	
	public AIEarthGrudgeFear(EntityKakuzu Kakuzu) {
		super(Kakuzu);
		entityKakuzu = Kakuzu;
		attackTarget = null;
	}
	
	

	public int getAnimID() {
		return 3;
	}
	
	public boolean isAutomatic() {
		return true;
	}
	
	public int getDuration() {
		return 30;
	}
	
	public void startExecuting(){
		super.startExecuting();
		
	}
	
	
	
	public void updateTask() {
		attackTarget = entityKakuzu.getAttackTarget();
		counter++;
		Vec3 vec = entityKakuzu.getLookVec();
		//if(entityKakuzu.getAnimTick() < 14)
			//entityKakuzu.getLookHelper().setLookPositionWithEntity(attackTarget, 30F, 30F);
		if(entityKakuzu.getAnimTick() == 2)
			if (!entityKakuzu.worldObj.isRemote) {
				EntityWind entity1 = new EntityWind(entityKakuzu.worldObj);
					entity1.setLocationAndAngles(entityKakuzu.posX, entityKakuzu.posY, entityKakuzu.posZ, entityKakuzu.worldObj.rand.nextFloat() * 360F, 0.0F);
					entityKakuzu.worldObj.spawnEntityInWorld(entity1);
					((EntityLiving) entity1).playLivingSound();
				EntityFire entity2 = new EntityFire(entityKakuzu.worldObj);
					entity2.setLocationAndAngles(entityKakuzu.posX, entityKakuzu.posY, entityKakuzu.posZ, entityKakuzu.worldObj.rand.nextFloat() * 360F, 0.0F);
					entityKakuzu.worldObj.spawnEntityInWorld(entity2);
					((EntityLiving) entity2).playLivingSound();
				EntityWater entity3 = new EntityWater(entityKakuzu.worldObj);
					entity3.setLocationAndAngles(entityKakuzu.posX, entityKakuzu.posY, entityKakuzu.posZ, entityKakuzu.worldObj.rand.nextFloat() * 360F, 0.0F);
					entityKakuzu.worldObj.spawnEntityInWorld(entity3);
					((EntityLiving) entity3).playLivingSound();
				EntityLightning sentity = new EntityLightning(entityKakuzu.worldObj);
					sentity.setLocationAndAngles(entityKakuzu.posX, entityKakuzu.posY, entityKakuzu.posZ, entityKakuzu.worldObj.rand.nextFloat() * 360F, 0.0F);
					entityKakuzu.worldObj.spawnEntityInWorld(sentity);
					((EntityLiving) sentity).playLivingSound();
				
					
				
				
			} 
		
			//entityKakuzu.worldObj.createExplosion((Entity)null, attackTarget.posX, attackTarget.posY, attackTarget.posZ, .1F, true);
	}
	
	
	
}
