package Shinobi.Entitys.Entitys.AI;

import java.util.List;
import java.util.Random;

import Shinobi.ShinobiMod;
import Shinobi.Entitys.EntityNinja;
import Shinobi.Entitys.EntityUtil;
import Shinobi.Entitys.Entitys.Entity3rdKazekagePuppet;
import Shinobi.Entitys.Entitys.EntityDeidara;
import Shinobi.Entitys.Entitys.EntitySasoriHiruko;
import Shinobi.Entitys.Projectiles.EntityFireBlast;
import Shinobi.Entitys.Projectiles.EntityMagnetCube;
import Shinobi.Entitys.Projectiles.EntityMagnetSpread;
import Shinobi.Entitys.Projectiles.EntityMagnetTriangle;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityCreature;
import net.minecraft.entity.EntityList;
import net.minecraft.entity.EntityLiving;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.ai.EntityAIBase;
import net.minecraft.util.MathHelper;
import thehippomasterAPI.AnimationAPI.AIAnimation;

public class AIEntityTarget extends EntityAIBase {

    private EntityCreature entity;

    public AIEntityTarget(EntityCreature et)
    {
        super();
        entity = et;
        
    }

    
   
    
	@Override
	public boolean shouldExecute() {
		if(entity.getAttackTarget() == null) return true;
			
		return false;
	}
    
    public void startExecuting()
    {
        super.startExecuting();
        EntityDeidara deidara = new EntityDeidara(entity.worldObj);
		double offsetX = Math.cos(entity.rotationYaw) * 2;
		double offsetZ = Math.sin(entity.rotationYaw) * 2;
		List<EntityLivingBase> Entities = entity.worldObj.getEntitiesWithinAABB(EntityDeidara.class, entity.boundingBox.getOffsetBoundingBox(offsetX, 0, offsetZ).expand(10, 10, 10));
		for (EntityLivingBase ent : Entities){
			if (ent == entity) continue;
        entity.setAttackTarget(((EntityLiving) ent).getAttackTarget());
		}
		
    }
        
    }


