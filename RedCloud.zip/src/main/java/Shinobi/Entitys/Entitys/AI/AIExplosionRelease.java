package Shinobi.Entitys.Entitys.AI;

import java.util.Random;

import Shinobi.ShinobiMod;
import Shinobi.Entitys.EntityNinja;
import Shinobi.Entitys.EntityUtil;
import Shinobi.Entitys.Entitys.Entity3rdKazekagePuppet;
import Shinobi.Entitys.Entitys.EntityDeidara;
import Shinobi.Entitys.Entitys.EntitySasoriHiruko;
import Shinobi.Entitys.Projectiles.EntityC2;
import Shinobi.Entitys.Projectiles.EntityFireBlast;
import Shinobi.Entitys.Projectiles.EntityMagnetCube;
import Shinobi.Entitys.Projectiles.EntityMagnetSpread;
import Shinobi.Entitys.Projectiles.EntityMagnetTriangle;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityCreature;
import net.minecraft.entity.EntityList;
import net.minecraft.entity.EntityLiving;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.util.MathHelper;
import thehippomasterAPI.AnimationAPI.AIAnimation;

public class AIExplosionRelease extends AIAnimation {

    private EntityDeidara entity;
    private EntityLivingBase attackTarget;

    public AIExplosionRelease(EntityDeidara et)
    {
        super(et);
        entity = et;
        attackTarget = null;
        
    }

    public int getAnimID()
    {
        return 1;
    }

    public boolean isAutomatic()
    {
        return false;
    }

    public int getDuration()
    {
        return 60;
    }
    
    public boolean shouldAnimate(){
		EntityLivingBase AITarget = entity.getAttackTarget();
		if (AITarget == null || AITarget.isDead) return false;
		if(entity.getHealth() < 35D) return false;
		
		
		return true;
		
	}

    public void startExecuting()
    {
        super.startExecuting();
        attackTarget = entity.getAttackTarget();
        Random rand = new Random();
        int	x = (int) entity.posX;
    	int	y = (int) entity.posY;
    	int	z = (int) entity.posZ;
        int e = rand.nextInt(2);
        
        switch(rand.nextInt(3))
    	{
    	case 0:
    		if (!entity.worldObj.isRemote) {
    			Entity entity1 = EntityList.createEntityByName("34ClayBird", entity.worldObj);
    				if (entity1 != null) {
    				entity1.setLocationAndAngles(x, y, z, entity1.worldObj.rand.nextFloat() * 360F, 0.0F);
    				entity1.worldObj.spawnEntityInWorld(entity1);
    				
    			}
        	}
    	break;
    	
    	case 1:
    	if (!entity.worldObj.isRemote) {
			Entity sentity = EntityList.createEntityByName("34ClaySpider", entity.worldObj);
			if (sentity != null) {
				sentity.setLocationAndAngles(x, y, z, entity.worldObj.rand.nextFloat() * 360F, 0.0F);
				entity.worldObj.spawnEntityInWorld(sentity);
				EntityUtil.setOwner((EntityLivingBase) sentity, entity);
				EntityUtil.makeSummon_MonsterFaction((EntityCreature) sentity, false);
				
			}
    	}
    	break;
    	
    	
    	default:
    		break;
    	
    	}
    }
    
    

   
    public void resetTask() {
    	super.resetTask();
    //	this.cooldown = 45;
    }
    
   

}
