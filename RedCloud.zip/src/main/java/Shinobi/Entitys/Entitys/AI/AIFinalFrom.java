package Shinobi.Entitys.Entitys.AI;

import Shinobi.Entitys.Entitys.EntityKakuzu3;
import Shinobi.Entitys.Projectiles.EntityFireBlast;
import Shinobi.Entitys.Projectiles.EntityWindBlast;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.util.MathHelper;
import thehippomasterAPI.AnimationAPI.AIAnimation;

public class AIFinalFrom extends AIAnimation {

    private EntityKakuzu3 entity;
    private EntityLivingBase attackTarget;

    public AIFinalFrom(EntityKakuzu3 ef)
    {
        super(ef);
        entity = ef;
        attackTarget = null;
    }

    public int getAnimID()
    {
        return 1;
    }

    public boolean isAutomatic()
    {
        return true;
    }

    public int getDuration()
    {
        return 20;
    }

    public boolean continueExecuting()
    {
        return entity.getAnimTick() > 20 ? false : super.continueExecuting();
    }

    public void startExecuting()
    {
        super.startExecuting();
        attackTarget = entity.getAttackTarget();
    }

    public void updateTask()
    {
        if(entity.getAnimTick() < 20 && attackTarget != null)
            entity.getLookHelper().setLookPositionWithEntity(attackTarget, 20F,20F);
        if(entity.getAnimTick() == 1 && attackTarget != null) {
            EntityFireBlast efb = new EntityFireBlast(entity.worldObj, entity);
            double d0 = attackTarget.posX - entity.posX;
            double d1 = attackTarget.posY + (double)attackTarget.getEyeHeight() - 1.100000023841858D - efb.posY;
            double d2 = attackTarget.posZ - entity.posZ;
            float f1 = MathHelper.sqrt_double(d0 * d0 + d2 * d2) * 0.2F;
            efb.setThrowableHeading(d0, d1 + (double)f1, d2, 1.6F, 12.0F);
            entity.worldObj.spawnEntityInWorld(efb);
            	
            }
        
        if(entity.getAnimTick() == 19 && attackTarget != null){
            EntityWindBlast ewb = new EntityWindBlast(entity.worldObj, entity);
            double w0 = attackTarget.posX - entity.posX;
            double w1 = attackTarget.posY + (double)attackTarget.getEyeHeight() - 1.100000023841858D - ewb.posY;
            double w2 = attackTarget.posZ - entity.posZ;
            float e1 = MathHelper.sqrt_double(w0 * w0 + w2 * w2) * 0.2F;
            ewb.setThrowableHeading(w0, w1 + (double)e1, w2, 1.6F, 12.0F);
            entity.worldObj.spawnEntityInWorld(ewb);
        }
        if(entity.getAnimTick() > 20)
			entity.setAnimID(0);
    
    }

}
