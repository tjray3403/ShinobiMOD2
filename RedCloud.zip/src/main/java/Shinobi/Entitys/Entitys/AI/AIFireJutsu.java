package Shinobi.Entitys.Entitys.AI;

import Shinobi.Entitys.Entitys.EntityPainAsura;
import Shinobi.Entitys.Entitys.EntityTobi;
import Shinobi.Entitys.Projectiles.EntityFireBlast;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.util.MathHelper;
import thehippomasterAPI.AnimationAPI.AIAnimation;

public class AIFireJutsu extends AIAnimation {

    private EntityTobi entity;
    private EntityLivingBase attackTarget;

    public AIFireJutsu(EntityTobi ef)
    {
        super(ef);
        entity = ef;
        attackTarget = null;
    }


	public int getAnimID()
    {
        return 1;
    }

    public boolean isAutomatic()
    {
        return false;
    }

    public int getDuration()
    {
        return 40;
    }

    
    public boolean shouldAnimate() {
    	EntityLivingBase AITarget = entity.getAttackTarget();
		if (AITarget == null || AITarget.isDead) return false;
    	if(entity.attack!=1)return false;
    	if(entity.getkamuiMode()==true)return false;
		return true;
    	
    }

    public void startExecuting()
    {
        super.startExecuting();
        attackTarget = entity.getAttackTarget();
    }

    public void updateTask()
    {
        if(entity.getAnimTick() < 10 && attackTarget != null)
            entity.getLookHelper().setLookPositionWithEntity(attackTarget, 20F,20F);
        if(entity.getAnimTick() > 35 && attackTarget != null && entity.getkamuiMode()==false) {
            EntityFireBlast efb = new EntityFireBlast(entity.worldObj, entity);
            double d0 = attackTarget.posX - entity.posX;
            double d1 = attackTarget.posY + (double)attackTarget.getEyeHeight() - 1.100000023841858D - efb.posY;
            double d2 = attackTarget.posZ - entity.posZ;
            float f1 = MathHelper.sqrt_double(d0 * d0 + d2 * d2) * 0.2F;
            efb.setThrowableHeading(d0, d1 + (double)f1, d2, 1.6F, 12.0F);
            entity.worldObj.spawnEntityInWorld(efb);
            	
            }
        
        
    
    }

}
