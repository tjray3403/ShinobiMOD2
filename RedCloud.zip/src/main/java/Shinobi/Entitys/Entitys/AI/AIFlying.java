package Shinobi.Entitys.Entitys.AI;

import java.util.Random;

import Shinobi.Entitys.EntityDeathPos;
import Shinobi.Entitys.EntityFlyingNinja;
import Shinobi.Entitys.Entitys.EntityHidan;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.ai.EntityAIBase;
import net.minecraft.util.AxisAlignedBB;
import net.minecraft.util.DamageSource;
import net.minecraft.util.MathHelper;

public class AIFlying extends EntityAIBase {

	 //public int courseChangeCooldown;
	 
	private Entity targetedEntity;

	private EntityFlyingNinja entity;
	private Random rand;

	private double waypointY;

	private double waypointZ;

	private double waypointX;

	private int courseChangeCooldown;
     
     
	public AIFlying(EntityFlyingNinja eh) {
		entity = eh;
	}

	@Override
	public boolean shouldExecute() {
		return false;
		
	}
	
	public void resetTask() {
	}
	public void startExecuting(){
		targetedEntity = entity.getAttackTarget();
		
		
	}
	public void updateTask() {
		double d0 = waypointX - entity.posX;
        double d1 = waypointY - entity.posY;
        double d2 = waypointZ - entity.posZ;
        double d3 = d0 * d0 + d1 * d1 + d2 * d2;

        if (d3 < 1.0D || d3 > 3600.0D)
        {
            waypointX = entity.posX + (double)((rand.nextFloat() * 2.0F - 1.0F) * 16.0F);
            waypointY = entity.posY + (double)((rand.nextFloat() * 2.0F - 1.0F) * 16.0F);
            waypointZ = entity.posZ + (double)((rand.nextFloat() * 2.0F - 1.0F) * 16.0F);
        }

        if (courseChangeCooldown-- <= 0)
        {
            courseChangeCooldown += rand.nextInt(5) + 2;
            d3 = (double)MathHelper.sqrt_double(d3);

            if (this.isCourseTraversable(waypointX, waypointY, waypointZ, d3))
            {
                entity.motionX += d0 / d3 * 0.1D;
                entity.motionY += d1 / d3 * 0.1D;
                entity.motionZ += d2 / d3 * 0.1D;
            }
            else
            {
                waypointX = entity.posX;
                waypointY = entity.posY;
                waypointZ = entity.posZ;
            }
        }

        

        double d4 = 64.0D;

        if (targetedEntity != null && targetedEntity.getDistanceSqToEntity(entity) < d4 * d4)
        {
            double d5 = targetedEntity.posX - entity.posX;
            double d6 = targetedEntity.boundingBox.minY + (double)(targetedEntity.height / 2.0F) - (entity.posY + (double)(entity.height / 2.0F));
            double d7 = targetedEntity.posZ - entity.posZ;
            entity.renderYawOffset = entity.rotationYaw = -((float)Math.atan2(d5, d7)) * 180.0F / (float)Math.PI;

            
            entity.renderYawOffset = entity.rotationYaw = -((float)Math.atan2(entity.motionX, entity.motionZ)) * 180.0F / (float)Math.PI;

            
        }
	}

	private boolean isCourseTraversable(double p_70790_1_, double p_70790_3_, double p_70790_5_, double p_70790_7_)
    {
        double d4 = (waypointX - entity.posX) / p_70790_7_;
        double d5 = (waypointY - entity.posY) / p_70790_7_;
        double d6 = (waypointZ - entity.posZ) / p_70790_7_;
        AxisAlignedBB axisalignedbb = entity.boundingBox.copy();

        for (int i = 1; (double)i < p_70790_7_; ++i)
        {
            axisalignedbb.offset(d4, d5, d6);

            if (!entity.worldObj.getCollidingBoundingBoxes(entity, axisalignedbb).isEmpty())
            {
                return false;
            }
        }

        return true;
    }
	
	


}