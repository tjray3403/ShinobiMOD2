package Shinobi.Entitys.Entitys.AI;

import java.util.Iterator;
import java.util.List;

import Shinobi.Entitys.EntityDeathPos;
import Shinobi.Entitys.Entitys.EntityHidan;
import Shinobi.Entitys.Entitys.EntitySasori;
import net.minecraft.entity.EntityCreature;
import net.minecraft.entity.EntityLiving;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.ai.EntityAIBase;

public class AIFollowEntity extends EntityAIBase {
	
	private EntitySasori entity;
	private EntityCreature host;
	 double speed;
	public AIFollowEntity(EntityCreature eh, double spd)
    {
		host = eh;
		speed = spd;
		this.setMutexBits(1);
    }

	@Override
	public boolean shouldExecute() {
		List list = this.host.worldObj.getEntitiesWithinAABB(EntitySasori.class, this.host.boundingBox.expand(15.0D, 10.0D, 15.0D));
		if(host.getAttackTarget()!=null)return false;
        if (list.isEmpty())
        {
            return false;
        }
        else
        {
            Iterator iterator = list.iterator();

            while (iterator.hasNext())
            {
                EntityLivingBase entt = (EntityLivingBase)iterator.next();

                
                    this.entity = (EntitySasori) entt;
                    break;
                
            }

            return this.entity != null;
        }
    }
	
	public void startExecuting()
    {
        ((EntityLiving) this.entity).getNavigator().clearPathEntity();
    }
	
	public void resetTask()
    {
        this.entity = null;
        this.host.getNavigator().clearPathEntity();
    }
	
	public void updateTask()
    {
        this.host.getLookHelper().setLookPositionWithEntity(this.entity, 30.0F, 30.0F);
        
            this.host.getNavigator().tryMoveToEntityLiving(this.entity, this.speed);
	
    }
            
            
	}
	


