package Shinobi.Entitys.Entitys.AI;

import Shinobi.Entitys.Entitys.EntityHidan;
import Shinobi.Entitys.Entitys.EntitySasoriHiruko;
import net.minecraft.entity.EntityLivingBase;
import thehippomasterAPI.AnimationAPI.AIAnimation;

public class AIHirukoBlock1 extends AIAnimation
{
    private EntitySasoriHiruko entity;
    private EntityLivingBase attackTarget;

    public AIHirukoBlock1(EntitySasoriHiruko jen)
    {
        super(jen);
        entity = jen;
        attackTarget = null;
    }

    public int getAnimID()
    {
        return 4;
    }

    public boolean isAutomatic()
    {
        return false;
    }

    public int getDuration()
    {
        return 15;
    }

    @Override
    public boolean shouldExecute() {
		
		EntitySasoriHiruko eht = getEntity();
		if(eht.func!=2)return false;
       return entity.getAnimID()==0;
		
	
	}

    public void startExecuting()
    {
        super.startExecuting();
        attackTarget = entity.getAttackTarget();
    }

    public void updateTask()
    {
        if(entity.getAnimTick() < 15 && attackTarget != null)
            entity.getLookHelper().setLookPositionWithEntity(attackTarget, 10F,10F);
        {
             entity.setAbsorptionAmount(12);
        }
         if(entity.getAnimTick() == 15)
        {
            entity.setAbsorptionAmount(0);;
        }
        if(entity.getAnimTick() > 15)
            entity.setAnimID(7);
    }

}