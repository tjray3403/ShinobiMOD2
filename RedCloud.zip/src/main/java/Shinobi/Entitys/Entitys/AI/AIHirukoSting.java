package Shinobi.Entitys.Entitys.AI;

import java.util.List;

import Shinobi.ShinobiMod;
import Shinobi.Entitys.Entitys.EntityKakuzu;
import Shinobi.Entitys.Entitys.EntitySasoriHiruko;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.potion.PotionEffect;
import net.minecraft.util.DamageSource;
import net.minecraft.util.Vec3;
import thehippomasterAPI.AnimationAPI.AIAnimation;

public class AIHirukoSting extends AIAnimation {
	
	private EntitySasoriHiruko entityHir;
	private EntityLivingBase attackTarget;
	private double speed;
	
	public AIHirukoSting(EntitySasoriHiruko hiruko, float spd) {
		super(hiruko);
		entityHir = hiruko;
		attackTarget = null;
		speed = spd;
	}
	
	

	public int getAnimID() {
		return 5;
	}
	
	public int getDuration() {
		return 30;
	}
	
	public void startExecuting() {
		super.startExecuting();
		attackTarget = entityHir.getAttackTarget();
		entityHir.getNavigator().clearPathEntity();
	}
	
	
	public boolean shouldAnimate(){
		EntityLivingBase AITarget = entityHir.getAttackTarget();
		if (AITarget == null || AITarget.isDead) return false;
		if (AITarget != null && entityHir.getDistanceSqToEntity(AITarget) > 5D){
				return false;
		}
		return entityHir.getAnimID() == 0;
		
	}
	
	
	public void updateTask() {
	//	double d0 = entityHir.getDistanceSq(attackTarget.posX, attackTarget.boundingBox.minY, attackTarget.posZ);
		//double d1 = (double)(this.entityHir.width * 2.0F * this.entityHir.width * 2.0F + attackTarget.width);
			entityHir.getLookHelper().setLookPositionWithEntity(attackTarget, 30F, 30F);
			entityHir.getNavigator().tryMoveToEntityLiving(attackTarget, speed);
		if(entityHir.getAnimTick() == 7 && attackTarget != null){

		double offsetX = Math.cos(entityHir.rotationYaw) * 2;
		double offsetZ = Math.sin(entityHir.rotationYaw) * 2;;
		List<EntityLivingBase> Entities = entityHir.worldObj.getEntitiesWithinAABB(EntityLivingBase.class, entityHir.boundingBox.getOffsetBoundingBox(offsetX, 0, offsetZ).expand(2.7, 2, 2.7));
		for (EntityLivingBase ent : Entities){
			if (ent == entityHir) continue;
			ent.attackEntityFrom(DamageSource.causeMobDamage(entityHir), 35);
			ent.addPotionEffect(new PotionEffect(ShinobiMod.SPoison.id, 200, 3));
		}
		}
		
		

	}

	@Override
	public boolean isAutomatic() {
		// TODO Auto-generated method stub
		return false;
	}



	
}