package Shinobi.Entitys.Entitys.AI;

import Shinobi.Entitys.Entitys.EntityKakuzu2;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.util.DamageSource;
import thehippomasterAPI.AnimationAPI.AIAnimation;

public class AIKPunch extends AIAnimation {
	
	private EntityKakuzu2 entityKakuzu2;
	private EntityLivingBase attackTarget;
	
	public AIKPunch(EntityKakuzu2 Kakuzu2) {
		super(Kakuzu2);
		entityKakuzu2 = Kakuzu2;
		attackTarget = null;
	}
	
	

	public int getAnimID() {
		return 1;
	}
	
	public boolean isAutomatic() {
		return true;
	}
	
	public int getDuration() {
		return 30;
	}
	
	public void startExecuting() {
		super.startExecuting();
		attackTarget = entityKakuzu2.getAttackTarget();
	}
	
	public void updateTask() {
		if(entityKakuzu2.getAnimTick() < 14)
			entityKakuzu2.getLookHelper().setLookPositionWithEntity(attackTarget, 30F, 30F);
		if(entityKakuzu2.getAnimTick() == 14 && attackTarget != null)
			attackTarget.attackEntityFrom(DamageSource.causeMobDamage(entityKakuzu2), 25);
		
	}
}
