package Shinobi.Entitys.Entitys.AI;

import java.util.List;

import Shinobi.Entitys.EntityEarthGrudgeFear;
import Shinobi.Entitys.Entitys.EntityKakuzu;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.util.DamageSource;
import net.minecraft.world.World;
import thehippomasterAPI.AnimationAPI.AIAnimation;

public class AIKakuzuSmash extends AIAnimation
{
    private EntityKakuzu entity;
    private EntityLivingBase attackTarget;
	private World world;

    public AIKakuzuSmash(EntityKakuzu jen)
    {
        super(jen);
        entity = jen;
        attackTarget = null;
        
    }

    public int getAnimID()
    {
        return 1;
    }

    public boolean isAutomatic()
    {
        return false;
    }

    public int getDuration()
    {
        return 30;
    }

    @Override
    public boolean shouldAnimate(){
		EntityLivingBase AITarget = entity.getAttackTarget();
		EntityKakuzu enty = this.getEntity();
		if (AITarget == null || AITarget.isDead) return false;
		if(enty.getDistanceToEntity(AITarget) > 5D)return false;
		if (entity.getcount()!=1){
				return false;
		}
		 return entity.getAnimID() == 0;
		
	}
    
    

    
    
    public void updateTask() {
    	attackTarget = entity.getAttackTarget();
        if(entity.getAnimTick() > 30 && attackTarget != null)
            entity.getLookHelper().setLookPositionWithEntity(attackTarget, 10F,10F);
        if((entity.getAnimTick() == 10 || entity.getAnimTick() == 15) && attackTarget != null) {
        	double offsetX = Math.cos(entity.rotationYaw) * 2;
    		double offsetZ = Math.sin(entity.rotationYaw) * 2;;
    		List<EntityLivingBase> Entities = entity.worldObj.getEntitiesWithinAABB(EntityLivingBase.class, entity.boundingBox.getOffsetBoundingBox(offsetX, 0, offsetZ).expand(7.0, 7, 7.0));
    		for (EntityLivingBase ent : Entities){
    			if (ent == entity) continue;
    			ent.attackEntityFrom(DamageSource.causeMobDamage(entity), 20);
        }
    		
        if(entity.getAnimTick() > 30)
            entity.setAnimID(0);
    }
    }
}