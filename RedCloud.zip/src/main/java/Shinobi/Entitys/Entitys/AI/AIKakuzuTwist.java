package Shinobi.Entitys.Entitys.AI;

import Shinobi.Entitys.EntityEarthGrudgeFear;
import Shinobi.Entitys.Entitys.EntityKakuzu;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.util.DamageSource;
import net.minecraft.world.World;
import thehippomasterAPI.AnimationAPI.AIAnimation;

public class AIKakuzuTwist extends AIAnimation
{
    private EntityKakuzu entity;
    private EntityLivingBase attackTarget;
	private World world;

    public AIKakuzuTwist(EntityKakuzu jen)
    {
        super(jen);
        entity = jen;
        attackTarget = null;
        
    }

    public int getAnimID()
    {
        return 4;
    }

    public boolean isAutomatic()
    {
        return false;
    }

    public int getDuration()
    {
        return 30;
    }

    @Override
    public boolean shouldAnimate(){
		EntityLivingBase AITarget = entity.getAttackTarget();
		EntityKakuzu enty = this.getEntity();
		if (AITarget == null || AITarget.isDead) return false;
		if(enty.getDistanceToEntity(AITarget) > 5D)return false;
		if (entity.getcount()!=3){
				return false;
		}
		 return entity.getAnimID() == 0;
		
	}
    
    

    
    
    public void updateTask() {
    	attackTarget = entity.getAttackTarget();
        if(entity.getAnimTick() > 30 && attackTarget != null)
            entity.getLookHelper().setLookPositionWithEntity(attackTarget, 10F,10F);
        if((entity.getAnimTick() == 10 || entity.getAnimTick() == 15) && attackTarget != null) {
        	EntityEarthGrudgeFear enf = new EntityEarthGrudgeFear(world);
			if(attackTarget!=enf)
        	attackTarget.attackEntityFrom(DamageSource.causeMobDamage(entity), 10);
        }
        
        if(entity.getAnimTick() > 30)
            entity.setAnimID(0);
    }

}