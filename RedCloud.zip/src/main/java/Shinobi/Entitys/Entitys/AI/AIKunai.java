package Shinobi.Entitys.Entitys.AI;

import java.util.List;
import java.util.Random;

import Shinobi.ShinobiMod;
import Shinobi.Entitys.EntityNinja;
import Shinobi.Entitys.Entitys.Entity3rdKazekagePuppet;
import Shinobi.Entitys.Entitys.EntityItachi;
import Shinobi.Entitys.Entitys.EntityKisame;
import Shinobi.Entitys.Entitys.EntitySasoriHiruko;
import Shinobi.Entitys.Entitys.EntitySusanooItachi;
import Shinobi.Entitys.Projectiles.EntityFireBlast;
import Shinobi.Entitys.Projectiles.EntityGreatFireball;
import Shinobi.Entitys.Projectiles.EntityKunai;
import Shinobi.Entitys.Projectiles.EntityLShark;
import Shinobi.Entitys.Projectiles.EntityMShark;
import Shinobi.Entitys.Projectiles.EntityMagnetCube;
import Shinobi.Entitys.Projectiles.EntityMagnetSpread;
import Shinobi.Entitys.Projectiles.EntityMagnetTriangle;
import Shinobi.Entitys.Projectiles.EntitySShark;
import Shinobi.Entitys.Projectiles.EntityWaterBlast;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityList;
import net.minecraft.entity.EntityLiving;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.util.MathHelper;
import thehippomasterAPI.AnimationAPI.AIAnimation;

public class AIKunai extends AIAnimation {

    private EntityItachi entity;
    private EntityLivingBase attackTarget;
    private int cooldown = 45;

    public AIKunai(EntityItachi itachi)
    {
        super(itachi);
        entity = itachi;
        attackTarget = null;
        
    }

    public int getAnimID()
    {
        return 3;
    }

    public boolean isAutomatic()
    {
        return false;
    }

    public int getDuration()
    {
        return 30;
    }
    
    
    public boolean shouldAnimate(){
		EntityLivingBase AITarget = entity.getAttackTarget();
		double offsetX = Math.cos(entity.rotationYaw) * 2;
		double offsetZ = Math.sin(entity.rotationYaw) * 2;
		List<EntityLivingBase> Entities = entity.worldObj.getEntitiesWithinAABB(EntitySusanooItachi.class, entity.boundingBox.getOffsetBoundingBox(offsetX, 0, offsetZ).expand(5, 5, 5));
		for (EntityLivingBase ent : Entities){
			if (ent == entity) continue;
		if(entity.getDistanceSqToEntity(ent)<3 && ent.getHealth()<800)return false;
		}
		if (AITarget == null || AITarget.isDead) return false;
		if(entity.jts!=3)return false;
		if ( entity.getDistanceSqToEntity(AITarget) < 3D){
				return false;
		}
		return true;
		
	}

    public void startExecuting()
    {
        super.startExecuting();
        attackTarget = entity.getAttackTarget();
    }
    
    

    public void updateTask()
    {
    	Random rand = new Random();
        if(entity.getAnimTick() < 10 && attackTarget != null)
            entity.getLookHelper().setLookPositionWithEntity(attackTarget, 20F,20F);
         if(attackTarget != null && entity.getAnimTick() > 20){
             EntityKunai emc = new EntityKunai (entity.worldObj, entity, 1F);
             double d0 = attackTarget.posX - entity.posX;
             double d1 = attackTarget.posY + (double)attackTarget.getEyeHeight() - 1.100000023841858D - emc.posY;
             double d2 = attackTarget.posZ - entity.posZ;
             float f1 = MathHelper.sqrt_double(d0 * d0 + d2 * d2) * 0.2F;
             emc.setThrowableHeading(d0, d1 + (double)f1, d2, 1.6F, 12.0F);
             entity.worldObj.spawnEntityInWorld(emc);
          
             
         	
             
             
 
        	
        	
            
        	}
        
        
        
        
         }
    
    
    }

	
