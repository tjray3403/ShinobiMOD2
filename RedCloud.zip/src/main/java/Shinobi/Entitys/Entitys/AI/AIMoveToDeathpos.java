package Shinobi.Entitys.Entitys.AI;

import java.util.Iterator;
import java.util.List;

import Shinobi.ShinobiDS;
import Shinobi.ShinobiVariables;
import Shinobi.Entitys.EntityDeathPos;
import Shinobi.Entitys.Entitys.EntityHidan;
import Shinobi.Entitys.Entitys.EntityKakuzu;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.ai.EntityAIBase;
import net.minecraft.entity.monster.EntityIronGolem;
import net.minecraft.entity.passive.EntityVillager;
import net.minecraft.util.DamageSource;

public class AIMoveToDeathpos extends EntityAIBase
{
    private EntityHidan entityH;
    private EntityDeathPos ent;
    private EntityLivingBase elb;
    
    private double Speed;

    public AIMoveToDeathpos(EntityHidan eh, double spd)
    {
        this.entityH = eh;
        this.elb = null;
        this.Speed = spd;
        this.setMutexBits(1);
    }

    /**
     * Returns whether the EntityAIBase should begin execution.
     */
    public boolean shouldExecute()
    {
        
        {
            List list = this.entityH.worldObj.getEntitiesWithinAABB(EntityDeathPos.class, this.entityH.boundingBox.expand(10.0D, 2.0D, 10.0D));

            if (list.isEmpty())
            {
                return false;
            }
            else
            {
                Iterator iterator = list.iterator();

                while (iterator.hasNext())
                {
                    EntityDeathPos entt = (EntityDeathPos)iterator.next();

                    
                        this.ent = entt;
                        break;
                    
                }

                return this.ent != null;
            }
        }
    }

    /**
     * Returns whether an in-progress EntityAIBase should continue executing
     */
    //public boolean continueExecuting()
   // {
	//	return true;
        
    //}

    /**
     * Execute a one shot task or start executing a continuous task
     */
    public void startExecuting()
    {
        elb = entityH.getAttackTarget();
        this.ent.getNavigator().clearPathEntity();
    }

    /**
     * Resets the task
     */
    public void resetTask()
    {
        this.ent = null;
        this.entityH.getNavigator().clearPathEntity();
    }

    /**
     * Updates the task
     */
    public void updateTask()
    {
        this.entityH.getLookHelper().setLookPositionWithEntity(this.ent, 30.0F, 30.0F);
        
            this.entityH.getNavigator().tryMoveToEntityLiving(this.ent, this.Speed);
        
            /**
        if (this.entityH.getDistanceSqToEntity(this.ent) < 4.0D && entityH.cursed==true)	{
        	entityH.attackEntityAsMob(elb);
        //    this.entityH.getNavigator().clearPathEntity();
     }
        else if(this.entityH.getDistanceSqToEntity(this.ent) < 9.0D )
        {
        //	entityH.setCursed(false);
       }
       */
    }
}