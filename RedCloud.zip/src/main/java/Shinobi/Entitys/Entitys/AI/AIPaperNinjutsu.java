package Shinobi.Entitys.Entitys.AI;

import java.util.Random;

import Shinobi.ShinobiMod;
import Shinobi.Entitys.EntityNinja;
import Shinobi.Entitys.Entitys.Entity3rdKazekagePuppet;
import Shinobi.Entitys.Entitys.EntityKonan;
import Shinobi.Entitys.Entitys.EntitySasoriHiruko;
import Shinobi.Entitys.Projectiles.EntityFireBlast;
import Shinobi.Entitys.Projectiles.EntityMagnetCube;
import Shinobi.Entitys.Projectiles.EntityMagnetSpread;
import Shinobi.Entitys.Projectiles.EntityMagnetTriangle;
import Shinobi.Entitys.Projectiles.EntityPaperBomb;
import Shinobi.Entitys.Projectiles.EntityPaperChakram;
import Shinobi.Entitys.Projectiles.EntityPaperTwister;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityList;
import net.minecraft.entity.EntityLiving;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.util.MathHelper;
import thehippomasterAPI.AnimationAPI.AIAnimation;

public class AIPaperNinjutsu extends AIAnimation {

    private EntityKonan entity;
    private EntityLivingBase attackTarget;
    private int cooldown = 45;

    public AIPaperNinjutsu(EntityKonan kon)
    {
        super(kon);
        entity = kon;
        attackTarget = null;
        
    }

    public int getAnimID()
    {
        return 1;
    }

    public boolean isAutomatic()
    {
        return false;
    }

    public int getDuration()
    {
        return 55;
    }
    
    
    public boolean shouldAnimate(){
		EntityLivingBase AITarget = entity.getAttackTarget();
		if (AITarget == null || AITarget.isDead) return false;
		if ( entity.getDistanceSqToEntity(AITarget) < 3D){
				return false;
		}
		return true;
		
	}

    public void startExecuting()
    {
        super.startExecuting();
        attackTarget = entity.getAttackTarget();
    }
    
    

    public void updateTask()
    {
    	Random rand = new Random();
        if(entity.getAnimTick() < 10 && attackTarget != null)
            entity.getLookHelper().setLookPositionWithEntity(attackTarget, 20F,20F);
        if(entity.getAnimTick() ==54 && attackTarget != null)
        {
        	
        	
        	switch(rand.nextInt(4))
        	{
        	
        	case 0:
            EntityPaperTwister emc = new EntityPaperTwister (entity.worldObj, entity, 0.3F);
            double d0 = attackTarget.posX - entity.posX;
            double d1 = attackTarget.posY + (double)attackTarget.getEyeHeight() - 1.100000023841858D - emc.posY;;
            double d2 = attackTarget.posZ - entity.posZ;
            float f1 = MathHelper.sqrt_double(d0 * d0 + d2 * d2) * 0.2F;
            emc.setHeading(d0, d1 + (double)f1, d2, 1.6F, 12.0F);
            entity.worldObj.spawnEntityInWorld(emc);
            break;
            
        	case 1:
        	EntityPaperBomb emt = new EntityPaperBomb (entity.worldObj, entity);
            double c0 = attackTarget.posX - entity.posX;
            double c1 = attackTarget.posY + (double)attackTarget.getEyeHeight() - 1.100000023841858D - emt.posY;;
            double c2 = attackTarget.posZ - entity.posZ;
            float w1 = MathHelper.sqrt_double(c0 * c0 + c2 * c2) * 0.2F;
            emt.setThrowableHeading(c0, c1 + (double)w1, c2, 1.6F, 12.0F);
            entity.worldObj.spawnEntityInWorld(emt);
        	break;
        	
        	case 2:
        	Random rr = new Random();
        	int	x = (int) attackTarget.posX;
        	int	y = (int) attackTarget.posY;
        	int	z = (int) attackTarget.posZ;
        	int t = rr.nextInt(7);
        	entity.motionY = 1.1F;
        	if (!entity.worldObj.isRemote) {
    			Entity sentity = EntityList.createEntityByName("34PaperPerson", entity.worldObj);
    			if (sentity != null) {
    				sentity.setLocationAndAngles(x, y, z, entity.worldObj.rand.nextFloat() * 360F, 0.0F);
    				entity.worldObj.spawnEntityInWorld(sentity);
    			}
    		} 
        	
        	break; 
        	
        	case 3:
        		if(entity.getHealth()<3500) {
            	EntityPaperChakram eee = new EntityPaperChakram (entity.worldObj, entity);
                double z0 = attackTarget.posX - entity.posX;
                double z1 = attackTarget.posY + (double)attackTarget.getEyeHeight() - 1.100000023841858D - eee.posY;;
                double z2 = attackTarget.posZ - entity.posZ;
                float x1 = MathHelper.sqrt_double(z0 * z0 + z2 * z2) * 0.2F;
                eee.setThrowableHeading(z0, z1 + (double)x1, z2, 1.6F, 12.0F);
                entity.worldObj.spawnEntityInWorld(eee);
        		}
            	break;
        		
        		default:
        			break;
            
            
            
        	}
        }
        
        
        
        
    }
    
    
   

}
