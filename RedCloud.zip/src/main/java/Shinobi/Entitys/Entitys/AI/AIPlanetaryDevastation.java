package Shinobi.Entitys.Entitys.AI;

import java.util.List;
import java.util.Random;

import Shinobi.ShinobiMod;
import Shinobi.Entitys.EntityEarthGrudgeFear;
import Shinobi.Entitys.EntityNinja;
import Shinobi.Entitys.EntityUtil;
import Shinobi.Entitys.Entitys.Entity3rdKazekagePuppet;
import Shinobi.Entitys.Entitys.EntityItachi;
import Shinobi.Entitys.Entitys.EntityKisame;
import Shinobi.Entitys.Entitys.EntityPainDeva;
import Shinobi.Entitys.Entitys.EntitySasoriHiruko;
import Shinobi.Entitys.Projectiles.EntityFireBlast;
import Shinobi.Entitys.Projectiles.EntityGreatFireball;
import Shinobi.Entitys.Projectiles.EntityKunai;
import Shinobi.Entitys.Projectiles.EntityLShark;
import Shinobi.Entitys.Projectiles.EntityMShark;
import Shinobi.Entitys.Projectiles.EntityMagnetCube;
import Shinobi.Entitys.Projectiles.EntityMagnetSpread;
import Shinobi.Entitys.Projectiles.EntityMagnetTriangle;
import Shinobi.Entitys.Projectiles.EntitySShark;
import Shinobi.Entitys.Projectiles.EntityWaterBlast;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityCreature;
import net.minecraft.entity.EntityList;
import net.minecraft.entity.EntityLiving;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.util.DamageSource;
import net.minecraft.util.MathHelper;
import net.minecraft.util.Vec3;
import net.minecraft.world.World;
import thehippomasterAPI.AnimationAPI.AIAnimation;

public class AIPlanetaryDevastation extends AIAnimation {

    private EntityPainDeva entity;
    private EntityLivingBase attackTarget;
    private int cooldown = 45;

    public AIPlanetaryDevastation(EntityPainDeva pain)
    {
        super(pain);
        entity = pain;
        attackTarget = null;
        
    }

    public int getAnimID()
    {
        return 4;
    }

    public boolean isAutomatic()
    {
        return true;
    }

    public int getDuration()
    {
        return 30;
    }
    
    

    public void startExecuting()
    {
        super.startExecuting();
        attackTarget = entity.getAttackTarget();
    }
    
    

    public void updateTask()
    {
    	double offsetX = Math.cos(entity.rotationYaw) * 2;
    	double offsetZ = Math.sin(entity.rotationYaw) * 2;
    	Vec3 vec = entity.getLookVec();
        if(entity.getAnimTick() > 30 && attackTarget != null)
            entity.getLookHelper().setLookPositionWithEntity(attackTarget, 10F,10F);
        if(entity.getAnimTick() == 5 && attackTarget != null) {
        	
        	if (!entity.worldObj.isRemote) {
    			Entity sentity = EntityList.createEntityByName("34ChibakuTensei", entity.worldObj);
    			if (sentity != null) {
    				sentity.setLocationAndAngles(attackTarget.posX, attackTarget.posY, attackTarget.posZ, entity.worldObj.rand.nextFloat() * 360F, 0.0F);
    				entity.worldObj.spawnEntityInWorld(sentity);
    				((EntityLiving) sentity).playLivingSound();
    		}
        	}
    		
        }
         
    }
}


