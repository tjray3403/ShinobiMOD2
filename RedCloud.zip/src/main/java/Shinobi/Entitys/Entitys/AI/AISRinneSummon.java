package Shinobi.Entitys.Entitys.AI;

import java.util.List;
import java.util.Random;

import Shinobi.Entitys.EntityNinja;
import Shinobi.Entitys.EntityRSummoning;
import Shinobi.Entitys.EntityUtil;
import Shinobi.Entitys.Entitys.EntityKakuzu3;
import Shinobi.Entitys.Entitys.EntityPainAnimal;
import Shinobi.Entitys.Entitys.EntityPainAsura;
import Shinobi.Entitys.Entitys.EntityPainHuman;
import Shinobi.Entitys.Entitys.EntityPainNaraka;
import Shinobi.Entitys.Projectiles.EntityAsuraHand;
import Shinobi.Entitys.Projectiles.EntityChakraRod;
import Shinobi.Entitys.Projectiles.EntityFireBlast;
import Shinobi.Entitys.Projectiles.EntityMagnetCube;
import Shinobi.Entitys.Projectiles.EntityRinneBullet;
import Shinobi.Entitys.Projectiles.EntityWindBlast;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityCreature;
import net.minecraft.entity.EntityList;
import net.minecraft.entity.EntityLiving;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.util.MathHelper;
import thehippomasterAPI.AnimationAPI.AIAnimation;

public class AISRinneSummon extends AIAnimation {

    private EntityPainAnimal entity;
    private EntityLivingBase attackTarget;

    public AISRinneSummon(EntityPainAnimal ef)
    {
        super(ef);
        entity = ef;
        attackTarget = null;
    }


	public int getAnimID()
    {
        return 5;
    }

    public boolean isAutomatic()
    {
        return false;
    }

    public int getDuration()
    {
        return 40;
    }

    
    public boolean shouldAnimate() {
    	EntityLivingBase AITarget = entity.getAttackTarget();
		if (AITarget == null || AITarget.isDead) return false;
		double offsetX = Math.cos(entity.rotationYaw) * 2;
		double offsetZ = Math.sin(entity.rotationYaw) * 2;
		List<EntityLivingBase> Entities = entity.worldObj.getEntitiesWithinAABB(EntityRSummoning.class, entity.boundingBox.getOffsetBoundingBox(offsetX, 0, offsetZ).expand(10, 10, 10));
		for (EntityLivingBase ent : Entities){
			
	
			
		}
		if(!Entities.isEmpty()) {
			return false;
		}
    	//if(entity.attack!=1)return false;
		return true;
    	
    }

    public void startExecuting()
    {
        super.startExecuting();
        attackTarget = entity.getAttackTarget();
    }

    public void updateTask()
    {
    	Random rand = new Random();

        if(entity.getAnimTick() < 10 && attackTarget != null)
            entity.getLookHelper().setLookPositionWithEntity(attackTarget, 20F,20F);
        if(entity.getAnimTick() == 5 && attackTarget != null) {
           
        	
			switch(rand.nextInt(5))
        	{
        	case 0:
        		if (!entity.worldObj.isRemote) {
        			Entity sentity = EntityList.createEntityByName("34SMChimera", entity.worldObj);
        			if (sentity != null) {
        				sentity.setLocationAndAngles(entity.posX, entity.posY, entity.posZ, entity.worldObj.rand.nextFloat() * 360F, 0.0F);
        				entity.worldObj.spawnEntityInWorld(sentity);
        				((EntityLiving) sentity).playLivingSound();
        				EntityUtil.setOwner((EntityLivingBase) sentity, entity);
        				EntityUtil.makeSummon_MonsterFaction((EntityCreature) sentity, false);
        		}
            	}
            break;
            
        	case 1:
        		if (!entity.worldObj.isRemote) {
        			Entity sentity = EntityList.createEntityByName("34SMChameleon", entity.worldObj);
        			if (sentity != null) {
        				sentity.setLocationAndAngles(entity.posX, entity.posY, entity.posZ, entity.worldObj.rand.nextFloat() * 360F, 0.0F);
        				entity.worldObj.spawnEntityInWorld(sentity);
        				((EntityLiving) sentity).playLivingSound();
        				EntityUtil.setOwner((EntityLivingBase) sentity, entity);
        				EntityUtil.makeSummon_MonsterFaction((EntityCreature) sentity, false);
        		}
            	}
                break;
            
        	case 2:
        		if (!entity.worldObj.isRemote) {
        			Entity sentity = EntityList.createEntityByName("34SMDrillBeakBird", entity.worldObj);
        			if (sentity != null) {
        				sentity.setLocationAndAngles(entity.posX, entity.posY, entity.posZ, entity.worldObj.rand.nextFloat() * 360F, 0.0F);
        				entity.worldObj.spawnEntityInWorld(sentity);
        				((EntityLiving) sentity).playLivingSound();

        				
        		}
            	}
                break;
            
        	case 3:
        		if (!entity.worldObj.isRemote) {
        			Entity sentity = EntityList.createEntityByName("34SMRhino", entity.worldObj);
        			if (sentity != null) {
        				sentity.setLocationAndAngles(entity.posX, entity.posY, entity.posZ, entity.worldObj.rand.nextFloat() * 360F, 0.0F);
        				entity.worldObj.spawnEntityInWorld(sentity);
        				((EntityLiving) sentity).playLivingSound();
        				EntityUtil.setOwner((EntityLivingBase) sentity, entity);
        				EntityUtil.makeSummon_MonsterFaction((EntityCreature) sentity, true);
        				
        		}
            	}
                break;
            
           
            
            }
        
        
    
    }
    
    }

}
