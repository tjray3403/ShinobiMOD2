package Shinobi.Entitys.Entitys.AI;

import java.util.Iterator;
import java.util.List;

import Shinobi.Entitys.EntityRSummoning;
import Shinobi.Entitys.Entitys.EntityPainAnimal;
import net.minecraft.entity.EntityCreature;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.ai.EntityAIBase;
import net.minecraft.entity.ai.EntityAITarget;
import net.minecraft.util.AxisAlignedBB;

public class AISSUmmon extends EntityAIBase
{

	private EntityRSummoning entt;
	private EntityPainAnimal entity;
	
    public AISSUmmon(EntityRSummoning ent)
    {
        super();
        ent =  entt;
        
    }

    /**
     * Returns whether the EntityAIBase should begin execution.
     */
    public boolean shouldExecute()
    {
    	//double offsetX = Math.cos(entt.rotationYaw) * 2;
		//double offsetZ = Math.sin(entt.rotationYaw) * 2;
		//List<EntityLivingBase> Entities = entt.worldObj.getEntitiesWithinAABB(EntityPainAnimal.class, entt.boundingBox.getOffsetBoundingBox(offsetX, 0, offsetZ).expand(10, 10, 10));
		//if(Entities.isEmpty()) {
		//	return false;
		//}
			
			
            return this.entity != null;
        }
    
	
    

    /**
     * Execute a one shot task or start executing a continuous task
     */
    public void startExecuting()
    {
        this.entt.setAttackTarget(this.entity.getAITarget());

        
           
        

        super.startExecuting();
    }
}