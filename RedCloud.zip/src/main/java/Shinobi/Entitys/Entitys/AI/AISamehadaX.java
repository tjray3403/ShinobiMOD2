package Shinobi.Entitys.Entitys.AI;

import java.util.Random;

import Shinobi.ShinobiMod;
import Shinobi.Entitys.EntityNinja;
import Shinobi.Entitys.Entitys.Entity3rdKazekagePuppet;
import Shinobi.Entitys.Entitys.EntityKisame;
import Shinobi.Entitys.Entitys.EntitySasori;
import Shinobi.Entitys.Entitys.EntitySasoriHiruko;
import Shinobi.Entitys.Projectiles.EntityFireBlast;
import Shinobi.Entitys.Projectiles.EntityFireJet;
import Shinobi.Entitys.Projectiles.EntityMagnetCube;
import Shinobi.Entitys.Projectiles.EntityMagnetSpread;
import Shinobi.Entitys.Projectiles.EntityMagnetTriangle;
import Shinobi.Entitys.Projectiles.EntityWaterJet;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityList;
import net.minecraft.entity.EntityLiving;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.util.DamageSource;
import net.minecraft.util.MathHelper;
import thehippomasterAPI.AnimationAPI.AIAnimation;

public class AISamehadaX extends AIAnimation {

    private EntityKisame entity;
    private EntityLivingBase attackTarget;

    public AISamehadaX(EntityKisame sas)
    {
        super(sas);
        entity = sas;
        attackTarget = null;
        
    }

    public int getAnimID()
    {
        return 2;
    }

    public boolean isAutomatic()
    {
        return false;
    }

    public int getDuration()
    {
        return 90;
    }
    
    
    public boolean shouldAnimate(){
		EntityLivingBase AITarget = entity.getAttackTarget();	
		if (AITarget == null || AITarget.isDead) return false;
		if (entity.getDistanceSqToEntity(AITarget) > 4D)return false;
				if(entity.getcount()==1 || entity.getcount()==2) {
					return true;
				}
		
		return false;
		
	}

    
    
    

    public void updateTask()
    {
    	attackTarget = entity.getAttackTarget();
        if(entity.getAnimTick() < 10 && attackTarget != null)
            entity.getLookHelper().setLookPositionWithEntity(attackTarget, 20F,20F);
        if(entity.getAnimTick() == 50 && attackTarget != null )
        {
        	attackTarget.attackEntityFrom(DamageSource.generic, 10);  	    	
        }
        if(entity.getAnimTick() < 60 && attackTarget != null)
        {
        	attackTarget.attackEntityFrom(DamageSource.generic, 10);  	    	
        }
        if(entity.getAnimTick() < 70 && attackTarget != null)
        {
        	attackTarget.attackEntityFrom(DamageSource.generic, 10);  	    	
        }if(entity.getAnimTick() < 80 && attackTarget != null)
        {
        	attackTarget.attackEntityFrom(DamageSource.generic, 10);  	    	
        }
        
       
        
    }
    
    
   

}
