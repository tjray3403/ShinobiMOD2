package Shinobi.Entitys.Entitys.AI;

import java.util.List;
import java.util.Random;

import Shinobi.Entitys.EntityEarthGrudgeFear;
import Shinobi.Entitys.Entitys.EntityKisame;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.init.Blocks;
import net.minecraft.util.DamageSource;
import net.minecraft.util.MathHelper;
import net.minecraft.util.Vec3;
import net.minecraft.world.World;
import thehippomasterAPI.AnimationAPI.AIAnimation;

public class AISamehadaY extends AIAnimation
{
    private EntityKisame entity;
    private EntityLivingBase attackTarget;
	private World world;

    public AISamehadaY(EntityKisame jen)
    {
        super(jen);
        entity = jen;
        attackTarget = null;
        
    }

    public int getAnimID()
    {
        return 5;
    }

    public boolean isAutomatic()
    {
        return false;
    }

    public int getDuration()
    {
        return 30;
    }

    @Override
    public boolean shouldAnimate(){
		EntityLivingBase AITarget = entity.getAttackTarget();
		EntityKisame enty = this.getEntity();
		if (AITarget == null || AITarget.isDead) return false;
		if(enty.getDistanceToEntity(AITarget) > 3D)return false;
		if (entity.getcount()==4){
				return true;
		}
		 return false;
		
	}
    
    

    
    
    public void updateTask() {
    	attackTarget = entity.getAttackTarget();
    	Vec3 vec = entity.getLookVec();
        if(entity.getAnimTick() > 30 && attackTarget != null)
            entity.getLookHelper().setLookPositionWithEntity(attackTarget, 10F,10F);
        if(( entity.getAnimTick() == 20) && attackTarget != null) {
        	int i = (int) attackTarget.posX;
			int j = (int) attackTarget.posY;
			int k = (int) attackTarget.posZ;
			Random rand = new Random();
			int rr;
			//int i = (int) vec.xCoord;
			//int j = (int) entity.posY-2;
			//int k = (int) vec.zCoord;
			attackTarget.attackEntityFrom(DamageSource.generic, 20);
			
			
        	
        	
        }
    		
        
    }
    
}