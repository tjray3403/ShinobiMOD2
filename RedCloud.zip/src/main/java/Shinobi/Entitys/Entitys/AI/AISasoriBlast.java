package Shinobi.Entitys.Entitys.AI;

import java.util.Random;

import Shinobi.ShinobiMod;
import Shinobi.Entitys.EntityNinja;
import Shinobi.Entitys.EntityUtil;
import Shinobi.Entitys.Entitys.Entity3rdKazekagePuppet;
import Shinobi.Entitys.Entitys.EntityDeidara;
import Shinobi.Entitys.Entitys.EntitySasori;
import Shinobi.Entitys.Entitys.EntitySasoriHiruko;
import Shinobi.Entitys.Projectiles.EntityC2;
import Shinobi.Entitys.Projectiles.EntityFireBlast;
import Shinobi.Entitys.Projectiles.EntityFireJet;
import Shinobi.Entitys.Projectiles.EntityLightningBlast;
import Shinobi.Entitys.Projectiles.EntityMagnetCube;
import Shinobi.Entitys.Projectiles.EntityMagnetSpread;
import Shinobi.Entitys.Projectiles.EntityMagnetTriangle;
import Shinobi.Entitys.Projectiles.EntityWaterJet;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityCreature;
import net.minecraft.entity.EntityList;
import net.minecraft.entity.EntityLiving;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.util.MathHelper;
import thehippomasterAPI.AnimationAPI.AIAnimation;

public class AISasoriBlast extends AIAnimation {

    private EntitySasori entity;
    private EntityLivingBase attackTarget;

    public AISasoriBlast(EntitySasori et)
    {
        super(et);
        entity = et;
        attackTarget = null;
        
    }

    public int getAnimID()
    {
        return 3;
    }

    public boolean isAutomatic()
    {
        return false;
    }

    public int getDuration()
    {
        return 25;
    }
    
    public boolean shouldAnimate(){
		EntityLivingBase AITarget = entity.getAttackTarget();
		if (AITarget == null || AITarget.isDead) return false;
		if(entity.getHealth() > 2000D) return false;
		if(entity.getDistanceSqToEntity(AITarget)<4)return false;
		
		return true;
		
	}

    public void startExecuting()
    {
        super.startExecuting();
        attackTarget = entity.getAttackTarget();
        Random rand = new Random();
        int	x = (int) entity.posX;
    	int	y = (int) entity.posY;
    	int	z = (int) entity.posZ;
        int e = rand.nextInt(2);
        
        switch(rand.nextInt(2))
    	{
    	case 0:
    		EntityWaterJet emc = new EntityWaterJet (entity.worldObj, entity, 0.5F);
            double d0 = attackTarget.posX - entity.posX;
            double d1 = attackTarget.posY + (double)attackTarget.getEyeHeight() - 1.100000023841858D - emc.posY;
            double d2 = attackTarget.posZ - entity.posZ;
            float f1 = MathHelper.sqrt_double(d0 * d0 + d2 * d2) * 0.2F;
            emc.setHeading(d0, d1 + (double)f1, d2, 1.6F, 12.0F);
            entity.worldObj.spawnEntityInWorld(emc);
    	break;
    	
    	case 1:
    		EntityFireJet ef = new EntityFireJet (entity.worldObj, entity, 0.5F);
            double c0 = attackTarget.posX - entity.posX;
            double c1 = attackTarget.posY + (double)attackTarget.getEyeHeight() - 1.100000023841858D - ef.posY;
            double c2 = attackTarget.posZ - entity.posZ;
            float s1 = MathHelper.sqrt_double(c0 * c0 + c2 * c2) * 0.2F;
            ef.setHeading(c0, c1 + (double)s1, c2, 1.6F, 12.0F);
            entity.worldObj.spawnEntityInWorld(ef);
    	break;
    	
    	
    	default:
    		break;
    	
    	}
    }
    
    

   
   
   

}
