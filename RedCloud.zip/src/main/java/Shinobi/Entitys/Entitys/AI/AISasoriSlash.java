package Shinobi.Entitys.Entitys.AI;

import java.util.Random;

import Shinobi.ShinobiMod;
import Shinobi.Entitys.EntityNinja;
import Shinobi.Entitys.Entitys.Entity3rdKazekagePuppet;
import Shinobi.Entitys.Entitys.EntitySasori;
import Shinobi.Entitys.Entitys.EntitySasoriHiruko;
import Shinobi.Entitys.Projectiles.EntityFireBlast;
import Shinobi.Entitys.Projectiles.EntityFireJet;
import Shinobi.Entitys.Projectiles.EntityMagnetCube;
import Shinobi.Entitys.Projectiles.EntityMagnetSpread;
import Shinobi.Entitys.Projectiles.EntityMagnetTriangle;
import Shinobi.Entitys.Projectiles.EntityWaterJet;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityList;
import net.minecraft.entity.EntityLiving;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.util.DamageSource;
import net.minecraft.util.MathHelper;
import thehippomasterAPI.AnimationAPI.AIAnimation;

public class AISasoriSlash extends AIAnimation {

    private EntitySasori entity;
    private EntityLivingBase attackTarget;

    public AISasoriSlash(EntitySasori sas)
    {
        super(sas);
        entity = sas;
        attackTarget = null;
        
    }

    public int getAnimID()
    {
        return 4;
    }

    public boolean isAutomatic()
    {
        return false;
    }

    public int getDuration()
    {
        return 45;
    }
    
    
    public boolean shouldAnimate(){
		EntityLivingBase AITarget = entity.getAttackTarget();
		if (AITarget == null || AITarget.isDead) return false;
		if(entity.getHealth() > 2500D) return false;
		if (entity.getDistanceSqToEntity(AITarget) > 4D){
				return false;
		}
		return true;
		
	}

    public void startExecuting()
    {
        super.startExecuting();
        attackTarget = entity.getAttackTarget();
    }
    
    

    public void updateTask()
    {
        if(entity.getAnimTick() < 10 && attackTarget != null)
            entity.getLookHelper().setLookPositionWithEntity(attackTarget, 20F,20F);
        if(entity.getAnimTick() == 5 && attackTarget != null)
        {
        	attackTarget.attackEntityFrom(DamageSource.generic, 10);  	    	
        }
        if(entity.getAnimTick() == 15 && attackTarget != null)
        {
        	attackTarget.attackEntityFrom(DamageSource.generic, 10);  	    	
        }
        if(entity.getAnimTick() == 25 && attackTarget != null)
        {
        	attackTarget.attackEntityFrom(DamageSource.generic, 10);  	    	
        }
        
        
        
    }
    
    
   

}
