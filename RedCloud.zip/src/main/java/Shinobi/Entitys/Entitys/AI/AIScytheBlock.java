package Shinobi.Entitys.Entitys.AI;

import Shinobi.Entitys.Entitys.EntityHidan;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.SharedMonsterAttributes;
import net.minecraft.util.DamageSource;
import net.minecraft.util.EntityDamageSourceIndirect;
import thehippomasterAPI.AnimationAPI.AIAnimation;

public class AIScytheBlock extends AIAnimation
{
    private EntityHidan entity;
    private EntityLivingBase attackTarget;
	private int field_142052_b;
	private int cooldown = 20;

    public AIScytheBlock(EntityHidan jen)
    {
        super(jen);
        entity = jen;
        attackTarget = null;
    }

    public int getAnimID()
    {
        return 3;
    }

    public boolean isAutomatic()
    {
        return false;
    }

    public int getDuration()
    {
        return 15;
    }

   
	@Override
    public boolean shouldExecute() {
		
		EntityHidan eht = getEntity();
		if(eht.func21!=true)return false;
       return entity.getAnimID()==0;
		
	
	}
    
	
    public void updateTask()
    {
    	//this.field_142052_b = this.entity.func_142015_aE();
    	attackTarget = entity.getAttackTarget();
        if(entity.getAnimTick() < 15 && attackTarget != null)
            entity.getLookHelper().setLookPositionWithEntity(attackTarget, 10F,10F);
        {
             entity.setAbsorptionAmount(10);
        }
         if(entity.getAnimTick() == 15)
        {
            entity.setAbsorptionAmount(0);;
        }
        if(entity.getAnimTick() > 15)
           entity.setAnimID(0);
    }
    
    

}
    


