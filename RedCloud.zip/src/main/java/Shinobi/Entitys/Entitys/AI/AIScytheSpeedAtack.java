package Shinobi.Entitys.Entitys.AI;

import Shinobi.Entitys.Entitys.EntityHidan;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.util.DamageSource;
import net.minecraft.util.Vec3;
import thehippomasterAPI.AnimationAPI.AIAnimation;

public class AIScytheSpeedAtack extends AIAnimation
{
    private EntityHidan entity;
    private EntityLivingBase attackTarget;

    public AIScytheSpeedAtack(EntityHidan hid)
    {
        super(hid);
        entity = hid;
        attackTarget = null;
    }

    public int getAnimID()
    {
        return 5;
    }

    public boolean isAutomatic()
    {
        return false;
    }

    public int getDuration()
    {
        return 30;
    }
    
    @Override
    public boolean shouldAnimate(){
		EntityLivingBase AITarget = entity.getAttackTarget();
		EntityHidan enty = this.getEntity();
		if (AITarget == null || AITarget.isDead) return false;
		if(enty.getDistanceToEntity(AITarget) > 2D)return false;
		if ( entity.getcount()!=5){
				return false;
		}
		 return entity.getAnimID() == 0;
		
	}

   

    public void startExecuting()
    {
        super.startExecuting();
        
    }

    public void updateTask(){
    	attackTarget = entity.getAttackTarget();
    	Vec3 vec = entity.getLookVec();
        if(entity.getAnimTick() < 30 && attackTarget != null)
            entity.getLookHelper().setLookPositionWithEntity(attackTarget, 10F,10F);
        if((entity.getAnimID() == 10 || entity.getAnimTick() == 15) && attackTarget != null){
        	if(entity.getDistanceToEntity(attackTarget) < 2D)
        	entity.motionX = vec.xCoord + -0.2;
            entity.motionY = vec.yCoord;
            entity.motionZ = vec.zCoord + -0.2;
        	attackTarget.attackEntityFrom(DamageSource.causeMobDamage(entity), 30);
        }
        
        if(entity.getAnimTick() > 30)
            entity.setAnimID(0);
    }

}