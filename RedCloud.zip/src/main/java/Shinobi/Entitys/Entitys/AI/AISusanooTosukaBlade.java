package Shinobi.Entitys.Entitys.AI;

import java.util.List;
import java.util.Random;

import Shinobi.ShinobiMod;
import Shinobi.Entitys.EntityNinja;
import Shinobi.Entitys.Entitys.Entity3rdKazekagePuppet;
import Shinobi.Entitys.Entitys.EntityItachi;
import Shinobi.Entitys.Entitys.EntityKisame;
import Shinobi.Entitys.Entitys.EntitySasoriHiruko;
import Shinobi.Entitys.Entitys.EntitySusanooItachi;
import Shinobi.Entitys.Projectiles.EntityFireBlast;
import Shinobi.Entitys.Projectiles.EntityGreatFireball;
import Shinobi.Entitys.Projectiles.EntityLShark;
import Shinobi.Entitys.Projectiles.EntityMShark;
import Shinobi.Entitys.Projectiles.EntityMagnetCube;
import Shinobi.Entitys.Projectiles.EntityMagnetSpread;
import Shinobi.Entitys.Projectiles.EntityMagnetTriangle;
import Shinobi.Entitys.Projectiles.EntitySShark;
import Shinobi.Entitys.Projectiles.EntityWaterBlast;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityList;
import net.minecraft.entity.EntityLiving;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.util.DamageSource;
import net.minecraft.util.MathHelper;
import net.minecraft.util.Vec3;
import thehippomasterAPI.AnimationAPI.AIAnimation;

public class AISusanooTosukaBlade extends AIAnimation {

    private EntitySusanooItachi entity;
    private EntityLivingBase attackTarget;

    public AISusanooTosukaBlade(EntitySusanooItachi sus)
    {
        super(sus);
        entity = sus;
        attackTarget = null;
        
    }

    public int getAnimID()
    {
        return 4;
    }

    public boolean isAutomatic()
    {
        return false;
    }

    public int getDuration()
    {
        return 30;
    }
    
    
    public boolean shouldAnimate(){
		EntityLivingBase AITarget = entity.getAttackTarget();
		if (AITarget == null || AITarget.isDead) return false;
		if(entity.jts!=5)return false;
		if(entity.getHealth()>300)return false;
		if (entity.getDistanceSqToEntity(AITarget) > 4D){
				return false;
		}
		
		return true;
		
	}

    public void startExecuting()
    {
        super.startExecuting();
        attackTarget = entity.getAttackTarget();
    }
    
    

    public void updateTask()
    {
    	Random rand = new Random();
    	Vec3 vec = entity.getLookVec();
    	int i = (int) vec.xCoord - 2;
    	int j = (int) vec.yCoord;
    	int k = (int) vec.zCoord - 2;
    	//float yaw = entity.rotationYaw;
    	//float pitch = entity.rotationPitch;
    	//float f = 1.0F;
    	//double X = (double)(-MathHelper.sin(yaw / 180.0F * (float)Math.PI) * MathHelper.cos(pitch / 180.0F * (float)Math.PI) * f);
    	//double Z = (double)(MathHelper.cos(yaw / 180.0F * (float)Math.PI) * MathHelper.cos(pitch / 180.0F * (float)Math.PI) * f);
    	//double Y = (double)(-MathHelper.sin((pitch) / 180.0F * (float)Math.PI) * f);


        if(entity.getAnimTick() < 10 && attackTarget != null)
            entity.getLookHelper().setLookPositionWithEntity(attackTarget, 20F,20F);
         if(attackTarget != null && entity.getAnimTick() == 25){
 			attackTarget.attackEntityFrom(DamageSource.causeMobDamage(entity), 50);
 			attackTarget.setFire(10);
        		}
 
        	
        	
            
        	}
        
        
        
        
        
    }
    
    
   


