package Shinobi.Entitys.Entitys.AI;

import java.util.List;
import java.util.Random;

import Shinobi.ShinobiMod;
import Shinobi.Entitys.EntityNinja;
import Shinobi.Entitys.Entitys.Entity3rdKazekagePuppet;
import Shinobi.Entitys.Entitys.EntityHidan;
import Shinobi.Entitys.Entitys.EntityItachi;
import Shinobi.Entitys.Entitys.EntityKisame;
import Shinobi.Entitys.Entitys.EntitySasoriHiruko;
import Shinobi.Entitys.Entitys.EntitySusanooItachi;
import Shinobi.Entitys.Projectiles.EntityFireBlast;
import Shinobi.Entitys.Projectiles.EntityGreatFireball;
import Shinobi.Entitys.Projectiles.EntityLShark;
import Shinobi.Entitys.Projectiles.EntityMShark;
import Shinobi.Entitys.Projectiles.EntityMagnetCube;
import Shinobi.Entitys.Projectiles.EntityMagnetSpread;
import Shinobi.Entitys.Projectiles.EntityMagnetTriangle;
import Shinobi.Entitys.Projectiles.EntitySShark;
import Shinobi.Entitys.Projectiles.EntityWaterBlast;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityList;
import net.minecraft.entity.EntityLiving;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.util.DamageSource;
import net.minecraft.util.MathHelper;
import net.minecraft.util.Vec3;
import thehippomasterAPI.AnimationAPI.AIAnimation;

public class AISusanooYataMirror extends AIAnimation {

    private EntitySusanooItachi entity;
    private EntityLivingBase attackTarget;

    public AISusanooYataMirror(EntitySusanooItachi sus)
    {
        super(sus);
        entity = sus;
        attackTarget = null;
        
    }

    public int getAnimID()
    {
        return 6;
    }

    public boolean isAutomatic()
    {
        return false;
    }

    public int getDuration()
    {
        return 30;
    }
    
    
    public boolean shouldAnimate(){
    	EntitySusanooItachi eht = getEntity();
    	if(eht.getHealth()>300)return false;
		if(eht.func21!=true)return false;
       return true;
		
		
	}

    public void startExecuting()
    {
        super.startExecuting();
        attackTarget = entity.getAttackTarget();
    }
    
    

    public void updateTask()
    {
    	
    	if(entity.getHealth()<299)
         entity.heal(1);
        	}
        
        
        
        
        
    }
    
    
   


