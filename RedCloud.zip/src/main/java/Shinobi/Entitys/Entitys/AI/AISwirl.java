package Shinobi.Entitys.Entitys.AI;

import Shinobi.Entitys.Entitys.EntityKakuzu3;
import net.minecraft.entity.EntityLiving;
import thehippomasterAPI.AnimationAPI.AIAnimation;
import thehippomasterAPI.AnimationAPI.IAnimatedEntity;

public class AISwirl extends AIAnimation {
	
	public AISwirl(IAnimatedEntity entity) {
		super(entity);
	}
	
	public AISwirl(EntityKakuzu3 entityKakuzu3) {
		super(entityKakuzu3);
	}

	public int getAnimID() {
		return 1;
	}
	
	public boolean isAutomatic() {
		return false;
	}
	
	public int getDuration() {
		return 30;
	}
	
	public boolean shouldAnimate() {
		EntityLiving living = getEntity();
		IAnimatedEntity entity = (IAnimatedEntity)living;
		return entity.getAnimID() == 0 && living.getRNG().nextInt(1) == 0;
	}
	
	public void resetTask() {
		super.resetTask();

	}
}
