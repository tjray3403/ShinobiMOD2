package Shinobi.Entitys.Entitys.AI;

import java.util.Iterator;
import java.util.List;

import Shinobi.Entitys.EntityDeathPos;
import Shinobi.Entitys.Entitys.EntityHidan;
import net.minecraft.entity.EntityCreature;
import net.minecraft.entity.EntityLiving;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.ai.EntityAIBase;

public class AITeleportToEntity extends EntityAIBase {
	
	private EntityLivingBase entity;
	private EntityCreature host;

	public AITeleportToEntity(EntityCreature eh, EntityLivingBase elb)
    {
		host = eh;
		entity = elb;
    }

	@Override
	public boolean shouldExecute() {
		List list = this.host.worldObj.getEntitiesWithinAABB(EntityCreature.class, this.host.boundingBox.expand(15.0D, 10.0D, 15.0D));
        if (list.isEmpty())
        {
            return false;
        }
        else
        {
            Iterator iterator = list.iterator();

            while (iterator.hasNext())
            {
                EntityLivingBase entt = (EntityLivingBase)iterator.next();

                
                    this.entity = entt;
                    break;
                
            }

            return this.entity != null;
        }
    }
	
	
	
	public void updateTask()
    {
        this.host.getLookHelper().setLookPositionWithEntity(this.entity, 30.0F, 30.0F);
        
            this.host.setPositionAndUpdate(entity.posX, entity.posY, entity.posZ);;
	
    }
            
            
	}
	


