package Shinobi.Entitys.Entitys.AI;

import Shinobi.Entitys.EntityEarthGrudgeFear;
import Shinobi.Entitys.EntityNinja;
import Shinobi.Entitys.Projectiles.EntityWaterBlast;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.util.MathHelper;
import thehippomasterAPI.AnimationAPI.AIAnimation;

public class AIWaterBlast extends AIAnimation {

    private EntityEarthGrudgeFear entity;
    private EntityLivingBase attackTarget;

    public AIWaterBlast(EntityEarthGrudgeFear ef)
    {
        super(ef);
        entity = ef;
        attackTarget = null;
    }

    public int getAnimID()
    {
        return 3;
    }

    public boolean isAutomatic()
    {
        return true;
    }

    public int getDuration()
    {
        return 10;
    }

    public boolean continueExecuting()
    {
        return entity.getAnimTick() > 10 ? false : super.continueExecuting();
    }

    public void startExecuting()
    {
        super.startExecuting();
        attackTarget = entity.getAttackTarget();
    }

    public void updateTask()
    {
        if(entity.getAnimTick() < 10 && attackTarget != null)
            entity.getLookHelper().setLookPositionWithEntity(attackTarget, 20F,20F);
        if(entity.getAnimTick() == 2 && attackTarget != null)
        {
            EntityWaterBlast ewb = new EntityWaterBlast(entity.worldObj, entity);
            double d0 = attackTarget.posX - entity.posX;
            double d1 = attackTarget.posY + (double)attackTarget.getEyeHeight() - 1.100000023841858D - ewb.posY;
            double d2 = attackTarget.posZ - entity.posZ;
            float f1 = MathHelper.sqrt_double(d0 * d0 + d2 * d2) * 0.2F;
            ewb.setThrowableHeading(d0, d1 + (double)f1, d2, 1.6F, 12.0F);
            entity.worldObj.spawnEntityInWorld(ewb);
        }
        if(entity.getAnimTick() > 10)
			entity.setAnimID(0);
    }

}
