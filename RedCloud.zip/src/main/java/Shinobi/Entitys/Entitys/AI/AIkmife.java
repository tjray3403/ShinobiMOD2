package Shinobi.Entitys.Entitys.AI;

import Shinobi.Entitys.Entitys.EntityShinUchiha;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.util.DamageSource;
import thehippomasterAPI.AnimationAPI.AIAnimation;

public class AIkmife extends AIAnimation {
	
	private EntityShinUchiha entityShinUchiha;
	private EntityLivingBase attackTarget;
	
	public AIkmife(EntityShinUchiha ShinUchiha) {
		super(ShinUchiha);
		entityShinUchiha = ShinUchiha;
		attackTarget = null;
	}
	
	public int getAnimID() {
		return 1;
	}
	
	public boolean isAutomatic() {
		return true;
	}
	
	public int getDuration() {
		return 100;
	}
	
	public void startExecuting() {
		super.startExecuting();
		attackTarget = entityShinUchiha.getAttackTarget();
	}
	
	public void updateTask() {
		if(entityShinUchiha.getAnimTick() < 14)
			entityShinUchiha.getLookHelper().setLookPositionWithEntity(attackTarget, 30F, 30F);
		if(entityShinUchiha.getAnimTick() == 14 && attackTarget != null)
			attackTarget.attackEntityFrom(DamageSource.causeMobDamage(entityShinUchiha), 30);
	}
}
