package Shinobi.Entitys.Entitys.AI;

import Shinobi.Entitys.Entitys.EntityUchihaShin;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.util.DamageSource;
import thehippomasterAPI.AnimationAPI.AIAnimation;

public class AIslice extends AIAnimation {
	
	private EntityUchihaShin entityUchihaShin;
	private EntityLivingBase attackTarget;
	
	public AIslice(EntityUchihaShin UchihaShin) {
		super(UchihaShin);
		entityUchihaShin = UchihaShin;
		attackTarget = null;
	}
	
	public int getAnimID() {
		return 1;
	}
	
	public boolean isAutomatic() {
		return true;
	}
	
	public int getDuration() {
		return 100;
	}
	
	public void startExecuting() {
		super.startExecuting();
		attackTarget = entityUchihaShin.getAttackTarget();
	}
	
	public void updateTask() {
		if(entityUchihaShin.getAnimTick() < 14)
			entityUchihaShin.getLookHelper().setLookPositionWithEntity(attackTarget, 30F, 30F);
		if(entityUchihaShin.getAnimTick() == 14 && attackTarget != null)
			attackTarget.attackEntityFrom(DamageSource.causeMobDamage(entityUchihaShin), 35);
	}
}
