package Shinobi.Entitys.Entitys.AI;

import Shinobi.Entitys.Entitys.EntityHidanCurse;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.util.DamageSource;
import thehippomasterAPI.AnimationAPI.AIAnimation;

public class AIstab extends AIAnimation {
	
	private EntityHidanCurse entityHidancurse;
	private EntityLivingBase attackTarget;
	
	public AIstab(EntityHidanCurse hidan) {
		super(hidan);
		entityHidancurse = hidan;
		attackTarget = null;
	}
	
	public int getAnimID() {
		return 1;
	}
	
	public boolean isAutomatic() {
		return true;
	}
	
	public int getDuration() {
		return 30;
	}
	
	public void startExecuting() {
		super.startExecuting();
		attackTarget = entityHidancurse.getAttackTarget();
	}
	
	public void updateTask() {
		if(entityHidancurse.getAnimTick() < 14)
			entityHidancurse.getLookHelper().setLookPositionWithEntity(attackTarget, 30F, 30F);
		if(entityHidancurse.getAnimTick() == 14 && attackTarget != null)
			attackTarget.attackEntityFrom(DamageSource.causeMobDamage(entityHidancurse), 9);
	}
}
