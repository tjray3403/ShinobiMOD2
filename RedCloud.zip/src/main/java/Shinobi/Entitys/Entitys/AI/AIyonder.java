 package Shinobi.Entitys.Entitys.AI;

import Shinobi.Entitys.Entitys.EntityKakuzu3;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.util.DamageSource;
import thehippomasterAPI.AnimationAPI.AIAnimation;

public class AIyonder extends AIAnimation {
	
	private EntityKakuzu3 entityKakuzu3;
	private EntityLivingBase attackTarget;
	
	public AIyonder(EntityKakuzu3 Kakuzu3) {
		super(Kakuzu3);
		entityKakuzu3 = Kakuzu3;
		attackTarget = null;
	}
	
	public int getAnimID() {
		return 1;
	}
	
	public boolean isAutomatic() {
		return true;
	}
	
	public int getDuration() {
		return 30;
	}
	
	public void startExecuting() {
		super.startExecuting();
		attackTarget = entityKakuzu3.getAttackTarget();
	}
	
	public void updateTask() {
		if(entityKakuzu3.getAnimTick() < 14)
			entityKakuzu3.getLookHelper().setLookPositionWithEntity(attackTarget, 30F, 30F);
		if(entityKakuzu3.getAnimTick() == 14 && attackTarget != null)
			attackTarget.attackEntityFrom(DamageSource.causeMobDamage(entityKakuzu3), 30);
	}
}
