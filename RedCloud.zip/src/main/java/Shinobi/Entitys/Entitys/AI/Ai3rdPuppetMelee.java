package Shinobi.Entitys.Entitys.AI;

import java.util.List;

import Shinobi.ShinobiMod;
import Shinobi.Entitys.Entitys.Entity3rdKazekagePuppet;
import Shinobi.Entitys.Entitys.EntityKakuzu;
import Shinobi.Entitys.Entitys.EntitySasoriHiruko;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.potion.PotionEffect;
import net.minecraft.util.DamageSource;
import net.minecraft.util.Vec3;
import thehippomasterAPI.AnimationAPI.AIAnimation;

public class Ai3rdPuppetMelee extends AIAnimation {
	
	private Entity3rdKazekagePuppet entitypup;
	private EntityLivingBase attackTarget;
	private double speed;
	
	public Ai3rdPuppetMelee(Entity3rdKazekagePuppet pup, float spd) {
		super(pup);
		entitypup = pup;
		attackTarget = null;
		speed = spd;
	}
	
	public boolean isAutomatic() {

		return false;
	}

	public int getAnimID() {
		return 1;
	}
	
	public int getDuration() {
		return 30;
	}
	
	public void startExecuting() {
		super.startExecuting();
		attackTarget = entitypup.getAttackTarget();
		//entitypup.getNavigator().clearPathEntity();
	}
	
	
	public boolean shouldAnimate(){
		EntityLivingBase AITarget = entitypup.getAttackTarget();
		if (AITarget == null || AITarget.isDead) return false;
		if (entitypup.getDistanceSqToEntity(AITarget) > 4D){
				return false;
		}
		return entitypup.getAnimID() == 0;
		
	}
	
	public void resetTask() {
		super.resetTask();
	}
	
	
	public void updateTask() {
	//	double d0 = entityHir.getDistanceSq(attackTarget.posX, attackTarget.boundingBox.minY, attackTarget.posZ);
		//double d1 = (double)(this.entityHir.width * 2.0F * this.entityHir.width * 2.0F + attackTarget.width);
		//	entitypup.getLookHelper().setLookPositionWithEntity(attackTarget, 30F, 30F);
		//	entitypup.getNavigator().tryMoveToEntityLiving(attackTarget, speed);
		if(entitypup.getAnimTick() == 7 && attackTarget != null){

		double offsetX = Math.cos(entitypup.rotationYaw) * 2;
		double offsetZ = Math.sin(entitypup.rotationYaw) * 2;;
		List<EntityLivingBase> Entities = entitypup.worldObj.getEntitiesWithinAABB(EntityLivingBase.class, entitypup.boundingBox.getOffsetBoundingBox(offsetX, 0, offsetZ).expand(2.0, 2, 2.0));
		for (EntityLivingBase ent : Entities){
			if (ent == entitypup) continue;
			ent.attackEntityFrom(DamageSource.causeMobDamage(entitypup), 40);
			ent.addPotionEffect(new PotionEffect(ShinobiMod.SPoison.id, 900, 1));
		}
		}
		

	}

	
	



	
}