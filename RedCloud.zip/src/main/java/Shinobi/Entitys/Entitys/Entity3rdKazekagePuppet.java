package Shinobi.Entitys.Entitys;

import java.util.List;

import Shinobi.Entitys.EntityPuppet;
import Shinobi.Entitys.Entitys.AI.AI3rdPuppetArmsATtack;
import Shinobi.Entitys.Entitys.AI.AI3rdPuppetMagnetStyle;
import Shinobi.Entitys.Entitys.AI.AIFollowEntity;
import Shinobi.Entitys.Entitys.AI.AITeleportToEntity;
import Shinobi.Entitys.Entitys.AI.Ai3rdPuppetMelee;
import Shinobi.Entitys.Projectiles.EntityMagnetCube;
import Shinobi.Entitys.Projectiles.EntityMagnetSpread;
import Shinobi.Entitys.Projectiles.EntityMagnetTriangle;
import Shinobi.Entitys.Projectiles.EntityPuppetArmattack;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLiving;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.SharedMonsterAttributes;
import net.minecraft.entity.ai.EntityAIAttackOnCollide;
import net.minecraft.entity.ai.EntityAIAvoidEntity;
import net.minecraft.entity.ai.EntityAIBase;
import net.minecraft.entity.ai.EntityAIHurtByTarget;
import net.minecraft.entity.ai.EntityAILeapAtTarget;
import net.minecraft.entity.ai.EntityAILookIdle;
import net.minecraft.entity.ai.EntityAINearestAttackableTarget;
import net.minecraft.entity.ai.EntityAIOpenDoor;
import net.minecraft.entity.ai.EntityAISwimming;
import net.minecraft.entity.monster.EntityMob;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.util.DamageSource;
import net.minecraft.world.World;
import thehippomasterAPI.AnimationAPI.IAnimatedEntity;

public class Entity3rdKazekagePuppet extends EntityMob implements IAnimatedEntity {
	
	
	
	World world = null;
	private int animID;
	private int animTick;
	public int counter = 1;
	public Entity3rdKazekagePuppet(World par1World) {
        super(par1World);
        this.getNavigator().setBreakDoors(true);
        this.tasks.addTask(5, new Ai3rdPuppetMelee(this, 0.5F));
		this.tasks.addTask(5, new AI3rdPuppetArmsATtack(this));
		this.tasks.addTask(6, new AIFollowEntity(this, 1.5D));
		this.tasks.addTask(5, new AI3rdPuppetMagnetStyle(this));
        this.tasks.addTask(1, new EntityAISwimming(this));
        this.tasks.addTask(3, new EntityAILeapAtTarget(this, 0.4F));
        this.tasks.addTask(4, new EntityAIAttackOnCollide(this, 1.0D, true));
        this.tasks.addTask(4, new EntityAIOpenDoor(this, true));
        this.tasks.addTask(9, new EntityAILookIdle(this));

    }

    

    protected void applyEntityAttributes() {
        super.applyEntityAttributes();
        this.getEntityAttribute(SharedMonsterAttributes.maxHealth).setBaseValue(2000.0D);
        this.getEntityAttribute(SharedMonsterAttributes.followRange).setBaseValue(40.0D);
        this.getEntityAttribute(SharedMonsterAttributes.movementSpeed).setBaseValue(0.4D);
        this.getEntityAttribute(SharedMonsterAttributes.attackDamage).setBaseValue(10.0D);
    }

   
    
    public boolean attackEntityFrom(DamageSource par1DamageSource, float par2) {
        if (!super.attackEntityFrom(par1DamageSource, par2)) {
            return false;
        } else {
            EntityLivingBase entitylivingbase = this.getAttackTarget();

            System.out.println(entitylivingbase);

            if (entitylivingbase == null && this.getEntityToAttack() instanceof EntityLivingBase) {
                entitylivingbase = (EntityLivingBase) this.getEntityToAttack();
            }

            if (entitylivingbase == null && par1DamageSource.getEntity() instanceof EntityLivingBase) {
                entitylivingbase = (EntityLivingBase) par1DamageSource.getEntity();
            }

            this.setAttackTarget(entitylivingbase);

            return true;
        }
    }

    /**
     * Returns true if the newer Entity AI code should be run
     */
    protected boolean isAIEnabled() {
        return true;
    }

 
   
    
    


    @Override
	public void onLivingUpdate() {
		super.onLivingUpdate();
		this.stepHeight=50f;
		this.fallDistance = 0f;
		double offsetX = Math.cos(this.rotationYaw) * 2;
		double offsetZ = Math.sin(this.rotationYaw) * 2;
		List<EntityLivingBase> Entities = this.worldObj.getEntitiesWithinAABB(EntitySasori.class, this.boundingBox.getOffsetBoundingBox(offsetX, 0, offsetZ).expand(25, 25, 25));
		for (EntityLivingBase ent : Entities){
			if (ent == this) continue;
		//EntityPlayer ep = Minecraft.getMinecraft().thePlayer;
		EntityLivingBase elb = ((EntityLiving)ent).getAttackTarget();
			this.setAttackTarget(elb);
		
		}
		
		if(Entities.isEmpty()) {
			this.setDead();
		}
		 
		counter++;
		if(counter==75){
			counter = 1;
		}
		
		if(counter==74){
			
		
		}
		
	}
    
    protected void onDeathUpdate() {
   for (int i = 0; i < 20; ++i) {
                double d0 = this.rand.nextGaussian() * 0.02D;
                double d1 = this.rand.nextGaussian() * 0.02D;
                double d2 = this.rand.nextGaussian() * 0.02D;
                this.worldObj.spawnParticle("explode", this.posX + (double) (this.rand.nextFloat() * this.width * 2.0F) - (double) this.width, this.posY + (double) (this.rand.nextFloat() * this.height), this.posZ + (double) (this.rand.nextFloat() * this.width * 2.0F) - (double) this.width, d0, d1, d2);
            }
        }
    

	public void setAnimID(int id) {
		animID = id;
	}

	public void setAnimTick(int tick) {
		animTick = tick;
	}

	public int getAnimID() {
		return animID;
	}

	public int getAnimTick() {
		return animTick;
	}
	
	public void onUpdate() {
		super.onUpdate();
		//increment the animTick if there is an animation playing
		if(animID != 0) animTick++;
	}
	
	public void writeEntityToNBT(NBTTagCompound nbt) {
	       super.writeEntityToNBT(nbt);
	       nbt.setInteger("counter", this.counter);
	     
	       
	   }

	   /**
	    * (abstract) Protected helper method to read subclass entity data from NBT.
	    */
	   public void readEntityFromNBT(NBTTagCompound nbtt) {
	       super.readEntityFromNBT(nbtt);
	           this.counter = nbtt.getInteger("counter");
	         

	   }

	
	

	   
}

