package Shinobi.Entitys.Entitys;

import java.util.Iterator;
import java.util.List;

import Shinobi.Entitys.EntityDeathPos;
import Shinobi.Entitys.EntityFlyingNinja;
import net.minecraft.client.Minecraft;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLiving;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.SharedMonsterAttributes;
import net.minecraft.entity.ai.EntityAIAttackOnCollide;
import net.minecraft.entity.ai.EntityAINearestAttackableTarget;
import net.minecraft.entity.ai.EntityAIWander;
import net.minecraft.entity.monster.EntityBlaze;
import net.minecraft.entity.monster.EntityGhast;
import net.minecraft.entity.passive.EntityPig;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.util.DamageSource;
import net.minecraft.world.World;

public class EntityClayBird extends EntityFlyingNinja {

	private int var = 0;
	private int flytimer;
	private int tix = 0;


	public EntityClayBird(World p_i1735_1_) {
		super(p_i1735_1_);
		this.setSize(1, 1);
		
	}
	
	@Override
	protected void applyEntityAttributes() {
		super.applyEntityAttributes();
		getEntityAttribute(SharedMonsterAttributes.maxHealth).setBaseValue(3D); //max health
		getEntityAttribute(SharedMonsterAttributes.knockbackResistance).setBaseValue(5.0D); //move speed
	 	getEntityAttribute(SharedMonsterAttributes.followRange).setBaseValue(100.0D);
		//if (this.getEntityAttribute(SharedMonsterAttributes.attackDamage) != null)
			//this.getEntityAttribute(SharedMonsterAttributes.attackDamage).setBaseValue(25.0D);
		
	}
	
	
	
	public boolean isAIEnabled() {
		return false;
	}
	
	
	
	public void onLivingUpdate() {
		super.onLivingUpdate();
		int i = (int) this.posX;
		int j = (int) this.posY;
		int k = (int) this.posZ;
		tix++;
		this.fly=true;
		EntityDeidara deidara = new EntityDeidara(worldObj);
		double offsetX = Math.cos(this.rotationYaw) * 2;
		double offsetZ = Math.sin(this.rotationYaw) * 2;
		List<EntityLivingBase> Entities = this.worldObj.getEntitiesWithinAABB(EntityDeidara.class, this.boundingBox.getOffsetBoundingBox(offsetX, 0, offsetZ).expand(10, 10, 10));
		for (EntityLivingBase ent : Entities){
			if (ent == this) continue;
		//EntityPlayer ep = Minecraft.getMinecraft().thePlayer;
		EntityLivingBase elb = ((EntityLiving)ent).getAttackTarget();
			this.setAttackTarget(elb);
		
		}
		 
		double offsetX1 = Math.cos(this.rotationYaw) * 2;
		double offsetZ1 = Math.sin(this.rotationYaw) * 2;
		List<EntityLivingBase> Entities1 = this.worldObj.getEntitiesWithinAABB(EntityLivingBase.class, this.boundingBox.getOffsetBoundingBox(offsetX1, 0, offsetZ1).expand(1.5, 1.5, 1.5));
		for (EntityLivingBase ent1 : Entities1){
			if (ent1 == this.getAttackTarget()) continue;
		//EntityPlayer ep = Minecraft.getMinecraft().thePlayer;
			if(tix>20 && this.getAttackTarget()!=null && this.getDistanceToEntity(this.getAttackTarget())<3){
			this.worldObj.createExplosion(this, this.posX, this.posY, this.posZ, 2F, true);
			this.setDead();
			}
		}
		
		
		
	}

	
	
	
	public int getFlyTimer() {
		// TODO Auto-generated method stub
		return flytimer;
	}
	
	
    public void writeEntityToNBT(NBTTagCompound nbt)
    {
        super.writeEntityToNBT(nbt);
        nbt.setInteger("tix", this.tix);
    }

    
    public void readEntityFromNBT(NBTTagCompound nbtt)
    {
        super.readEntityFromNBT(nbtt);
        this.tix = nbtt.getInteger("tix");
        
    }
	
		
}
