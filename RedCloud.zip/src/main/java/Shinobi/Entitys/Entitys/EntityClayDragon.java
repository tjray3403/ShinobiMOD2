package Shinobi.Entitys.Entitys;

import java.util.Iterator;
import java.util.List;

import Shinobi.Entitys.EntityDeathPos;
import Shinobi.Entitys.EntityDragonDragon;
import Shinobi.Entitys.EntityFlyingNinja;
import Shinobi.Entitys.Projectiles.EntityC2;
import Shinobi.Entitys.Projectiles.EntityC3;
import Shinobi.Entitys.Projectiles.EntityC4;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLiving;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.SharedMonsterAttributes;
import net.minecraft.entity.ai.EntityAIAttackOnCollide;
import net.minecraft.entity.ai.EntityAINearestAttackableTarget;
import net.minecraft.entity.ai.EntityAIWander;
import net.minecraft.entity.monster.EntityBlaze;
import net.minecraft.entity.monster.EntityGhast;
import net.minecraft.entity.passive.EntityPig;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.DamageSource;
import net.minecraft.world.World;

public class EntityClayDragon extends EntityDragonDragon {

	private int var = 0;
	public boolean onG = false;
	private int flytimer;


	public EntityClayDragon(World p_i1735_1_) {
		super(p_i1735_1_);
		this.setSize(5, 5);
		
	}
	
	@Override
	protected void applyEntityAttributes() {
		super.applyEntityAttributes();
		getEntityAttribute(SharedMonsterAttributes.maxHealth).setBaseValue(750D); //max health
		getEntityAttribute(SharedMonsterAttributes.knockbackResistance).setBaseValue(5.0D); //move speed
		getEntityAttribute(SharedMonsterAttributes.followRange).setBaseValue(100.0D);
		//if (this.getEntityAttribute(SharedMonsterAttributes.attackDamage) != null)
			//this.getEntityAttribute(SharedMonsterAttributes.attackDamage).setBaseValue(25.0D);
		
	}
	
	public boolean attackEntityFrom(DamageSource dmg, float flt) {
		
		Entity ent = dmg.getSourceOfDamage();
		if(ent instanceof EntityClaySpider)return false;
		if(ent instanceof EntityClayBird)return false;
		if(ent instanceof EntityC4)return false;
		if(ent instanceof EntityC2)return false;
		if(ent instanceof EntityC3)return false;
				
		return super.attackEntityFrom(dmg, flt);
		
	}
	
	public boolean isAIEnabled() {
		return false;
	}
	
	
	
	public void onLivingUpdate() {
		super.onLivingUpdate();
		int i = (int) this.posX;
		int j = (int) this.posY;
		int k = (int) this.posZ;
		
		EntityDeidara deidara = new EntityDeidara(worldObj);
		double offsetX = Math.cos(this.rotationYaw) * 2;
		double offsetZ = Math.sin(this.rotationYaw) * 2;;
		List<EntityLivingBase> Entities = this.worldObj.getEntitiesWithinAABB(EntityDeidara.class, this.boundingBox.getOffsetBoundingBox(offsetX, 0, offsetZ).expand(4, 3, 4));
		for (EntityLivingBase ent : Entities){
			if (ent == this) continue;
		this.fly=true;
		
		EntityLivingBase elb = ((EntityLiving)ent).getAttackTarget();
		this.setAttackTarget(elb);
		
		}
		if(deidara.getAttackTarget()!=null)
		//if(deidara.isEntityAlive() && !this.worldObj.isRemote) {
		var++;
		//if(this.var==10)deidara.attackEntityFrom(DamageSource.generic, 1);
		//	deidara.mountEntity(this);
		//}
		if(this.fly==true)flytimer++;
		if(this.fly==false)flytimer=0;
	}

	public int getFlyTimer() {
		// TODO Auto-generated method stub
		return flytimer;
	}
	
	
	
		
}
