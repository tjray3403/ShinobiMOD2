package Shinobi.Entitys.Entitys;

import java.util.Iterator;
import java.util.List;

import Shinobi.Entitys.EntityDeathPos;
import Shinobi.Entitys.EntityFlyingNinja;
import net.minecraft.client.Minecraft;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLiving;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.SharedMonsterAttributes;
import net.minecraft.entity.ai.EntityAIAttackOnCollide;
import net.minecraft.entity.ai.EntityAINearestAttackableTarget;
import net.minecraft.entity.ai.EntityAIWander;
import net.minecraft.entity.monster.EntityBlaze;
import net.minecraft.entity.monster.EntityGhast;
import net.minecraft.entity.passive.EntityBat;
import net.minecraft.entity.passive.EntityPig;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.util.DamageSource;
import net.minecraft.world.World;

public class EntityCrow extends EntityBat {

	private int var = 0;
	private int flytimer;
	private int tix = 0;


	public EntityCrow(World p_i1735_1_) {
		super(p_i1735_1_);
		this.setSize(1, 1);
		
	}
	
	@Override
	protected void applyEntityAttributes() {
		super.applyEntityAttributes();
		getEntityAttribute(SharedMonsterAttributes.maxHealth).setBaseValue(3D); //max health
		getEntityAttribute(SharedMonsterAttributes.knockbackResistance).setBaseValue(5.0D); //move speed
	 	getEntityAttribute(SharedMonsterAttributes.followRange).setBaseValue(100.0D);
		//if (this.getEntityAttribute(SharedMonsterAttributes.attackDamage) != null)
			//this.getEntityAttribute(SharedMonsterAttributes.attackDamage).setBaseValue(25.0D);
		
	}
	
	
	public void onLivingUpdate() {
		super.onLivingUpdate();
		double offsetX = Math.cos(this.rotationYaw) * 2;
		double offsetZ = Math.sin(this.rotationYaw) * 2;
		List<EntityLivingBase> Entities = this.worldObj.getEntitiesWithinAABB(EntityItachi.class, this.boundingBox.getOffsetBoundingBox(offsetX, 0, offsetZ).expand(5, 5, 5));
		for (EntityLivingBase ent : Entities){
			if (ent == this) continue;
		double d0 = ent.posX - this.posX;
        double d1 = ent.posY - this.posY;
        double d2 = ent.posZ - this.posZ;
        double d3 = d0 * d0 + d1 * d1 + d2 * d2;
        
        this.motionX += d0 / d3 * 0.1D;
        this.motionY += d1 / d3 * 0.1D;
        this.motionZ += d2 / d3 * 0.1D;
		tix++;
		if(tix==90) {
			this.setDead();
		}
		
		
		}
		
	}
		
}
