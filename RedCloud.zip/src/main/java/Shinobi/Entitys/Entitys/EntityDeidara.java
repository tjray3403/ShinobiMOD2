package Shinobi.Entitys.Entitys;

import java.util.List;

import Shinobi.Entitys.EntityDeathPos;
import Shinobi.Entitys.EntityFlyingNinja;
import Shinobi.Entitys.EntityNinja;
import Shinobi.Entitys.Entitys.AI.AIC2;
import Shinobi.Entitys.Entitys.AI.AIC4;
import Shinobi.Entitys.Entitys.AI.AIDeathpos;
import Shinobi.Entitys.Entitys.AI.AIExplosionRelease;
import Shinobi.Entitys.Entitys.AI.AIFlying;
import Shinobi.Entitys.Entitys.AI.AIMoveToDeathpos;
import Shinobi.Entitys.Entitys.AI.AISasoriBlast;
import Shinobi.Entitys.Entitys.AI.AIScytheBlock;
import Shinobi.Entitys.Entitys.AI.AIScytheSpeedAtack;
import Shinobi.Entitys.Entitys.AI.AIScytheSpinAtack;
import Shinobi.Entitys.Entitys.AI.AIScytheSwing;
import Shinobi.Entitys.Entitys.AI.AIScytheUpperCut;
import Shinobi.Entitys.Projectiles.EntityC2;
import Shinobi.Entitys.Projectiles.EntityC3;
import Shinobi.Entitys.Projectiles.EntityC4;
import Shinobi.Entitys.Projectiles.EntityFireBlast;
import Shinobi.Entitys.Projectiles.EntityFireJet;
import net.minecraft.client.Minecraft;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityList;
import net.minecraft.entity.EntityLiving;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.SharedMonsterAttributes;
import net.minecraft.entity.ai.EntityAIAvoidEntity;
import net.minecraft.entity.ai.EntityAIWander;
import net.minecraft.entity.monster.EntityMob;
import net.minecraft.entity.passive.EntityPig;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.util.DamageSource;
import net.minecraft.util.EntityDamageSource;
import net.minecraft.util.EntityDamageSourceIndirect;
import net.minecraft.util.MathHelper;
import net.minecraft.world.World;
import thehippomasterAPI.AnimationAPI.AnimationAPI;
import thehippomasterAPI.AnimationAPI.IAnimatedEntity;

public class EntityDeidara extends EntityNinja implements IAnimatedEntity {
	
	
	
	public int C2 = 0;
	public int dp = 0;
	public int var = 0;
	public int C4 = 0;
	public int C3 = 0; 
	public boolean bomb = false;
	
	public EntityDeidara(World world) {
		super(world);
		
		this.tasks.addTask(8, new AIExplosionRelease(this));
		this.tasks.addTask(8, new AIC2(this));
		this.tasks.addTask(8, new AIC4(this));
	}
	
	@Override
	protected void applyEntityAttributes() {
		super.applyEntityAttributes();
		getEntityAttribute(SharedMonsterAttributes.maxHealth).setBaseValue(7000); //max health
		getEntityAttribute(SharedMonsterAttributes.movementSpeed).setBaseValue(0.35D); //move speed
		getEntityAttribute(SharedMonsterAttributes.knockbackResistance).setBaseValue(5.0D); //move speed
		getEntityAttribute(SharedMonsterAttributes.followRange).setBaseValue(100.0D);
		if (this.getEntityAttribute(SharedMonsterAttributes.attackDamage) != null)
			this.getEntityAttribute(SharedMonsterAttributes.attackDamage).setBaseValue(1.0D);
		
	}
	
	
	
	public boolean isAIEnabled() {
		return true;
	}
	
	
	public boolean attackEntityFrom(DamageSource dmg, float flt) {
		
		Entity ent = dmg.getSourceOfDamage();
		if(ent instanceof EntityClaySpider)return false;
		if(ent instanceof EntityClayBird)return false;
		if(ent instanceof EntityC4)return false;
		if(ent instanceof EntityC2)return false;
		if(ent instanceof EntityC3)return false;
				
		return super.attackEntityFrom(dmg, flt);
		
	}

	
	
	public void onLivingUpdate() {
		super.onLivingUpdate();
		int i = (int) this.posX;
		int j = (int) this.posY;
		int k = (int) this.posZ;
	
		double offsetX = Math.cos(this.rotationYaw) * 2;
		double offsetZ = Math.sin(this.rotationYaw) * 2;
		List<EntityLivingBase> Entities = this.worldObj.getEntitiesWithinAABB(EntityClayDragon.class, this.boundingBox.getOffsetBoundingBox(offsetX, 0, offsetZ).expand(4, 3, 4));
		for (EntityLivingBase ent : Entities){
			if (ent == this) continue;
		
		this.mountEntity(ent);
		EntityLivingBase elb = this.getAttackTarget();
		//EntityLivingBase ert = this.getAttackTarget();
		C2++;
		
		
		if(ent.getHealth()<400){
		C4++;
		if (!worldObj.isRemote && C4==175) {
			Entity sentity = EntityList.createEntityByName("34C4", worldObj);
			if (sentity != null) {
				sentity.setLocationAndAngles(elb.posX, j, elb.posZ, worldObj.rand.nextFloat() * 360F, 0.0F);
				worldObj.spawnEntityInWorld(sentity);
				((EntityLiving) sentity).playLivingSound();
			}
		} 
		}
		
		if(this.getHealth()<2000 && ent.getHealth()<100) {
		
			C3++;
			if(C3==100) {
				if (!worldObj.isRemote) {
					Entity sentity = EntityList.createEntityByName("34C3", worldObj);
					if (sentity != null) {
						sentity.setLocationAndAngles(elb.posX, j, elb.posZ, worldObj.rand.nextFloat() * 360F, 0.0F);
						worldObj.spawnEntityInWorld(sentity);

					}
				} 
			}
				
			
		}
			
		
		
		}
		
		
		
		if(this.getHealth()<20 && this.getHealth()>10) {
			var++;
			
			
				this.bomb=true;
				if(var==100){
		        worldObj.createExplosion(this, this.posX, this.posY, this.posZ, 100F, true);
				this.setHealth(0);
				}
				
			}
		
		
		if(this.getHealth()<2000) {
			dp++;
			if(dp==1) {
				if (!worldObj.isRemote) {
					Entity sentity = EntityList.createEntityByName("34ClayDragon", worldObj);
					if (sentity != null) {
						sentity.setLocationAndAngles(i, j, k, worldObj.rand.nextFloat() * 360F, 0.0F);
						worldObj.spawnEntityInWorld(sentity);
						((EntityLiving) sentity).playLivingSound();
					}
				} 
			}
			
		}
		
		
		
		
		
		
		
		
	}

	
	public void writeEntityToNBT(NBTTagCompound nbt) {
	       super.writeEntityToNBT(nbt);
	       nbt.setInteger("C2", this.C2);
	       nbt.setInteger("C3", this.C3);
	       nbt.setInteger("C4", this.C4);
	       nbt.setInteger("var", this.var);
	       nbt.setInteger("dp", this.dp);
	   }

	   /**
	    * (abstract) Protected helper method to read subclass entity data from NBT.
	    */
	   public void readEntityFromNBT(NBTTagCompound nbtt) {
	       super.readEntityFromNBT(nbtt);
           this.var = nbtt.getInteger("var");
           this.C2 = nbtt.getInteger("C2");
           this.C3 = nbtt.getInteger("C3");
           this.C4 = nbtt.getInteger("C4");
	       this.dp = nbtt.getInteger("dp");
	           
	   }
	
    }
	
	

