package Shinobi.Entitys.Entitys;

import java.util.List;

import Shinobi.Entitys.EntityDeathPos;
import Shinobi.Entitys.EntityNinja;
import Shinobi.Entitys.Entitys.AI.AIDeathpos;
import Shinobi.Entitys.Entitys.AI.AIMoveToDeathpos;
import Shinobi.Entitys.Entitys.AI.AIScytheBlock;
import Shinobi.Entitys.Entitys.AI.AIScytheSpeedAtack;
import Shinobi.Entitys.Entitys.AI.AIScytheSpinAtack;
import Shinobi.Entitys.Entitys.AI.AIScytheSwing;
import Shinobi.Entitys.Entitys.AI.AIScytheUpperCut;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityList;
import net.minecraft.entity.EntityLiving;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.SharedMonsterAttributes;
import net.minecraft.entity.monster.EntityMob;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.util.DamageSource;
import net.minecraft.util.EntityDamageSource;
import net.minecraft.util.EntityDamageSourceIndirect;
import net.minecraft.world.World;
import thehippomasterAPI.AnimationAPI.AnimationAPI;
import thehippomasterAPI.AnimationAPI.IAnimatedEntity;

public class EntityHidan extends EntityNinja implements IAnimatedEntity {
	
	public boolean cursed = false;
	//public boolean cursed = false;
	//World world;
	private EntityDeathPos dps;
	private int animID;
	private int animTick;
	private int dp = 0; 
	int i = (int) this.posX;
	int j = (int) this.posY;
	int k = (int) this.posZ;
	private EntityLivingBase targetTarget;
	private boolean hascursed;
	private boolean isbeinghurt;
	private int counter = 0;
	//public boolean attackEntAsM;
	//public boolean attckEntfrm;
	public int plus=0;
	public boolean func21;
	private int tickx = 50;
	public EntityHidan(World world) {
		super(world);
		animID = 0;
		animTick = 0;
		this.tasks.addTask(7, new AIScytheSwing(this));
		this.tasks.addTask(7, new AIScytheSpinAtack(this));
		this.tasks.addTask(6, new AIScytheBlock(this));
		this.tasks.addTask(7, new AIMoveToDeathpos(this, 0.4F));
		this.tasks.addTask(7, new AIDeathpos(this));
		this.tasks.addTask(7, new AIScytheUpperCut(this));
		this.tasks.addTask(7, new AIScytheSpeedAtack(this));
		 
		
	}
	
	@Override
	protected void applyEntityAttributes() {
		super.applyEntityAttributes();
		getEntityAttribute(SharedMonsterAttributes.maxHealth).setBaseValue(7000D); //max health
		getEntityAttribute(SharedMonsterAttributes.movementSpeed).setBaseValue(0.35D); //move speed
		getEntityAttribute(SharedMonsterAttributes.knockbackResistance).setBaseValue(5.0D); //move speed
		getEntityAttribute(SharedMonsterAttributes.followRange).setBaseValue(100.0D);
		if (this.getEntityAttribute(SharedMonsterAttributes.attackDamage) != null)
			this.getEntityAttribute(SharedMonsterAttributes.attackDamage).setBaseValue(25.0D);
		
	}
	
	
	@Override
	public boolean isAIEnabled() {
		return true;
	}
	
	
	public boolean attackEntityFrom(DamageSource dmg, float flt) {
		
		if(dmg instanceof EntityDamageSource) {
			if((Math.random() * 100) <= 35){
			func21 = true;
			return false;
		}}
		
			
		return super.attackEntityFrom(dmg, flt);
		
	}

	public void onDeath(DamageSource dsource) {
		super.onDeath(dsource);
		int i = (int) this.posX;
		int j = (int) this.posY;
		int k = (int) this.posZ;
		Entity entity = this;
		
		if (!worldObj.isRemote) {
			Entity sentity = EntityList.createEntityByName("34HurtHidan", worldObj);
			if (sentity != null) {
				sentity.setLocationAndAngles(i, j, k, worldObj.rand.nextFloat() * 360F, 0.0F);
				worldObj.spawnEntityInWorld(sentity);
				((EntityLiving) sentity).playLivingSound();
			}
		} 
		}

	
	
	
	public void onLivingUpdate() {
		super.onLivingUpdate();
		int i = (int) this.posX;
		int j = (int) this.posY;
		int k = (int) this.posZ;
		EntityHidan entity = this;
		EntityLivingBase en = this.getAttackTarget();
		ratee();
		this.fireResistance = 10;
		
		if(plus>=1) plus=0;
		
		if(this.getHealth()<800) {
			dp++;
			}
		//if(this.getHealth())
		if(dp==1) {
			cursed = true;
			//if(this.getAttackTarget() != null)
			//this.worldObj.setBlock(i, j, k, ShinobiMod.blockDeathPossesion);
			if (!worldObj.isRemote) {
				Entity sentity = EntityList.createEntityByName("34Dp", worldObj);
				if (sentity != null) {
					sentity.setLocationAndAngles(i, j, k, worldObj.rand.nextFloat() * 360F, 0.0F);
					worldObj.spawnEntityInWorld(sentity);
					((EntityLiving) sentity).playLivingSound();
				}
			} 
		}
		if(this.getHealth()<500) {
			this.heal(2);
		}
		
		
			if(this.getHealth()<100) {
				cursed = false;
			}
			
			
			counter++;
			if(counter==7) {
				counter = 0;
			}
			
			
			
			}
	
		
	
	private void ratee() {
		
		if(func21==true)func21=false;
		
	}

	public int getcount() {
		return counter;
	}

	//@Override
	//public boolean attackEntityAsMob(Entity entity) {
		
	//	return attackEntAsM;
            
            
          //  }
	public void writeEntityToNBT(NBTTagCompound nbt) {
	       super.writeEntityToNBT(nbt);
	       nbt.setBoolean("cursed", this.cursed);
	       nbt.setBoolean("func21", this.func21);
	       nbt.setInteger("dp", this.dp);
	   }

	   /**
	    * (abstract) Protected helper method to read subclass entity data from NBT.
	    */
	   public void readEntityFromNBT(NBTTagCompound nbtt) {
	       super.readEntityFromNBT(nbtt);
           this.cursed = nbtt.getBoolean("cursed");
	           this.func21 = nbtt.getBoolean("func21");
	           this.dp = nbtt.getInteger("dp");
	           
	   }

	
	
}
