package Shinobi.Entitys.Entitys;

import Shinobi.Entitys.EntityFlyingNinja;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityAgeable;
import net.minecraft.entity.EntityCreature;
import net.minecraft.entity.EntityList;
import net.minecraft.entity.EntityLiving;
import net.minecraft.entity.SharedMonsterAttributes;
import net.minecraft.entity.ai.EntityAIFollowOwner;
import net.minecraft.entity.ai.EntityAIHurtByTarget;
import net.minecraft.entity.ai.EntityAILookIdle;
import net.minecraft.entity.ai.EntityAIOwnerHurtByTarget;
import net.minecraft.entity.ai.EntityAIOwnerHurtTarget;
import net.minecraft.entity.ai.EntityAISwimming;
import net.minecraft.entity.ai.EntityAITargetNonTamed;
import net.minecraft.entity.ai.EntityAIWander;
import net.minecraft.entity.monster.EntityMob;
import net.minecraft.entity.passive.EntitySheep;
import net.minecraft.entity.passive.EntityTameable;
import net.minecraft.util.DamageSource;
import net.minecraft.world.World;

public class EntityHidanHurt extends EntityFlyingNinja {

	private int regen = 2400;
	public EntityHidanHurt(World world) {
		super(world);
		
		//this.tasks.addTask(1, new EntityAILookIdle(this));
		
		
	}
	
	protected void applyEntityAttributes()
	{
		super.applyEntityAttributes();
		this.getEntityAttribute(SharedMonsterAttributes.maxHealth).setBaseValue(40.0F);
		this.getEntityAttribute(SharedMonsterAttributes.movementSpeed).setBaseValue(0.0F);
		this.getEntityAttribute(SharedMonsterAttributes.attackDamage).setBaseValue(1.0F);
	}
	
	protected boolean isAIenabled()
	{
		return true;
	}

	public void onLivingUpdate() {
		super.onLivingUpdate();
		regen--;
		int i = (int) this.posX;
		int j = (int) this.posY;
		int k = (int) this.posZ;
		if(regen==0) {
			if (!worldObj.isRemote) {
				Entity sentity = EntityList.createEntityByName("34Hidan", worldObj);
				if (sentity != null) {
					sentity.setLocationAndAngles(i, j, k, worldObj.rand.nextFloat() * 360F, 0.0F);
					worldObj.spawnEntityInWorld(sentity);
					((EntityLiving) sentity).playLivingSound();
				}
			} 
		}
		
	}
	
	


}
