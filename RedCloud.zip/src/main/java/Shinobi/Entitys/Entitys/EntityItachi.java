package Shinobi.Entitys.Entitys;

import java.util.List;
import java.util.Random;

import Shinobi.Entitys.EntityNinja;
import Shinobi.Entitys.Entitys.AI.AIAmaterasu;
import Shinobi.Entitys.Entitys.AI.AIFireKunai;
import Shinobi.Entitys.Entitys.AI.AIFireStyle;
import Shinobi.Entitys.Entitys.AI.AIKunai;
import Shinobi.Entitys.Projectiles.EntityGreatFireball;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityList;
import net.minecraft.entity.EntityLiving;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.SharedMonsterAttributes;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.potion.Potion;
import net.minecraft.potion.PotionEffect;
import net.minecraft.util.DamageSource;
import net.minecraft.util.Vec3;
import net.minecraft.world.World;
import thehippomasterAPI.AnimationAPI.IAnimatedEntity;

public class EntityItachi extends EntityNinja implements IAnimatedEntity {

	private int stareTimer;
	private boolean genjutsu=false;
	public int sharingan = 1;
	public int jts;
	private int sam;


	public EntityItachi(World var1) {
		super(var1);
		//this.setSize(1, 2.0F);
		this.tasks.addTask(5, new AIFireStyle(this));
		this.tasks.addTask(5, new AIKunai(this));
		this.tasks.addTask(5, new AIFireKunai(this));
		this.tasks.addTask(5, new AIAmaterasu(this));
		this.fireResistance = 500;
		
	}
	
	@Override
	protected void applyEntityAttributes() {
		super.applyEntityAttributes();
		getEntityAttribute(SharedMonsterAttributes.maxHealth).setBaseValue(7000); //max health
		getEntityAttribute(SharedMonsterAttributes.movementSpeed).setBaseValue(0.25D); //move speed
		getEntityAttribute(SharedMonsterAttributes.knockbackResistance).setBaseValue(0.0D); //move speed
		if (this.getEntityAttribute(SharedMonsterAttributes.attackDamage) != null)
			this.getEntityAttribute(SharedMonsterAttributes.attackDamage).setBaseValue(5.0D);
		
	}
	
	public boolean attackEntityFrom(DamageSource dmg, float flt) {
    
	Entity ent = dmg.getSourceOfDamage();
	 
	if (ent instanceof EntityGreatFireball){
		 return false;
	 }
	
	if (ent instanceof EntitySusanooItachi){
		 return false;
	 }
	
	Random rr = new Random();
	int ee = rr.nextInt(4);
	
	if (genjutsu==true){
	 
	int d = 0;
	d++;
	if(d==1){
	spawnCrow(this.posX, this.posY, this.posZ);
	spawnCrow(this.posX, this.posY, this.posZ);
	spawnCrow(this.posX, this.posY, this.posZ);
	spawnCrow(this.posX, this.posY, this.posZ);
	spawnCrow(this.posX, this.posY+1, this.posZ);
	spawnCrow(this.posX, this.posY+1, this.posZ);
	spawnCrow(this.posX, this.posY+1, this.posZ);
	spawnCrow(this.posX, this.posY+1, this.posZ);
	spawnCrow(this.posX, this.posY+2, this.posZ);
	spawnCrow(this.posX, this.posY+2, this.posZ);
	spawnCrow(this.posX, this.posY+2, this.posZ);
	spawnCrow(this.posX, this.posY+2, this.posZ);
	
	this.teleportRandomly(15);
	this.addPotionEffect(new PotionEffect(Potion.invisibility.id, 100, 100));
	}
	}
	
	return super.attackEntityFrom(dmg, flt) ;
    }


public void updateRiderPosition() {
	super.updateRiderPosition();
	this.riddenByEntity.setPosition(this.posX, this.posY, this.posZ);
	
}

	public void spawnCrow(double x, double y, double z) {
		if (!worldObj.isRemote) {
			Entity entity1 = EntityList.createEntityByName("34Crow", worldObj);
			if (entity1 != null) {
				entity1.setLocationAndAngles(x, y, z, this.worldObj.rand.nextFloat() * 360F, 0.0F);
				worldObj.spawnEntityInWorld(entity1);
				((EntityLiving) entity1).playLivingSound();
			}
		}
		
	}
	
	public void onLivingUpdate() {
		super.onLivingUpdate();
		findEntityforGenjutsu();
		double offsetX = Math.cos(this.rotationYaw) * 2;
		double offsetZ = Math.sin(this.rotationYaw) * 2;
		List<EntityLivingBase> Entities = this.worldObj.getEntitiesWithinAABB(EntitySusanooItachi.class, this.boundingBox.getOffsetBoundingBox(offsetX, 0, offsetZ).expand(5, 5, 5));
		for (EntityLivingBase ent : Entities){
			if (ent == this) continue;
		for (int ii = 0; ii < 20; ++ii) {
            double d0 = this.rand.nextGaussian() * 0.02D;
            double d1 = this.rand.nextGaussian() * 0.02D;
            double d2 = this.rand.nextGaussian() * 1.02D;
            this.worldObj.spawnParticle("reddust", this.posX + (double) (this.rand.nextFloat() * this.width * 2.0F) - (double) this.width, this.posY + (double) (this.rand.nextFloat() * this.height), this.posZ + (double) (this.rand.nextFloat() * this.width * 2.0F) - (double) this.width, 10, 0, 0);           
            //this.worldObj.spawnParticle("flame", this.posX + (double) (this.rand.nextFloat() * this.width * 2.0F) - (double) this.width, this.posY + (double) (this.rand.nextFloat() * this.height), this.posZ + (double) (this.rand.nextFloat() * this.width * 2.0F) - (double) this.width, 0, 0, 0);
		
            EntityLivingBase elb = ((EntityLiving)ent).getAttackTarget();
            if(elb!=null) {
			this.setAttackTarget(elb);
            }
            if(ent.isEntityAlive()) {
		this.setAbsorptionAmount(30);
		
		}
		else
		{
			this.setAbsorptionAmount(0);
		}
		
		}
		
		}
		
		//Genjutsu(this.getAttackTarget());
		EntityLivingBase ewr = this.getAttackTarget();
		int time = 20;
				
		int nn = rand.nextInt(5);
		jts=nn;
		
		if(this.getHealth()<4500) {
			this.sharingan=2;
		}
		
		if(this.getHealth()<450){
			this.sharingan=0;
			
			sam++;
			if(sam==1) {
			if (!worldObj.isRemote) {
				Entity entity1 = EntityList.createEntityByName("34ItachiSusanoo", worldObj);
				if (entity1 != null) {
					entity1.setLocationAndAngles(this.posX, this.posY, this.posZ, this.worldObj.rand.nextFloat() * 360F, 0.0F);
					worldObj.spawnEntityInWorld(entity1);
					((EntityLiving) entity1).playLivingSound();
				}
		}
			}
		}
	}
	
	protected Entity findEntityforGenjutsu()
    {
		double offsetX = Math.cos(this.rotationYaw) * 2;
		double offsetZ = Math.sin(this.rotationYaw) * 2;
		List<EntityLivingBase> Entities = this.worldObj.getEntitiesWithinAABB(EntityLivingBase.class, this.boundingBox.getOffsetBoundingBox(offsetX, 0, offsetZ).expand(5, 5, 5));
		for (EntityLivingBase ent : Entities){
			if (ent == this) continue;
			
        if (ent != null)
        {
            if (this.shouldAttack(ent))
            {

                if (this.stareTimer++ == 10)
                {
                	if(sharingan>=2) {
        				ent.addPotionEffect(new PotionEffect(2, 100, 15*20));
        				ent.addPotionEffect(new PotionEffect(18, 100, 15*20));
        				ent.addPotionEffect(new PotionEffect(9, 100, 15*20));
        				ent.addPotionEffect(new PotionEffect(20, 100, 17*20));

        			}
        			else
        			{
        			ent.addPotionEffect(new PotionEffect(2, 100, 15*20));
        			}
                    this.stareTimer = 0;
                    this.genjutsu = true;
                    return ent;
                }
            }
            else
            {
                this.stareTimer = 0;
                this.genjutsu = false;
            }
        }
		}
        return null;
    }

    /**
     * Checks to see if this enderman should be attacking this player
     */
    private boolean shouldAttack(EntityLivingBase p_70821_1_)
    {
        
        {
            Vec3 vec3 = p_70821_1_.getLook(1.0F).normalize();
            Vec3 vec31 = Vec3.createVectorHelper(this.posX - p_70821_1_.posX, this.boundingBox.minY + (double)(this.height / 2.0F) - (p_70821_1_.posY + (double)p_70821_1_.getEyeHeight()), this.posZ - p_70821_1_.posZ);
            double d0 = vec31.lengthVector();
            vec31 = vec31.normalize();
            double d1 = vec3.dotProduct(vec31);
            return d1 > 1.0D - 0.025D / d0 && p_70821_1_.canEntityBeSeen(this);
        }
    }
    
	
    public void writeEntityToNBT(NBTTagCompound nbt) {
	       super.writeEntityToNBT(nbt);
	      nbt.setInteger("stareTimer", stareTimer);
	      nbt.setBoolean("genjutsu", this.genjutsu);
	      nbt.setInteger("sharingan", sharingan);
	      nbt.setInteger("jutsu", jts);
	      nbt.setInteger("sam", sam);
	      
	   }

	   /**
	    * (abstract) Protected helper method to read subclass entity data from NBT.
	    */
	   public void readEntityFromNBT(NBTTagCompound nbtt) {
	       super.readEntityFromNBT(nbtt);
        this.stareTimer = nbtt.getInteger("stareTimer");
        this.genjutsu = nbtt.getBoolean("genjutsu");
        this.sharingan = nbtt.getInteger("sharingan");
        this.jts = nbtt.getInteger("jutsu");
        this.sam = nbtt.getInteger("sam");

        
	   }
	

}
