package Shinobi.Entitys.Entitys;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import Shinobi.Entitys.EntityEarthGrudgeFear;
import Shinobi.Entitys.EntityNinja;
import Shinobi.Entitys.Entitys.AI.AIDeathpos;
import Shinobi.Entitys.Entitys.AI.AIEarthGrudgeFear;
import Shinobi.Entitys.Entitys.AI.AIKakuzuFist;
import Shinobi.Entitys.Entitys.AI.AIKakuzuSmash;
import Shinobi.Entitys.Entitys.AI.AIKakuzuTwist;
import Shinobi.Entitys.Projectiles.EntityFireBlast;
import Shinobi.Entitys.Projectiles.EntityLightningBlast;
import Shinobi.Entitys.Projectiles.EntityWaterBlast;
import Shinobi.Entitys.Projectiles.EntityWindBlast;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityList;
import net.minecraft.entity.EntityLiving;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.SharedMonsterAttributes;
import net.minecraft.entity.monster.EntityMob;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.scoreboard.Team;
import net.minecraft.util.DamageSource;
import net.minecraft.util.EntityDamageSource;
import net.minecraft.util.EntityDamageSourceIndirect;
import net.minecraft.world.World;
import thehippomasterAPI.AnimationAPI.AnimationAPI;
import thehippomasterAPI.AnimationAPI.IAnimatedEntity;

public class EntityKakuzu extends EntityNinja implements IAnimatedEntity {
	
	
	
	//World world;
	private int animID;
	private int animTick;
	public int counter = 20;
	public int plus=0;
	private int tickx = 50;
	private int coun;
	private int counter2;
	public int kakuzu;
	public Team team;
	public boolean hasspawned = false;
	
	public EntityKakuzu(World world) {
		super(world);
		animID = 0;
		animTick = 0;
		this.tasks.addTask(7, new AIKakuzuSmash(this));
		this.tasks.addTask(7, new AIKakuzuFist(this));
		this.tasks.addTask(7, new AIKakuzuTwist(this));
		this.tasks.addTask(0, new AIEarthGrudgeFear(this));
		
		
	}
	
	@Override
	protected void applyEntityAttributes() {
		super.applyEntityAttributes();
		getEntityAttribute(SharedMonsterAttributes.maxHealth).setBaseValue(7000D); //max health
		getEntityAttribute(SharedMonsterAttributes.movementSpeed).setBaseValue(0.35D); //move speed
		getEntityAttribute(SharedMonsterAttributes.knockbackResistance).setBaseValue(5.0D); //move speed
		getEntityAttribute(SharedMonsterAttributes.followRange).setBaseValue(100.0D);
		if (this.getEntityAttribute(SharedMonsterAttributes.attackDamage) != null)
			this.getEntityAttribute(SharedMonsterAttributes.attackDamage).setBaseValue(25.0D);
		
	}
	
	
	@Override
	public boolean isAIEnabled() {
		return true;
	}
	

	public float getAbsorptionAmount() {
		return 7;
		
	}
	
	
	public Team getTeam()
    {
        return team;
    }
	
	public boolean attackEntityFrom(DamageSource dmg, float flt)
    {
	Entity ent = dmg.getSourceOfDamage();
	 
	 //EntityKakuzu entk = new EntityKakuzu(worldObj);
	if (ent instanceof EntityEarthGrudgeFear){
		 return false;
	 }
	
	if (ent instanceof EntityFireBlast){
		 return false;
	 }
	if (ent instanceof EntityLightningBlast){
		 return false;
	 }
	if (ent instanceof EntityWaterBlast){
		 return false;
	 }
	if (ent instanceof EntityWindBlast){
		 return false;
	 }
	return super.attackEntityFrom(dmg, flt) ;
    }
	
	public void onLivingUpdate() {
		super.onLivingUpdate();
		int i = (int) this.posX;
		int j = (int) this.posY;
		int k = (int) this.posZ;
		Entity entity = this;
		counter2--;
		
		if(counter2 == 0) {
			counter2 = 75;
		}
		if(counter2==1){
			this.heal(10);
		}
		
		if(this.getHealth()<5000) {
			kakuzu = 1;
		}
			if(this.getHealth()<=3000 && this.getAttackTarget()!=null ) {
			 counter--;
			 
			if(counter==1){
                 this.setAnimID(3);
                 AnimationAPI.sendAnimPacket(this, 3);
                 
			 }
                
			}
			
			if(this.getHealth()<1000 && this.getHealth()>100) {
				
				if (!worldObj.isRemote) {
					Entity entity1 = EntityList.createEntityByName("34Kakuzuthird", worldObj);
					if (entity1 != null) {
						entity1.setLocationAndAngles(this.posX, this.posY, this.posZ, this.worldObj.rand.nextFloat() * 360F, 0.0F);
						worldObj.spawnEntityInWorld(entity1);
						((EntityLiving) entity1).playLivingSound();
					}
			}
				this.setDead();
				
			}
		
			coun ++;
			if(coun==4) {
				coun = 0;
			}
			
			
			
			
			
	}
	
	public int getcount() {
		return coun;
	}
	
	
	
	//@Override
	//public boolean attackEntityAsMob(Entity entity) {
		
	//	return attackEntAsM;
            
            
          //  }
	public void writeEntityToNBT(NBTTagCompound nbt) {
	       super.writeEntityToNBT(nbt);
	      nbt.setInteger("counter", counter);
	      nbt.setBoolean("hasSpawned", this.hasspawned);
	      
	   }

	   /**
	    * (abstract) Protected helper method to read subclass entity data from NBT.
	    */
	   public void readEntityFromNBT(NBTTagCompound nbtt) {
	       super.readEntityFromNBT(nbtt);
           this.counter = nbtt.getInteger("counter");
           this.hasspawned = nbtt.getBoolean("hasSpawned");
	           
	   }

	
	
}
