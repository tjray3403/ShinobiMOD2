package Shinobi.Entitys.Entitys;


import Shinobi.Entitys.EntityNinja;
import Shinobi.Entitys.Entitys.AI.AIFinalFrom;
import net.minecraft.entity.Entity;
import net.minecraft.entity.SharedMonsterAttributes;
import net.minecraft.util.DamageSource;
import net.minecraft.world.World;
import thehippomasterAPI.AnimationAPI.AnimationAPI;
import thehippomasterAPI.AnimationAPI.IAnimatedEntity;

public class EntityKakuzu3 extends EntityNinja implements IAnimatedEntity {
	
	
	
	World world = null;
	private int animID;
	public int animTick;
	public int cooldown = 55;
	public int var = 0;
	public EntityKakuzu3(World var1) {
		super(var1);
		world = var1;
		animID = 0;
		animTick = 0;
		this.tasks.addTask(5, new AIFinalFrom(this));
	}
	
	@Override
	protected void applyEntityAttributes() {
		super.applyEntityAttributes();
		getEntityAttribute(SharedMonsterAttributes.maxHealth).setBaseValue(1500); //max health
		getEntityAttribute(SharedMonsterAttributes.movementSpeed).setBaseValue(0.25D); //move speed
		getEntityAttribute(SharedMonsterAttributes.knockbackResistance).setBaseValue(0.0D); //move speed
		if (this.getEntityAttribute(SharedMonsterAttributes.attackDamage) != null)
			this.getEntityAttribute(SharedMonsterAttributes.attackDamage).setBaseValue(15.0D);
		
	}
	public boolean isAIEnabled() {
		return true;
	}
	
	
	 
	
	public float getAbsorptionAmount() {
		return 5;
		
	}
	
	
	
	
	public void onLivingUpdate() {
		super.onLivingUpdate();
		int i = (int) this.posX;
		int j = (int) this.posY;
		int k = (int) this.posZ;
		Entity entity = this;
		cooldown--;
		if(cooldown==var){
			cooldown = 55;
		}
			
		if(this.getAttackTarget() != null && cooldown==1) {
			if(animID == 0) AnimationAPI.sendAnimPacket(this, 1);

		}
	}
	

	public void onDeath(DamageSource dsource) {
		super.onDeath(dsource);
		int i = (int) this.posX;
		int j = (int) this.posY;
		int k = (int) this.posZ;
		Entity entity = this;
		
		if(true) {
				world.spawnParticle("hugeexplosion", (double) i, (double) j, (double) k, 1.0D, 1.0D, 1.0D);
		}
		
		
		}

	
	
	
	

		
	/*
	 * Implemented method from IAnimatedEntity.
	 * Set the animID field to the id in the parameter.
	 */
	public void setAnimID(int id) {
		animID = id;
	}
	
	/*
	 * Implemented method from IAnimatedEntity.
	 * Set the animTick field to the tick in the parameter.
	 */
	public void setAnimTick(int tick) {
		animTick = tick;
	}
	
	/*
	 * Implemented method from IAnimatedEntity.
	 * Return the animID.
	 */
	public int getAnimID() {
		return animID;
	}
	
	/*
	 * Implemented method from IAnimatedEntity.
	 * Return the animTick.
	 */
	public int getAnimTick() {
		return animTick;
	}
	
	public void onUpdate() {
		super.onUpdate();
		//increment the animTick if there is an animation playing
		if(animID != 0) animTick++;
		
		
	}
	
	public boolean attackEntityAsMob(Entity entity) {
		if(animID == 0) AnimationAPI.sendAnimPacket(this, 1);
	
		return true;

	
	
	}
	
	
	}
	

