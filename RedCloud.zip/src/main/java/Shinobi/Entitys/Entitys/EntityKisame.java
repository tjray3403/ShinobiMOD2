package Shinobi.Entitys.Entitys;

import java.util.List;
import java.util.Random;

import Shinobi.Entitys.EntityNinja;
import Shinobi.Entitys.Entitys.AI.AISamehadaBlock;
import Shinobi.Entitys.Entitys.AI.AISamehadaX;
import Shinobi.Entitys.Entitys.AI.AISamehadaY;
import Shinobi.Entitys.Entitys.AI.AISamehadaZ;
import Shinobi.Entitys.Entitys.AI.AIWSGreatWaterSharkBomb;
import Shinobi.Entitys.Entitys.AI.AIWSRainWaterSharkWave;
import Shinobi.Entitys.Entitys.AI.AIWSThousandFeedingSharks;
import Shinobi.Entitys.Entitys.AI.AIWSWaterSharkBomb;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.SharedMonsterAttributes;
import net.minecraft.init.Blocks;
import net.minecraft.util.DamageSource;
import net.minecraft.util.EntityDamageSource;
import net.minecraft.world.World;
import thehippomasterAPI.AnimationAPI.IAnimatedEntity;

public class EntityKisame extends EntityNinja implements IAnimatedEntity {
	
	
	
	public boolean func21 = false;
	private int Samehada = 1;
	public int SharkSkin = 0;
	World world = null;
	private int animID;
	private int animTick;
	public int cn;
	private boolean hasS=true;
	private int cooldown=0;
	public int jts;
	
	public EntityKisame(World var1) {
		super(var1);
		world = var1;
		animID = 0;
		animTick = 0;
		this.tasks.addTask(5, new AISamehadaY(this));
		this.tasks.addTask(5, new AIWSRainWaterSharkWave(this));
		this.tasks.addTask(5, new AIWSWaterSharkBomb(this));
		this.tasks.addTask(5, new AIWSGreatWaterSharkBomb(this));
		this.tasks.addTask(5, new AIWSThousandFeedingSharks(this));
		this.tasks.addTask(5, new AISamehadaX(this));
		this.tasks.addTask(5, new AISamehadaZ(this));
		this.tasks.addTask(5, new AISamehadaBlock(this));
		
	}
	
	@Override
	protected void applyEntityAttributes() {
		super.applyEntityAttributes();
		getEntityAttribute(SharedMonsterAttributes.maxHealth).setBaseValue(7000); //max health
		getEntityAttribute(SharedMonsterAttributes.movementSpeed).setBaseValue(0.25D); //move speed
		getEntityAttribute(SharedMonsterAttributes.knockbackResistance).setBaseValue(0.0D); //move speed
		if (this.getEntityAttribute(SharedMonsterAttributes.attackDamage) != null)
			this.getEntityAttribute(SharedMonsterAttributes.attackDamage).setBaseValue(5.0D);
		
	}
	
	
	public boolean isAIEnabled() {
		return true;
	}
	
	public float getAbsorptionAmount() {
		return 5;
		
	}
	
public boolean attackEntityFrom(DamageSource dmg, float flt) {
		
		if(dmg instanceof EntityDamageSource) {
			if((Math.random() * 100) <= 35){
			func21 = true;
			return false;
		}}
		
			
		return super.attackEntityFrom(dmg, flt);
		
	}
	
	
	
	public void onLivingUpdate() {
		super.onLivingUpdate();
		int i = (int) this.posX;
		int j = (int) this.posY;
		int k = (int) this.posZ;
		Entity entity = this;
		
		if(this.getHealth()<6000)SharkSkin=1;
		if(this.getHealth()<4000)SharkSkin=2;
		if(this.getHealth()<2000) {
		
			this.heal(1);
			SharkSkin=3;
		}
		
		
		cooldown++;
		if(cooldown==50)cooldown=0;
		ratee();
		if(this.getAnimID()==1)Samehada=21;
		if(this.getAnimID()==2)Samehada=21;
		if(this.getAnimID()==3)Samehada=21;
		if(this.getAnimID()==5)Samehada=21;
		if(this.getAnimID()==0)Samehada=0;
		
		double offsetX = Math.cos(this.rotationYaw) * 2;
		double offsetZ = Math.sin(this.rotationYaw) * 2;
		List<EntityLivingBase> Entities = this.worldObj.getEntitiesWithinAABB(EntityLivingBase.class, this.boundingBox.getOffsetBoundingBox(offsetX, 0, offsetZ).expand(2, 2, 2));
		for (EntityLivingBase ent : Entities){
			if (ent == this.getAttackTarget()) continue;
		
		if(this.getAnimID()==5){
			
		 for (int ii = 0; ii < 20; ++ii) {
             double d0 = this.rand.nextGaussian() * 0.02D;
             double d1 = this.rand.nextGaussian() * 0.02D;
             double d2 = this.rand.nextGaussian() * 1.02D;
             this.worldObj.spawnParticle("splash", this.posX + (double) (this.rand.nextFloat() * this.width * 2.0F) - (double) this.width, this.posY + (double) (this.rand.nextFloat() * this.height), this.posZ + (double) (this.rand.nextFloat() * this.width * 2.0F) - (double) this.width, d0, d1, d2);
             this.worldObj.spawnParticle("splash", ent.posX + (double) (this.rand.nextFloat() * ent.width * 2.0F) - (double) ent.width, ent.posY + (double) (this.rand.nextFloat() * ent.height), ent.posZ + (double) (this.rand.nextFloat() * ent.width * 2.0F) - (double) ent.width, d0, d1, d2);
            
             this.worldObj.spawnParticle("bubble", this.posX + (double) (this.rand.nextFloat() * this.width * 2.0F) - (double) this.width, this.posY + (double) (this.rand.nextFloat() * this.height), this.posZ + (double) (this.rand.nextFloat() * this.width * 2.0F) - (double) this.width, d0, d1, d2);
             this.worldObj.spawnParticle("bubble", ent.posX + (double) (this.rand.nextFloat() * ent.width * 2.0F) - (double) ent.width, ent.posY + (double) (this.rand.nextFloat() * ent.height), ent.posZ + (double) (this.rand.nextFloat() * ent.width * 2.0F) - (double) ent.width, d0, d1, d2);
		 }
		}
		}
		if(this.getHealth()<this.getMaxHealth()) {
			
		}
		
		Random rand = new Random();
		int n = rand.nextInt(5);
		int nn = rand.nextInt(5);
		//cn++;
		cn=n;
		jts=nn;
	}
	
	
	private void ratee() {
		// TODO Auto-generated method stub
		if(func21==true)func21=false;
	}

	public int getSamehadaTimer() {
		return Samehada;
	
	}
	
	public void onEntityUpdate()
    {
        int i = this.getAir();
        super.onEntityUpdate();

        if(this.isInWater())
        {
            this.setAir(300);
        }
    }

	public int getcount() {
		// TODO Auto-generated method stub
		return cn;
	}

	public int getcooldown() {
		// TODO Auto-generated method stub
		return cooldown;
	}
	

	
	}
	

