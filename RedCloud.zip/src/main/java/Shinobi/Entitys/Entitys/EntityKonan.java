package Shinobi.Entitys.Entitys;


import Shinobi.Entitys.EntityNinja;
import Shinobi.Entitys.Entitys.AI.AIFireBlast;
import Shinobi.Entitys.Entitys.AI.AIPaperNinjutsu;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityList;
import net.minecraft.entity.SharedMonsterAttributes;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.util.DamageSource;
import net.minecraft.world.World;
import thehippomasterAPI.AnimationAPI.AnimationAPI;
import thehippomasterAPI.AnimationAPI.IAnimatedEntity;

public class EntityKonan extends EntityNinja implements IAnimatedEntity {
	
	
	
	World world = null;
	private int animID;
	public int animTick;
	private int cooldown = 55;
	private int var = 0;
	private int tix;
	
	public EntityKonan(World var1) {
		super(var1);
		world = var1;
		animID = 0;
		animTick = 0;
		this.tasks.addTask(5, new AIPaperNinjutsu(this));
		
		

	}
	
	@Override
	protected void applyEntityAttributes() {
		super.applyEntityAttributes();
		getEntityAttribute(SharedMonsterAttributes.maxHealth).setBaseValue(7000); //max health
		getEntityAttribute(SharedMonsterAttributes.movementSpeed).setBaseValue(0.25D); //move speed
		getEntityAttribute(SharedMonsterAttributes.knockbackResistance).setBaseValue(0.0D); //move speed
		if (this.getEntityAttribute(SharedMonsterAttributes.attackDamage) != null)
			this.getEntityAttribute(SharedMonsterAttributes.attackDamage).setBaseValue(15.0D);
		
	}
	
	public boolean isAIEnabled() {
		return true;
	}
	
	public float getAbsorptionAmount() {
		return 5;
		
	}
	
	public boolean attackEntityFrom(DamageSource dmg, float flt) {
		if((Math.random() * 100) <= 35){
		for (int ii = 0; ii < 20; ++ii) {
            double d0 = this.rand.nextGaussian() * 0.02D;
            double d1 = this.rand.nextGaussian() * 0.02D;
            double d2 = this.rand.nextGaussian() * 1.02D;
            this.worldObj.spawnParticle("snowballpoof", this.posX + (double) (this.rand.nextFloat() * this.width * 2.0F) - (double) this.width, this.posY + (double) (this.rand.nextFloat() * this.height) + .2, this.posZ + (double) (this.rand.nextFloat() * this.width * 2.0F) - (double) this.width, d0, d1, d2);           
           // this.worldObj.spawnParticle("explode", this.posX + (double) (this.rand.nextFloat() * this.width * 2.0F) - (double) this.width, this.posY + (double) (this.rand.nextFloat() * this.height), this.posZ + (double) (this.rand.nextFloat() * this.width * 2.0F) - (double) this.width, d0, d1, d2);
		 }
		return false;
		}
		
		return super.attackEntityFrom(dmg, flt);
		
	}
	
	public void onLivingUpdate() {
		super.onLivingUpdate();
		int i = (int) this.posX;
		int j = (int) this.posY;
		int k = (int) this.posZ;
		
		if(this.getHealth()<2000) {
		if(tix++ ==10) {
		if (!worldObj.isRemote) {
			Entity sentity = EntityList.createEntityByName("34PaperWings", worldObj);
			if (sentity != null) {
				sentity.setLocationAndAngles(i, j, k, worldObj.rand.nextFloat() * 360F, 0.0F);
				worldObj.spawnEntityInWorld(sentity);
			}
		} 
		}
		}
	}
	
	public void writeEntityToNBT(NBTTagCompound nbt) {
	       super.writeEntityToNBT(nbt);
	      nbt.setInteger("tix", tix);
	      
	   }

	   public void readEntityFromNBT(NBTTagCompound nbtt) {
	       super.readEntityFromNBT(nbtt);
        this.tix = nbtt.getInteger("tix");
	           
	   }

	
}

