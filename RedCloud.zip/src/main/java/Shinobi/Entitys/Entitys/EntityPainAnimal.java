package Shinobi.Entitys.Entitys;

import java.util.List;

import Shinobi.Entitys.EntityNinja;
import Shinobi.Entitys.EntityPain;
import Shinobi.Entitys.EntityRSummoning;
import Shinobi.Entitys.Entitys.AI.AIChakraRodd;
import Shinobi.Entitys.Entitys.AI.AISRinneSummon;
import Shinobi.Entitys.Entitys.AI.AISoultake;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLiving;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.SharedMonsterAttributes;
import net.minecraft.world.World;
import thehippomasterAPI.AnimationAPI.IAnimatedEntity;

public class EntityPainAnimal extends EntityPain implements IAnimatedEntity{

	public EntityPainAnimal(World var1) {
		super(var1);
		this.tasks.addTask(5, new AISRinneSummon(this));
		this.tasks.addTask(5, new AIChakraRodd(this));
		
		
		// TODO Auto-generated constructor stub
	}
	
	@Override
	protected void applyEntityAttributes() {
		super.applyEntityAttributes();
		getEntityAttribute(SharedMonsterAttributes.maxHealth).setBaseValue(3500); //max health
		getEntityAttribute(SharedMonsterAttributes.movementSpeed).setBaseValue(0.25D); //move speed
		getEntityAttribute(SharedMonsterAttributes.knockbackResistance).setBaseValue(0.0D); //move speed
		if (this.getEntityAttribute(SharedMonsterAttributes.attackDamage) != null)
			this.getEntityAttribute(SharedMonsterAttributes.attackDamage).setBaseValue(15.0D);
		
	}
	
	public boolean isAIEnabled() {
		return true;
	}
	
	public float getAbsorptionAmount() {
		return 5;
		
	}
	
	public void onLivingUpdate() {
		super.onLivingUpdate();
		int i = (int) this.posX;
		int j = (int) this.posY;
		int k = (int) this.posZ;
		Entity entity = this;
		if(true) {
			this.stepHeight = 50f;
			this.fallDistance = 0f;
			
		}
		
		if(this.inWater) {
			this.motionY = 0.1;
			this.onGround = true;
		}
			
		double offsetX = Math.cos(this.rotationYaw) * 2;
		double offsetZ = Math.sin(this.rotationYaw) * 2;
		List<EntityLivingBase> Entities = this.worldObj.getEntitiesWithinAABB(EntitySMChimera.class, this.boundingBox.getOffsetBoundingBox(offsetX, 0, offsetZ).expand(10, 10, 10));
		for (EntityLivingBase ent : Entities){
			if (ent == this) continue;
		
			if(this.ridingEntity==null) {
				this.mountEntity(ent);
			}
		}
		
		
		
	}

}
