package Shinobi.Entitys.Entitys;


import java.util.List;
import java.util.Random;

import Shinobi.Entitys.EntityEarthGrudgeFear;
import Shinobi.Entitys.EntityNinja;
import Shinobi.Entitys.EntityPain;
import Shinobi.Entitys.Entitys.AI.AIAsuraHand;
import Shinobi.Entitys.Entitys.AI.AIChakraRod;
import Shinobi.Entitys.Entitys.AI.AIEnergyBlast;
import Shinobi.Entitys.Entitys.AI.AIRinneBullet;
import Shinobi.Entitys.Projectiles.EntityAsuraHand;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.SharedMonsterAttributes;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.util.DamageSource;
import net.minecraft.world.World;
import thehippomasterAPI.AnimationAPI.IAnimatedEntity;

public class EntityPainAsura extends EntityPain implements IAnimatedEntity {
	
	
	
	World world = null;
	private int animID;
	public int animTick;
	private int cooldown = 55;
	private int var = 0;
	private int tix;
	public int attack;
	
	public EntityPainAsura(World var1) {
		super(var1);
		world = var1;
		animID = 0;
		animTick = 0;
		this.tasks.addTask(5, new AIAsuraHand(this));
		this.tasks.addTask(5, new AIRinneBullet(this));
		this.tasks.addTask(5, new AIChakraRod(this));
		this.tasks.addTask(5, new AIEnergyBlast(this));
		
		

	}
	
	@Override
	protected void applyEntityAttributes() {
		super.applyEntityAttributes();
		getEntityAttribute(SharedMonsterAttributes.maxHealth).setBaseValue(3000); //max health
		getEntityAttribute(SharedMonsterAttributes.movementSpeed).setBaseValue(0.25D); //move speed
		getEntityAttribute(SharedMonsterAttributes.knockbackResistance).setBaseValue(7.0D); //move speed
		if (this.getEntityAttribute(SharedMonsterAttributes.attackDamage) != null)
			this.getEntityAttribute(SharedMonsterAttributes.attackDamage).setBaseValue(15.0D);
		
	}
	
	public boolean isAIEnabled() {
		return true;
	}
	
	public float getAbsorptionAmount() {
		return 5;
		
	}
	
	public boolean attackEntityFrom(DamageSource dmg, float flt) {
		Entity ent = dmg.getSourceOfDamage();
		 
		if (ent instanceof EntityAsuraHand){
			 return false;
		 }
		
		return super.attackEntityFrom(dmg, flt);
	}
	
	
	public void onLivingUpdate() {
		super.onLivingUpdate();
		Random rand = new Random();
		int t = rand.nextInt(5);
		
		attack = t;
		
		if(this.getHealth()<2000) {
			tix = 20;
		}
		else
		{
			tix=0;
		}
	}

	public int getchangeTimer() {
		// TODO Auto-generated method stub
		return tix;
	}
		
	
	
	public void writeEntityToNBT(NBTTagCompound nbt) {
	       super.writeEntityToNBT(nbt);
	      nbt.setInteger("tix", tix);
	      
	   }

	   public void readEntityFromNBT(NBTTagCompound nbtt) {
	       super.readEntityFromNBT(nbtt);
        this.tix = nbtt.getInteger("tix");
	           
	   }

	
}

