package Shinobi.Entitys.Entitys;


import java.util.List;
import java.util.Random;

import Shinobi.Entitys.EntityEarthGrudgeFear;
import Shinobi.Entitys.EntityNinja;
import Shinobi.Entitys.EntityPain;
import Shinobi.Entitys.Entitys.AI.AIAlmightPush;
import Shinobi.Entitys.Entitys.AI.AIAsuraHand;
import Shinobi.Entitys.Entitys.AI.AIChakraRod;
import Shinobi.Entitys.Entitys.AI.AIChakraRodd;
import Shinobi.Entitys.Entitys.AI.AIEnergyBlast;
import Shinobi.Entitys.Entitys.AI.AIPlanetaryDevastation;
import Shinobi.Entitys.Entitys.AI.AIRinneBullet;
import Shinobi.Entitys.Entitys.AI.AISuperAlmightPush;
import Shinobi.Entitys.Entitys.AI.AIUniversalPull;
import Shinobi.Entitys.Projectiles.EntityAsuraHand;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.SharedMonsterAttributes;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.util.DamageSource;
import net.minecraft.world.World;
import thehippomasterAPI.AnimationAPI.AnimationAPI;
import thehippomasterAPI.AnimationAPI.IAnimatedEntity;

public class EntityPainDeva extends EntityPain implements IAnimatedEntity {
	
	
	
	World world = null;
	private int animID;
	public int animTick;
	private int cooldown = 55;
	private int var = 0;
	private int tix;
	private int tixx;
	public int attack;
	public int jts;
	
	public EntityPainDeva(World var1) {
		super(var1);
		world = var1;
		animID = 0;
		animTick = 0;
		this.tasks.addTask(5, new AIAlmightPush(this));
		this.tasks.addTask(5, new AISuperAlmightPush(this));
		this.tasks.addTask(5, new AIUniversalPull(this));
		this.tasks.addTask(5, new AIPlanetaryDevastation(this));
		this.tasks.addTask(5, new AIChakraRodd(this));
		
		

	}
	
	@Override
	protected void applyEntityAttributes() {
		super.applyEntityAttributes();
		getEntityAttribute(SharedMonsterAttributes.maxHealth).setBaseValue(4000); //max health
		getEntityAttribute(SharedMonsterAttributes.movementSpeed).setBaseValue(0.25D); //move speed
		getEntityAttribute(SharedMonsterAttributes.knockbackResistance).setBaseValue(7.0D); //move speed
		if (this.getEntityAttribute(SharedMonsterAttributes.attackDamage) != null)
			this.getEntityAttribute(SharedMonsterAttributes.attackDamage).setBaseValue(15.0D);
		
	}
	
	public boolean isAIEnabled() {
		return true;
	}
	
	public float getAbsorptionAmount() {
		return 5;
		
	}
	
	
	
	public void onLivingUpdate() {
		super.onLivingUpdate();
		Random rand = new Random();
		int yy = rand.nextInt(4);
		
		jts = yy;
		
		
		
		if(this.getHealth()<3000) {
			tix++;
			if(tix>1 && tix<40){
			for (int ii = 0; ii < 20; ++ii) {
		             double d0 = this.rand.nextGaussian() * 0.02D;
		             double d1 = this.rand.nextGaussian() * 0.02D;
		             double d2 = this.rand.nextGaussian() * 1.02D;
		             this.worldObj.spawnParticle("reddust", this.posX + (double) (this.rand.nextFloat() * this.width * 2.0F) - (double) this.width, this.posY + (double) (this.rand.nextFloat() * this.height), this.posZ + (double) (this.rand.nextFloat() * this.width * 2.0F) - (double) this.width, d0, d1, d2);
			}
				 }
			if(tix==40) {
				AnimationAPI.sendAnimPacket(this, 3);
				
			}
			
		}
		
		if(this.getHealth()<1000) {
			tixx++;
			if(tixx>1 && tixx<40){
			for (int ii = 0; ii < 20; ++ii) {
		             double d0 = this.rand.nextGaussian() * 0.02D;
		             double d1 = this.rand.nextGaussian() * 0.02D;
		             double d2 = this.rand.nextGaussian() * 1.02D;
		             this.worldObj.spawnParticle("reddust", this.posX + (double) (this.rand.nextFloat() * this.width * 2.0F) - (double) this.width, this.posY + (double) (this.rand.nextFloat() * this.height), this.posZ + (double) (this.rand.nextFloat() * this.width * 2.0F) - (double) this.width, d0, d1, d2);
			}
				 }
			if(tixx==40) {
				AnimationAPI.sendAnimPacket(this, 4);
				
			}
			
		}
		
		
	}

	
		
	
	
	public void writeEntityToNBT(NBTTagCompound nbt) {
	       super.writeEntityToNBT(nbt);
	      nbt.setInteger("tix", tix);
	      nbt.setInteger("tixx", tixx);

	   }

	   public void readEntityFromNBT(NBTTagCompound nbtt) {
	       super.readEntityFromNBT(nbtt);
        this.tix = nbtt.getInteger("tix");
        this.tixx = nbtt.getInteger("tixx");

	   }

	
}

