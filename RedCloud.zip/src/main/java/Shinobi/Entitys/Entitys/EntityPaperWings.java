package Shinobi.Entitys.Entitys;

import java.util.List;

import Shinobi.Entitys.EntityFlyingNinja;
import net.minecraft.entity.EntityLiving;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.SharedMonsterAttributes;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.util.DamageSource;
import net.minecraft.world.World;

public class EntityPaperWings extends EntityFlyingNinja {

	private int tix;


	public EntityPaperWings(World p_i1735_1_) {
		super(p_i1735_1_);
		// TODO Auto-generated constructor stub
	}

	
	@Override
	protected void applyEntityAttributes() {
		super.applyEntityAttributes();
		getEntityAttribute(SharedMonsterAttributes.maxHealth).setBaseValue(3D); //max health
		getEntityAttribute(SharedMonsterAttributes.knockbackResistance).setBaseValue(5.0D); //move speed
	 	getEntityAttribute(SharedMonsterAttributes.followRange).setBaseValue(100.0D);
		//if (this.getEntityAttribute(SharedMonsterAttributes.attackDamage) != null)
			//this.getEntityAttribute(SharedMonsterAttributes.attackDamage).setBaseValue(25.0D);
		
	}
	
	
	
	public boolean isAIEnabled() {
		return false;
	}
	
	public boolean attackEntityFrom(DamageSource dmg, float flt) {
		
		
		return false;
		
	}
	
	public void updateRiderPosition() {
		super.updateRiderPosition();
		this.riddenByEntity.setPosition(this.posX, this.posY, this.posZ);
		
	}
	
	public void onLivingUpdate() {
		super.onLivingUpdate();
		int i = (int) this.posX;
		int j = (int) this.posY;
		int k = (int) this.posZ;
		this.fly=true;
		
		double offsetX = Math.cos(this.rotationYaw) * 2;
		double offsetZ = Math.sin(this.rotationYaw) * 2;
		List<EntityLivingBase> Entities = this.worldObj.getEntitiesWithinAABB(EntityKonan.class, this.boundingBox.getOffsetBoundingBox(offsetX, 0, offsetZ).expand(10, 10, 10));
		for (EntityLivingBase ent : Entities){
			if (ent == this) continue;
		//EntityPlayer ep = Minecraft.getMinecraft().thePlayer;
		EntityLivingBase elb = ((EntityLiving)ent).getAttackTarget();
			this.setAttackTarget(elb);
			
		
			if(tix++ ==1000) {
				ent.motionY=-1;
				this.setDead();
			}
			
			
			ent.mountEntity(this);
			this.rotationYaw = ent.rotationYaw;
			this.rotationPitch = ent.rotationPitch;
		
		}
		 
		double offsetX1 = Math.cos(this.rotationYaw) * 2;
		double offsetZ1 = Math.sin(this.rotationYaw) * 2;
		List<EntityLivingBase> Entities1 = this.worldObj.getEntitiesWithinAABB(EntityLivingBase.class, this.boundingBox.getOffsetBoundingBox(offsetX1, 0, offsetZ1).expand(1.5, 1.5, 1.5));
		for (EntityLivingBase ent1 : Entities1){
			if (ent1 == this.getAttackTarget()) continue;
		//EntityPlayer ep = Minecraft.getMinecraft().thePlayer;
			
			}
		}
		
		
		
	

	
	public void writeEntityToNBT(NBTTagCompound nbt) {
	       super.writeEntityToNBT(nbt);
	      nbt.setInteger("tix", tix);
	      
	   }

	   public void readEntityFromNBT(NBTTagCompound nbtt) {
	       super.readEntityFromNBT(nbtt);
     this.tix = nbtt.getInteger("tix");
	           
	   }
	
}
