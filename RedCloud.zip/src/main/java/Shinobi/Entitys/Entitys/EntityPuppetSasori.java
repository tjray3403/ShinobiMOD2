package Shinobi.Entitys.Entitys;

import java.util.List;

import Shinobi.Entitys.EntityPuppet;
import Shinobi.Entitys.Entitys.AI.AI3rdPuppetArmsATtack;
import Shinobi.Entitys.Entitys.AI.AI3rdPuppetMagnetStyle;
import Shinobi.Entitys.Entitys.AI.AITeleportToEntity;
import Shinobi.Entitys.Entitys.AI.Ai3rdPuppetMelee;
import Shinobi.Entitys.Projectiles.EntityFireJet;
import Shinobi.Entitys.Projectiles.EntityWaterJet;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.SharedMonsterAttributes;
import net.minecraft.entity.ai.EntityAIAttackOnCollide;
import net.minecraft.entity.ai.EntityAIBase;
import net.minecraft.entity.ai.EntityAIHurtByTarget;
import net.minecraft.entity.ai.EntityAINearestAttackableTarget;
import net.minecraft.entity.monster.EntityMob;
import net.minecraft.entity.monster.EntityPigZombie;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.util.DamageSource;
import net.minecraft.world.World;
import thehippomasterAPI.AnimationAPI.IAnimatedEntity;

public class EntityPuppetSasori extends EntityPuppet {
	
	
	
	World world = null;
	private int animID;
	private int animTick;
	public int counter = 1;
	public EntityPuppetSasori(World var1) {
		super(var1);
		world = var1;
		animID = 0;
		animTick = 0;
		
		//this.tasks.addTask(1, new AITeleportToEntity(this, getAttackTarget()));
		
	}
	
	 public boolean isAIEnabled() {
		return true;
	}

	@Override
	protected void applyEntityAttributes() {
		super.applyEntityAttributes();
		getEntityAttribute(SharedMonsterAttributes.maxHealth).setBaseValue(25); //max health
		getEntityAttribute(SharedMonsterAttributes.followRange).setBaseValue(100);; //max health
		getEntityAttribute(SharedMonsterAttributes.movementSpeed).setBaseValue(0.3D); //move speed
		getEntityAttribute(SharedMonsterAttributes.knockbackResistance).setBaseValue(0.0D); //move speed
		if (this.getEntityAttribute(SharedMonsterAttributes.attackDamage) != null)
			this.getEntityAttribute(SharedMonsterAttributes.attackDamage).setBaseValue(5.0D);
		
	}
	
	
	
	public float getAbsorptionAmount() {
		return 0;
		
	}
	
	public boolean attackEntityFrom(DamageSource dmg, float flt) {
		Entity entity = dmg.getSourceOfDamage();
		if(entity instanceof EntityFireJet) {
			return false;
		}
		if(entity instanceof EntityWaterJet) {
			return false;
		}
		if(entity instanceof EntitySasori) {
			return false;
		}
		
		return super.attackEntityFrom(dmg, flt);
		
	}
	
	
	
	public void onLivingUpdate() {
		super.onLivingUpdate();
		int i = (int) this.posX;
		int j = (int) this.posY;
		int k = (int) this.posZ;
		Entity entity = this;
		counter++;
		if(counter==75){
			counter = 1;
		}
		EntitySasori ent = new EntitySasori(worldObj);
		if(counter==74){
			
		
		}
		

	
	 
	//}
	
	
		
	
	

	   }

	
	protected void entityInit()
    {
        super.entityInit();
        this.dataWatcher.addObject(22, Byte.valueOf((byte)0));
        
    }

    public void setPuppetType(int intt)
    {
        this.dataWatcher.updateObject(22, Byte.valueOf((byte)intt));
    }

    /**
     * returns the puppet type
     */
    public int getPuppetType()
    {
        return this.dataWatcher.getWatchableObjectByte(22);
    }
	
	
	
	
}

