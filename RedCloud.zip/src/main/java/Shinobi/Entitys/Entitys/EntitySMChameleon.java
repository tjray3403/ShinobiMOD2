package Shinobi.Entitys.Entitys;

import java.util.List;

import Shinobi.Entitys.EntityRSummoning;
import net.minecraft.entity.EntityLiving;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.world.World;

public class EntitySMChameleon extends EntityRSummoning {

	public EntitySMChameleon(World var1) {
		super(var1);
		this.setSize(4, 5);	
	}

	
	
	
	
}


