package Shinobi.Entitys.Entitys;

import java.util.List;

import Shinobi.Entitys.EntityRSummoning;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityList;
import net.minecraft.entity.EntityLiving;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.world.World;

public class EntitySMChimera extends EntityRSummoning {

	public EntitySMChimera(World var1) {
		super(var1);
		this.setSize(4, 7);
		// TODO Auto-generated constructor stub
	}
	
	
	public void onLivingUpdate() {
		super.onLivingUpdate();
		double offsetX = Math.cos(this.rotationYaw) * 2;
		double offsetZ = Math.sin(this.rotationYaw) * 2;
		List<EntityLivingBase> Entities = this.worldObj.getEntitiesWithinAABB(EntitySMChimera.class, this.boundingBox.getOffsetBoundingBox(offsetX, 0, offsetZ).expand(5, 5, 5));
		for (EntityLivingBase ent : Entities){
			if (ent == this) continue;
		
			if(ent.getHealth()<100) {
				this.setDead();
				if (!worldObj.isRemote) {
					Entity sentity = EntityList.createEntityByName("34Chimera3", worldObj);
					if (sentity != null) {
						sentity.setLocationAndAngles(this.posX, this.posY, this.posZ, worldObj.rand.nextFloat() * 360F, 0.0F);
						worldObj.spawnEntityInWorld(sentity);
						((EntityLiving) sentity).playLivingSound();
					}
			}
		
			}
		}
		
		
		
		}
		
}
	
	

