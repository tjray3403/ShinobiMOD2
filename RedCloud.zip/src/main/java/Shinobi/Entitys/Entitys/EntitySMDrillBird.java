package Shinobi.Entitys.Entitys;

import java.util.List;

import Shinobi.Entitys.EntityFlyingNinja;
import Shinobi.Entitys.EntityRSummoning;
import net.minecraft.entity.EntityLiving;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.SharedMonsterAttributes;
import net.minecraft.entity.monster.EntityMob;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.ChunkCoordinates;
import net.minecraft.util.MathHelper;
import net.minecraft.world.World;

public class EntitySMDrillBird extends EntityFlyingNinja {

	private ChunkCoordinates spawnPosition;
	private int lifetime = 500;
	
	public EntitySMDrillBird(World var1) {
		super(var1);
		this.setSize(5, 5);
	}
	
	 protected void applyEntityAttributes() {
	        super.applyEntityAttributes();
	        this.getEntityAttribute(SharedMonsterAttributes.maxHealth).setBaseValue(500.0D);
	        this.getEntityAttribute(SharedMonsterAttributes.followRange).setBaseValue(40.0D);
	        this.getEntityAttribute(SharedMonsterAttributes.attackDamage).setBaseValue(10.0D);
	    }

	
	public void onLivingUpdate() {
		super.onLivingUpdate();
		this.fly=true;
		lifetime--;
		if(lifetime==0)this.setDead();
		double offsetX1 = Math.cos(this.rotationYaw) * 2;
		double offsetZ1 = Math.sin(this.rotationYaw) * 2;
		List<EntityLivingBase> Entities1 = this.worldObj.getEntitiesWithinAABB(EntityPainAnimal.class, this.boundingBox.getOffsetBoundingBox(offsetX1, 0, offsetZ1).expand(10, 10, 10));
		for (EntityLivingBase ent1 : Entities1){
			if (ent1 == this) continue;
		//EntityPlayer ep = Minecraft.getMinecraft().thePlayer;
		EntityLivingBase elb = ((EntityLiving)ent1).getAttackTarget();
			this.setAttackTarget(elb);
		
			if(this.getDistanceSqToEntity(elb)<4) {
				this.attackEntityAsMob(elb);
			}
			
			
		}
		
		
		
		
		if(Entities1.isEmpty()) {
			this.setDead();
		}
		
		
		
	}
	
	
	
}