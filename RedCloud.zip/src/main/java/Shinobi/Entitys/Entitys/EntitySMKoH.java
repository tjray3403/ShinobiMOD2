package Shinobi.Entitys.Entitys;

import java.util.List;

import Shinobi.Entitys.EntityPain;
import Shinobi.Entitys.Entitys.AI.AIFollowEntity;
import Shinobi.Entitys.Entitys.AI.AILook;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.monster.EntityMob;
import net.minecraft.util.Vec3;
import net.minecraft.world.World;

public class EntitySMKoH extends EntityMob {

	public EntitySMKoH(World p_i1738_1_) {
		super(p_i1738_1_);
		this.tasks.addTask(5, new AILook(this, 0.3));
		this.setSize(5, 5);
		// TODO Auto-generated constructor stub
	}
	
	public boolean isAIEnabled() {
		return true;
	}
	
	public boolean isEntityInvulnerable() {
		return true;
		
	}
	
	public void onLivingUpdate() {
		super.onLivingUpdate();
		
		EntityPainNaraka ert = new EntityPainNaraka(worldObj);
		
		
		
		double offsetX = Math.cos(this.rotationYaw) * 2;
		double offsetZ = Math.sin(this.rotationYaw) * 2;
		List<EntityLivingBase> Entities = this.worldObj.getEntitiesWithinAABB(EntityPainNaraka.class, this.boundingBox.getOffsetBoundingBox(offsetX, 0, offsetZ).expand(5, 5, 5));
		for (EntityLivingBase ent : Entities){
			}
			
			if(Entities.isEmpty()) {
			this.setDead();
			
		}
				
			
				for (int ii = 0; ii < 20; ++ii) {
		            double d0 = this.rand.nextGaussian() * 0.02D;
		            double d1 = this.rand.nextGaussian() * 0.02D;
		            double d2 = this.rand.nextGaussian() * 1.02D;
		            this.worldObj.spawnParticle("reddust", this.posX + (double) (this.rand.nextFloat() * this.width * 2.0F) - (double) this.width, this.posY, this.posZ + (double) (this.rand.nextFloat() * this.width * 2.0F) - (double) this.width, d0, d1, d2);           
				}
	
		
		List<EntityLivingBase> Entities1 = this.worldObj.getEntitiesWithinAABB(EntityPain.class, this.boundingBox.getOffsetBoundingBox(offsetX, 0, offsetZ).expand(5, 5, 5));
		for (EntityLivingBase ent1 : Entities1){
			if (ent1 == this) continue;
			EntityPainNaraka wew = (EntityPainNaraka) ent1;
			if(wew.getAnimID()!=7 && ent1.getHealth()>100) {
				this.setDead();
			}
			
			
			
			for (int ii = 0; ii < 20; ++ii) {
	            double d0 = this.rand.nextGaussian() * 0.02D;
	            double d1 = this.rand.nextGaussian() * 0.02D;
	            double d2 = this.rand.nextGaussian() * 1.02D;
	            this.worldObj.spawnParticle("villagerhappy", ent1.posX + (double) (this.rand.nextFloat() * ent1.width * 2.0F) - (double) this.width, ent1.posY, ent1.posZ + (double) (this.rand.nextFloat() * ent1.width * 2.0F) - (double) ent1.width, d0, d1, d2);           
			}
			ent1.heal(2);
	}
		}

	
}