package Shinobi.Entitys.Entitys;

import java.util.List;

import Shinobi.Entitys.EntityRSummoning;
import Shinobi.Entitys.Entitys.AI.AICloneFollowOwna;
import Shinobi.Entitys.Entitys.AI.AIDefend;
import Shinobi.Entitys.Entitys.AI.AIProtect;
import net.minecraft.client.entity.AbstractClientPlayer;
import net.minecraft.entity.EntityLiving;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.IEntityLivingData;
import net.minecraft.entity.SharedMonsterAttributes;
import net.minecraft.entity.ai.EntityAIAttackOnCollide;
import net.minecraft.entity.ai.EntityAILeapAtTarget;
import net.minecraft.entity.ai.EntityAILookIdle;
import net.minecraft.entity.ai.EntityAIOpenDoor;
import net.minecraft.entity.ai.EntityAISwimming;
import net.minecraft.entity.ai.EntityAIWander;
import net.minecraft.entity.ai.EntityAIWatchClosest;
import net.minecraft.entity.monster.EntityMob;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.util.DamageSource;
import net.minecraft.util.ResourceLocation;
import net.minecraft.world.World;

public class EntitySMRhino extends EntityRSummoning {

    //public static final ResourceLocation locationStevePng = new ResourceLocation("textures/entity/steve.png");

    
    

    public EntitySMRhino(World par1World) {
        super(par1World);
        this.setSize(6F, 11.5F);

    }

    
    
}
