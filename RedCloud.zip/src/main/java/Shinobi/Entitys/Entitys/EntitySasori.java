package Shinobi.Entitys.Entitys;

import java.util.List;

import Shinobi.Entitys.EntityNinja;
import Shinobi.Entitys.Entitys.AI.AIEarthGrudgeFear;
import Shinobi.Entitys.Entitys.AI.AIHirukoJab;
import Shinobi.Entitys.Entitys.AI.AIHirukoNeedless;
import Shinobi.Entitys.Entitys.AI.AIHirukoSting;
import Shinobi.Entitys.Entitys.AI.AIKakuzuFist;
import Shinobi.Entitys.Entitys.AI.AIKakuzuSmash;
import Shinobi.Entitys.Entitys.AI.AIKakuzuTwist;
import Shinobi.Entitys.Entitys.AI.AISasoriBlast;
import Shinobi.Entitys.Entitys.AI.AISasoriSlash;
import Shinobi.Entitys.Projectiles.EntityMagnetCube;
import Shinobi.Entitys.Projectiles.EntityMagnetSpread;
import Shinobi.Entitys.Projectiles.EntityMagnetTriangle;
import Shinobi.Entitys.Projectiles.EntityPuppetArmattack;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityList;
import net.minecraft.entity.EntityLiving;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.SharedMonsterAttributes;
import net.minecraft.entity.ai.EntityAIAttackOnCollide;
import net.minecraft.entity.ai.EntityAIHurtByTarget;
import net.minecraft.entity.ai.EntityAILookIdle;
import net.minecraft.entity.ai.EntityAINearestAttackableTarget;
import net.minecraft.entity.monster.EntityMob;
import net.minecraft.entity.passive.IAnimals;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.util.DamageSource;
import net.minecraft.world.World;
import thehippomasterAPI.AnimationAPI.AnimationAPI;
import thehippomasterAPI.AnimationAPI.IAnimatedEntity;

public class EntitySasori extends EntityNinja implements IAnimatedEntity {
	
	
	
	World world = null;
	private int animID;
	private int animTick;
	public int counter = 1;
	public int cntr2 = 1;
	public boolean puppetmode = false;
	private Entity3rdKazekagePuppet thirdd;
	public boolean puppetry = false;
	private int cnt = 0;
	public EntitySasori(World var1) {
		super(var1);
		world = var1;
		animID = 0;
		animTick = 0;
		this.tasks.addTask(5, new AISasoriBlast(this));
		this.tasks.addTask(5, new AISasoriSlash(this));
		//this.tasks.addTask(3, new EntityAIAttackOnCollide(this, EntityPlayer.class, 1.0D, false));
		//this.targetTasks.addTask(2, new EntityAINearestAttackableTarget(this, EntityPlayer.class, 2, true));
		//this.targetTasks.addTask(1, new EntityAIHurtByTarget(this, false));
		
	}
	
	
	 public boolean isAIEnabled() {
		return true;
	}
	

	@Override
	protected void applyEntityAttributes() {
		super.applyEntityAttributes();
		getEntityAttribute(SharedMonsterAttributes.maxHealth).setBaseValue(3000); //max health
		getEntityAttribute(SharedMonsterAttributes.movementSpeed).setBaseValue(0.25D); //move speed
		getEntityAttribute(SharedMonsterAttributes.knockbackResistance).setBaseValue(0.0D); //move speed
		if (this.getEntityAttribute(SharedMonsterAttributes.attackDamage) != null)
			this.getEntityAttribute(SharedMonsterAttributes.attackDamage).setBaseValue(15.0D);
		
	}
	
	
	
	
	
	public float getAbsorptionAmount() {
		return 0;
		
	}
	
	
	public boolean attackEntityFrom(DamageSource dmg, float flt) {
		Entity entity = dmg.getSourceOfDamage();
		if(entity instanceof EntityMagnetCube) return false;
		if(entity instanceof EntityMagnetSpread) return false;
		if(entity instanceof EntityMagnetTriangle) return false;
		if(entity instanceof Entity3rdKazekagePuppet) return false;
		if(entity instanceof EntityPuppetArmattack) return false;
		
		/**double offsetX = Math.cos(this.rotationYaw) * 2;
		double offsetZ = Math.sin(this.rotationYaw) * 2;
		List<EntityLivingBase> Entities = this.worldObj.getEntitiesWithinAABB(Entity3rdKazekagePuppet.class, this.boundingBox.getOffsetBoundingBox(offsetX, 0, offsetZ).expand(20, 10, 20));
		for (EntityLivingBase ent : Entities){
			if (ent == this) continue;
			//ent.attackEntityFrom(dmg, flt);
		}
		*/
		return super.attackEntityFrom(dmg, flt);
		
	}
	
	
	
	public void onLivingUpdate() {
		super.onLivingUpdate();
		int i = (int) this.posX;
		int j = (int) this.posY;
		int k = (int) this.posZ;
		Entity entity = this;
		Entity3rdKazekagePuppet entt = thirdd;
		counter++;
		if(counter==21){
			counter = 1;
		}
		
		if(this.getHealth()<2000) {
			puppetmode = true;
		}
	
		if(this.getHealth()<100){
			cnt++;
				if(cnt<100){
					if (!worldObj.isRemote) {
	 					Entity entity1 = EntityList.createEntityByName("34Puppet", worldObj);
	 					if (entity1 != null) {
	 						entity1.setLocationAndAngles(this.posX, this.posY, this.posZ, this.worldObj.rand.nextFloat() * 360F, 0.0F);
	 						worldObj.spawnEntityInWorld(entity1);
	 						((EntityLiving) entity1).playLivingSound();
	 					
	 			}
				}
		}
		}
		if(this.getHealth()<this.getMaxHealth() && this.getAttackTarget()!=null){
			cntr2++;
			if(cntr2==20 && this.getHealth()>2000) {
				 
                
                 if (!worldObj.isRemote) {
 					Entity entity1 = EntityList.createEntityByName("343rdKazekagePuppet", worldObj);
 					if (entity1 != null) {
 						entity1.setLocationAndAngles(this.posX, this.posY, this.posZ, this.worldObj.rand.nextFloat() * 360F, 0.0F);
 						worldObj.spawnEntityInWorld(entity1);
 						((EntityLiving) entity1).playLivingSound();
 					
 			}
			}
		}
		}
		
		double offsetX = Math.cos(this.rotationYaw) * 2;
		double offsetZ = Math.sin(this.rotationYaw) * 2;
		List<EntityLivingBase> Entities = this.worldObj.getEntitiesWithinAABB(Entity3rdKazekagePuppet.class, this.boundingBox.getOffsetBoundingBox(offsetX, 0, offsetZ).expand(15, 15, 15));
		for (EntityLivingBase ent : Entities){
			if (ent == this) continue;
		this.setAnimID(2);
                 AnimationAPI.sendAnimPacket(this, 2);
		}
		
		}
	
	
	public void writeEntityToNBT(NBTTagCompound nbt) {
	       super.writeEntityToNBT(nbt);
	       nbt.setInteger("counter", this.counter);
	       nbt.setInteger("counter2", this.cntr2);
	       nbt.setBoolean("puppetmode", this.puppetmode);
	       nbt.setBoolean("puppetry", this.puppetry);
	       nbt.setInteger("cnt", this.cnt);
	       
	   }

	   /**
	    * (abstract) Protected helper method to read subclass entity data from NBT.
	    */
	   public void readEntityFromNBT(NBTTagCompound nbtt) {
	       super.readEntityFromNBT(nbtt);
	           this.counter = nbtt.getInteger("counter");
	           this.cntr2  = nbtt.getInteger("counter2");
	           this.puppetmode = nbtt.getBoolean("puppetmode");
	           this.puppetry = nbtt.getBoolean("puppetry");
	           this.cnt = nbtt.getInteger("cnt");

   

	
	

	   }


	
	   }
	

