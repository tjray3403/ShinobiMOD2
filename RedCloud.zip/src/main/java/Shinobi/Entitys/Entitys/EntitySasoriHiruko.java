package Shinobi.Entitys.Entitys;

import Shinobi.Entitys.EntityNinja;
import Shinobi.Entitys.Entitys.AI.AIEarthGrudgeFear;
import Shinobi.Entitys.Entitys.AI.AIHirukoBlock1;
import Shinobi.Entitys.Entitys.AI.AIHirukoBlockX;
import Shinobi.Entitys.Entitys.AI.AIHirukoJab;
import Shinobi.Entitys.Entitys.AI.AIHirukoNeedless;
import Shinobi.Entitys.Entitys.AI.AIHirukoSting;
import Shinobi.Entitys.Entitys.AI.AIKakuzuFist;
import Shinobi.Entitys.Entitys.AI.AIKakuzuSmash;
import Shinobi.Entitys.Entitys.AI.AIKakuzuTwist;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityList;
import net.minecraft.entity.EntityLiving;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.SharedMonsterAttributes;
import net.minecraft.entity.ai.EntityAILookIdle;
import net.minecraft.entity.passive.IAnimals;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.util.DamageSource;
import net.minecraft.world.World;
import thehippomasterAPI.AnimationAPI.AnimationAPI;
import thehippomasterAPI.AnimationAPI.IAnimatedEntity;

public class EntitySasoriHiruko extends EntityNinja implements IAnimatedEntity {
	
	
	
	World world = null;
	private int animID;
	private int animTick;
	public int counter = 1;
	public boolean attackM = true;
	public boolean hirukomode = false;
	public int func;
	public EntitySasoriHiruko(World var1) {
		super(var1);
		world = var1;
		animID = 0;
		animTick = 0;
		this.tasks.addTask(5, new AIHirukoNeedless(this));
		this.tasks.addTask(5, new AIHirukoBlockX(this));		
		this.tasks.addTask(5, new AIHirukoBlock1(this));
		this.tasks.addTask(5, new AIHirukoJab(this, 0.25F));
		this.tasks.addTask(5, new AIHirukoSting(this, 0.25F));
		
	}
	
	 

	@Override
	protected void applyEntityAttributes() {
		super.applyEntityAttributes();
		getEntityAttribute(SharedMonsterAttributes.maxHealth).setBaseValue(4000); //max health
		getEntityAttribute(SharedMonsterAttributes.movementSpeed).setBaseValue(0.25D); //move speed
		getEntityAttribute(SharedMonsterAttributes.knockbackResistance).setBaseValue(0.5D); //move speed
		if (this.getEntityAttribute(SharedMonsterAttributes.attackDamage) != null)
			this.getEntityAttribute(SharedMonsterAttributes.attackDamage).setBaseValue(15.0D);
		
	}
	
	
	
	
	
	public float getAbsorptionAmount() {
		return 7;
		
	}
	
	
	
	public void onDeath(DamageSource ent) {
		super.onDeath(ent);
		if (!worldObj.isRemote) {
				Entity entity1 = EntityList.createEntityByName("34Sasori", worldObj);
				if (entity1 != null) {
					entity1.setLocationAndAngles(this.posX, this.posY, this.posZ, this.worldObj.rand.nextFloat() * 360F, 0.0F);
					worldObj.spawnEntityInWorld(entity1);
					((EntityLiving) entity1).playLivingSound();
				}
		}
		
		
	}
	
	public void onLivingUpdate() {
		super.onLivingUpdate();
		int i = (int) this.posX;
		int j = (int) this.posY;
		int k = (int) this.posZ;
		Entity entity = this;
		counter++;
		if(counter==21){
			counter = 1;
		}
		
		if(this.getHealth()<2000) {
			hirukomode = true;
		}
		
		if(this.getAttackTarget() != null) {
			
			attackM = true;
			
		}
		func = 0;
		
		if(this.getAttackTarget()!=null) {
			switch((this.rand.nextInt(3)))
			{
			case 0:
                this.setAnimID(2);
                AnimationAPI.sendAnimPacket(this, 2);
                break;
                
			case 1:
				this.setAnimID(1);
                AnimationAPI.sendAnimPacket(this, 1);
				break;
				
               default:
                	break;
			
			}
		}
		
		
	}
	
	public boolean attackEntityFrom(DamageSource source, float amount) {

		Entity entity = source.getEntity();
		if(entity instanceof EntityLivingBase) {
			switch((this.rand.nextInt(2)))
			{
			case 0:
                func = 1;
                break;
                
			case 1:
				func = 2;
				break;
				
                default:
                	break;
			
			}
		
		}
		return super.attackEntityFrom(source, amount);
		}
		
	/*
	 * Implemented method from IAnimatedEntity.
	 * Set the animID field to the id in the parameter.
	 */
	public void setAnimID(int id) {
		animID = id;
	}
	
	/*
	 * Implemented method from IAnimatedEntity.
	 * Set the animTick field to the tick in the parameter.
	 */
	public void setAnimTick(int tick) {
		animTick = tick;
	}
	
	/*
	 * Implemented method from IAnimatedEntity.
	 * Return the animID.
	 */
	public int getAnimID() {
		return animID;
	}
	
	/*
	 * Implemented method from IAnimatedEntity.
	 * Return the animTick.
	 */
	public int getAnimTick() {
		return animTick;
	}
	
	public void onUpdate() {
		super.onUpdate();
		//increment the animTick if there is an animation playing
		if(animID != 0) animTick++;
		
		
		
		
		
		
	}
	/**
	public boolean attackEntityAsMob(Entity entity) {
		if(this.getAttackTarget() != null && this.animID == 0)
            switch(this.rand.nextInt(3))
            {
                case 0:
                    this.setAnimID(1);
                    AnimationAPI.sendAnimPacket(this, 1);
                    break;
                    
                case 1:
                    this.setAnimID(2);
                    AnimationAPI.sendAnimPacket(this, 2);
                    break;

                    
                    default:
                    	break;
	}
		return true;

	
	
	}
	*/
	public void writeEntityToNBT(NBTTagCompound nbt) {
	       super.writeEntityToNBT(nbt);
	       nbt.setBoolean("attackM", this.attackM);
	   }

	   /**
	    * (abstract) Protected helper method to read subclass entity data from NBT.
	    */
	   public void readEntityFromNBT(NBTTagCompound nbtt) {
	       super.readEntityFromNBT(nbtt);
	           this.attackM = nbtt.getBoolean("attackM");

    
   

	
	

	   }
	   }
	

