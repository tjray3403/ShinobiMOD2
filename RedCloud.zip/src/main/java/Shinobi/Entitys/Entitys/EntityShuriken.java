package Shinobi.Entitys.Entitys;

import net.minecraft.entity.Entity;
import net.minecraft.entity.SharedMonsterAttributes;
import net.minecraft.entity.ai.EntityAIAttackOnCollide;
import net.minecraft.entity.ai.EntityAIHurtByTarget;
import net.minecraft.entity.ai.EntityAINearestAttackableTarget;
import net.minecraft.entity.ai.EntityAISwimming;
import net.minecraft.entity.monster.EntityMob;
import net.minecraft.entity.monster.IMob;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.world.World;

public class EntityShuriken extends EntityMob implements IMob {

	private static final double Hlth = 1D;
	World world = null;

	public EntityShuriken(World var1) {
		
		super(var1);
		this.tasks.addTask(10, new EntityAISwimming(this));
		this.tasks.addTask(10, new EntityAIAttackOnCollide(this, EntityPlayer.class, 1.0D, false));
		this.targetTasks.addTask(10, new EntityAINearestAttackableTarget(this, EntityPlayer.class, 2, true));
		this.targetTasks.addTask(11, new EntityAIHurtByTarget(this, false));

		
		
	}
	
	@Override
	public void applyEntityAttributes() {
		super.applyEntityAttributes();
		getEntityAttribute(SharedMonsterAttributes.maxHealth).setBaseValue(Hlth); //max health
		getEntityAttribute(SharedMonsterAttributes.movementSpeed).setBaseValue(0.95D); //move speed
		getEntityAttribute(SharedMonsterAttributes.knockbackResistance).setBaseValue(10.0D); //move speed
		if (this.getEntityAttribute(SharedMonsterAttributes.attackDamage) != null)
			this.getEntityAttribute(SharedMonsterAttributes.attackDamage).setBaseValue(15.0D);
		
	}

	
	public boolean isAIEnabled() {
		return true;
	}
	
	public void onLivingUpdate() {
		super.onLivingUpdate();
		int i = (int) this.posX;
		int j = (int) this.posY;
		int k = (int) this.posZ;
		int EGF = (int) this.Hlth;
		Entity entity = this;
		if(true) {
			this.stepHeight = 50f;
			this.fallDistance = 0f;


		}
		
		
		
	}
	
	
	

	
	}


