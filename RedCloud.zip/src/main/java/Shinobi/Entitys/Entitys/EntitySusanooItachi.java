package Shinobi.Entitys.Entitys;

import java.util.List;

import Shinobi.Entitys.Entitys.AI.AISusanooPunch;
import Shinobi.Entitys.Entitys.AI.AISusanooSmash;
import Shinobi.Entitys.Entitys.AI.AISusanooTosukaBlade;
import Shinobi.Entitys.Entitys.AI.AISusanooTosukaBladeSwing;
import Shinobi.Entitys.Entitys.AI.AISusanooYasakaBeads;
import Shinobi.Entitys.Entitys.AI.AISusanooYataMirror;
import Shinobi.Entitys.Projectiles.EntityGreatFireball;
import Shinobi.Entitys.Projectiles.EntityYasaka;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLiving;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.SharedMonsterAttributes;
import net.minecraft.entity.ai.EntityAIAttackOnCollide;
import net.minecraft.entity.ai.EntityAIHurtByTarget;
import net.minecraft.entity.ai.EntityAINearestAttackableTarget;
import net.minecraft.entity.monster.EntityMob;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.DamageSource;
import net.minecraft.util.EntityDamageSource;
import net.minecraft.world.World;
import thehippomasterAPI.AnimationAPI.IAnimatedEntity;

public class EntitySusanooItachi extends EntityMob implements IAnimatedEntity{

	public int Susanoo = 0;
	private int animID;
	private int animTick;
	public boolean func21;
	public int jts;

	public EntitySusanooItachi(World p_i1738_1_) {
		super(p_i1738_1_);
		this.setSize(4, 7.5F);
		//this.tasks.addTask(2, new EntityAIAttackOnCollide(this, EntityPlayer.class, 1.0D, false));
		//this.targetTasks.addTask(2, new EntityAINearestAttackableTarget(this, EntityPlayer.class, 2, true));
		this.targetTasks.addTask(2, new EntityAIHurtByTarget(this, false));
		this.tasks.addTask(5, new AISusanooPunch(this));
		this.tasks.addTask(5, new AISusanooSmash(this));
		this.tasks.addTask(5, new AISusanooYasakaBeads(this));
		this.tasks.addTask(5, new AISusanooTosukaBlade(this));
		this.tasks.addTask(5, new AISusanooTosukaBladeSwing(this));
		//this.tasks.addTask(5, new AISusanooYataMirror(this));

		this.isImmuneToFire = true;
		// TODO Auto-generated constructor stub
	}
	
	public boolean isAIEnabled () {
		return true;
		
	}
	
	public boolean attackEntityFrom(DamageSource dmg, float flt) {
	    
		Entity ent = dmg.getSourceOfDamage();
		 
		if (ent instanceof EntityYasaka){
			 return false;
		}
			 if(dmg instanceof EntityDamageSource) {
				if((Math.random() * 100) <= 35){
					func21 = true;
			if(this.getAnimID()==6){
					return false;
				}
			}
			 
			 
		}
		return super.attackEntityFrom(dmg, flt);
		
		}
	
	@Override
	protected void applyEntityAttributes() {
		super.applyEntityAttributes();
		getEntityAttribute(SharedMonsterAttributes.maxHealth).setBaseValue(1000D); //max health
		getEntityAttribute(SharedMonsterAttributes.movementSpeed).setBaseValue(0.0D); //move speed
		getEntityAttribute(SharedMonsterAttributes.knockbackResistance).setBaseValue(5.0D); //move speed
		getEntityAttribute(SharedMonsterAttributes.followRange).setBaseValue(100.0D);
		if (this.getEntityAttribute(SharedMonsterAttributes.attackDamage) != null)
			this.getEntityAttribute(SharedMonsterAttributes.attackDamage).setBaseValue(25.0D);
		
	}
	
	public float getAbsorptionAmount() {
		if(Susanoo==1) {
			return 7;
		}
		else if(Susanoo==2) {
			return 9;
		}
		else if(Susanoo==3) {
			return 20;
		}
		return 5;
		
	}
	
	
	
	public void onLivingUpdate() {
		super.onLivingUpdate();
		if(func21==true)func21=false;
		if(Susanoo==3){
		for (int ii = 0; ii < 20; ++ii) {
            double d0 = this.rand.nextGaussian() * 0.02D;
            double d1 = this.rand.nextGaussian() * 0.02D;
            double d2 = this.rand.nextGaussian() * 1.02D;
            this.worldObj.spawnParticle("reddust", this.posX + (double) (this.rand.nextFloat() * this.width * 2.0F) - (double) this.width, this.posY + (double) (this.rand.nextFloat() * this.height), this.posZ + (double) (this.rand.nextFloat() * this.width * 2.0F) - (double) this.width, 10, 0, 0);           
            this.worldObj.spawnParticle("flame", this.posX + (double) (this.rand.nextFloat() * this.width * 2.0F) - (double) this.width, this.posY + (double) (this.rand.nextFloat() * this.height), this.posZ + (double) (this.rand.nextFloat() * this.width * 2.0F) - (double) this.width, 0, 0, 0);
		 }
		}
		double offsetX = Math.cos(this.rotationYaw) * 2;
		double offsetZ = Math.sin(this.rotationYaw) * 2;
		List<EntityLivingBase> Entities = this.worldObj.getEntitiesWithinAABB(EntityItachi.class, this.boundingBox.getOffsetBoundingBox(offsetX, 0, offsetZ).expand(5, 5, 5));
		for (EntityLivingBase ent : Entities){
			if (ent == this) continue;
			mountEntity(ent);
			
			EntityLivingBase elb = ((EntityLiving)ent).getAttackTarget();
			this.setAttackTarget(elb);
			
		
		}
		if(this.getHealth()<800) {
			Susanoo = 1;
		}
		if(this.getHealth()<500) {
			Susanoo = 2;
		}
		if(this.getHealth()<300) {
			Susanoo = 3;
		}
		
		int nn = rand.nextInt(6);
		jts=nn;
		
		
	}
	
	public void updateRiderPosition() {
		super.updateRiderPosition();
		this.riddenByEntity.setPosition(this.posX, this.posY + this.getMountedYOffset() + 1.0D + this.getYOffset(), this.posZ);
		
	}
    

	@Override
	public void setAnimID(int id) {
		animID = id;
		
	}

	@Override
	public void setAnimTick(int tick) {
		animTick = tick;
		
	}

	@Override
	public int getAnimID() {
				return animID;
	}

	@Override
	public int getAnimTick() {
		return animTick;
	}
	
	@Override
	public void onUpdate() {
		super.onUpdate();
		if(animID!=0)animTick++;
	}

}
