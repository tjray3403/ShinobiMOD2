package Shinobi.Entitys.Entitys;

import java.util.List;
import java.util.Random;

import Shinobi.Entitys.EntityNinja;
import Shinobi.Entitys.Entitys.AI.AIFireJutsu;
import Shinobi.Entitys.Entitys.AI.AIFireStyle;
import Shinobi.Entitys.Entitys.AI.AIslice;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityList;
import net.minecraft.entity.EntityLiving;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.SharedMonsterAttributes;
import net.minecraft.entity.passive.IAnimals;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.potion.Potion;
import net.minecraft.potion.PotionEffect;
import net.minecraft.util.DamageSource;
import net.minecraft.util.Vec3;
import net.minecraft.world.World;
import thehippomasterAPI.AnimationAPI.AnimationAPI;
import thehippomasterAPI.AnimationAPI.IAnimatedEntity;

public class EntityTobi extends EntityNinja {
	
	
	
	World world = null;
	private int stareTimer;
	private boolean genjutsu;
	public int attack = 0;
	private int kamuit;
	private boolean iskamuiactive = false;
	private boolean kamuu;
	private int tix;
	private double attackdam;

	
	public EntityTobi(World var1) {
		super(var1);
		world = var1;
		
		this.tasks.addTask(5, new AIFireJutsu(this));

		
	}
	
	@Override
	protected void applyEntityAttributes() {
		super.applyEntityAttributes();
		getEntityAttribute(SharedMonsterAttributes.maxHealth).setBaseValue(7000); //max health
		getEntityAttribute(SharedMonsterAttributes.movementSpeed).setBaseValue(0.55D); //move speed
		getEntityAttribute(SharedMonsterAttributes.knockbackResistance).setBaseValue(0.0D); //move speed
		if (this.getEntityAttribute(SharedMonsterAttributes.attackDamage) != null)
			this.getEntityAttribute(SharedMonsterAttributes.attackDamage).setBaseValue(attackdam);
		
	}
	
	public boolean isAIEnabled() {
		return true;
	}
	
	
	public float getAbsorptionAmount() {
		return 3;
		
	}
	
	
	public boolean attackEntityFrom(DamageSource dmg, float flt) {
		Entity ent = dmg.getSourceOfDamage();
        
		if(kamuu==true) {
			return false;
		}
		
		
		if((Math.random() * 100) <= 40){
	           //  this.kamuiability(true);
	        //  this.worldObj.spawnParticle("explode", this.posX + (double) (this.rand.nextFloat() * this.width * 2.0F) - (double) this.width, this.posY + (double) (this.rand.nextFloat() * this.height), this.posZ + (double) (this.rand.nextFloat() * this.width * 2.0F) - (double) this.width, 0, 0, 0);
	            
			kamuu=true;
				//return false;
			}

		
		return super.attackEntityFrom(dmg, flt);
	}

	public boolean getkamuiMode(){
		return kamuu;
	}
	
	

	public void onLivingUpdate() {
		super.onLivingUpdate();
		if(this.getHealth()<100) this.heal(2);
		int i = (int) this.posX;
		int j = (int) this.posY;
		int k = (int) this.posZ;
		Entity entity = this;
		if(true) {
			this.stepHeight = 50f;
			this.fallDistance = 0f;
			this.fireResistance = 10;
		}
		

		this.findEntityforGenjutsu(); 
	
		
		
			kamuiability(kamuu);
		
		
		if(kamuu==true) {
			tix++;
			if(tix==100)kamuu=false;
			attackdam=0;
			
		}
		
		if(kamuu==false){
			if(tix<=100){tix=0;}
			attackdam=15;
		}
		
		
		Random rand = new Random();
		int n = rand.nextInt(2);
		int nn = rand.nextInt(5);
		//cn++;
		attack=n;
		
	
	}
	
	

	public void onDeath(DamageSource dsource) {
		super.onDeath(dsource);
		int i = (int) this.posX;
		int j = (int) this.posY;
		int k = (int) this.posZ;
		Entity entity = this;
		
		
		}
	
	private void kamuiability(boolean kamu) {
		if(kamu) {
        this.worldObj.spawnParticle("explode", this.posX + (double) (this.rand.nextFloat() * this.width * 2.0F) - (double) this.width, this.posY + (double) (this.rand.nextFloat() * this.height), this.posZ + (double) (this.rand.nextFloat() * this.width * 2.0F) - (double) this.width, 0, 0, 0);
        this.iskamuiactive = true;
        if(this.isCollidedHorizontally) {
        	noClip = true;
        this.onGround = true;
        if(motionY<0)this.motionY = 0.01F;
        
        }
		}
		else
		{
			this.noClip = false;
	        this.iskamuiactive = false;	
		}
		
	}
	
	
	public boolean canBeCollidedWith() {
		return !kamuu;
		
	}

	protected Entity findEntityforGenjutsu()
    {
		double offsetX = Math.cos(this.rotationYaw) * 2;
		double offsetZ = Math.sin(this.rotationYaw) * 2;
		List<EntityLivingBase> Entities = this.worldObj.getEntitiesWithinAABB(EntityLivingBase.class, this.boundingBox.getOffsetBoundingBox(offsetX, 0, offsetZ).expand(5, 5, 5));
		for (EntityLivingBase ent : Entities){
			if (ent == this) continue;
			
        if (ent != null)
        {
            if (this.shouldAttack(ent))
            {

                if (this.stareTimer++ == 10)
                {
        	        ent.worldObj.spawnParticle("explode", ent.posX + (double) (this.rand.nextFloat() * ent.width * 2.0F) - (double) ent.width, ent.posY + (double) (this.rand.nextFloat() * ent.height), ent.posZ + (double) (this.rand.nextFloat() * ent.width * 2.0F) - (double) ent.width, 0, 0, 0);
        			ent.addPotionEffect(new PotionEffect(2, 100, 15*20));
        			ent.addPotionEffect(new PotionEffect(Potion.blindness.id, 100, 15*20));

        			}
                    this.stareTimer = 0;
                    this.genjutsu = true;
                    return ent;
                }
            }
            else
            {
                this.stareTimer = 0;
                this.genjutsu = false;
            }
        }
		
        return null;
    }

    /**
     * Checks to see if this enderman should be attacking this player
     */
    private boolean shouldAttack(EntityLivingBase p_70821_1_)
    {
        
        {
            Vec3 vec3 = p_70821_1_.getLook(1.0F).normalize();
            Vec3 vec31 = Vec3.createVectorHelper(this.posX - p_70821_1_.posX, this.boundingBox.minY + (double)(this.height / 2.0F) - (p_70821_1_.posY + (double)p_70821_1_.getEyeHeight()), this.posZ - p_70821_1_.posZ);
            double d0 = vec31.lengthVector();
            vec31 = vec31.normalize();
            double d1 = vec3.dotProduct(vec31);
            return d1 > 1.0D - 0.025D / d0 && p_70821_1_.canEntityBeSeen(this);
        }
    }
    

	
	
	
	
	
    public void writeEntityToNBT(NBTTagCompound nbt) {
	       super.writeEntityToNBT(nbt);
	      nbt.setInteger("stareTimer", stareTimer);
	      nbt.setBoolean("genjutsu", this.genjutsu);
	      nbt.setBoolean("iskamuiactive", this.iskamuiactive);
	      nbt.setBoolean("kamuu", this.kamuu);
	      nbt.setInteger("kamuit", this.kamuit);
	      nbt.setInteger("attack", attack);
	      nbt.setInteger("tix", tix);
	      
	   }

	   /**
	    * (abstract) Protected helper method to read subclass entity data from NBT.
	    */
	   public void readEntityFromNBT(NBTTagCompound nbtt) {
	       super.readEntityFromNBT(nbtt);
     this.stareTimer = nbtt.getInteger("stareTimer");
     this.kamuit = nbtt.getInteger("kamuit");
     this.attack = nbtt.getInteger("attack");
     this.tix = nbtt.getInteger("tix");
     this.iskamuiactive = nbtt.getBoolean("iskamuiactive");
     this.kamuu = nbtt.getBoolean("kamuu");
     this.genjutsu = nbtt.getBoolean("genjutsu");
     
     
	   }
	

}



