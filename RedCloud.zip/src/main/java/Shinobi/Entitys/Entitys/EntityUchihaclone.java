package Shinobi.Entitys.Entitys;

import Shinobi.Entitys.Entitys.AI.AISwipe;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.SharedMonsterAttributes;
import net.minecraft.entity.ai.EntityAIAttackOnCollide;
import net.minecraft.entity.ai.EntityAIHurtByTarget;
import net.minecraft.entity.ai.EntityAILookIdle;
import net.minecraft.entity.ai.EntityAINearestAttackableTarget;
import net.minecraft.entity.ai.EntityAISwimming;
import net.minecraft.entity.ai.EntityAIWander;
import net.minecraft.entity.monster.EntityMob;
import net.minecraft.entity.passive.IAnimals;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.DamageSource;
import net.minecraft.world.World;
import thehippomasterAPI.AnimationAPI.AnimationAPI;
import thehippomasterAPI.AnimationAPI.IAnimatedEntity;

public class EntityUchihaclone extends EntityMob implements IAnimals, IAnimatedEntity {
	
	
	
	private static final double Hlth = 100D;
	World world = null;
	private int animID;
	private int animTick;

	
	public EntityUchihaclone(World var1) {
		super(var1);
		world = var1;
		animID = 0;
		animTick = 0;
		this.tasks.addTask(5, new AISwipe(this));
		this.tasks.addTask(7, new EntityAIWander(this, 0.8D));
		this.tasks.addTask(5, new EntityAILookIdle(this));
		this.tasks.addTask(4, new EntityAISwimming(this));
		this.tasks.addTask(10, new EntityAIAttackOnCollide(this, EntityPlayer.class, 1.0D, false));
		this.targetTasks.addTask(10, new EntityAINearestAttackableTarget(this, EntityPlayer.class, 2, true));
		this.targetTasks.addTask(11, new EntityAIHurtByTarget(this, false));
		
		
	}
	
	@Override
	protected void applyEntityAttributes() {
		super.applyEntityAttributes();
		getEntityAttribute(SharedMonsterAttributes.maxHealth).setBaseValue(Hlth); //max health
		getEntityAttribute(SharedMonsterAttributes.movementSpeed).setBaseValue(0.35D); //move speed
		getEntityAttribute(SharedMonsterAttributes.knockbackResistance).setBaseValue(0.0D); //move speed
		if (this.getEntityAttribute(SharedMonsterAttributes.attackDamage) != null)
			this.getEntityAttribute(SharedMonsterAttributes.attackDamage).setBaseValue(5.0D);
		
	}
	
	public boolean isAIEnabled() {
		return true;
	}
	
	public float getAbsorptionAmount() {
		return 5;
		
	}
	
	public void onEntityUpdate() {
		super.onEntityUpdate();
		int i = (int) this.posX;
		int j = (int) this.posY;
		int k = (int) this.posZ;
		Entity entity = this;
		
		
		
	}
	
	public void onkillEntity(EntityLivingBase e) {
		super.onKillEntity(e);
		int i = (int) this.posX;
		int j = (int) this.posY;
		int k = (int) this.posZ;
		Entity entity = this;
		
	}
	
	public void onLivingUpdate() {
		super.onLivingUpdate();
		int i = (int) this.posX;
		int j = (int) this.posY;
		int k = (int) this.posZ;
		int EGF = (int) this.Hlth;
		Entity entity = this;
		if(true) {
			this.stepHeight = 50f;
			this.fallDistance = 0f;
			this.fireResistance = 10;
		}
		
			
		
		
	}
	
	private void setHealth(double he2) {
		// TODO Auto-generated method stub
		
	}

	private void getHealth(boolean he2) {
		// TODO Auto-generated method stub
		
	}

	private void getHealth(int he) {
		// TODO Auto-generated method stub
		
	}

	public void onDeath(DamageSource dsource) {
		super.onDeath(dsource);
		int i = (int) this.posX;
		int j = (int) this.posY;
		int k = (int) this.posZ;
		Entity entity = this;
		
		
		
	}
	
	
	

		
	/*
	 * Implemented method from IAnimatedEntity.
	 * Set the animID field to the id in the parameter.
	 */
	public void setAnimID(int id) {
		animID = id;
	}
	
	/*
	 * Implemented method from IAnimatedEntity.
	 * Set the animTick field to the tick in the parameter.
	 */
	public void setAnimTick(int tick) {
		animTick = tick;
	}
	
	/*
	 * Implemented method from IAnimatedEntity.
	 * Return the animID.
	 */
	public int getAnimID() {
		return animID;
	}
	
	/*
	 * Implemented method from IAnimatedEntity.
	 * Return the animTick.
	 */
	public int getAnimTick() {
		return animTick;
	}
	
	public void onUpdate() {
		super.onUpdate();
		//increment the animTick if there is an animation playing
		if(animID != 0) animTick++;
	}
	
	public boolean attackEntityAsMob(Entity entity) {
		if(animID == 0) AnimationAPI.sendAnimPacket(this, 1);
		return true;
	}

	
	
	
	}
	

