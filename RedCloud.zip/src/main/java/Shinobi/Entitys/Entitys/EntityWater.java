package Shinobi.Entitys.Entitys;

import Shinobi.Entitys.EntityEarthGrudgeFear;
import Shinobi.Entitys.Entitys.AI.AIWaterBlast;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.SharedMonsterAttributes;
import net.minecraft.util.DamageSource;
import net.minecraft.world.World;
import thehippomasterAPI.AnimationAPI.AnimationAPI;
import thehippomasterAPI.AnimationAPI.IAnimatedEntity;

public class EntityWater extends EntityEarthGrudgeFear implements IAnimatedEntity {
	
	
	
	EntityWind Ewd;
	World world = null;
	private int animID;
	public int animTick;
	private int cooldown = 55;
	private int var = 0;
	
	public EntityWater(World var1) {
		super(var1);
		world = var1;
		animID = 0;
		animTick = 0;
		this.tasks.addTask(0, new AIWaterBlast(this));
		
		
	}
	
	@Override
	protected void applyEntityAttributes() {
		super.applyEntityAttributes();
		getEntityAttribute(SharedMonsterAttributes.maxHealth).setBaseValue(1000); //max health
		getEntityAttribute(SharedMonsterAttributes.movementSpeed).setBaseValue(0.25D); //move speed
		getEntityAttribute(SharedMonsterAttributes.knockbackResistance).setBaseValue(0.0D); //move speed
		if (this.getEntityAttribute(SharedMonsterAttributes.attackDamage) != null)
			this.getEntityAttribute(SharedMonsterAttributes.attackDamage).setBaseValue(15.0D);
		
	}
	
	public boolean isAIEnabled() {
		return true;
	}
	
	public float getAbsorptionAmount() {
		return 5;
		
	}
	
	public void onEntityUpdate() {
		super.onEntityUpdate();
		int i = (int) this.posX;
		int j = (int) this.posY;
		int k = (int) this.posZ;
		Entity entity = this;
		
		
		
	}
	
	
	public void onLivingUpdate() {
		super.onLivingUpdate();
		int i = (int) this.posX;
		int j = (int) this.posY;
		int k = (int) this.posZ;
		Entity entity = this;
		EntityLivingBase ew = Ewd;
		cooldown--;
		if(cooldown==var ){
			cooldown = 55;
		}
			
		if(this.getAttackTarget() != null && cooldown==1) {
			if(animID == 0) AnimationAPI.sendAnimPacket(this, 3);
		}
		
		
		
	}
	

	public void onDeath(DamageSource dsource) {
		super.onDeath(dsource);
		int i = (int) this.posX;
		int j = (int) this.posY;
		int k = (int) this.posZ;
		Entity entity = this;
		
		if(true) {
				world.spawnParticle("hugeexplosion", (double) i, (double) j, (double) k, 1.0D, 1.0D, 1.0D);
		}
		
		
		
		}

	
	
	
	

		
	/*
	 * Implemented method from IAnimatedEntity.
	 * Set the animID field to the id in the parameter.
	 */
	public void setAnimID(int id) {
		animID = id;
	}
	
	/*
	 * Implemented method from IAnimatedEntity.
	 * Set the animTick field to the tick in the parameter.
	 */
	public void setAnimTick(int tick) {
		animTick = tick;
	}
	
	/*
	 * Implemented method from IAnimatedEntity.
	 * Return the animID.
	 */
	public int getAnimID() {
		return animID;
	}
	
	/*
	 * Implemented method from IAnimatedEntity.
	 * Return the animTick.
	 */
	public int getAnimTick() {
		return animTick;
	}
	
	public void onUpdate() {
		super.onUpdate();
		//increment the animTick if there is an animation playing
		if(animID != 0) animTick++;
		
	}
	
	public boolean attackEntityAsMob(Entity entity) {
		//if(animID == 0) AnimationAPI.sendAnimPacket(this, 1);
	
		return true;

	
	
	}
	}
	

