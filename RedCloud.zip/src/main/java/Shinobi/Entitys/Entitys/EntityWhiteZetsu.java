package Shinobi.Entitys.Entitys;

import Shinobi.Entitys.EntityNinja;
import Shinobi.Entitys.Entitys.AI.AIslice;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityList;
import net.minecraft.entity.EntityLiving;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.SharedMonsterAttributes;
import net.minecraft.entity.passive.IAnimals;
import net.minecraft.util.DamageSource;
import net.minecraft.world.World;
import thehippomasterAPI.AnimationAPI.AnimationAPI;
import thehippomasterAPI.AnimationAPI.IAnimatedEntity;

public class EntityWhiteZetsu extends EntityNinja {
	
	
	
	World world = null;
	
	public EntityWhiteZetsu(World var1) {
		super(var1);
		world = var1;
		
		
		
	}
	
	@Override
	protected void applyEntityAttributes() {
		super.applyEntityAttributes();
		getEntityAttribute(SharedMonsterAttributes.maxHealth).setBaseValue(100); //max health
		getEntityAttribute(SharedMonsterAttributes.movementSpeed).setBaseValue(0.55D); //move speed
		getEntityAttribute(SharedMonsterAttributes.knockbackResistance).setBaseValue(0.0D); //move speed
		if (this.getEntityAttribute(SharedMonsterAttributes.attackDamage) != null)
			this.getEntityAttribute(SharedMonsterAttributes.attackDamage).setBaseValue(15.0D);
		
	}
	
	public boolean isAIEnabled() {
		return true;
	}
	
	
	public float getAbsorptionAmount() {
		return 3;
		
	}
	
	
		

	
	
	
	
	
	}
	

