package Shinobi.Entitys.Entitys;

import Shinobi.Entitys.EntityNinja;
import Shinobi.Entitys.Entitys.AI.AIslice;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityList;
import net.minecraft.entity.EntityLiving;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.SharedMonsterAttributes;
import net.minecraft.entity.passive.IAnimals;
import net.minecraft.potion.Potion;
import net.minecraft.potion.PotionEffect;
import net.minecraft.util.DamageSource;
import net.minecraft.world.World;
import thehippomasterAPI.AnimationAPI.AnimationAPI;
import thehippomasterAPI.AnimationAPI.IAnimatedEntity;

public class EntityZetsu extends EntityNinja {
	
	
	
	World world = null;
	private boolean inground;
	public int tix;
	
	public EntityZetsu(World var1) {
		super(var1);
		world = var1;
		
		
		
	}
	
	@Override
	protected void applyEntityAttributes() {
		super.applyEntityAttributes();
		getEntityAttribute(SharedMonsterAttributes.maxHealth).setBaseValue(5000); //max health
		getEntityAttribute(SharedMonsterAttributes.movementSpeed).setBaseValue(0.55D); //move speed
		getEntityAttribute(SharedMonsterAttributes.knockbackResistance).setBaseValue(0.0D); //move speed
		if (this.getEntityAttribute(SharedMonsterAttributes.attackDamage) != null)
			this.getEntityAttribute(SharedMonsterAttributes.attackDamage).setBaseValue(15.0D);
		
	}
	
	public boolean isAIEnabled() {
		return true;
	}
	
	
	public float getAbsorptionAmount() {
		return 3;
		
	}
	
	public boolean attackEntityFrom(DamageSource dmg, float flt) {
		Entity ent = dmg.getSourceOfDamage();
        
		if(inground==true) {
			return false;
		}
		
		
		if((Math.random() * 100) <= 30){
	           //  this.kamuiability(true);
	        //  this.worldObj.spawnParticle("explode", this.posX + (double) (this.rand.nextFloat() * this.width * 2.0F) - (double) this.width, this.posY + (double) (this.rand.nextFloat() * this.height), this.posZ + (double) (this.rand.nextFloat() * this.width * 2.0F) - (double) this.width, 0, 0, 0);
	            
			inground=true;
				//return false;
			}

		
		return super.attackEntityFrom(dmg, flt);
	}
	
	public void onLivingUpdate() {
		super.onLivingUpdate();
		int i = (int) this.posX;
		int j = (int) this.posY;
		int k = (int) this.posZ;
		Entity entity = this;
		if(this.getHealth()<500){
		this.heal(1);
		}
		if(true) {
			this.stepHeight = 50f;
			this.fallDistance = 0f;
			this.fireResistance = 10;
		}
		
		if(inground==true) {
			
			this.noClip=true;
			tix++;
			if(tix==20){
			this.motionY=0;
			this.teleportRandomly(3);
			}
			
			if(tix==25 && !this.onGround)this.motionY=0.7F;
			
		}
		else
		{
			this.noClip = false;
			tix = 0;
		}
		
		if(tix>26)inground = false;
		
	
	}
	
	

	public boolean attackEntityAsMob(Entity ent) {
		ent = this.getAttackTarget();
		if(ent!=null && (Math.random() * 100) <= 20){
		switch(rand.nextInt(3))
		{
		
		case 0:
			ent.worldObj.spawnParticle("ink", ent.posX + (double) (this.rand.nextFloat() * ent.width * 2.0F) - (double) ent.width, ent.posY + (double) (this.rand.nextFloat() * ent.height), ent.posZ + (double) (this.rand.nextFloat() * ent.width * 2.0F) - (double) ent.width, 0, 0, 0);
			((EntityLivingBase) ent).addPotionEffect(new PotionEffect(Potion.moveSlowdown.id, 100, 15*20));
			
			break;
			
			
		case 1:
			if (!worldObj.isRemote) {
					Entity entity1 = EntityList.createEntityByName("34WhiteZetsu", worldObj);
					if (entity1 != null) {
						entity1.setLocationAndAngles(ent.posX, ent.posY, ent.posZ, this.worldObj.rand.nextFloat() * 360F, 0.0F);
						worldObj.spawnEntityInWorld(entity1);
						((EntityLiving) entity1).playLivingSound();
					
			
		}
			}
			break;
			
			
		case 2:
			if (!worldObj.isRemote) {
				Entity entity1 = EntityList.createEntityByName("34WoodVines", worldObj);
				if (entity1 != null) {
					entity1.setLocationAndAngles(ent.posX, ent.posY, ent.posZ, ent.worldObj.rand.nextFloat() * 360F, 0.0F);
					worldObj.spawnEntityInWorld(entity1);
				
		}
				
	}
			break;
			
			default:
				break;
		
		}
		
		
		
		
		
		
		
		
		
		
		}
		
		
		
		return super.attackEntityAsMob(ent);
		
	}
		
	

	public void onDeath(DamageSource dsource) {
		super.onDeath(dsource);
		int i = (int) this.posX;
		int j = (int) this.posY;
		int k = (int) this.posZ;
		Entity entity = this;
		}
	
	

		

	
	
	
	
	
	}
	

