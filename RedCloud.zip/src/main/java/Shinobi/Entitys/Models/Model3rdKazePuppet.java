package Shinobi.Entitys.Models;

import net.minecraft.client.model.ModelBase;
import net.minecraft.client.model.ModelRenderer;
import net.minecraft.entity.Entity;
import net.minecraft.util.MathHelper;
import thehippomasterAPI.AnimationAPI.IAnimatedEntity;
import thehippomasterAPI.AnimationAPI.client.Animator;

/**
 * ModelBiped - Either Mojang or a mod author
 * Created using Tabula 4.1.1
 */
public class Model3rdKazePuppet extends ModelBase {
    public ModelRenderer hair;
    public ModelRenderer rightarm;
    public ModelRenderer body;
    public ModelRenderer leftarm;
    public ModelRenderer shape20;
    public ModelRenderer knbtm;
    public ModelRenderer K1;
    public ModelRenderer K2;
    public ModelRenderer K3;
    public ModelRenderer K4;
    public ModelRenderer shape18;
    public ModelRenderer b1;
    public ModelRenderer b2;
    public ModelRenderer b3;
    public ModelRenderer b4;
    public ModelRenderer shape19;
    public ModelRenderer head;

    private Animator animator;
	
	public static final float PI = (float)Math.PI;
	
    public Model3rdKazePuppet() {
    	
        this.textureWidth = 64;
        this.textureHeight = 64;
        
        this.shape18 = new ModelRenderer(this, 0, 50);
        this.shape18.setRotationPoint(-5.9F, 1.0F, -0.1F);
        this.shape18.addBox(0.0F, 0.0F, 0.0F, 3, 3, 1, 0.0F);
        
        
        this.b2 = new ModelRenderer(this, 0, 19);
        this.b2.setRotationPoint(0.2F, 5.0F, 0.5F);
        this.b2.addBox(0.0F, 0.0F, 0.0F, 2, 3, 1, 0.0F);
        
        this.head = new ModelRenderer(this, 0, 0);
        this.head.setRotationPoint(0.0F, 0.0F, 0.0F);
        this.head.addBox(-4.0F, -8.0F, -4.0F, 8, 8, 8, 0.0F);
        
        this.knbtm = new ModelRenderer(this, 0, 38);
        this.knbtm.setRotationPoint(0.0F, 10.0F, 0.0F);
        this.knbtm.addBox(-3.5F, -1.0F, -2.5F, 4, 4, 5, 0.0F);
        
        this.shape19 = new ModelRenderer(this, 0, 55);
        this.shape19.setRotationPoint(-2.0F, 0.0F, 0.0F);
        this.shape19.addBox(0.0F, -0.4F, 0.0F, 2, 4, 1, 0.0F);
        
        this.b1 = new ModelRenderer(this, 0, 19);
        this.b1.setRotationPoint(0.1F, 3.4F, 0.6F);
        this.b1.addBox(0.0F, 0.0F, 0.0F, 1, 3, 1, 0.0F);
        
        this.K2 = new ModelRenderer(this, 0, 25);
        this.K2.setRotationPoint(-4.5F, 2.2F, -1.0F);
        this.K2.addBox(0.0F, 0.0F, 0.0F, 3, 5, 2, 0.0F);
        
        this.K4 = new ModelRenderer(this, 0, 25);
        this.K4.setRotationPoint(-2.1F, 1.5F, 1.8F);
        this.K4.addBox(0.0F, 0.0F, 0.0F, 2, 3, 2, 0.0F);
        
        this.b4 = new ModelRenderer(this, 0, 19);
        this.b4.setRotationPoint(0.5F, 3.0F, 0.4F);
        this.b4.addBox(0.0F, 0.0F, 0.0F, 1, 3, 1, 0.0F);
        
        this.shape20 = new ModelRenderer(this, 18, 47);
        this.shape20.setRotationPoint(0.0F, 1.0F, -2.2F);
        this.shape20.addBox(-8.0F, -14.0F, -2.0F, 16, 12, 5, 0.0F);
        
        
        this.K3 = new ModelRenderer(this, 0, 25);
        this.K3.setRotationPoint(-3.9F, 1.7F, -3.0F);
        this.K3.addBox(0.0F, 0.0F, 0.0F, 3, 4, 2, 0.0F);
        
        this.rightarm = new ModelRenderer(this, 40, 16);
        this.rightarm.setRotationPoint(-5.0F, 0.0F, 0.0F);
        this.rightarm.addBox(-3.0F, -2.0F, -2.0F, 4, 12, 4, 0.0F);
        
        
        this.body = new ModelRenderer(this, 16, 16);
        this.body.setRotationPoint(0.0F, -2.0F, 0.0F);
        this.body.addBox(-4.0F, 0.0F, -2.0F, 8, 17, 4, 0.0F);
        
        this.b3 = new ModelRenderer(this, 0, 19);
        this.b3.mirror = true;
        this.b3.setRotationPoint(0.3F, 4.0F, 0.0F);
        this.b3.addBox(0.0F, 0.0F, 0.0F, 2, 2, 1, 0.0F);
        
        this.leftarm = new ModelRenderer(this, 40, 16);
        this.leftarm.mirror = true;
        this.leftarm.setRotationPoint(5.0F, 0.0F, 0.0F);
        this.leftarm.addBox(-1.0F, -2.0F, -2.0F, 4, 12, 4, 0.0F);
        
        this.hair = new ModelRenderer(this, 32, 0);
        this.hair.setRotationPoint(0.0F, -2.0F, 0.0F);
        this.hair.addBox(-4.0F, -8.0F, -4.0F, 8, 8, 8, 0.5F);
        
        this.K1 = new ModelRenderer(this, 0, 25);
        this.K1.setRotationPoint(-4.1F, 1.9F, 0.8F);
        this.K1.addBox(0.0F, 0.0F, 0.0F, 2, 4, 2, 0.0F);
        
        animator = new Animator(this);
        
        this.knbtm.addChild(this.shape18);
        this.K2.addChild(this.b2);
        this.body.addChild(this.head);
        this.rightarm.addChild(this.knbtm);
        this.shape18.addChild(this.shape19);
        this.K1.addChild(this.b1);
        this.knbtm.addChild(this.K2);
        this.knbtm.addChild(this.K4);
        this.K4.addChild(this.b4);
        this.knbtm.addChild(this.K3);
        this.K3.addChild(this.b3);
        this.knbtm.addChild(this.K1);
    }

    @Override
    public void render(Entity entity, float f, float f1, float f2, float f3, float f4, float f5) { 
    	animate((IAnimatedEntity)entity, f, f1, f2, f3, f4, f5);
    	this.shape20.render(f5);
        this.rightarm.render(f5);
        this.body.render(f5);
        this.leftarm.render(f5);
        this.hair.render(f5);
    }
    
    public void animate(IAnimatedEntity entity, float f, float f1, float f2, float f3, float f4, float f5) {
		animator.update(entity);
		setAngles();
		
		this.head.rotateAngleY = f3 / (180F / (float)Math.PI);
        this.head.rotateAngleX = f4 / (180F / (float)Math.PI);    
        this.rightarm.rotateAngleX = MathHelper.cos(f * 0.6662F + (float)Math.PI) * 2.0F * f1 * 0.5F;
        this.leftarm.rotateAngleX = MathHelper.cos(f * 0.6662F) * 2.0F * f1 * 0.5F;
		
        animator.setAnim(1);
        animator.startPhase(10);
       animator.rotate(rightarm, -1.3F, 0.2F, 1.4F);
        animator.endPhase();
        
        animator.setAnim(2);
        animator.startPhase(10);
       animator.rotate(rightarm, -1F, 0F, 0F);
        animator.endPhase();
        animator.setStationaryPhase(10);
        
        animator.setAnim(3);
        animator.startPhase(10);
       animator.rotate(rightarm, -1F, 0F, 0F);
        animator.endPhase();
        animator.setStationaryPhase(20);
        
        animator.setAnim(4);
        animator.startPhase(10);
       animator.rotate(rightarm, -1F, 0F, 0F);
        animator.endPhase();
        animator.setStationaryPhase(20);
		
    }

    private void setAngles() {
    	
		        this.setRotateAngle(leftarm, 0.0F, 0.0F, -0.08726646259971647F);
		        this.setRotateAngle(rightarm, 0.0F, 0.0F, 0.08726646259971647F);
		        this.setRotateAngle(shape20, -0.7740535232594852F, 0.0F, 0.0F);
		        this.setRotateAngle(shape18, 0.0F, 0.0F, 0.27314402793711257F);
	}

	/**
     * This is a helper function from Tabula to set the rotation of model parts
     */
    public void setRotateAngle(ModelRenderer modelRenderer, float x, float y, float z) {
        modelRenderer.rotateAngleX = x;
        modelRenderer.rotateAngleY = y;
        modelRenderer.rotateAngleZ = z;
    }
}
