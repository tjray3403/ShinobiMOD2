package Shinobi.Entitys.Models;

import org.lwjgl.opengl.GL11;

import net.minecraft.client.model.ModelBase;
import net.minecraft.client.model.ModelRenderer;
import net.minecraft.entity.Entity;
import thehippomasterAPI.AnimationAPI.IAnimatedEntity;
import thehippomasterAPI.AnimationAPI.client.Animator;

/**
 * ModelBiped - Either Mojang or a mod author
 * Created using Tabula 4.1.1
 */
public class ModelBonesusanoo extends ModelBase {
    public ModelRenderer field_78112_f;
    public ModelRenderer field_78116_c;
    public ModelRenderer field_78115_e;
    public ModelRenderer field_78113_g;
    
    private Animator animator;
    
    public static final float PI = (float)Math.PI;

    public ModelBonesusanoo() {
        this.textureWidth = 64;
        this.textureHeight = 32;
        this.field_78113_g = new ModelRenderer(this, 40, 16);
        this.field_78113_g.mirror = true;
        this.field_78113_g.setRotationPoint(35.0F, -35.0F, -0.0F);
        this.field_78113_g.addBox(-1.0F, -2.0F, -2.0F, 4, 12, 4, 0.0F);
        this.setRotateAngle(field_78113_g, 0.0F, 0.0F, -0.10000736613927509F);
        this.field_78115_e = new ModelRenderer(this, 16, 16);
        this.field_78115_e.setRotationPoint(0.0F, -40.0F, 0.0F);
        this.field_78115_e.addBox(-4.0F, 0.0F, -2.0F, 8, 12, 4, 0.0F);
        this.field_78116_c = new ModelRenderer(this, 0, 0);
        this.field_78116_c.setRotationPoint(0.0F, -40.0F, 0.0F);
        this.field_78116_c.addBox(-4.0F, -8.0F, -4.0F, 8, 8, 8, 0.0F);
        this.field_78112_f = new ModelRenderer(this, 40, 16);
        this.field_78112_f.setRotationPoint(-35.0F, -35.0F, 0.0F);
        this.field_78112_f.addBox(-3.0F, -2.0F, -2.0F, 4, 12, 4, 0.0F);
        this.setRotateAngle(field_78112_f, 0.0F, 0.0F, 0.10000736613927509F);
    
        animator = new Animator(this);
        
    }
    
    public void animate(IAnimatedEntity entity, float f, float f1, float f2, float f3, float f4, float f5) {
		animator.update(entity);
		setAngles();
		
		animator.setAnim(1);
		animator.startPhase(4);
			animator.rotate(field_78112_f, -PI / 2F, PI / 2F, 0F);
			animator.rotate(field_78113_g, PI / 2F, -PI / 2F, 0F);

		animator.endPhase();
		animator.startPhase(4);
			animator.rotate(field_78112_f, -PI / 2F, -PI / 2F, PI / 4F);	
			animator.rotate(field_78113_g, PI / 2F, PI / 2F, -PI / 4F);	

		animator.endPhase();
		
		
		animator.setStationaryPhase(6);
		animator.resetPhase(10);
    }

    private void setAngles() {
		// TODO Auto-generated method stub
		
	}

	@Override
    public void render(Entity entity, float f, float f1, float f2, float f3, float f4, float f5) { 
		GL11.glPushMatrix();
        GL11.glTranslatef(this.field_78113_g.offsetX, this.field_78113_g.offsetY, this.field_78113_g.offsetZ);
        GL11.glTranslatef(this.field_78113_g.rotationPointX * f5, this.field_78113_g.rotationPointY * f5, this.field_78113_g.rotationPointZ * f5);
        GL11.glScaled(6.0D, 6.0D, 6.0D);
        GL11.glTranslatef(-this.field_78113_g.offsetX, -this.field_78113_g.offsetY, -this.field_78113_g.offsetZ);
        GL11.glTranslatef(-this.field_78113_g.rotationPointX * f5, -this.field_78113_g.rotationPointY * f5, -this.field_78113_g.rotationPointZ * f5);
        GL11.glEnable(GL11.GL_BLEND);
        GL11.glBlendFunc(GL11.GL_SRC_ALPHA, GL11.GL_ONE_MINUS_SRC_ALPHA);
        GL11.glColor4f(1.0F, 1.0F, 1.0F, 0.7F);
        this.field_78113_g.render(f5);
        GL11.glDisable(GL11.GL_BLEND);
        GL11.glPopMatrix();
        GL11.glPushMatrix();
        GL11.glTranslatef(this.field_78115_e.offsetX, this.field_78115_e.offsetY, this.field_78115_e.offsetZ);
        GL11.glTranslatef(this.field_78115_e.rotationPointX * f5, this.field_78115_e.rotationPointY * f5, this.field_78115_e.rotationPointZ * f5);
        GL11.glScaled(6.0D, 6.0D, 6.0D);
        GL11.glTranslatef(-this.field_78115_e.offsetX, -this.field_78115_e.offsetY, -this.field_78115_e.offsetZ);
        GL11.glTranslatef(-this.field_78115_e.rotationPointX * f5, -this.field_78115_e.rotationPointY * f5, -this.field_78115_e.rotationPointZ * f5);
        GL11.glEnable(GL11.GL_BLEND);
        GL11.glBlendFunc(GL11.GL_SRC_ALPHA, GL11.GL_ONE_MINUS_SRC_ALPHA);
        GL11.glColor4f(1.0F, 1.0F, 1.0F, 0.7F);
        this.field_78115_e.render(f5);
        GL11.glDisable(GL11.GL_BLEND);
        GL11.glPopMatrix();
        GL11.glPushMatrix();
        GL11.glTranslatef(this.field_78116_c.offsetX, this.field_78116_c.offsetY, this.field_78116_c.offsetZ);
        GL11.glTranslatef(this.field_78116_c.rotationPointX * f5, this.field_78116_c.rotationPointY * f5, this.field_78116_c.rotationPointZ * f5);
        GL11.glScaled(6.0D, 6.0D, 6.0D);
        GL11.glTranslatef(-this.field_78116_c.offsetX, -this.field_78116_c.offsetY, -this.field_78116_c.offsetZ);
        GL11.glTranslatef(-this.field_78116_c.rotationPointX * f5, -this.field_78116_c.rotationPointY * f5, -this.field_78116_c.rotationPointZ * f5);
        GL11.glEnable(GL11.GL_BLEND);
        GL11.glBlendFunc(GL11.GL_SRC_ALPHA, GL11.GL_ONE_MINUS_SRC_ALPHA);
        GL11.glColor4f(1.0F, 1.0F, 1.0F, 0.7F);
        this.field_78116_c.render(f5);
        GL11.glDisable(GL11.GL_BLEND);
        GL11.glPopMatrix();
        GL11.glPushMatrix();
        GL11.glTranslatef(this.field_78112_f.offsetX, this.field_78112_f.offsetY, this.field_78112_f.offsetZ);
        GL11.glTranslatef(this.field_78112_f.rotationPointX * f5, this.field_78112_f.rotationPointY * f5, this.field_78112_f.rotationPointZ * f5);
        GL11.glScaled(6.0D, 6.0D, 6.0D);
        GL11.glTranslatef(-this.field_78112_f.offsetX, -this.field_78112_f.offsetY, -this.field_78112_f.offsetZ);
        GL11.glTranslatef(-this.field_78112_f.rotationPointX * f5, -this.field_78112_f.rotationPointY * f5, -this.field_78112_f.rotationPointZ * f5);
        GL11.glEnable(GL11.GL_BLEND);
        GL11.glBlendFunc(GL11.GL_SRC_ALPHA, GL11.GL_ONE_MINUS_SRC_ALPHA);
        GL11.glColor4f(1.0F, 1.0F, 1.0F, 0.7F);
        this.field_78112_f.render(f5);
        GL11.glDisable(GL11.GL_BLEND);
        GL11.glPopMatrix();
    }

    /**
     * This is a helper function from Tabula to set the rotation of model parts
     */
    public void setRotateAngle(ModelRenderer modelRenderer, float x, float y, float z) {
        modelRenderer.rotateAngleX = x;
        modelRenderer.rotateAngleY = y;
        modelRenderer.rotateAngleZ = z;
    }
}
