package Shinobi.Entitys.Models;

import net.minecraft.client.model.ModelBase;
import net.minecraft.client.model.ModelRenderer;
import net.minecraft.entity.Entity;

public class ModelC4 extends ModelBase
{
  //fields
    ModelRenderer head;
    ModelRenderer body;
    ModelRenderer rightarm;
    ModelRenderer leftarm;
    ModelRenderer body2;
    ModelRenderer body3;
    ModelRenderer Shape1;
    ModelRenderer Shape2;
  
  public ModelC4()
  {
    textureWidth = 128;
    textureHeight = 140;
    
      head = new ModelRenderer(this, 0, 109);
      head.addBox(-4F, -8F, -4F, 8, 12, 8);
      head.setRotationPoint(0F, -30F, -11F);
      head.setTextureSize(128, 140);
      head.mirror = true;
      setRotation(head, 0F, 0F, 0F);
      body = new ModelRenderer(this, 16, 16);
      body.addBox(-7.5F, 0F, -7.5F, 15, 15, 15);
      body.setRotationPoint(0F, -46F, 0F);
      body.setTextureSize(128, 140);
      body.mirror = true;
      setRotation(body, 0F, 0F, 0F);
      rightarm = new ModelRenderer(this, 40, 16);
      rightarm.addBox(-25F, -8F, -2F, 25, 18, 8);
      rightarm.setRotationPoint(-8F, -22F, -3F);
      rightarm.setTextureSize(128, 140);
      rightarm.mirror = true;
      setRotation(rightarm, 0F, 0F, 0.3490659F);
      leftarm = new ModelRenderer(this, 40, 16);
      leftarm.addBox(0F, -8F, -3F, 25, 18, 8);
      leftarm.setRotationPoint(8F, -22F, -3F);
      leftarm.setTextureSize(128, 140);
      leftarm.mirror = true;
      setRotation(leftarm, 0F, 0F, -0.3490659F);
      body2 = new ModelRenderer(this, 0, 16);
      body2.addBox(-12.5F, 0F, -12.5F, 25, 20, 25);
      body2.setRotationPoint(0F, -31F, 0F);
      body2.setTextureSize(128, 140);
      body2.mirror = true;
      setRotation(body2, 0F, 0F, 0F);
      body3 = new ModelRenderer(this, 7, 1);
      body3.addBox(-15F, 0F, -15F, 30, 35, 30);
      body3.setRotationPoint(0F, -11F, 0F);
      body3.setTextureSize(128, 140);
      body3.mirror = true;
      setRotation(body3, 0F, 0F, 0F);
      Shape1 = new ModelRenderer(this, 51, 106);
      Shape1.addBox(-30F, -11F, -4F, 30, 25, 8);
      Shape1.setRotationPoint(-28F, -30F, -3F);
      Shape1.setTextureSize(128, 140);
      Shape1.mirror = true;
      setRotation(Shape1, 0F, -0.122173F, 0.7330383F);
      Shape2 = new ModelRenderer(this, 0, 72);
      Shape2.addBox(0F, -11F, -4F, 30, 25, 8);
      Shape2.setRotationPoint(28F, -30F, -3F);
      Shape2.setTextureSize(128, 140);
      Shape2.mirror = true;
      setRotation(Shape2, 0F, 0.122173F, -0.7330383F);
  }
  
  public void render(Entity entity, float f, float f1, float f2, float f3, float f4, float f5)
  {
    super.render(entity, f, f1, f2, f3, f4, f5);
    setRotationAngles(f, f1, f2, f3, f4, f5, entity);
    head.render(f5);
    body.render(f5);
    rightarm.render(f5);
    leftarm.render(f5);
    body2.render(f5);
    body3.render(f5);
    Shape1.render(f5);
    Shape2.render(f5);
  }
  
  private void setRotation(ModelRenderer model, float x, float y, float z)
  {
    model.rotateAngleX = x;
    model.rotateAngleY = y;
    model.rotateAngleZ = z;
  }
  
  public void setRotationAngles(float f, float f1, float f2, float f3, float f4, float f5, Entity entity)
  {
    super.setRotationAngles(f, f1, f2, f3, f4, f5, entity);
  }

}
