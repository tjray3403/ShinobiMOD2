package Shinobi.Entitys.Models;

import net.minecraft.client.model.ModelBase;
import net.minecraft.client.model.ModelRenderer;
import net.minecraft.entity.Entity;
import net.minecraft.util.MathHelper;

import org.lwjgl.opengl.GL11;

/**
 * ModelSpider - Either Mojang or a mod author
 * Created using Tabula 4.1.1
 */
public class ModelChameleonS extends ModelBase {
    public ModelRenderer body;
    public ModelRenderer rightleg;
    public ModelRenderer rightarm;
    public ModelRenderer head;
    public ModelRenderer body2;
    public ModelRenderer leftleg;
    public ModelRenderer leftarm;
    public ModelRenderer sn1;
    public ModelRenderer lw;
    public ModelRenderer rw;
    public ModelRenderer t1;
    public ModelRenderer t2;
    public ModelRenderer t3;
    public ModelRenderer snk2;
    public ModelRenderer snakehead;

    public ModelChameleonS() {
        this.textureWidth = 64;
        this.textureHeight = 90;
        this.body2 = new ModelRenderer(this, 31, 35);
        this.body2.setRotationPoint(0.0F, 16.0F, 9.0F);
        this.body2.addBox(-4.5F, -3.0F, 0.0F, 9, 6, 7, 0.0F);
        this.t2 = new ModelRenderer(this, 0, 36);
        this.t2.setRotationPoint(0.0F, 0.0F, 8.0F);
        this.t2.addBox(-2.5F, -0.8F, 0.0F, 5, 3, 7, 0.0F);
        this.setRotateAngle(t2, 0.08726646259971647F, 0.0F, 0.0F);
        this.t1 = new ModelRenderer(this, 0, 5);
        this.t1.setRotationPoint(0.0F, -3.5F, -5.0F);
        this.t1.addBox(-3.5F, -1.0F, 0.0F, 7, 3, 8, 0.0F);
        this.setRotateAngle(t1, 0.2617993877991494F, 0.0F, 0.0F);
        this.rightleg = new ModelRenderer(this, 30, 23);
        this.rightleg.mirror = true;
        this.rightleg.setRotationPoint(-4.0F, 17.0F, 4.5F);
        this.rightleg.addBox(-10.0F, -1.0F, -1.0F, 10, 4, 4, 0.0F);
        this.setRotateAngle(rightleg, 0.0F, 0.7853981633974483F, -0.7853981633974483F);
        this.leftarm = new ModelRenderer(this, 30, 23);
        this.leftarm.setRotationPoint(4.0F, 15.0F, -1.0F);
        this.leftarm.addBox(0.0F, -1.0F, -1.0F, 12, 4, 4, 0.0F);
        this.setRotateAngle(leftarm, 0.0F, 0.7853981633974483F, 0.7853981633974483F);
        this.sn1 = new ModelRenderer(this, 0, 22);
        this.sn1.setRotationPoint(0.0F, 13.5F, 16.0F);
        this.sn1.addBox(-2.5F, 0.0F, 0.0F, 5, 5, 7, 0.0F);
        this.t3 = new ModelRenderer(this, 0, 48);
        this.t3.setRotationPoint(0.0F, 0.0F, 6.8F);
        this.t3.addBox(-1.5F, -0.7F, 0.0F, 3, 3, 7, 0.0F);
        this.setRotateAngle(t3, -0.08726646259971647F, 0.0F, 0.0F);
        this.leftleg = new ModelRenderer(this, 30, 23);
        this.leftleg.setRotationPoint(7.0F, 17.0F, 4.5F);
        this.leftleg.addBox(-1.0F, -1.0F, -1.0F, 10, 4, 4, 0.0F);
        this.setRotateAngle(leftleg, 0.0F, -0.7853981633974483F, 0.7853981633974483F);
        this.rightarm = new ModelRenderer(this, 30, 23);
        this.rightarm.mirror = true;
        this.rightarm.setRotationPoint(-4.0F, 15.0F, -1.0F);
        this.rightarm.addBox(-12.0F, -1.0F, -1.0F, 12, 4, 4, 0.0F);
        this.setRotateAngle(rightarm, 0.0F, -0.7853981633974483F, -0.7853981633974483F);
        this.head = new ModelRenderer(this, 32, 4);
        this.head.setRotationPoint(0.0F, 15.0F, -4.0F);
        this.head.addBox(-4.0F, -4.0F, -8.0F, 8, 8, 9, 0.0F);
        this.body = new ModelRenderer(this, 0, 66);
        this.body.setRotationPoint(0.0F, -106.8F, 0.0F);
        this.body.addBox(-6.0F, 12.0F, -3.0F, 12, 8, 12, 0.0F);
        this.snk2 = new ModelRenderer(this, 9, 44);
        this.snk2.setRotationPoint(0.0F, 2.5F, 7.0F);
        this.snk2.addBox(-1.5F, -2.0F, 0.0F, 3, 4, 15, 0.0F);
        this.setRotateAngle(snk2, 0.0F, 0.0F, 0.008377580409572781F);
        this.lw = new ModelRenderer(this, 50, 50);
        this.lw.setRotationPoint(3.5F, 10.9F, 0.0F);
        this.lw.addBox(0.0F, -8.0F, -1.1F, 1, 8, 5, 0.0F);
        this.setRotateAngle(lw, -0.8726646259971648F, 0.0F, 0.0F);
        this.rw = new ModelRenderer(this, 50, 50);
        this.rw.mirror = true;
        this.rw.setRotationPoint(-4.5F, 10.9F, 0.0F);
        this.rw.addBox(0.0F, -8.0F, -1.1F, 1, 8, 5, 0.0F);
        this.setRotateAngle(rw, -0.8726646259971648F, 0.0F, 0.0F);
        this.snakehead = new ModelRenderer(this, 32, 49);
        this.snakehead.setRotationPoint(0.0F, 0.0F, 15.0F);
        this.snakehead.addBox(-2.0F, -2.5F, 0.0F, 4, 5, 4, 0.0F);
        this.body.addChild(this.body2);
        this.t1.addChild(this.t2);
        this.head.addChild(this.t1);
        this.body.addChild(this.rightleg);
        this.body.addChild(this.leftarm);
        this.body.addChild(this.sn1);
        this.t2.addChild(this.t3);
        this.body.addChild(this.leftleg);
        this.body.addChild(this.rightarm);
        this.body.addChild(this.head);
        this.sn1.addChild(this.snk2);
        this.body.addChild(this.lw);
        this.body.addChild(this.rw);
        this.snk2.addChild(this.snakehead);
    }

    @Override
    public void render(Entity entity, float f, float f1, float f2, float f3, float f4, float f5) { 
    	setRotationAngles(f, f1, f2, f3, f4, f5, entity);
    	GL11.glPushMatrix();
        GL11.glTranslatef(this.body.offsetX, this.body.offsetY, this.body.offsetZ);
        GL11.glTranslatef(this.body.rotationPointX * f5, this.body.rotationPointY * f5, this.body.rotationPointZ * f5);
        GL11.glScaled(5.5D, 5.5D, 5.5D);
        GL11.glTranslatef(-this.body.offsetX, -this.body.offsetY, -this.body.offsetZ);
        GL11.glTranslatef(-this.body.rotationPointX * f5, -this.body.rotationPointY * f5, -this.body.rotationPointZ * f5);
        this.body.render(f5);
        GL11.glPopMatrix();
    }

    /**
     * This is a helper function from Tabula to set the rotation of model parts
     */
    public void setRotateAngle(ModelRenderer modelRenderer, float x, float y, float z) {
        modelRenderer.rotateAngleX = x;
        modelRenderer.rotateAngleY = y;
        modelRenderer.rotateAngleZ = z;
    }
    
    public void setRotationAngles(float f, float f1, float f2, float f3, float f4, float f5, Entity entity) {
		super.setRotationAngles(f, f1, f2, f3, f4, f5, entity);
        this.head.rotateAngleY = f3 / (180F / (float)Math.PI);
        this.head.rotateAngleX = f4 / (180F / (float)Math.PI);    
        this.rightleg.rotateAngleX = MathHelper.cos(f * 1.0F) * -1.0F * f1;
        this.leftleg.rotateAngleX = MathHelper.cos(f * 1.0F) * 1.0F * f1;
        this.rightarm.rotateAngleX = MathHelper.cos(f * 0.6662F + (float)Math.PI) * 2.0F * f1 * 0.5F;
        this.leftarm.rotateAngleX = MathHelper.cos(f * 0.6662F) * 2.0F * f1 * 0.5F;
		
	}
}
