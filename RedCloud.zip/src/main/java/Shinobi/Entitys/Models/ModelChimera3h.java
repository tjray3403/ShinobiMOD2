package Shinobi.Entitys.Models;

import net.minecraft.client.model.ModelBase;
import net.minecraft.client.model.ModelRenderer;
import net.minecraft.entity.Entity;
import net.minecraft.util.MathHelper;

import org.lwjgl.opengl.GL11;

/**
 * ModelWolf - Either Mojang or a mod author
 * Created using Tabula 4.1.1
 */
public class ModelChimera3h extends ModelBase {
    public ModelRenderer body;
    public ModelRenderer leftleg;
    public ModelRenderer leftleg2;
    public ModelRenderer rightleg2;
    public ModelRenderer rightleg;
    public ModelRenderer tail;
    public ModelRenderer head;
    public ModelRenderer mane;
    public ModelRenderer head2;
    public ModelRenderer head3;
    public ModelRenderer snout;
    public ModelRenderer rod1;
    public ModelRenderer rw;
    public ModelRenderer lw;
    public ModelRenderer snout2;
    public ModelRenderer rod2;
    public ModelRenderer snout3;
    public ModelRenderer rod3;

    public ModelChimera3h() {
        this.textureWidth = 64;
        this.textureHeight = 32;
        this.head2 = new ModelRenderer(this, 0, 0);
        this.head2.setRotationPoint(3.0F, 0.0F, -4.5F);
        this.head2.addBox(-3.0F, -3.0F, -4.0F, 6, 6, 4, 0.0F);
        this.setRotateAngle(head2, 0.0F, -0.9599310885968813F, 0.0F);
        this.rightleg2 = new ModelRenderer(this, 0, 18);
        this.rightleg2.setRotationPoint(-2.5F, 2.0F, 4.0F);
        this.rightleg2.addBox(-1.0F, 0.0F, -1.0F, 2, 8, 2, 0.0F);
        this.head3 = new ModelRenderer(this, 0, 0);
        this.head3.setRotationPoint(-5.8F, 0.0F, -4.6F);
        this.head3.addBox(-3.0F, -3.0F, -4.0F, 6, 6, 4, 0.0F);
        this.setRotateAngle(head3, -0.12217304763960307F, 0.4363323129985824F, 0.0F);
        this.rod3 = new ModelRenderer(this, 20, 0);
        this.rod3.setRotationPoint(0.0F, 0.0F, -6.0F);
        this.rod3.addBox(-0.5F, -1.0F, 0.0F, 1, 2, 1, 0.0F);
        this.rw = new ModelRenderer(this, 16, 14);
        this.rw.setRotationPoint(0.5F, -2.0F, -1.8F);
        this.rw.addBox(-3.0F, -5.0F, 0.0F, 2, 4, 1, 0.0F);
        this.setRotateAngle(rw, -0.4886921905584123F, 0.0F, -0.12217304763960307F);
        this.head = new ModelRenderer(this, 0, 0);
        this.head.setRotationPoint(-1.0F, -1.0F, -5.5F);
        this.head.addBox(-3.0F, -3.0F, -4.0F, 6, 6, 4, 0.0F);
        this.snout2 = new ModelRenderer(this, 0, 10);
        this.snout2.setRotationPoint(0.0F, 0.0F, 0.0F);
        this.snout2.addBox(-1.5F, 0.0F, -7.0F, 3, 3, 4, 0.0F);
        this.snout3 = new ModelRenderer(this, 0, 10);
        this.snout3.setRotationPoint(0.0F, 0.0F, 0.0F);
        this.snout3.addBox(-1.5F, 0.0F, -7.0F, 3, 3, 4, 0.0F);
        this.leftleg2 = new ModelRenderer(this, 0, 18);
        this.leftleg2.setRotationPoint(0.5F, 2.0F, 4.0F);
        this.leftleg2.addBox(-1.0F, 0.0F, -1.0F, 2, 8, 2, 0.0F);
        this.rightleg = new ModelRenderer(this, 0, 18);
        this.rightleg.setRotationPoint(-3.0F, 2.0F, -4.0F);
        this.rightleg.addBox(-1.0F, 0.0F, -1.0F, 2, 8, 2, 0.0F);
        this.tail = new ModelRenderer(this, 9, 18);
        this.tail.setRotationPoint(-1.0F, -1.3F, 4.5F);
        this.tail.addBox(-1.0F, 0.0F, -1.0F, 2, 5, 2, 0.0F);
        this.setRotateAngle(tail, 0.7853981633974483F, 0.0F, 0.0F);
        this.snout = new ModelRenderer(this, 0, 10);
        this.snout.setRotationPoint(0.0F, 0.0F, 0.2F);
        this.snout.addBox(-1.5F, 0.0F, -7.0F, 3, 3, 4, 0.0F);
        this.setRotateAngle(snout, 0.0F, 0.007330382858376183F, 0.007812014006733319F);
        this.rod1 = new ModelRenderer(this, 20, 0);
        this.rod1.setRotationPoint(0.0F, -1.0F, -6.0F);
        this.rod1.addBox(-0.5F, 0.0F, 0.0F, 1, 2, 1, 0.0F);
        this.lw = new ModelRenderer(this, 16, 14);
        this.lw.setRotationPoint(-0.5F, -2.0F, -1.8F);
        this.lw.addBox(1.0F, -5.0F, 0.0F, 2, 4, 1, 0.0F);
        this.setRotateAngle(lw, -0.4886921905584123F, 0.0F, 0.12217304763960307F);
        this.body = new ModelRenderer(this, 18, 14);
        this.body.setRotationPoint(0.0F, -46.0F, 2.0F);
        this.body.addBox(-4.0F, -2.0F, -3.0F, 6, 6, 8, 0.0F);
        this.leftleg = new ModelRenderer(this, 0, 18);
        this.leftleg.setRotationPoint(1.0F, 2.0F, -4.0F);
        this.leftleg.addBox(-1.0F, 0.0F, -1.0F, 2, 8, 2, 0.0F);
        this.mane = new ModelRenderer(this, 21, 0);
        this.mane.setRotationPoint(-1.0F, 0.8F, -3.4F);
        this.mane.addBox(-5.0F, -3.0F, -3.0F, 10, 6, 4, 0.0F);
        this.setRotateAngle(mane, -0.3490658503988659F, 0.0F, 0.0F);
        this.rod2 = new ModelRenderer(this, 20, 0);
        this.rod2.setRotationPoint(0.0F, -1.0F, -6.0F);
        this.rod2.addBox(-0.5F, 0.0F, 0.0F, 1, 2, 1, 0.0F);
        this.body.addChild(this.head2);
        this.body.addChild(this.rightleg2);
        this.body.addChild(this.head3);
        this.snout3.addChild(this.rod3);
        this.mane.addChild(this.rw);
        this.body.addChild(this.head);
        this.head2.addChild(this.snout2);
        this.head3.addChild(this.snout3);
        this.body.addChild(this.leftleg2);
        this.body.addChild(this.rightleg);
        this.body.addChild(this.tail);
        this.head.addChild(this.snout);
        this.snout.addChild(this.rod1);
        this.mane.addChild(this.lw);
        this.body.addChild(this.leftleg);
        this.body.addChild(this.mane);
        this.snout2.addChild(this.rod2);
    }

    @Override
    public void render(Entity entity, float f, float f1, float f2, float f3, float f4, float f5) { 
    	setRotationAngles(f, f1, f2, f3, f4, f5, entity);
    	GL11.glPushMatrix();
        GL11.glTranslatef(this.body.offsetX, this.body.offsetY, this.body.offsetZ);
        GL11.glTranslatef(this.body.rotationPointX * f5, this.body.rotationPointY * f5, this.body.rotationPointZ * f5);
        GL11.glScaled(7.0D, 7.0D, 7.0D);
        GL11.glTranslatef(-this.body.offsetX, -this.body.offsetY, -this.body.offsetZ);
        GL11.glTranslatef(-this.body.rotationPointX * f5, -this.body.rotationPointY * f5, -this.body.rotationPointZ * f5);
        this.body.render(f5);
        GL11.glPopMatrix();
    }

    /**
     * This is a helper function from Tabula to set the rotation of model parts
     */
    public void setRotateAngle(ModelRenderer modelRenderer, float x, float y, float z) {
        modelRenderer.rotateAngleX = x;
        modelRenderer.rotateAngleY = y;
        modelRenderer.rotateAngleZ = z;
    }
    
    public void setRotationAngles(float f, float f1, float f2, float f3, float f4, float f5, Entity entity)
    {
      super.setRotationAngles(f, f1, f2, f3, f4, f5, entity);
      this.head.rotateAngleY = f3 / (180F / (float)Math.PI);
      this.head.rotateAngleX = f4 / (180F / (float)Math.PI);    
      this.leftleg.rotateAngleX = MathHelper.cos(f * 1.0F) * -1.0F * f1;
      this.rightleg.rotateAngleX = MathHelper.cos(f * 1.0F) * 1.0F * f1;
      this.rightleg2.rotateAngleX = MathHelper.cos(f * 0.6662F + (float)Math.PI) * 2.0F * f1 * 0.5F;
      this.leftleg2.rotateAngleX = MathHelper.cos(f * 0.6662F) * 2.0F * f1 * 0.5F;
    }
}
