package Shinobi.Entitys.Models;

import Shinobi.Entitys.Entitys.EntityClayDragon;
import net.minecraft.client.model.ModelBase;
import net.minecraft.client.model.ModelRenderer;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.monster.EntityIronGolem;
import net.minecraft.entity.passive.EntitySheep;
import net.minecraft.util.MathHelper;

/**
 * ModelBiped - Either Mojang or a mod author
 * Created using Tabula 4.1.1
 */
public class ModelClayDRagon extends ModelBase {
	
    public ModelRenderer rightarm;
    public ModelRenderer leftleg;
    public ModelRenderer body;
    public ModelRenderer leftarm;
    public ModelRenderer rightleg;
    public ModelRenderer tail1;
    public ModelRenderer lw1;
    public ModelRenderer rw1;
    public ModelRenderer rl1;
    public ModelRenderer rf1;
    public ModelRenderer ll2;
    public ModelRenderer lf2;
    public ModelRenderer neck1;
    public ModelRenderer neck2;
    public ModelRenderer neck3;
    public ModelRenderer head;
    public ModelRenderer mouthb;
    public ModelRenderer moutht;
    public ModelRenderer rh;
    public ModelRenderer lh;
    public ModelRenderer shape34;
    public ModelRenderer ll1;
    public ModelRenderer lf1;
    public ModelRenderer rl2;
    public ModelRenderer rf2;
    public ModelRenderer tail2;
    public ModelRenderer tail3;
    public ModelRenderer tail4;
    public ModelRenderer lw2;
    public ModelRenderer lw3;
    public ModelRenderer rw2;
    public ModelRenderer rw3;
	private boolean walk = true;

    public ModelClayDRagon() {
    	
        this.textureWidth = 300;
        this.textureHeight = 300;
        
        this.rw2 = new ModelRenderer(this, 0, 0);
        this.rw2.setRotationPoint(-42.0F, 0.0F, 0.0F);
        this.rw2.addBox(-36.0F, 0.0F, -31.0F, 36, 5, 55, 0.0F);
        this.setRotateAngle(rw2, 0.0F, 0.0F, -0.08726646259971647F);
        
        this.rf1 = new ModelRenderer(this, 0, 0);
        this.rf1.setRotationPoint(-5.0F, 17.0F, 1.0F);
        this.rf1.addBox(-7.0F, 0.0F, 0.0F, 14, 15, 9, 0.0F);
        this.setRotateAngle(rf1, -0.6981317007977318F, 0.0F, 0.0F);
        
        this.ll2 = new ModelRenderer(this, 0, 0);
        this.ll2.setRotationPoint(0.0F, 21.0F, 0.0F);
        this.ll2.addBox(0.0F, -5.2F, 0.0F, 10, 27, 14, 0.0F);
        this.setRotateAngle(ll2, -1.0471975511965976F, 0.0F, 0.0F);
        
        this.head = new ModelRenderer(this, 0, 130);
        this.head.setRotationPoint(0.0F, 0.0F, -25.5F);
        this.head.addBox(-16.0F, -15.0F, -28.0F, 32, 30, 28, 0.0F);
        this.setRotateAngle(head, 0.20943951023931953F, 0.0F, 0.0F);
        
        this.tail2 = new ModelRenderer(this, 0, 0);
        this.tail2.setRotationPoint(0.0F, 0.0F, 50.0F);
        this.tail2.addBox(-12.5F, -10.5F, 0.0F, 25, 24, 46, 0.0F);
        
        this.body = new ModelRenderer(this, 16, 16);
        this.body.setRotationPoint(0.0F, -20.0F, -10.0F);
        this.body.addBox(-25.0F, -20.0F, -2.0F, 50, 35, 70, 0.0F);
        
        this.rw3 = new ModelRenderer(this, 0, 200);
        this.rw3.setRotationPoint(-36.0F, 0.0F, 0.0F);
        this.rw3.addBox(-90.0F, 0.0F, -34.5F, 90, 5, 60, 0.0F);
        this.setRotateAngle(rw3, 0.0F, 0.0F, -0.2617993877991494F);
        
        this.lf1 = new ModelRenderer(this, 0, 0);
        this.lf1.setRotationPoint(5.0F, 17.0F, 1.0F);
        this.lf1.addBox(-7.0F, 0.0F, 0.0F, 14, 15, 9, 0.0F);
        this.setRotateAngle(lf1, -0.6981317007977318F, -0.0F, 0.0F);
        
        this.rf2 = new ModelRenderer(this, 0, 0);
        this.rf2.setRotationPoint(-5.0F, 16.0F, 9.0F);
        this.rf2.addBox(-7.0F, 0.0F, 0.0F, 14, 15, 9, 0.0F);
        this.setRotateAngle(rf2, -1.186823891356144F, 0.0F, 0.0F);
        
        this.rightarm = new ModelRenderer(this, 40, 16);
        this.rightarm.setRotationPoint(-26.0F, -11.0F, 0.0F);
        this.rightarm.addBox(-11.0F, -2.5F, -7.5F, 12, 25, 15, 0.0F);
        this.setRotateAngle(rightarm, 0.6981317007977318F, 0.0F, 0.0F);
        
        this.leftarm = new ModelRenderer(this, 40, 16);
        this.leftarm.mirror = true;
        this.leftarm.setRotationPoint(26.0F, -11.0F, 0.0F);
        this.leftarm.addBox(-1.0F, -2.5F, -7.5F, 12, 25, 15, 0.0F);
        this.setRotateAngle(leftarm, 0.6981317007977318F, 0.0F, 0.0F);
        
        this.leftleg = new ModelRenderer(this, 0, 16);
        this.leftleg.setRotationPoint(27.0F, -20.0F, 38.0F);
        this.leftleg.addBox(-2.0F, -4.0F, -8.0F, 12, 27, 18, 0.0F);
        this.setRotateAngle(leftleg, 0.5009094953223726F, 0.0F, 0.0F);
        
        this.neck1 = new ModelRenderer(this, 0, 0);
        this.neck1.setRotationPoint(0.0F, -1.0F, 0.0F);
        this.neck1.addBox(-17.0F, -17.1F, -25.0F, 34, 28, 25, 0.0F);
        this.setRotateAngle(neck1, -0.4363323129985824F, 0.0F, 0.0F);
        
        this.rightleg = new ModelRenderer(this, 0, 16);
        this.rightleg.setRotationPoint(-27.0F, -20.0F, 38.0F);
        this.rightleg.addBox(-10.0F, -4.0F, -8.0F, 12, 27, 18, 0.0F);
        this.setRotateAngle(rightleg, 0.6632251157578453F, 0.0F, 0.0F);
        
        this.tail1 = new ModelRenderer(this, 0, 0);
        this.tail1.setRotationPoint(0.0F, -24.5F, 58.0F);
        this.tail1.addBox(-19.0F, -12.0F, 0.0F, 38, 27, 50, 0.0F);
        
        this.shape34 = new ModelRenderer(this, 0, 0);
        this.shape34.setRotationPoint(0.0F, 10.9F, -20.0F);
        this.shape34.addBox(-3.5F, 0.0F, -3.5F, 9, 12, 9, 0.0F);
        this.setRotateAngle(shape34, -0.5235987755982988F, 0.0F, 0.0F);
        
        this.lh = new ModelRenderer(this, 0, 0);
        this.lh.setRotationPoint(9.0F, -14.0F, -4.0F);
        this.lh.addBox(-3.5F, -10.0F, -3.5F, 7, 10, 7, 0.0F);
        this.setRotateAngle(lh, 0.2617993877991494F, 0.0F, 0.0F);
        
        this.tail3 = new ModelRenderer(this, 0, 0);
        this.tail3.setRotationPoint(0.0F, 0.0F, 46.0F);
        this.tail3.addBox(-14.0F, -13.0F, 0.0F, 28, 27, 34, 0.0F);
        
        this.mouthb = new ModelRenderer(this, 172, 125);
        this.mouthb.setRotationPoint(-0.3F, 4.5F, -28.0F);
        this.mouthb.addBox(-17.0F, 0.0F, -24.0F, 34, 14, 29, 0.0F);
        this.setRotateAngle(mouthb, 0.08726646259971647F, 0.0F, 0.0F);
        
        this.lf2 = new ModelRenderer(this, 0, 0);
        this.lf2.setRotationPoint(5.0F, 16.0F, 9.0F);
        this.lf2.addBox(-7.0F, 0.0F, 0.0F, 14, 15, 9, 0.0F);
        this.setRotateAngle(lf2, -1.186823891356144F, 0.0F, 0.0F);
        
        this.lw1 = new ModelRenderer(this, 0, 0);
        this.lw1.setRotationPoint(7.0F, -40.0F, 22.0F);
        this.lw1.addBox(0.0F, 0.0F, -22.0F, 42, 5, 44, 0.0F);
        this.setRotateAngle(lw1, 0.0F, 0.0F, -0.4363323129985824F);
        
        this.lw2 = new ModelRenderer(this, 0, 0);
        this.lw2.setRotationPoint(42.0F, 0.0F, 0.0F);
        this.lw2.addBox(0.0F, 0.0F, -31.0F, 36, 5, 55, 0.0F);
        this.setRotateAngle(lw2, 0.0F, 0.0F, 0.08726646259971647F);
        
        this.rh = new ModelRenderer(this, 0, 0);
        this.rh.setRotationPoint(-9.0F, -14.0F, -4.0F);
        this.rh.addBox(-3.5F, -10.0F, -3.5F, 7, 10, 7, 0.0F);
        this.setRotateAngle(rh, 0.2617993877991494F, 0.0F, 0.0F);
        
        this.lw3 = new ModelRenderer(this, 0, 200);
        this.lw3.setRotationPoint(36.0F, 0.0F, 0.0F);
        this.lw3.addBox(0.0F, 0.0F, -34.5F, 90, 5, 60, 0.0F);
        this.setRotateAngle(lw3, 0.0F, 0.0F, 0.2617993877991494F);
        
        this.rw1 = new ModelRenderer(this, 0, 0);
        this.rw1.setRotationPoint(-7.0F, -40.0F, 22.0F);
        this.rw1.addBox(-42.0F, 0.0F, -22.0F, 42, 5, 44, 0.0F);
        this.setRotateAngle(rw1, 0.0F, 0.0F, 0.4363323129985824F);
        
        this.rl1 = new ModelRenderer(this, 0, 0);
        this.rl1.setRotationPoint(0.0F, 19.0F, 0.0F);
        this.rl1.addBox(-11.0F, 0.0F, -7.5F, 12, 22, 15, 0.0F);
        this.setRotateAngle(rl1, -1.5882496193148399F, 0.0F, 0.0F);
        
        this.neck3 = new ModelRenderer(this, 0, 0);
        this.neck3.setRotationPoint(0.0F, 0.0F, -25.0F);
        this.neck3.addBox(-12.0F, -11.5F, -25.0F, 24, 23, 25, 0.0F);
        this.setRotateAngle(neck3, 0.12217304763960307F, 0.0F, 0.0F);
        
        this.neck2 = new ModelRenderer(this, 0, 0);
        this.neck2.setRotationPoint(0.0F, -3.0F, -25.0F);
        this.neck2.addBox(-12.0F, -12.0F, -25.0F, 24, 24, 25, 0.0F);
        this.setRotateAngle(neck2, 0.08726646259971647F, 0.0F, 0.0F);
        
        this.rl2 = new ModelRenderer(this, 0, 0);
        this.rl2.setRotationPoint(0.0F, 21.0F, 0.0F);
        this.rl2.addBox(-10.0F, -5.2F, 0.0F, 10, 27, 14, 0.0F);
        this.setRotateAngle(rl2, -1.0471975511965976F, 0.0F, 0.0F);
        
        this.tail4 = new ModelRenderer(this, 0, 0);
        this.tail4.setRotationPoint(0.0F, 0.0F, 34.0F);
        this.tail4.addBox(-10.0F, -11.0F, 0.0F, 20, 22, 30, 0.0F);
        
        this.ll1 = new ModelRenderer(this, 0, 0);
        this.ll1.setRotationPoint(0.0F, 19.0F, 0.0F);
        this.ll1.addBox(-1.0F, 0.0F, -7.5F, 12, 22, 15, 0.0F);
        this.setRotateAngle(ll1, -1.5882496193148399F, 0.0F, 0.0F);
        
        this.moutht = new ModelRenderer(this, 172, 0);
        this.moutht.setRotationPoint(0.0F, 1.0F, -28.0F);
        this.moutht.addBox(-17.0F, -10.5F, -24.0F, 34, 14, 29, 0.0F);
        
        this.rw1.addChild(this.rw2);
        this.rl1.addChild(this.rf1);
        this.leftleg.addChild(this.ll2);
        this.neck3.addChild(this.head);
        this.tail1.addChild(this.tail2);
        this.rw2.addChild(this.rw3);
        this.ll1.addChild(this.lf1);
        this.rl2.addChild(this.rf2);
        this.body.addChild(this.neck1);
        this.mouthb.addChild(this.shape34);
        this.head.addChild(this.lh);
        this.tail2.addChild(this.tail3);
        this.head.addChild(this.mouthb);
        this.ll2.addChild(this.lf2);
        this.lw1.addChild(this.lw2);
        this.head.addChild(this.rh);
        this.lw2.addChild(this.lw3);
        this.rightarm.addChild(this.rl1);
        this.neck2.addChild(this.neck3);
        this.neck1.addChild(this.neck2);
        this.rightleg.addChild(this.rl2);
        this.tail3.addChild(this.tail4);
        this.leftarm.addChild(this.ll1);
        this.head.addChild(this.moutht);
    }

    @Override
    public void render(Entity entity, float f, float f1, float f2, float f3, float f4, float f5) { 
    	setRotationAngles(f, f1, f2, f3, f4, f5, entity);
    	this.body.render(f5);
        this.rightarm.render(f5);
        this.leftarm.render(f5);
        this.leftleg.render(f5);
        this.rightleg.render(f5);
        this.tail1.render(f5);
        this.lw1.render(f5);
        this.rw1.render(f5);
        
        EntityClayDragon ecd = (EntityClayDragon) entity;
        if(ecd.onG==true)walk=true;
        
    }

    /**
     * This is a helper function from Tabula to set the rotation of model parts
     */
    public void setRotateAngle(ModelRenderer modelRenderer, float x, float y, float z) {
        modelRenderer.rotateAngleX = x;
        modelRenderer.rotateAngleY = y;
        modelRenderer.rotateAngleZ = z;
    }
    
    public void setRotationAngles(float f, float f1, float f2, float f3, float f4, float f5, Entity entity)
    {
      super.setRotationAngles(f, f1, f2, f3, f4, f5, entity);
      EntityClayDragon ent = (EntityClayDragon) entity;
      
      this.head.rotateAngleY = f3 / (180F / (float)Math.PI);
      this.head.rotateAngleX = f4 / (180F / (float)Math.PI);  
      
      }
    
    public void setLivingAnimations(EntityLivingBase ent, float f, float f1, float f2)
    {
        super.setLivingAnimations(ent, f, f1, f2);
        EntityClayDragon ee = (EntityClayDragon)ent;
        int i = ee.getFlyTimer();
        if(i>40){
            this.lw1.rotateAngleZ = MathHelper.cos(f * 0.6662F) * 2.0F * f1 * 0.5F;
            this.rw1.rotateAngleZ = MathHelper.cos(f * 0.6662F + (float)Math.PI) * 1.5F * f1 * 0.5F;
            this.rightarm.rotateAngleX = 2F;
            this.leftarm.rotateAngleX = 2F;
            this.rightleg.rotateAngleX = 0.7F;
            this.leftleg.rotateAngleX = 0.7F;
            this.rl2.rotateAngleX = 0.5F;
            this.ll2.rotateAngleX = 0.5F;
            }
        else
        	{
            this.leftleg.rotateAngleX = MathHelper.cos(f * 1.0F) * -1.0F * f1;
            this.rightleg.rotateAngleX = MathHelper.cos(f * 1.0F) * 1.0F * f1;
            this.rightarm.rotateAngleX = MathHelper.cos(f * 0.6662F + (float)Math.PI) * 2.0F * f1 * 0.5F;
            this.leftarm.rotateAngleX = MathHelper.cos(f * 0.6662F) * 2.0F * f1 * 0.5F;
            }
        
        
        
    }


}

