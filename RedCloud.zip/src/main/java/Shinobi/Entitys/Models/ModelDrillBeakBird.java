package Shinobi.Entitys.Models;

import net.minecraft.client.model.ModelBase;
import net.minecraft.client.model.ModelRenderer;
import net.minecraft.entity.Entity;
import net.minecraft.util.MathHelper;

import org.lwjgl.opengl.GL11;

/**
 * ModelChicken - Either Mojang or a mod author
 * Created using Tabula 4.1.1
 */
public class ModelDrillBeakBird extends ModelBase {
    public ModelRenderer body;
    public ModelRenderer head;
    public ModelRenderer lwing;
    public ModelRenderer rwing;
    public ModelRenderer beak;
    public ModelRenderer neck;
    public ModelRenderer shape10;
    public ModelRenderer legs;
    public ModelRenderer legs2;
    public ModelRenderer shape12;
    public ModelRenderer shape13;

    public ModelDrillBeakBird() {
        this.textureWidth = 64;
        this.textureHeight = 32;
        this.legs = new ModelRenderer(this, 26, 0);
        this.legs.setRotationPoint(-2.5F, -1.0F, 2.0F);
        this.legs.addBox(-0.5F, 0.0F, -1.0F, 1, 5, 1, 0.0F);
        this.setRotateAngle(legs, 1.3962634015954636F, -0.4363323129985824F, 0.0F);
        this.shape12 = new ModelRenderer(this, 0, 25);
        this.shape12.setRotationPoint(0.0F, 0.5F, 1.5F);
        this.shape12.addBox(-0.5F, 0.0F, 0.0F, 1, 1, 5, 0.0F);
        this.setRotateAngle(shape12, -0.31869712141416456F, 0.0F, 0.0F);
        this.shape13 = new ModelRenderer(this, 20, 22);
        this.shape13.setRotationPoint(0.0F, 0.0F, -1.2F);
        this.shape13.addBox(-2.0F, -2.0F, -1.0F, 4, 4, 1, 0.0F);
        this.rwing = new ModelRenderer(this, 24, 13);
        this.rwing.mirror = true;
        this.rwing.setRotationPoint(-2.0F, -1.5F, -0.7F);
        this.rwing.addBox(-8.0F, 0.0F, -3.0F, 8, 1, 6, 0.0F);
        this.beak = new ModelRenderer(this, 14, 22);
        this.beak.setRotationPoint(0.0F, -1.0F, -8.0F);
        this.beak.addBox(-2.5F, -1.5F, -6.0F, 5, 3, 6, 0.0F);
        this.shape10 = new ModelRenderer(this, 0, 20);
        this.shape10.setRotationPoint(0.0F, -1.7F, 4.0F);
        this.shape10.addBox(-2.5F, 0.0F, 0.0F, 5, 1, 3, 0.0F);
        this.setRotateAngle(shape10, 0.08726646259971647F, 0.0F, 0.0F);
        this.neck = new ModelRenderer(this, 18, 7);
        this.neck.setRotationPoint(0.0F, 0.0F, -1.7F);
        this.neck.addBox(-1.5F, -1.5F, -4.0F, 3, 3, 3, 0.0F);
        this.setRotateAngle(neck, -0.22759093446006054F, 0.0F, 0.0F);
        this.body = new ModelRenderer(this, 0, 9);
        this.body.setRotationPoint(0.0F, -3.0F, 0.0F);
        this.body.addBox(-2.0F, -1.8F, -3.0F, 4, 3, 7, 0.0F);
        this.head = new ModelRenderer(this, 0, 0);
        this.head.setRotationPoint(0.0F, -1.0F, -4.5F);
        this.head.addBox(-2.0F, -1.5F, -3.5F, 4, 3, 3, 0.0F);
        this.setRotateAngle(head, 0.0066322511575784525F, 0.0F, 0.0F);
        this.lwing = new ModelRenderer(this, 24, 13);
        this.lwing.setRotationPoint(2.0F, -1.5F, -0.7F);
        this.lwing.addBox(0.0F, 0.0F, -3.0F, 8, 1, 6, 0.0F);
        this.legs2 = new ModelRenderer(this, 26, 0);
        this.legs2.setRotationPoint(1.5F, 0.0F, 2.0F);
        this.legs2.addBox(0.0F, 1.0F, 0.0F, 1, 5, 1, 0.0F);
        this.setRotateAngle(legs2, 1.3962634015954636F, 0.4363323129985824F, 0.0F);
        this.body.addChild(this.legs);
        this.body.addChild(this.shape12);
        this.beak.addChild(this.shape13);
        this.body.addChild(this.rwing);
        this.body.addChild(this.beak);
        this.body.addChild(this.shape10);
        this.body.addChild(this.neck);
        this.body.addChild(this.head);
        this.body.addChild(this.lwing);
        this.body.addChild(this.legs2);
    }

    @Override
    public void render(Entity entity, float f, float f1, float f2, float f3, float f4, float f5) { 
    	setRotationAngles(f, f1, f2, f3, f4, f5, entity);
    	GL11.glPushMatrix();
        GL11.glTranslatef(this.body.offsetX, this.body.offsetY, this.body.offsetZ);
        GL11.glTranslatef(this.body.rotationPointX * f5, this.body.rotationPointY * f5, this.body.rotationPointZ * f5);
        GL11.glScaled(10.0D, 10.0D, 10.0D);
        GL11.glTranslatef(-this.body.offsetX, -this.body.offsetY, -this.body.offsetZ);
        GL11.glTranslatef(-this.body.rotationPointX * f5, -this.body.rotationPointY * f5, -this.body.rotationPointZ * f5);
        this.body.render(f5);
        GL11.glPopMatrix();
    }

    /**
     * This is a helper function from Tabula to set the rotation of model parts
     */
    public void setRotateAngle(ModelRenderer modelRenderer, float x, float y, float z) {
        modelRenderer.rotateAngleX = x;
        modelRenderer.rotateAngleY = y;
        modelRenderer.rotateAngleZ = z;
    }
    
    public void setRotationAngles(float f, float f1, float f2, float f3, float f4, float f5, Entity entity) {
		super.setRotationAngles(f, f1, f2, f3, f4, f5, entity);
        //this.head.rotateAngleY = f3 / (180F / (float)Math.PI);
      //  this.head.rotateAngleX = f4 / (180F / (float)Math.PI);    
        this.rwing.rotateAngleZ = MathHelper.cos(f * 0.6662F + (float)Math.PI) * 2.0F * f1 * 0.5F;
        this.lwing.rotateAngleZ = MathHelper.cos(f * 0.6662F) * 2.0F * f1 * 0.5F;
		
	}
}
