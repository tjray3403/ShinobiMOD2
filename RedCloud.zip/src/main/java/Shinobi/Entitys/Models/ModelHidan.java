package Shinobi.Entitys.Models;

import net.minecraft.client.model.ModelBase;
import net.minecraft.client.model.ModelRenderer;
import net.minecraft.entity.Entity;
import net.minecraft.util.MathHelper;
import thehippomasterAPI.AnimationAPI.IAnimatedEntity;
import thehippomasterAPI.AnimationAPI.client.Animator;

public class ModelHidan extends ModelBase {
	public ModelRenderer leftleg;
    public ModelRenderer handle;
    public ModelRenderer body;
    public ModelRenderer d1;
    public ModelRenderer rightarm1;
    public ModelRenderer rightarm2;
    public ModelRenderer leftarm2;
    public ModelRenderer d2;
    public ModelRenderer leftarm1;
    public ModelRenderer b1;
    public ModelRenderer d3;
    public ModelRenderer head;
    public ModelRenderer b2;
    public ModelRenderer b3;
    public ModelRenderer rightleg;
    public ModelRenderer cth;
    public ModelRenderer t1;
    public ModelRenderer t2;
    public ModelRenderer t3;
    public ModelRenderer t;

	private Animator animator;
	
	public static final float PI = (float)Math.PI;
	
	public ModelHidan() {
		textureWidth = 128;
        textureHeight = 128;
        
        body = new ModelRenderer(this, 16, 16);
        body.setRotationPoint(0.0F, 0.0F, 0.0F);
        body.addBox(-4.0F, -24.0F, -2.0F, 8, 12, 4, 0.0F);
        
        t = new ModelRenderer(this, 16, 16);
        t.setRotationPoint(0.0F, 0.0F, 0.0F);
        t.addBox(0.0F, 0.0F, 0.0F, 1, 1, 1, 0.0F);
        
        t1 = new ModelRenderer(this, 70, 0);
        t1.setRotationPoint(-1.0F, 5.5F, 0.0F);
        t1.addBox(0.0F, -2.0F, -28.0F, 1, 1, 4, 0.0F);
        
        t3 = new ModelRenderer(this, 70, 0);
        t3.setRotationPoint(-1.0F, 5.5F, 0.0F);
        t3.addBox(0.0F, -2.0F, -18.0F, 1, 1, 4, 0.0F);
        
        rightarm1 = new ModelRenderer(this, 40, 16);
        rightarm1.setRotationPoint(-5.0F, -22.0F, 0.0F);
        rightarm1.addBox(-3.0F, -2.0F, -2.0F, 4, 6, 4, 0.0F);
        
        rightarm2 = new ModelRenderer(this, 0, 60);
        rightarm2.addBox(-2F, 0F, -2F, 4, 6, 4);
        rightarm2.setRotationPoint(-6F, -18F, 0F);
        
        
        leftarm2 = new ModelRenderer(this, 0, 60);
        leftarm2.setRotationPoint(6.0F, -18.0F, 0.0F);
        leftarm2.addBox(-2.0F, 0.0F, -2.0F, 4, 6, 4, 0.0F);
        
        t2 = new ModelRenderer(this, 70, 0);
        t2.setRotationPoint(-1.0F, 5.5F, 0.0F);
        t2.addBox(0.0F, -2.0F, -23.0F, 1, 1, 4, 0.0F);
        
        b3 = new ModelRenderer(this, 40, 0);
        b3.setRotationPoint(-1.0F, 5.5F, 0.0F);
        b3.addBox(0.0F, 0.0F, -18.0F, 1, 4, 4, 0.0F);
        
        handle = new ModelRenderer(this, 0, 72);
        handle.setRotationPoint(-2.0F, 8.5F, -2.0F);
        handle.addBox(0.0F, 0.0F, -27.0F, 1, 1, 37, 0.0F);
        
        head = new ModelRenderer(this, 0, 0);
        head.setRotationPoint(0.0F, -24.0F, 0.0F);
        head.addBox(-4.0F, -8.0F, -4.0F, 8, 8, 8, 0.0F);
        
        d3 = new ModelRenderer(this, 55, 0);
        d3.setRotationPoint(-1.0F, 9.5F, 0.0F);
        d3.addBox(0.0F, 0.0F, -18.5F, 1, 5, 4, 0.0F);
        setRotateAngle(d3, 0.19198620319366455F, 0.0F, 0.0F);
        
        b1 = new ModelRenderer(this, 40, 0);
        b1.setRotationPoint(-1.0F, 5.5F, 2.0F);
        b1.addBox(0.0F, 0.0F, -30.0F, 1, 4, 4, 0.0F);
        
        rightleg = new ModelRenderer(this, 0, 16);
        rightleg.setRotationPoint(-2.0F, -12.0F, 0.0F);
        rightleg.addBox(-2.0F, 0.0F, -2.0F, 4, 12, 4, 0.0F);
        
        cth = new ModelRenderer(this, 0, 49);
        cth.setRotationPoint(0.0F, 0.0F, 0.0F);
        cth.addBox(-5.0F, -26.9000000953674316F, -2.0F, 10, 3, 7, 0.0F);
        
        leftleg = new ModelRenderer(this, 0, 32);
        leftleg.setRotationPoint(2.0F, -12.0F, 0.0F);
        leftleg.addBox(-2.0F, 0.0F, -2.0F, 4, 12, 4, 0.0F);
        
        b2 = new ModelRenderer(this, 40, 0);
        b2.setRotationPoint(-1.0F, 5.5F, 0.0F);
        b2.addBox(0.0F, 0.0F, -23.0F, 1, 4, 4, 0.0F);
        
        d2 = new ModelRenderer(this, 55, 0);
        d2.setRotationPoint(-1.0F, 9.5F, 0.0F);
        d2.addBox(0.0F, -0.5F, -23.5F, 1, 5, 4, 0.0F);
        setRotateAngle(d2, 0.19198620319366455F, 0.0F, 0.0F);
        
        leftarm1 = new ModelRenderer(this, 40, 16);
        leftarm1.setRotationPoint(5.0F, -22.0F, 0.0F);
        leftarm1.addBox(-1.0F, -2.0F, -2.0F, 4, 6, 4, 0.0F);
        
        d1 = new ModelRenderer(this, 55, 0);
        d1.setRotationPoint(-1.0F, 9.5F, 0.0F);
        d1.addBox(0.0F, 0.0F, -28.5F, 1, 5, 4, 0.0F);
        setRotateAngle(d1, 0.13962629437446594F, 0.0F, 0.0F);
		
		animator = new Animator(this);
		
		 convertToChild(rightarm1, rightarm2);
		 convertToChild(rightarm2, handle);
		 convertToChild(handle, t1);
		 convertToChild(handle, t2);
		 convertToChild(handle, t3);
		 convertToChild(b1, d1);
		 convertToChild(b2, d2);
		 convertToChild(b3, d3);
		 convertToChild(handle, b1);
		 convertToChild(handle, b2);
		 convertToChild(handle, b3);
		 convertToChild(leftarm1, leftarm2);
		 convertToChild(head, cth);
		 convertToChild(body, head);
		 convertToChild(body, rightarm1);
		 convertToChild(body, leftarm1);
		 convertToChild(body, rightleg);
		 convertToChild(body, leftleg);





	}
	
	protected void convertToChild(ModelRenderer parParent, ModelRenderer parChild)
	{
	   // move child rotation point to be relative to parent
	   parChild.rotationPointX -= parParent.rotationPointX;
	   parChild.rotationPointY -= parParent.rotationPointY;
	   parChild.rotationPointZ -= parParent.rotationPointZ;
	   // make rotations relative to parent
	   parChild.rotateAngleX -= parParent.rotateAngleX;
	   parChild.rotateAngleY -= parParent.rotateAngleY;
	   parChild.rotateAngleZ -= parParent.rotateAngleZ;
	   // create relationship
	   parParent.addChild(parChild);
	}
	
	private void setRotateAngle(ModelRenderer d32, float f, float g, float h) {
		// TODO Auto-generated method stub
		
	}

	public void render(Entity entity, float f, float f1, float f2, float f3, float f4, float f5) {
		animate((IAnimatedEntity)entity, f, f1, f2, f3, f4, f5);
		setRotationAngles(f, f1, f2, f3, f4, f5, entity);
		t.render(f5);
		body.render(f5);     
        
        
	}
	
	private void setRotation(ModelRenderer model, float x, float y, float z) {
		model.rotateAngleX = x;
		model.rotateAngleY = y;
		model.rotateAngleZ = z;
	}

	public void setRotationAngles(float f, float f1, float f2, float f3, float f4, float f5, Entity entity) {
		super.setRotationAngles(f, f1, f2, f3, f4, f5, entity);
        this.head.rotateAngleY = f3 / (180F / (float)Math.PI);
        this.head.rotateAngleX = f4 / (180F / (float)Math.PI);    
        this.leftleg.rotateAngleX = MathHelper.cos(f * 1.0F) * -1.0F * f1;
        this.rightleg.rotateAngleX = MathHelper.cos(f * 1.0F) * 1.0F * f1;
        this.rightarm1.rotateAngleX = MathHelper.cos(f * 0.6662F + (float)Math.PI) * 2.0F * f1 * 0.5F;
        this.leftarm1.rotateAngleX = MathHelper.cos(f * 0.6662F) * 2.0F * f1 * 0.5F;
		
	}
	
	public void setAngles() {
		//reset the rotation point each render tick
		body.rotationPointY = 24F;
        setRotateAngle(d3, 0.19198620319366455F, 0.0F, 0.0F);
        setRotateAngle(d2, 0.19198620319366455F, 0.0F, 0.0F);
        setRotateAngle(d1, 0.13962629437446594F, 0.0F, 0.0F);
        
	}
	
	public void animate(IAnimatedEntity entity, float f, float f1, float f2, float f3, float f4, float f5) {
		animator.update(entity);
		setAngles();
		
		animator.setAnim(1);////////Slash
		animator.startPhase(4);
			animator.rotate(rightarm1, 1F, 3F, 2.8F);
			animator.rotate(rightarm2, -0.2F, 0F, 0F);
			animator.rotate(leftarm1, 1F, 2F, -1F);
		animator.endPhase();	
		animator.startPhase(3);
			animator.rotate(rightarm1, -5F, 0F, 0F);
		animator.endPhase();
		animator.startPhase(3);
			animator.rotate(rightarm1, -5F, 0F, 0F);
		animator.endPhase();
		
		animator.setStationaryPhase(6);
		animator.resetPhase(10);
		
		animator.setAnim(2);//////Spinn
		animator.startPhase(5);
			animator.rotate(rightarm1, -PI / 2F, -PI / 2F, PI / 2F);
			animator.rotate(rightarm2, -PI / 2F, -PI / 2F, PI / 2F);
		animator.endPhase();
		animator.startPhase(4);
			animator.rotate(body, 0F, -PI / 1F, 0F);
			animator.rotate(rightarm1, -PI / 1F, -PI / 2F, PI / 2F);
			animator.rotate(handle, 2F, -1.3F, 0F);
	//10rotate  up // 	
		animator.endPhase();
		animator.startPhase(3);
			animator.rotate(body, 0F, -PI / 1.5F, 0F);
		animator.endPhase();
		animator.startPhase(3);
			animator.rotate(body, 0F, -PI / 2F, 0F);
		animator.endPhase();
		animator.startPhase(3);
			animator.rotate(body, 0F, -PI / 2.5F, 0F);
		animator.endPhase();
		animator.startPhase(3);
			animator.rotate(body, 0F, -PI / 3F, 0F);
		animator.endPhase();
		animator.startPhase(3);
			animator.rotate(body, 0F, -PI / 7F, 0F);
		animator.endPhase();
			
		animator.setStationaryPhase(15);
		animator.resetPhase(10);
		
		animator.setAnim(3);///////Block
		animator.startPhase(3);
		animator.rotate(rightarm1, 1F, 0F, 2F);
		animator.rotate(rightarm2, -1.3F, 0F, 0F);
		animator.rotate(handle, 0F, 0F, -1.1F);
	animator.endPhase();	
	
		animator.setStationaryPhase(15);
		animator.resetPhase(10);
		
		animator.setAnim(4);///////uppercut
	animator.startPhase(5);
		animator.rotate(rightarm1, -2F, -1.1F, -1.0F);
		animator.rotate(rightarm2, -0.4F, 0F, 0F);
	animator.endPhase();
	animator.startPhase(3);
		animator.rotate(rightarm1, 2F, 2F, 1F);
		animator.rotate(handle, .2F, 0F, 0F);
	animator.endPhase();
	//animator.startPhase(3);
		
	//animator.endPhase();

		
		animator.setStationaryPhase(20);
		animator.resetPhase(10);
		
		animator.setAnim(5);///////speed
	animator.startPhase(7);
		animator.rotate(leftarm2, -0.4F, 0F, 0F);
		animator.rotate(rightarm1, 0F, 0F, 2F);
		animator.rotate(rightarm2, -0.9F, 0F, 0F);
	animator.endPhase();
	
	animator.setStationaryPhase(20);
	animator.resetPhase(10);
	}
}
