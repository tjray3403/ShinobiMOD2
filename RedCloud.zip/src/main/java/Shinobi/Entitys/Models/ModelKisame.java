package Shinobi.Entitys.Models;

import Shinobi.Entitys.Entitys.EntityClayDragon;
import Shinobi.Entitys.Entitys.EntityKisame;
import net.minecraft.client.model.ModelBase;
import net.minecraft.client.model.ModelRenderer;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.util.MathHelper;
import thehippomasterAPI.AnimationAPI.IAnimatedEntity;
import thehippomasterAPI.AnimationAPI.client.Animator;

/**
 * ModelKisame - Either Mojang or a mod author
 * Created using Tabula 4.1.1
 */
public class ModelKisame extends ModelBase {
    public ModelRenderer rightarm;
    public ModelRenderer rightarm1;
    public ModelRenderer leftleg;
    public ModelRenderer head;
    public ModelRenderer body;
    public ModelRenderer leftarm;
    public ModelRenderer rightleg;
    public ModelRenderer handle;
    public ModelRenderer sam1;
    public ModelRenderer shape20;
    public ModelRenderer sam2;
    public ModelRenderer sam3;
    public ModelRenderer sam4;
    public ModelRenderer bigsa;
    public ModelRenderer sam5;
    public ModelRenderer bigsa2;
    public ModelRenderer bigsa3;
    public ModelRenderer aka;
    public ModelRenderer hair;
    
    private Animator animator;
    
    public static final float PI = (float)Math.PI;

    public ModelKisame() {
    	
        this.textureWidth = 75;
        this.textureHeight = 100;
        
        this.rightarm = new ModelRenderer(this, 40, 22);
        this.rightarm.setRotationPoint(0.0F, 4.0F, 0.0F);
        this.rightarm.addBox(-3.0F, 0.0F, -2.0F, 4, 6, 4, 0.0F);
        
        this.rightarm1 = new ModelRenderer(this, 40, 16);
        this.rightarm1.setRotationPoint(-5.0F, 2.0F, 0.0F);
        this.rightarm1.addBox(-3.0F, -2.0F, -2.0F, 4, 6, 4, 0.0F);

        
        this.sam1 = new ModelRenderer(this, 5, 52);
        this.sam1.setRotationPoint(0.5F, -5.0F, 10.0F);
        this.sam1.addBox(-2.5F, 0.0F, 1.5F, 5, 4, 3, 0.0F);
        
        this.sam2 = new ModelRenderer(this, 22, 52);
        this.sam2.setRotationPoint(0.0F, 4.1F, 0.0F);
        this.sam2.addBox(-3.5F, 0.0F, 1.0F, 7, 8, 4, 0.0F);
        
        this.body = new ModelRenderer(this, 16, 16);
        this.body.setRotationPoint(0.0F, 0.0F, 0.0F);
        this.body.addBox(-4.0F, 0.0F, -2.0F, 8, 12, 4, 0.0F);
        
        this.bigsa2 = new ModelRenderer(this, 30, 65);
        this.bigsa2.setRotationPoint(0.0F, 9.0F, 0.0F);
        this.bigsa2.addBox(-5.0F, 0.0F, -0.5F, 10, 7, 7, 0.0F);
        
        this.shape20 = new ModelRenderer(this, 0, 0);
        this.shape20.setRotationPoint(-0.5F, -14.0F, 12.0F);
        this.shape20.addBox(0.0F, 0.0F, 0.0F, 2, 2, 2, 0.0F);
        
        this.sam3 = new ModelRenderer(this, 40, 44);
        this.sam3.setRotationPoint(-0.1F, 7.8F, 0.0F);
        this.sam3.addBox(-4.0F, 0.0F, 1.0F, 8, 8, 4, 0.0F);
        
        this.aka = new ModelRenderer(this, 33, 0);
        this.aka.setRotationPoint(0.0F, 0.1F, 0.0F);
        this.aka.addBox(-4.5F, -3.0F, -4.5F, 9, 3, 9, 0.0F);
        
        this.head = new ModelRenderer(this, 0, 0);
        this.head.setRotationPoint(0.0F, 0.0F, 0.0F);
        this.head.addBox(-4.0F, -8.0F, -4.0F, 8, 8, 8, 0.0F);
        
        this.leftleg = new ModelRenderer(this, 0, 32);
        this.leftleg.setRotationPoint(1.9F, 12.0F, 0.0F);
        this.leftleg.addBox(-2.0F, 0.0F, -2.0F, 4, 12, 4, 0.0F);
        
        this.bigsa3 = new ModelRenderer(this, 0, 84);
        this.bigsa3.setRotationPoint(0.0F, 7.0F, 0.0F);
        this.bigsa3.addBox(-5.5F, 0.0F, -1.0F, 11, 5, 8, 0.0F);
        
        this.leftarm = new ModelRenderer(this, 40, 16);
        this.leftarm.mirror = true;
        this.leftarm.setRotationPoint(5.0F, 2.0F, 0.0F);
        this.leftarm.addBox(-1.0F, -2.0F, -2.0F, 4, 12, 4, 0.0F);
        
        this.hair = new ModelRenderer(this, 38, 33);
        this.hair.setRotationPoint(-1.1F, -11.0F, -3.4F);
        this.hair.addBox(-2.4F, 0.0F, 0.0F, 7, 3, 6, 0.0F);
       
        this.bigsa = new ModelRenderer(this, 0, 65);   
        this.bigsa.setRotationPoint(0.0F, 0.8F, 0.0F);
        this.bigsa.addBox(-4.5F, 0.0F, 0.0F, 9, 9, 6, 0.0F);
        
        this.rightleg = new ModelRenderer(this, 0, 16);
        this.rightleg.setRotationPoint(-1.9F, 12.0F, 0.0F);
        this.rightleg.addBox(-2.0F, 0.0F, -2.0F, 4, 12, 4, 0.0F);
        
        this.sam5 = new ModelRenderer(this, 20, 35);
        this.sam5.setRotationPoint(0.0F, 4.0F, 0.0F);
        this.sam5.addBox(-2.5F, 0.0F, 2.0F, 5, 2, 2, 0.0F);
        
        this.handle = new ModelRenderer(this, 0, 53);
        this.handle.setRotationPoint(0.5F, -4.5F, -9.0F);
        this.handle.addBox(0.0F, -12.0F, 12.5F, 1, 7, 1, 0.0F);

        
        
        this.sam4 = new ModelRenderer(this, 19, 43);
        this.sam4.setRotationPoint(0.0F, 8.0F, 0.0F);
        this.sam4.addBox(-3.5F, 0.0F, 1.5F, 7, 4, 3, 0.0F);
        
        animator = new Animator(this);
        
        this.handle.addChild(this.sam1);
        this.sam1.addChild(this.sam2);
        this.bigsa.addChild(this.bigsa2);
        this.handle.addChild(this.shape20);
        this.sam2.addChild(this.sam3);
        this.head.addChild(this.aka);
        this.bigsa2.addChild(this.bigsa3);
        this.head.addChild(this.hair);
        this.sam3.addChild(this.bigsa);
        this.sam4.addChild(this.sam5);
        this.rightarm.addChild(this.handle);
        this.sam3.addChild(this.sam4);
        this.rightarm1.addChild(this.rightarm);

    }

    @Override
    public void render(Entity entity, float f, float f1, float f2, float f3, float f4, float f5) { 
    	animate((IAnimatedEntity)entity, f, f1, f2, f3, f4, f5);
        setRotationAngles(f, f1, f2, f3, f4, f5, entity);
    	this.rightarm1.render(f5);
        this.body.render(f5);
        this.head.render(f5);
        this.leftleg.render(f5);
        this.leftarm.render(f5);
        this.rightleg.render(f5);
    }

    /**
     * This is a helper function from Tabula to set the rotation of model parts
     */
    public void setRotateAngle(ModelRenderer modelRenderer, float x, float y, float z) {
        modelRenderer.rotateAngleX = x;
        modelRenderer.rotateAngleY = y;
        modelRenderer.rotateAngleZ = z;
    }
    public void animate(IAnimatedEntity entity, float f, float f1, float f2, float f3, float f4, float f5) {
		animator.update(entity);
		setAngles();
		this.rightarm1.rotateAngleX = MathHelper.cos(f * 0.6662F + (float)Math.PI) * 2.0F * f1 * 0.5F;
        this.leftarm.rotateAngleX = MathHelper.cos(f * 0.6662F) * 2.0F * f1 * 0.5F;
        EntityKisame ee = (EntityKisame)entity;
        int i = ee.getSamehadaTimer();
        if(i>20){
        	this.setRotateAngle(handle, -1.3962634015954636F, 0.0F, 0.2617993877991494F);
        }
        else if(i<20)
        {
        	this.setRotateAngle(handle, 0.0F, 0.0F, -0.7853981633974483F);
        	this.handle.rotateAngleX = MathHelper.cos(f * 0.6662F) * 01.0F * f1 * 0.5F;;
        }
        
        
		animator.setAnim(1);
	animator.startPhase(15);
		animator.rotate(rightarm1, -1.3F, 0F, 1.4F);
		animator.rotate(rightarm, -1F, 0F, 0F);
	animator.endPhase();
	animator.startPhase(5);
	animator.rotate(rightarm1, 1F, 0F, 1F);
	//animator.rotate(rightarm, 0F, 1F, 0F);
	animator.endPhase();
		
	animator.setStationaryPhase(15);
	animator.resetPhase(10);
	
	animator.setAnim(2);
	animator.startPhase(15);
		animator.rotate(rightarm1, -2F, 0F, 2F);
		animator.rotate(rightarm, -0.2F, 0F, 0F);
	animator.endPhase();	
	animator.startPhase(15);
		animator.rotate(rightarm1, 2.5F, 3F, 1.5F);
	animator.endPhase();
	animator.startPhase(15);
	animator.rotate(rightarm1, 0F, 0F, 1F);
animator.endPhase();
	animator.resetPhase(30);
	animator.setStationaryPhase(15);
	
	animator.setAnim(3);///////Block
	animator.startPhase(3);
	animator.rotate(rightarm1, -0.5F, 0F, 2F);
	animator.rotate(rightarm, -1.2F, 0F, 0F);
	animator.rotate(handle, 0F, 0F, 0F);
	animator.endPhase();	
	animator.setStationaryPhase(15);
	animator.resetPhase(10);
	
	animator.setAnim(4);///////Block
	animator.startPhase(3);
	animator.rotate(handle, 1F, 0F, 0F);
	animator.rotate(rightarm1, -0.5F, 0F, -0.5F);
	animator.rotate(rightarm, -0.5F, 0F, -0.5F);
	animator.rotate(leftarm, -1F, 0F, 1F);
	animator.endPhase();
	animator.startPhase(3);
	//animator.rotate(handle, 1F, 0F, 0F);
	animator.rotate(rightarm1, -0.3F, 0F, -0.3F);
	animator.rotate(rightarm, -0.3F, 0F, -0.3F);
	animator.rotate(leftarm, -0.5F, 0F, 0.5F);
	animator.endPhase();	
	animator.startPhase(3);
	//animator.rotate(handle, 0.2F, 0F, 0F);
	animator.rotate(rightarm1, -1F, 0F, -0.3F);
	animator.rotate(rightarm, -0.3F, 0F, -0.3F);
	animator.rotate(leftarm, -1F, 0F, 0.5F);
	animator.endPhase();
	animator.startPhase(3);
	animator.rotate(handle, 1F, 0F, 0F);
	animator.rotate(rightarm1, -1F, 0F, -0.3F);
	animator.rotate(rightarm, -0.3F, 0F, -0.3F);
	animator.rotate(leftarm, -1F, 0F, 0.5F);
	animator.endPhase();
	animator.startPhase(3);
	//animator.rotate(handle, 1F, 0F, 0F);
	animator.rotate(rightarm1, -0.5F, 0F, -0.5F);
	animator.rotate(rightarm, -0.5F, 0F, -0.5F);
	animator.rotate(leftarm, -1F, 0F, 1F);
	animator.endPhase();
	animator.startPhase(3);
	//animator.rotate(handle, 1F, 0F, 0F);
	animator.rotate(rightarm1, -0.3F, 0F, -0.3F);
	animator.rotate(rightarm, -0.3F, 0F, -0.3F);
	animator.rotate(leftarm, -0.5F, 0F, 0.5F);
	animator.endPhase();	
	animator.startPhase(3);
	//animator.rotate(handle, 0.1F, 0F, 0F);
	animator.rotate(rightarm1, -1F, 0F, -0.3F);
	animator.rotate(rightarm, -0.3F, 0F, -0.3F);
	animator.rotate(leftarm, -1F, 0F, 0.5F);
	animator.endPhase();
	animator.startPhase(3);
	animator.rotate(handle, 0.5F, 0F, 0F);
	animator.rotate(rightarm1, -1F, 0F, -0.5F);
	animator.rotate(rightarm, -0.3F, 0F, -0.5F);
	animator.rotate(leftarm, -1F, 0F, 0.8F);
	animator.endPhase();
	animator.setStationaryPhase(15);
	animator.resetPhase(10);
        
	animator.setAnim(5);
	animator.startPhase(15);
	animator.rotate(rightarm1, -2.2F, 0F, 0.7F);
	animator.rotate(rightarm, -0.5F, 0F, 0F);
	animator.rotate(leftarm, -2.2F, 0F, -1F);
	animator.endPhase();
	animator.startPhase(5);
	animator.rotate(rightarm1, 0F, 0F, -0.7F);
	animator.rotate(leftarm, 2F, 2.5F, 2F);
	animator.endPhase();
        
    }
    public void setRotationAngles(float f, float f1, float f2, float f3, float f4, float f5, Entity entity)
	  {
	    super.setRotationAngles(f, f1, f2, f3, f4, f5, entity);
	    
	    this.head.rotateAngleY = f3 / (180F / (float)Math.PI);
        this.head.rotateAngleX = f4 / (180F / (float)Math.PI);    
        this.leftleg.rotateAngleX = MathHelper.cos(f * 1.0F) * -1.0F * f1;
        this.rightleg.rotateAngleX = MathHelper.cos(f * 1.0F) * 1.0F * f1;
        
        
        
        	
	  }
    
    

	private void setAngles() {
		//this.setRotateAngle(handle, 0.0F, 0.0F, -0.7853981633974483F);
		//this.setRotateAngle(handle, -1.3962634015954636F, 0.0F, 0.2617993877991494F);
		
	}
	
	
        
        
        
    }
        
        
        

