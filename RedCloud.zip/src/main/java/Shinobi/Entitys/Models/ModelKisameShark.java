package Shinobi.Entitys.Models;

import net.minecraft.client.model.ModelBase;
import net.minecraft.client.model.ModelRenderer;
import net.minecraft.entity.Entity;

/**
 * ModelBiped - Either Mojang or a mod author
 * Created using Tabula 4.1.1
 */
public class ModelKisameShark extends ModelBase {
    public ModelRenderer rightarm;
    public ModelRenderer leftleg;
    public ModelRenderer head;
    public ModelRenderer body;
    public ModelRenderer leftarm;
    public ModelRenderer rightleg;
    public ModelRenderer shape13;
    public ModelRenderer shape10;
    public ModelRenderer shape11;
    public ModelRenderer shape12;
    public ModelRenderer shape9;
    public ModelRenderer shape14;
    public ModelRenderer shape15;
    public ModelRenderer shape16;

    public ModelKisameShark() {
        this.textureWidth = 64;
        this.textureHeight = 64;
        this.leftarm = new ModelRenderer(this, 40, 16);
        this.leftarm.mirror = true;
        this.leftarm.setRotationPoint(5.0F, 2.0F, 0.0F);
        this.leftarm.addBox(-1.0F, -2.0F, -2.0F, 4, 12, 4, 0.0F);
        this.shape16 = new ModelRenderer(this, 45, 5);
        this.shape16.setRotationPoint(0.0F, 1.8F, 8.0F);
        this.shape16.addBox(-1.0F, -1.0F, 0.0F, 2, 2, 7, 0.0F);
        this.setRotateAngle(shape16, 0.08726646259971647F, 0.0F, 0.0F);
        this.rightleg = new ModelRenderer(this, 0, 16);
        this.rightleg.mirror = true;
        this.rightleg.setRotationPoint(-1.9F, 12.0F, 0.0F);
        this.rightleg.addBox(-2.0F, 0.0F, -2.0F, 4, 12, 4, 0.0F);
        this.rightarm = new ModelRenderer(this, 40, 16);
        this.rightarm.setRotationPoint(-5.0F, 2.0F, 0.0F);
        this.rightarm.addBox(-3.0F, -2.0F, -2.0F, 4, 12, 4, 0.0F);
        this.shape13 = new ModelRenderer(this, 40, 0);
        this.shape13.setRotationPoint(0.0F, 10.0F, 0.4F);
        this.shape13.addBox(-2.5F, -3.0F, 0.0F, 5, 5, 4, 0.0F);
        this.setRotateAngle(shape13, -0.5235987755982988F, 0.0F, 0.0F);
        this.shape9 = new ModelRenderer(this, 25, 35);
        this.shape9.mirror = true;
        this.shape9.setRotationPoint(0.5F, 3.7F, -1.4F);
        this.shape9.addBox(0.0F, -6.0F, 0.0F, 1, 6, 5, 0.0F);
        this.setRotateAngle(shape9, -0.8726646259971648F, 0.0F, 0.0F);
        this.shape14 = new ModelRenderer(this, 40, 0);
        this.shape14.setRotationPoint(0.0F, -0.8F, 3.9F);
        this.shape14.addBox(-2.5F, -2.0F, 0.0F, 5, 5, 5, 0.0F);
        this.setRotateAngle(shape14, 0.05235987755982988F, 0.0F, 0.0F);
        this.body = new ModelRenderer(this, 16, 16);
        this.body.setRotationPoint(0.0F, 0.0F, 0.0F);
        this.body.addBox(-4.0F, 0.0F, -2.0F, 8, 12, 4, 0.0F);
        this.shape11 = new ModelRenderer(this, 0, 34);
        this.shape11.setRotationPoint(0.0F, 0.0F, -1.5F);
        this.shape11.addBox(-2.5F, -7.3F, 3.0F, 5, 10, 5, 0.0F);
        this.setRotateAngle(shape11, -0.12217304763960307F, 0.0F, 0.0F);
        this.shape15 = new ModelRenderer(this, 36, 1);
        this.shape15.setRotationPoint(0.0F, -1.3F, 4.0F);
        this.shape15.addBox(-2.5F, 0.0F, 0.0F, 5, 4, 8, 0.0F);
        this.setRotateAngle(shape15, 0.22689280275926282F, 0.0F, 0.0F);
        this.leftleg = new ModelRenderer(this, 0, 16);
        this.leftleg.setRotationPoint(1.9F, 12.0F, 0.0F);
        this.leftleg.addBox(-2.0F, 0.0F, -2.0F, 4, 12, 4, 0.0F);
        this.head = new ModelRenderer(this, 0, 0);
        this.head.setRotationPoint(0.0F, 0.0F, 0.0F);
        this.head.addBox(-4.0F, -8.0F, -4.0F, 8, 8, 8, 0.0F);
        this.shape10 = new ModelRenderer(this, 25, 35);
        this.shape10.setRotationPoint(-1.5F, 3.7F, -1.4F);
        this.shape10.addBox(0.0F, -6.0F, 0.0F, 1, 6, 5, 0.0F);
        this.setRotateAngle(shape10, -0.8726646259971648F, 0.0F, 0.0F);
        this.shape12 = new ModelRenderer(this, 0, 50);
        this.shape12.setRotationPoint(0.0F, -6.0F, 8.0F);
        this.shape12.addBox(-1.5F, 0.0F, 0.0F, 3, 7, 7, 0.0F);
        this.setRotateAngle(shape12, -0.12217304763960307F, 0.0F, 0.013788101090755204F);
        this.shape15.addChild(this.shape16);
        this.leftarm.addChild(this.shape9);
        this.shape13.addChild(this.shape14);
        this.head.addChild(this.shape11);
        this.shape14.addChild(this.shape15);
        this.rightarm.addChild(this.shape10);
        this.shape11.addChild(this.shape12);
    }

    @Override
    public void render(Entity entity, float f, float f1, float f2, float f3, float f4, float f5) { 
        this.leftarm.render(f5);
        this.rightleg.render(f5);
        this.rightarm.render(f5);
        this.shape13.render(f5);
        this.body.render(f5);
        this.leftleg.render(f5);
        this.head.render(f5);
    }

    /**
     * This is a helper function from Tabula to set the rotation of model parts
     */
    public void setRotateAngle(ModelRenderer modelRenderer, float x, float y, float z) {
        modelRenderer.rotateAngleX = x;
        modelRenderer.rotateAngleY = y;
        modelRenderer.rotateAngleZ = z;
    }
}
