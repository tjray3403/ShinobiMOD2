package Shinobi.Entitys.Models;

import net.minecraft.client.model.ModelBase;
import net.minecraft.client.model.ModelRenderer;
import net.minecraft.entity.Entity;

/**
 * ModelKoh - bhb
 * Created using Tabula 4.1.1
 */
public class ModelKoh extends ModelBase {
    public ModelRenderer shape1;
    public ModelRenderer shape2;
    public ModelRenderer shape3;
    public ModelRenderer shape4;
    public ModelRenderer shape5;
    public ModelRenderer shape6;
    public ModelRenderer shape7;
    public ModelRenderer shape8;
    public ModelRenderer shape9;
    public ModelRenderer shape10;
    public ModelRenderer shape11;
    public ModelRenderer shape12;
    public ModelRenderer shape13;

    public ModelKoh() {
        this.textureWidth = 400;
        this.textureHeight = 400;
        this.shape5 = new ModelRenderer(this, 0, 110);
        this.shape5.mirror = true;
        this.shape5.setRotationPoint(-17.0F, -22.5F, 12.0F);
        this.shape5.addBox(-45.0F, -25.0F, 0.0F, 45, 25, 10, 0.0F);
        this.setRotateAngle(shape5, -0.6981317007977318F, -0.6981317007977318F, -0.4363323129985824F);
        this.shape6 = new ModelRenderer(this, 0, 150);
        this.shape6.setRotationPoint(0.0F, -21.5F, 7.0F);
        this.shape6.addBox(-35.0F, -25.0F, 0.0F, 70, 25, 10, 0.0F);
        this.setRotateAngle(shape6, -0.9948376736367678F, 0.0F, 0.0F);
        this.shape13 = new ModelRenderer(this, 250, 250);
        this.shape13.setRotationPoint(-10.0F, -50.0F, -9.0F);
        this.shape13.addBox(-7.0F, -50.0F, 0.0F, 7, 50, 40, 0.0F);
        this.setRotateAngle(shape13, -0.6108652381980153F, -0.2617993877991494F, 0.0F);
        this.shape10 = new ModelRenderer(this, 0, 300);
        this.shape10.setRotationPoint(0.0F, -27.5F, 1.8F);
        this.shape10.addBox(-30.0F, -30.0F, -12.5F, 60, 30, 25, 0.0F);
        this.setRotateAngle(shape10, -0.2617993877991494F, 0.0F, 0.0F);
        this.shape11 = new ModelRenderer(this, 0, 200);
        this.shape11.setRotationPoint(0.0F, 19.7F, -11.0F);
        this.shape11.addBox(-25.0F, -45.0F, 0.0F, 50, 50, 41, 0.0F);
        this.shape12 = new ModelRenderer(this, 250, 250);
        this.shape12.setRotationPoint(10.0F, -50.0F, -9.0F);
        this.shape12.addBox(0.0F, -50.0F, 0.0F, 7, 50, 40, 0.0F);
        this.setRotateAngle(shape12, -0.6108652381980153F, 0.2617993877991494F, 0.0F);
        this.shape8 = new ModelRenderer(this, 200, 150);
        this.shape8.setRotationPoint(-22.0F, 25.0F, -5.5F);
        this.shape8.addBox(-17.5F, -25.0F, 0.0F, 35, 25, 8, 0.0F);
        this.setRotateAngle(shape8, -0.08726646259971647F, -0.22689280275926282F, 0.0F);
        this.shape4 = new ModelRenderer(this, 0, 110);
        this.shape4.setRotationPoint(17.0F, -22.5F, 12.0F);
        this.shape4.addBox(0.0F, -25.0F, 0.0F, 45, 25, 10, 0.0F);
        this.setRotateAngle(shape4, -0.6981317007977318F, 0.6981317007977318F, 0.4363323129985824F);
        this.shape1 = new ModelRenderer(this, 250, 0);
        this.shape1.setRotationPoint(0.0F, 25.0F, 10.0F);
        this.shape1.addBox(-30.0F, -50.0F, 0.0F, 60, 50, 12, 0.0F);
        this.setRotateAngle(shape1, -0.05235987755982988F, 0.0F, 0.0F);
        this.shape3 = new ModelRenderer(this, 150, 55);
        this.shape3.mirror = true;
        this.shape3.setRotationPoint(-31.5F, 25.0F, 13.0F);
        this.shape3.addBox(-20.0F, -42.0F, 0.0F, 30, 42, 15, 0.0F);
        this.setRotateAngle(shape3, 0.17453292519943295F, -0.6108652381980153F, 0.0F);
        this.shape7 = new ModelRenderer(this, 0, 0);
        this.shape7.setRotationPoint(0.0F, 25.0F, 0.0F);
        this.shape7.addBox(-27.5F, -65.0F, -7.5F, 55, 65, 15, 0.0F);
        this.shape2 = new ModelRenderer(this, 150, 55);
        this.shape2.setRotationPoint(31.5F, 25.0F, 13.0F);
        this.shape2.addBox(-10.0F, -42.0F, 0.0F, 30, 42, 15, 0.0F);
        this.setRotateAngle(shape2, 0.17453292519943295F, 0.6108652381980153F, 0.0F);
        this.shape9 = new ModelRenderer(this, 200, 150);
        this.shape9.setRotationPoint(22.0F, 25.0F, -5.5F);
        this.shape9.addBox(-17.5F, -25.0F, 0.0F, 35, 25, 8, 0.0F);
        this.setRotateAngle(shape9, -0.08726646259971647F, 0.22689280275926282F, 0.0F);
    }

    @Override
    public void render(Entity entity, float f, float f1, float f2, float f3, float f4, float f5) { 
        this.shape5.render(f5);
        this.shape6.render(f5);
        this.shape13.render(f5);
        this.shape10.render(f5);
        this.shape11.render(f5);
        this.shape12.render(f5);
        this.shape8.render(f5);
        this.shape4.render(f5);
        this.shape1.render(f5);
        this.shape3.render(f5);
        this.shape7.render(f5);
        this.shape2.render(f5);
        this.shape9.render(f5);
    }

    /**
     * This is a helper function from Tabula to set the rotation of model parts
     */
    public void setRotateAngle(ModelRenderer modelRenderer, float x, float y, float z) {
        modelRenderer.rotateAngleX = x;
        modelRenderer.rotateAngleY = y;
        modelRenderer.rotateAngleZ = z;
    }
}
