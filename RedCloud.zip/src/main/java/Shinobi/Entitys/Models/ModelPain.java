package Shinobi.Entitys.Models;

import net.minecraft.client.model.ModelBase;
import net.minecraft.client.model.ModelRenderer;
import net.minecraft.entity.Entity;
import net.minecraft.util.MathHelper;
import thehippomasterAPI.AnimationAPI.IAnimatedEntity;
import thehippomasterAPI.AnimationAPI.client.Animator;

/**
 * ModelBiped - Either Mojang or a mod author
 * Created using Tabula 4.1.1
 */
public class ModelPain extends ModelBase {
    public ModelRenderer leftleg;
    public ModelRenderer rightleg;
    public ModelRenderer body;
    public ModelRenderer rightarm1;
    public ModelRenderer leftarm1;
    public ModelRenderer head;
    public ModelRenderer rightarm2;
    public ModelRenderer leftarm2;
    public ModelRenderer aka;
    public ModelRenderer hair;
    
	private Animator animator;
	
	public static final float PI = (float)Math.PI;


    public ModelPain() {
        this.textureWidth = 64;
        this.textureHeight = 64;
        this.rightarm1 = new ModelRenderer(this, 40, 16);
        this.rightarm1.setRotationPoint(-5.0F, -10.0F, 0.0F);
        this.rightarm1.addBox(-3.0F, -2.0F, -2.0F, 4, 6, 4, 0.0F);
        this.leftleg = new ModelRenderer(this, 0, 16);
        this.leftleg.setRotationPoint(1.9F, 12.0F, 0.0F);
        this.leftleg.addBox(-2.0F, 0.0F, -2.0F, 4, 12, 4, 0.0F);
        this.body = new ModelRenderer(this, 16, 16);
        this.body.setRotationPoint(0.0F, 12.0F, 0.0F);
        this.body.addBox(-4.0F, -12.0F, -2.0F, 8, 12, 4, 0.0F);
        this.leftarm1 = new ModelRenderer(this, 40, 16);
        this.leftarm1.mirror = true;
        this.leftarm1.setRotationPoint(5.0F, -10.0F, 0.0F);
        this.leftarm1.addBox(-1.0F, -2.0F, -2.0F, 4, 6, 4, 0.0F);
        this.head = new ModelRenderer(this, 0, 0);
        this.head.setRotationPoint(0.0F, -12.0F, 0.0F);
        this.head.addBox(-4.0F, -8.0F, -4.0F, 8, 8, 8, 0.0F);
        this.hair = new ModelRenderer(this, 28, 33);
        this.hair.setRotationPoint(0.0F, 0.0F, 0.0F);
        this.hair.addBox(-4.5F, -8.3F, -4.5F, 9, 15, 9, 0.0F);
        this.leftarm2 = new ModelRenderer(this, 0, 35);
        this.leftarm2.setRotationPoint(1.0F, 4.0F, 0.0F);
        this.leftarm2.addBox(-2.0F, 0.0F, -2.0F, 4, 6, 4, 0.0F);
        this.rightleg = new ModelRenderer(this, 0, 16);
        this.rightleg.mirror = true;
        this.rightleg.setRotationPoint(-1.9F, 12.0F, 0.0F);
        this.rightleg.addBox(-2.0F, 0.0F, -2.0F, 4, 12, 4, 0.0F);
        this.aka = new ModelRenderer(this, 0, 50);
        this.aka.setRotationPoint(0.0F, 0.1F, 0.0F);
        this.aka.addBox(-4.5F, -3.0F, -4.5F, 9, 3, 9, 0.0F);
        this.rightarm2 = new ModelRenderer(this, 0, 35);
        this.rightarm2.setRotationPoint(-1.0F, 4.0F, 0.0F);
        this.rightarm2.addBox(-2.0F, 0.0F, -2.0F, 4, 6, 4, 0.0F);
        
        animator = new Animator(this);
        
        this.body.addChild(this.rightarm1);
        this.body.addChild(this.leftarm1);
        this.body.addChild(this.head);
        this.head.addChild(this.hair);
        this.leftarm1.addChild(this.leftarm2);
        this.head.addChild(this.aka);
        this.rightarm1.addChild(this.rightarm2);
    }

    @Override
    public void render(Entity entity, float f, float f1, float f2, float f3, float f4, float f5) { 
    	animate((IAnimatedEntity)entity, f, f1, f2, f3, f4, f5);
    	this.leftleg.render(f5);
        this.body.render(f5);
        this.rightleg.render(f5);
    }

    /**
     * This is a helper function from Tabula to set the rotation of model parts
     */
    public void setRotateAngle(ModelRenderer modelRenderer, float x, float y, float z) {
        modelRenderer.rotateAngleX = x;
        modelRenderer.rotateAngleY = y;
        modelRenderer.rotateAngleZ = z;
    }
    
    public void animate(IAnimatedEntity entity, float f, float f1, float f2, float f3, float f4, float f5) {
		animator.update(entity);
		setAngles();
		
		this.head.rotateAngleY = f3 / (180F / (float)Math.PI);
	    this.head.rotateAngleX = f4 / (180F / (float)Math.PI);    
		this.leftleg.rotateAngleX = MathHelper.cos(f * 1.0F) * -1.0F * f1;
        this.rightleg.rotateAngleX = MathHelper.cos(f * 1.0F) * 1.0F * f1;
        this.rightarm1.rotateAngleX = MathHelper.cos(f * 0.6662F + (float)Math.PI) * 2.0F * f1 * 0.5F;
        this.leftarm1.rotateAngleX = MathHelper.cos(f * 0.6662F) * 2.0F * f1 * 0.5F;
        
		animator.setAnim(1);//push
		animator.startPhase(10);
		animator.rotate(rightarm1, -1.8F, 0F, 0F);
		animator.rotate(rightarm2, 0.3F, 0F, 0F);
		animator.endPhase();
		animator.setStationaryPhase(20);
		
		animator.setAnim(2);//pull
		animator.startPhase(10);
		animator.rotate(leftarm1, -1.8F, 0F, 0F);
		animator.rotate(leftarm2, 0.3F, 0F, 0F);
		animator.endPhase();
		animator.setStationaryPhase(20);

		animator.setAnim(3);//superpush
		animator.startPhase(10);
		animator.rotate(leftarm1, -2.5F, 0F, 0.5F);
		animator.rotate(rightarm1, -2.5F, 0F, -0.5F);
		animator.endPhase();
		animator.setStationaryPhase(20);

		animator.setAnim(4);//planetarydevastarion
		animator.startPhase(20);
        animator.rotate(rightarm1, -1.8F, -0.9F, 0F);
        animator.rotate(leftarm1, -1.8F, 0.9F, 0F);
        animator.endPhase();
        animator.setStationaryPhase(10);
		
        animator.setAnim(5);//summoning
        animator.startPhase(20);
        animator.rotate(rightarm1, -1.8F, -1, 0);
        animator.rotate(leftarm1, -1.8F, 1, 0);
        animator.endPhase();

		animator.setAnim(7);//choke
		animator.startPhase(15);
		animator.rotate(rightarm1, -1.5F, 0F, 0F);
		animator.rotate(rightarm2, -0.3F, 0F, 0F);
		animator.endPhase();
		animator.setStationaryPhase(75);
		
		animator.setAnim(9);//soul
		animator.startPhase(10);
		animator.rotate(rightarm1, -1.5F, 0F, 1F);
		animator.rotate(rightarm2, -0.8F, 0F, 0F);
		animator.endPhase();
		animator.startPhase(10);
		animator.rotate(rightarm1, 1F, -1F, 0.7F);
		animator.rotate(rightarm2, -0.3F, 0F, 0F);
		animator.endPhase();
		
		animator.setAnim(10);//chrakrod
		animator.startPhase(20);
		animator.rotate(rightarm1, -2F, 0F, 0F);
		animator.endPhase();
		animator.setStationaryPhase(20);
		
    }

	private void setAngles() {
		// TODO Auto-generated method stub
		
	}
    
    
    
}
