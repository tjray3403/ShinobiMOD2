package Shinobi.Entitys.Models;

import org.lwjgl.opengl.GL11;

import net.minecraft.client.model.ModelBase;
import net.minecraft.client.model.ModelRenderer;
import net.minecraft.entity.Entity;
import net.minecraft.util.MathHelper;

/**
 * ModelCow - Either Mojang or a mod author
 * Created using Tabula 4.1.1
 */
public class ModelRhinoSum extends ModelBase {
    public ModelRenderer body;
    public ModelRenderer leftleg;
    public ModelRenderer leftarm;
    public ModelRenderer rightleg;
    public ModelRenderer rightarm;
    public ModelRenderer head;
    public ModelRenderer body2;
    public ModelRenderer tail;
    public ModelRenderer shape16;
    public ModelRenderer shape17;
    public ModelRenderer rod;
    public ModelRenderer horn;
    public ModelRenderer lear;
    public ModelRenderer rear;

    public ModelRhinoSum() {
        this.textureWidth = 75;
        this.textureHeight = 64;
        this.rear = new ModelRenderer(this, 20, 30);
        this.rear.setRotationPoint(-2.5F, -5.0F, -2.5F);
        this.rear.addBox(-4.0F, 0.0F, 0.0F, 4, 2, 1, 0.0F);
        this.setRotateAngle(rear, 0.0F, 0.17453292519943295F, 0.4886921905584123F);
        this.leftleg = new ModelRenderer(this, 0, 30);
        this.leftleg.setRotationPoint(4.0F, 14.0F, 7.0F);
        this.leftleg.addBox(-2.0F, 0.0F, -2.0F, 4, 10, 4, 0.0F);
        this.leftarm = new ModelRenderer(this, 0, 30);
        this.leftarm.setRotationPoint(4.0F, 14.0F, -6.0F);
        this.leftarm.addBox(-2.0F, 0.0F, -2.0F, 4, 10, 4, 0.0F);
        this.rod = new ModelRenderer(this, 0, 17);
        this.rod.setRotationPoint(0.0F, -5.4F, -3.5F);
        this.rod.addBox(-1.0F, 0.0F, -1.0F, 2, 9, 2, 0.0F);
        this.lear = new ModelRenderer(this, 20, 30);
        this.lear.setRotationPoint(3.0F, -4.0F, -2.5F);
        this.lear.addBox(0.0F, -1.0F, 0.0F, 4, 2, 1, 0.0F);
        this.setRotateAngle(lear, 0.0F, -0.17453292519943295F, -0.4886921905584123F);
        this.tail = new ModelRenderer(this, 28, 26);
        this.tail.setRotationPoint(0.0F, 3.0F, 3.0F);
        this.tail.addBox(-1.5F, 0.0F, 0.0F, 3, 3, 15, 0.0F);
        this.setRotateAngle(tail, -0.12217304763960307F, 0.0F, 0.0F);
        this.head = new ModelRenderer(this, 0, 0);
        this.head.setRotationPoint(0.0F, 8.6F, -11.5F);
        this.head.addBox(-3.5F, -4.0F, -8.0F, 7, 7, 8, 0.0F);
        this.setRotateAngle(head, 0.5074383219872474F, 0.0F, 0.0F);
        this.shape16 = new ModelRenderer(this, 0, 35);
        this.shape16.setRotationPoint(3.5F, 4.0F, -0.5F);
        this.shape16.addBox(0.0F, -5.0F, 0.0F, 1, 5, 2, 0.0F);
        this.setRotateAngle(shape16, -0.4363323129985824F, 0.0F, 0.0F);
        this.body = new ModelRenderer(this, 18, 0);
        this.body.setRotationPoint(0.0F, -143.0F, 2.0F);
        this.body.addBox(-6.0F, 4.0F, -7.1F, 12, 10, 16, 0.0F);
        this.setRotateAngle(body, 0.0F, -0.010995574287564275F, 0.0F);
        this.rightleg = new ModelRenderer(this, 0, 30);
        this.rightleg.setRotationPoint(-4.0F, 14.0F, 7.0F);
        this.rightleg.addBox(-2.0F, 0.0F, -2.0F, 4, 10, 4, 0.0F);
        this.shape17 = new ModelRenderer(this, 0, 35);
        this.shape17.setRotationPoint(-4.5F, 4.0F, -0.6F);
        this.shape17.addBox(0.0F, -5.0F, 0.0F, 1, 5, 2, 0.0F);
        this.setRotateAngle(shape17, -0.4363323129985824F, 0.0F, 0.0F);
        this.horn = new ModelRenderer(this, 31, 30);
        this.horn.setRotationPoint(0.0F, -2.5F, -8.8F);
        this.horn.addBox(-1.5F, -3.5F, 0.0F, 3, 5, 2, 0.0F);
        this.setRotateAngle(horn, 0.13962634015954636F, 0.0F, 0.0F);
        this.body2 = new ModelRenderer(this, 0, 45);
        this.body2.setRotationPoint(0.0F, 3.0F, -6.5F);
        this.body2.addBox(-7.0F, 0.0F, -5.0F, 14, 11, 8, 0.0F);
        this.rightarm = new ModelRenderer(this, 0, 30);
        this.rightarm.setRotationPoint(-4.0F, 14.0F, -6.0F);
        this.rightarm.addBox(-2.0F, 0.0F, -2.0F, 4, 10, 4, 0.0F);
        this.head.addChild(this.rear);
        this.body.addChild(this.leftleg);
        this.body.addChild(this.leftarm);
        this.head.addChild(this.rod);
        this.head.addChild(this.lear);
        this.body.addChild(this.tail);
        this.body.addChild(this.head);
        this.body.addChild(this.shape16);
        this.body.addChild(this.rightleg);
        this.body.addChild(this.shape17);
        this.head.addChild(this.horn);
        this.body.addChild(this.body2);
        this.body.addChild(this.rightarm);
    }

    @Override
    public void render(Entity entity, float f, float f1, float f2, float f3, float f4, float f5) { 
    	setRotationAngles(f, f1, f2, f3, f4, f5, entity);
    	GL11.glPushMatrix();
         GL11.glTranslatef(this.body.offsetX, this.body.offsetY, this.body.offsetZ);
         GL11.glTranslatef(this.body.rotationPointX * f5, this.body.rotationPointY * f5, this.body.rotationPointZ * f5);
         GL11.glScaled(7.0D, 7.0D, 7.0D);
         GL11.glTranslatef(-this.body.offsetX, -this.body.offsetY, -this.body.offsetZ);
         GL11.glTranslatef(-this.body.rotationPointX * f5, -this.body.rotationPointY * f5, -this.body.rotationPointZ * f5);
         this.body.render(f5);
         GL11.glPopMatrix();
    }

    /**
     * This is a helper function from Tabula to set the rotation of model parts
     */
    public void setRotateAngle(ModelRenderer modelRenderer, float x, float y, float z) {
        modelRenderer.rotateAngleX = x;
        modelRenderer.rotateAngleY = y;
        modelRenderer.rotateAngleZ = z;
    }
    
    public void setRotationAngles(float f, float f1, float f2, float f3, float f4, float f5, Entity entity) {
		super.setRotationAngles(f, f1, f2, f3, f4, f5, entity);
        this.head.rotateAngleY = f3 / (180F / (float)Math.PI);
        this.head.rotateAngleX = f4 / (180F / (float)Math.PI);    
        this.rightleg.rotateAngleX = MathHelper.cos(f * 1.0F) * -1.0F * f1;
        this.leftleg.rotateAngleX = MathHelper.cos(f * 1.0F) * 1.0F * f1;
        this.rightarm.rotateAngleX = MathHelper.cos(f * 0.6662F + (float)Math.PI) * 2.0F * f1 * 0.5F;
        this.leftarm.rotateAngleX = MathHelper.cos(f * 0.6662F) * 2.0F * f1 * 0.5F;
		
	}
}
