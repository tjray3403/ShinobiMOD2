package Shinobi.Entitys.Models;

import net.minecraft.client.model.ModelBase;
import net.minecraft.client.model.ModelRenderer;
import net.minecraft.entity.Entity;
import net.minecraft.util.MathHelper;
import thehippomasterAPI.AnimationAPI.IAnimatedEntity;
import thehippomasterAPI.AnimationAPI.client.Animator;

/**
 * Modelkakuzu - Either Mojang or a mod author
 * Created using Tabula 4.1.1
 */
public class ModelSasori extends ModelBase {
    public ModelRenderer rightarm;
    public ModelRenderer leftleg;
    public ModelRenderer body;
    public ModelRenderer head;
    public ModelRenderer rightleg;
    public ModelRenderer leftarm;
    public ModelRenderer mtal1;
    public ModelRenderer scrll1;
    public ModelRenderer scrll2;
    public ModelRenderer scrll3;
    public ModelRenderer scrll4;
    public ModelRenderer Lm;
    public ModelRenderer Rm;
    public ModelRenderer headChild;
    public ModelRenderer shape41;
    public ModelRenderer lbtm;
    public ModelRenderer ll1;
    public ModelRenderer ll2;
    public ModelRenderer ll3;
    public ModelRenderer ll4;
    public ModelRenderer ll5;
    public ModelRenderer rbtm;
    public ModelRenderer rr1;
    public ModelRenderer rr2;
    public ModelRenderer rr3;
    public ModelRenderer rr4;
    public ModelRenderer rr5;
    
    private Animator animator;
    
    public static final float PI = (float)Math.PI;

    public ModelSasori() {
    	
        this.textureWidth = 64;
        this.textureHeight = 64;
        
        this.ll4 = new ModelRenderer(this, 12, 35);
        this.ll4.setRotationPoint(0.0F, 0.0F, 1.3F);
        this.ll4.addBox(-1.0F, 0.0F, 0.0F, 2, 12, 1, 0.0F);
        
        
        this.ll3 = new ModelRenderer(this, 12, 35);
        this.ll3.setRotationPoint(0.0F, 0.0F, 1.2F);
        this.ll3.addBox(-1.0F, 0.0F, 0.0F, 2, 12, 1, 0.0F);
        
        
        this.scrll3 = new ModelRenderer(this, 15, 60);
        this.scrll3.setRotationPoint(0.0F, 4.1F, 2.0F);
        this.scrll3.addBox(-2.0F, 0.0F, 0.0F, 4, 1, 1, 0.0F);
        
        this.rr1 = new ModelRenderer(this, 12, 35);
        this.rr1.setRotationPoint(0.0F, 0.0F, 1.0F);
        this.rr1.addBox(0.0F, 0.0F, 0.0F, 2, 12, 1, 0.0F);
        
        this.headChild = new ModelRenderer(this, 22, 34);
        this.headChild.setRotationPoint(0.0F, 0.0F, 0.0F);
        this.headChild.addBox(-5.0F, -2.0F, -5.0F, 10, 3, 10, 0.0F);
        
        this.Lm = new ModelRenderer(this, 0, 45);
        this.Lm.setRotationPoint(2.1F, 6.0F, 2.0F);
        this.Lm.addBox(0.0F, 0.0F, 0.0F, 1, 2, 8, 0.0F);
        
        
        this.rr2 = new ModelRenderer(this, 12, 35);
        this.rr2.setRotationPoint(0.0F, 0.0F, 1.1F);
        this.rr2.addBox(0.0F, 0.0F, 0.0F, 2, 12, 1, 0.0F);
        
        
        this.scrll1 = new ModelRenderer(this, 15, 60);
        this.scrll1.setRotationPoint(0.0F, 1.7F, 2.0F);
        this.scrll1.addBox(-2.0F, 0.0F, 0.0F, 4, 1, 1, 0.0F);
        
        
        this.scrll4 = new ModelRenderer(this, 15, 60);
        this.scrll4.setRotationPoint(0.0F, 5.3F, 2.0F);
        this.scrll4.addBox(-2.0F, 0.0F, 0.0F, 4, 1, 1, 0.0F);
        
        this.rr3 = new ModelRenderer(this, 12, 35);
        this.rr3.setRotationPoint(0.0F, 0.0F, 1.2F);
        this.rr3.addBox(0.0F, 0.0F, 0.0F, 2, 12, 1, 0.0F);
        
        
        this.shape41 = new ModelRenderer(this, 27, 49);
        this.shape41.setRotationPoint(0.0F, -8.2F, 0.0F);
        this.shape41.addBox(-4.5F, 0.0F, -4.5F, 9, 4, 9, 0.0F);
        
        this.rbtm = new ModelRenderer(this, 0, 35);
        this.rbtm.setRotationPoint(0.0F, 0.0F, 8.0F);
        this.rbtm.addBox(0.0F, 0.0F, 0.0F, 2, 2, 1, 0.0F);
        
        this.scrll2 = new ModelRenderer(this, 15, 60);
        this.scrll2.setRotationPoint(0.0F, 2.9F, 2.0F);
        this.scrll2.addBox(-2.0F, 0.0F, 0.0F, 4, 1, 1, 0.0F);
        
        this.body = new ModelRenderer(this, 16, 16);
        this.body.setRotationPoint(0.0F, 0.0F, 0.0F);
        this.body.addBox(-4.0F, 0.0F, -2.0F, 8, 12, 4, 0.0F);
        
        this.rightleg = new ModelRenderer(this, 0, 16);
        this.rightleg.setRotationPoint(-2.0F, 12.0F, 0.0F);
        this.rightleg.addBox(-2.0F, 0.0F, -2.0F, 4, 12, 4, 0.0F);
        
        this.leftleg = new ModelRenderer(this, 35, 0);
        this.leftleg.setRotationPoint(2.0F, 12.0F, 0.0F);
        this.leftleg.addBox(-2.0F, 0.0F, -2.0F, 4, 12, 4, 0.0F);
        
        this.leftarm = new ModelRenderer(this, 40, 16);
        this.leftarm.setRotationPoint(5.0F, 2.0F, 0.0F);
        this.leftarm.addBox(-1.0F, -2.0F, -2.0F, 4, 12, 4, 0.0F);
        
        this.ll5 = new ModelRenderer(this, 12, 35);
        this.ll5.setRotationPoint(0.0F, 0.0F, 0.9F);
        this.ll5.addBox(-1.0F, 0.0F, 0.0F, 2, 12, 1, 0.0F);
        
        
        this.ll2 = new ModelRenderer(this, 12, 35);
        this.ll2.setRotationPoint(0.0F, 0.0F, 1.1F);
        this.ll2.addBox(-1.0F, 0.0F, 0.0F, 2, 12, 1, 0.0F);
        
        
        this.head = new ModelRenderer(this, 0, 0);
        this.head.setRotationPoint(0.0F, 0.0F, 0.0F);
        this.head.addBox(-4.0F, -8.0F, -4.0F, 8, 8, 8, 0.0F);
        
        this.rr4 = new ModelRenderer(this, 12, 35);
        this.rr4.setRotationPoint(0.0F, 0.0F, 1.3F);
        this.rr4.addBox(0.0F, 0.0F, 0.0F, 2, 12, 1, 0.0F);
        
        
        this.rr5 = new ModelRenderer(this, 12, 35);
        this.rr5.setRotationPoint(0.0F, 0.0F, 0.9F);
        this.rr5.addBox(0.0F, 0.0F, 0.0F, 2, 12, 1, 0.0F);
        
        
        this.rightarm = new ModelRenderer(this, 40, 16);
        this.rightarm.setRotationPoint(-5.0F, 2.0F, 0.0F);
        this.rightarm.addBox(-3.0F, -2.0F, -2.0F, 4, 12, 4, 0.0F);
        
        this.Rm = new ModelRenderer(this, 0, 45);
        this.Rm.setRotationPoint(-3.0F, 6.0F, 2.0F);
        this.Rm.addBox(0.0F, 0.0F, 0.0F, 1, 2, 8, 0.0F);
        
        
        this.mtal1 = new ModelRenderer(this, 0, 55);
        this.mtal1.setRotationPoint(0.0F, 1.5F, 1.2F);
        this.mtal1.addBox(-1.5F, 0.0F, 0.0F, 3, 5, 2, 0.0F);
        
        
        this.lbtm = new ModelRenderer(this, 0, 35);
        this.lbtm.setRotationPoint(0.0F, 0.0F, 8.0F);
        this.lbtm.addBox(-1.0F, 0.0F, 0.0F, 2, 2, 1, 0.0F);
        
        this.ll1 = new ModelRenderer(this, 12, 35);
        this.ll1.setRotationPoint(0.0F, 0.0F, 1.0F);
        this.ll1.addBox(-1.0F, 0.0F, 0.0F, 2, 12, 1, 0.0F);
        
        animator = new Animator(this);
        
        this.lbtm.addChild(this.ll4);
        this.lbtm.addChild(this.ll3);
        this.rbtm.addChild(this.rr1);
        this.head.addChild(this.headChild);
        this.rbtm.addChild(this.rr2);
        this.rbtm.addChild(this.rr3);
        this.head.addChild(this.shape41);
        this.Rm.addChild(this.rbtm);
        this.lbtm.addChild(this.ll5);
        this.lbtm.addChild(this.ll2);
        this.rbtm.addChild(this.rr4);
        this.rbtm.addChild(this.rr5);
        this.Lm.addChild(this.lbtm);
        this.lbtm.addChild(this.ll1);
    }

    @Override
    public void render(Entity entity, float f, float f1, float f2, float f3, float f4, float f5) { 
    	animate((IAnimatedEntity)entity, f, f1, f2, f3, f4, f5);
    	this.scrll3.render(f5);
        this.Lm.render(f5);
        this.scrll1.render(f5);
        this.scrll4.render(f5);
        this.scrll2.render(f5);
        this.body.render(f5);
        this.rightleg.render(f5);
        this.leftleg.render(f5);
        this.leftarm.render(f5);
        this.head.render(f5);
        this.rightarm.render(f5);
        this.Rm.render(f5);
        this.mtal1.render(f5);
    }
    
    public void animate(IAnimatedEntity entity, float f, float f1, float f2, float f3, float f4, float f5) {
		animator.update(entity);
		setAngles();
		
		this.head.rotateAngleY = f3 / (180F / (float)Math.PI);
	    this.head.rotateAngleX = f4 / (180F / (float)Math.PI);    
	    this.leftleg.rotateAngleX = MathHelper.cos(f * 1.0F) * -1.0F * f1;
	    this.rightleg.rotateAngleX = MathHelper.cos(f * 1.0F) * 1.0F * f1;
	    this.rightarm.rotateAngleX = MathHelper.cos(f * 0.6662F + (float)Math.PI) * 2.0F * f1 * 0.5F;
	    this.leftarm.rotateAngleX = MathHelper.cos(f * 0.6662F) * 2.0F * f1 * 0.5F;
	    
	    
	    animator.setAnim(1);
	animator.startPhase(4);
		animator.rotate(rightarm, -2F, 0F, 0F);
		animator.rotate(leftarm, -2F, 0F, 0F);
	animator.endPhase();
	animator.startPhase(10);
	    animator.rotate(rightarm, -1F, 0F, -1F);
	    animator.rotate(leftarm, -1F, 0F, 1F);
	animator.endPhase();
	    animator.setStationaryPhase(10);
	    animator.resetPhase(5);
	    
	    
	    animator.setAnim(2);
		animator.startPhase(10);
		animator.rotate(rightarm, -2F, 0, 0/**1.1F*/);
		animator.rotate(leftarm, -2F, 0, 0/**-1.1F*/);
		animator.endPhase();
		animator.setStationaryPhase(100);
		animator.resetPhase(5);
		
		animator.setAnim(3);
		animator.startPhase(10);
		animator.rotate(rightarm, -2F, 0, 1.1F);
		animator.rotate(leftarm, -2F, 0, -1.1F);
		animator.endPhase();
		animator.startPhase(10);
		animator.rotate(rightarm, -1F, 0, -1.1F);
		animator.rotate(leftarm, -1F, 0, 1.1F);
		animator.endPhase();
		animator.setStationaryPhase(20);
		animator.resetPhase(5);
		
		animator.setAnim(4);
	animator.startPhase(10);
		animator.rotate(Rm, 0F, -1F, 0F);
		animator.rotate(Lm, 0F, 1F, 0F);
		animator.endPhase();
		
		animator.startPhase(10);
		animator.rotate(rr1, 0F, 0F, -1F);
		animator.rotate(rr2, 0F, 0F, -0.3F);
		animator.rotate(rr3, 0F, 0F, 0.7F);
		animator.rotate(rr4, 0F, 0F, 1.7F);
		animator.rotate(rr5, 0F, 0F, -2F);
		
		animator.rotate(ll1, 0F, 0F, 1F);
		animator.rotate(ll2, 0F, 0F, 0.3F);
		animator.rotate(ll3, 0F, 0F, -0.7F);
		animator.rotate(ll4, 0F, 0F, -1.7F);
		animator.rotate(ll5, 0F, 0F, 2F);
		animator.endPhase();
	
	animator.startPhase(10);
	animator.rotate(Rm, 0F, -1F, 0F);
	animator.rotate(Lm, 0F, 1F, 0F);
		animator.rotate(rbtm, 0F, 0F, 5*5F);
		animator.rotate(lbtm, 0F, 0F, -5*5F);
		animator.rotate(rr1, 0F, 0F, -1F);
		animator.rotate(rr2, 0F, 0F, -0.3F);
		animator.rotate(rr3, 0F, 0F, 0.7F);
		animator.rotate(rr4, 0F, 0F, 1.7F);
		animator.rotate(rr5, 0F, 0F, -2F);
		
		animator.rotate(ll1, 0F, 0F, 1F);
		animator.rotate(ll2, 0F, 0F, 0.3F);
		animator.rotate(ll3, 0F, 0F, -0.7F);
		animator.rotate(ll4, 0F, 0F, -1.7F);
		animator.rotate(ll5, 0F, 0F, 2F);
		animator.endPhase();
		animator.startPhase(20);
		animator.rotate(rbtm, 0F, 0F, 5*5F);
		animator.rotate(lbtm, 0F, 0F, -5*5F);
		animator.endPhase();

		animator.resetPhase(30);
		
    }

    private void setAngles() {
		// TODO Auto-generated method stub
		this.setRotateAngle(mtal1, 0.0F, 0.0F, -0.006091900144596364F);
		this.setRotateAngle(Rm, 0.17453292519943295F, -0.4363323129985824F, 0.0F);
		this.setRotateAngle(ll2, 0.0F, 0.0F, -0.20943951023931953F);
		this.setRotateAngle(rr5, 0.0F, 0.0F, -0.22689280275926282F);
		this.setRotateAngle(rr4, 0.0F, 0.0F, 0.6632251157578453F);
		this.setRotateAngle(ll5, 0.0F, 0.0F, 0.22689280275926282F);
		this.setRotateAngle(rr3, 0.0F, 0.0F, 0.4363323129985824F);
		this.setRotateAngle(scrll1, 0.006108652381980153F, 0.0F, 0.0F);
		this.setRotateAngle(rr2, 0.0F, 0.0F, 0.20943951023931953F);
		this.setRotateAngle(Lm, 0.17453292519943295F, 0.4363323129985824F, 0.0F);
		this.setRotateAngle(ll3, 0.0F, 0.0F, -0.4363323129985824F);
		this.setRotateAngle(ll4, 0.0F, 0.0F, -0.6632251157578453F);
		
	}

	/**
     * This is a helper function from Tabula to set the rotation of model parts
     */
    public void setRotateAngle(ModelRenderer modelRenderer, float x, float y, float z) {
        modelRenderer.rotateAngleX = x;
        modelRenderer.rotateAngleY = y;
        modelRenderer.rotateAngleZ = z;
    }
}
