package Shinobi.Entitys.Models;

import Shinobi.Entitys.Entitys.EntitySasoriHiruko;
import net.minecraft.client.model.ModelBase;
import net.minecraft.client.model.ModelRenderer;
import net.minecraft.entity.Entity;
import net.minecraft.util.MathHelper;
import thehippomasterAPI.AnimationAPI.IAnimatedEntity;
import thehippomasterAPI.AnimationAPI.client.Animator;

/**
 * Sasori - tex
 * Created using Tabula 4.1.1
 */
public class ModelSasoriHiruko extends ModelBase {
    public ModelRenderer body;
    public ModelRenderer rightarm;
    public ModelRenderer leftarm;
    public ModelRenderer rightleg;
    public ModelRenderer leftleg;
    public ModelRenderer body2;
    public ModelRenderer lbp;
    public ModelRenderer rbp;
    public ModelRenderer A1;
    public ModelRenderer shape27;
    public ModelRenderer shape28;
    public ModelRenderer shape29;
    public ModelRenderer shape30;
    public ModelRenderer head;
    public ModelRenderer shape26;
    public ModelRenderer rightarm1;
    public ModelRenderer leftarm1;
    public ModelRenderer rightleg1;
    public ModelRenderer leftleg1;
    public ModelRenderer A2;
    public ModelRenderer A3;
    public ModelRenderer B1;
    public ModelRenderer B2;
    public ModelRenderer B3;
    public ModelRenderer C1;
    public ModelRenderer C2;
    public ModelRenderer C3;
    public ModelRenderer SR;
    public ModelRenderer SL;
    
    private Animator animator;
	private boolean attackmode = false;
	private boolean hirmode = false;

	private Entity entity;
    
    public static final float PI = (float)Math.PI;

    public ModelSasoriHiruko() {
        this.textureWidth = 200;
        this.textureHeight = 200;
        
        this.rightleg = new ModelRenderer(this, 75, 0);
        this.rightleg.setRotationPoint(-6.0F, 15.0F, 16.0F);
        this.rightleg.addBox(-2.0F, 0.0F, -2.0F, 4, 7, 4, 0.0F);
        this.setRotateAngle(rightleg, 0.0F, 0.0F, 0.6981317007977318F);
        
        this.rbp = new ModelRenderer(this, 0, 98);
        this.rbp.setRotationPoint(0.1F, 11.0F, -1.5F);
        this.rbp.addBox(-6.0F, 0.0F, 0.0F, 6, 3, 20, 0.0F);
        this.setRotateAngle(rbp, 0.0F, 0.0F, -0.12217304763960307F);
        
        this.shape28 = new ModelRenderer(this, 100, 55);
        this.shape28.setRotationPoint(0.0F, 5.0F, 0.0F);
        this.shape28.addBox(-7.5F, 0.0F, -2.1F, 15, 5, 20, 0.0F);
        
        this.B2 = new ModelRenderer(this, 0, 0);
        this.B2.setRotationPoint(0.0F, 13.0F, 2.0F);
        this.B2.addBox(-3.0F, 0.0F, 0.0F, 6, 4, 5, 0.0F);
        this.setRotateAngle(B2, 0.1228711793404008F, 0.0F, 0.0F);
        
        this.shape27 = new ModelRenderer(this, 70, 151);
        this.shape27.setRotationPoint(0.0F, 18.6F, 0.0F);
        this.shape27.addBox(-14.5F, 0.0F, -8.0F, 29, 4, 30, 0.0F);

        this.shape30 = new ModelRenderer(this, 86, 92);
        this.shape30.setRotationPoint(0.0F, 9.6F, -6.3F);
        this.shape30.addBox(-12.0F, 0.0F, 0.0F, 24, 9, 28, 0.0F);
        
        this.leftleg1 = new ModelRenderer(this, 75, 15);
        this.leftleg1.setRotationPoint(0.0F, 5.5F, -0.5F);
        this.leftleg1.addBox(-2.0F, 0.0F, -2.0F, 4, 7, 4, 0.0F);
        this.setRotateAngle(leftleg1, 0.8726646259971648F, 0.0F, 0.0F);
        
        this.body2 = new ModelRenderer(this, 16, 16);
        this.body2.setRotationPoint(0.0F, 13.0F, 8.0F);
        this.body2.addBox(-5.0F, 0.0F, 0.0F, 10, 7, 11, 0.0F);
        
        this.leftarm1 = new ModelRenderer(this, 0, 50);
        this.leftarm1.setRotationPoint(0.0F, 5.5F, 0.5F);
        this.leftarm1.addBox(-1.9F, 0.0F, -2.0F, 4, 7, 4, 0.0F);
        this.setRotateAngle(leftarm1, -0.8726646259971648F, 0.0F, 0.0F);
        
        this.rightarm1 = new ModelRenderer(this, 0, 37);
        this.rightarm1.setRotationPoint(0.0F, 5.5F, 0.5F);
        this.rightarm1.addBox(-2.0F, 0.0F, -2.0F, 4, 7, 4, 0.0F);
        this.setRotateAngle(rightarm1, -0.8726646259971648F, 0.0F, 0.0F);
        
        this.head = new ModelRenderer(this, 30, 40);
        this.head.setRotationPoint(0.0F, 1.5F, -10.0F);
        this.head.addBox(-3.0F, -4.0F, -6.0F, 6, 7, 6, 0.0F);
        
        this.SL = new ModelRenderer(this, 0, 0);
        this.SL.setRotationPoint(0.0F, -2.0F, 4.5F);
        this.SL.addBox(0.0F, 0.0F, 0.0F, 3, 4, 5, 0.0F);
        this.setRotateAngle(SL, 0.0F, -0.3141592653589793F, 0.0F);
        
        this.B3 = new ModelRenderer(this, 0, 0);
        this.B3.setRotationPoint(0.0F, 0.2F, 3.7F);
        this.B3.addBox(-3.0F, 0.0F, 0.0F, 6, 4, 5, 0.0F);
        this.setRotateAngle(B3, 0.296705972839036F, 0.0F, 0.0F);
        
        this.lbp = new ModelRenderer(this, 0, 70);
        this.lbp.setRotationPoint(0.1F, 11.0F, -1.5F);
        this.lbp.addBox(0.0F, 0.0F, 0.0F, 6, 3, 20, 0.0F);
        this.setRotateAngle(lbp, 0.0F, 0.0F, 0.12217304763960307F);
        
        this.A3 = new ModelRenderer(this, 0, 0);
        this.A3.setRotationPoint(0.0F, 0.0F, 4.9F);
        this.A3.addBox(-3.0F, 0.0F, 0.0F, 6, 4, 5, 0.0F);
        this.setRotateAngle(A3, 0.12217304763960307F, 0.0F, 0.0F);
        
        this.SR = new ModelRenderer(this, 0, 0);
        this.SR.setRotationPoint(-3.2F, -2.0F, 5.5F);
        this.SR.addBox(0.0F, 0.0F, 0.0F, 3, 4, 5, 0.0F);
        this.setRotateAngle(SR, 0.0F, 0.3141592653589793F, 0.0F);
        
        this.shape29 = new ModelRenderer(this, 83, 150);
        this.shape29.setRotationPoint(0.0F, 7.7F, 0.0F);
        this.shape29.addBox(-10.0F, 0.0F, -5.1F, 20, 2, 25, 0.0F);
        
        this.A2 = new ModelRenderer(this, 0, 0);
        this.A2.setRotationPoint(0.0F, 9.9F, 2.0F);
        this.A2.addBox(-3.0F, 0.0F, 0.0F, 6, 4, 5, 0.0F);
        this.setRotateAngle(A2, 0.12217304763960307F, 0.0F, 0.0F);
        
        this.body = new ModelRenderer(this, 16, 16);
        this.body.setRotationPoint(0.0F, 13.0F, 8.0F);
        this.body.addBox(-5.0F, 0.0F, -10.0F, 10, 7, 10, 0.0F);
        this.setRotateAngle(body, -0.9105382707654417F, 0.0F, 0.0F);
        
        this.leftleg = new ModelRenderer(this, 75, 0);
        this.leftleg.setRotationPoint(6.0F, 15.0F, 16.0F);
        this.leftleg.addBox(-2.0F, 0.0F, -2.0F, 4, 7, 4, 0.0F);
        this.setRotateAngle(leftleg, 0.0F, 0.0F, -0.6981317007977318F);
        
        this.B1 = new ModelRenderer(this, 0, 0);
        this.B1.setRotationPoint(0.0F, -10.5F, -4.5F);
        this.B1.addBox(-3.0F, 13.0F, -3.0F, 6, 4, 5, 0.0F);
        this.setRotateAngle(B1, 0.091106186954104F, 0.0F, 0.0F);
        
        this.C1 = new ModelRenderer(this, 0, 0);
        this.C1.setRotationPoint(0.0F, -13.9F, 2.2F);
        this.C1.addBox(-3.0F, 13.5F, -6.0F, 6, 4, 5, 0.0F);
        this.setRotateAngle(C1, -0.9250245035569946F, 0.0F, -0.006283185307179587F);
        
        this.rightarm = new ModelRenderer(this, 75, 0);
        this.rightarm.setRotationPoint(-6.0F, 15.0F, 0.0F);
        this.rightarm.addBox(-2.0F, 0.0F, -2.0F, 4, 7, 4, 0.0F);
        this.setRotateAngle(rightarm, 0.0F, 0.0F, 0.6981317007977318F);
        
        this.leftarm = new ModelRenderer(this, 75, 0);
        this.leftarm.setRotationPoint(6.0F, 15.0F, 0.0F);
        this.leftarm.addBox(-2.0F, 0.0F, -2.0F, 4, 7, 4, 0.0F);
        this.setRotateAngle(leftarm, 0.0F, 0.0F, -0.6981317007977318F);
        
        this.A1 = new ModelRenderer(this, 0, 0);
        this.A1.setRotationPoint(0.0F, 4.0F, 4.5F);
        this.A1.addBox(-3.0F, 9.9F, -3.0F, 6, 4, 5, 0.0F);
        this.setRotateAngle(A1, -0.017453292519943295F, 0.0F, 0.0F);
        
        this.C3 = new ModelRenderer(this, 0, 0);
        this.C3.setRotationPoint(0.0F, 0.0F, 4.0F);
        this.C3.addBox(-3.0F, -2.0F, 0.0F, 6, 4, 5, 0.0F);
        this.setRotateAngle(C3, 0.33161255787892263F, 0.0F, 0.0F);
        
        this.C2 = new ModelRenderer(this, 0, 0);
        this.C2.setRotationPoint(0.0F, 15.5F, 0.0F);
        this.C2.addBox(-3.0F, -2.1F, -1.0F, 6, 4, 5, 0.0F);
        this.setRotateAngle(C2, 0.2617993877991494F, 0.0F, 0.0F);
        
        this.shape26 = new ModelRenderer(this, 26, 60);
        this.shape26.setRotationPoint(0.0F, 0.0F, 0.0F);
        this.shape26.addBox(-3.0F, -5.2F, -2.7F, 6, 4, 3, 0.0F);
        
        this.rightleg1 = new ModelRenderer(this, 75, 15);
        this.rightleg1.setRotationPoint(0.0F, 5.5F, -0.5F);
        this.rightleg1.addBox(-2.0F, 0.0F, -2.0F, 4, 7, 4, 0.0F);
        this.setRotateAngle(rightleg1, 0.8726646259971648F, 0.0F, 0.0F);
        
        animator = new Animator(this);
        
        this.B1.addChild(this.B2);
        this.leftleg.addChild(this.leftleg1);
        this.leftarm.addChild(this.leftarm1);
        this.rightarm.addChild(this.rightarm1);
        this.body.addChild(this.head);
        this.C3.addChild(this.SL);
        this.B2.addChild(this.B3);
        this.A2.addChild(this.A3);
        this.C3.addChild(this.SR);
        this.A1.addChild(this.A2);
        this.A3.addChild(this.B1);
        this.B3.addChild(this.C1);
        this.C2.addChild(this.C3);
        this.C1.addChild(this.C2);
        this.head.addChild(this.shape26);
        this.rightleg.addChild(this.rightleg1);
    }

    @Override
    public void render(Entity entity, float f, float f1, float f2, float f3, float f4, float f5) { 
    	animate((IAnimatedEntity)entity, f, f1, f2, f3, f4, f5);
    	this.rightleg.render(f5);
        this.rbp.render(f5);
        this.shape28.render(f5);
        this.shape27.render(f5);
        this.shape30.render(f5);
        this.body2.render(f5);
        this.lbp.render(f5);
        this.shape29.render(f5);
        this.body.render(f5);
        this.leftleg.render(f5);
        this.rightarm.render(f5);
        this.leftarm.render(f5);
        this.A1.render(f5);
        
        
        EntitySasoriHiruko entitysas = (EntitySasoriHiruko) entity;
        if(entitysas.attackM==true) {
        	attackmode=true;
        }
        else
        {
        	attackmode=false;
        }
        
        if(entitysas.hirukomode==true) {
        	hirmode=true;
        }
        else
        {
        	hirmode=false;
        }
        
        
    }
    
    public void animate(IAnimatedEntity entity, float f, float f1, float f2, float f3, float f4, float f5) {
		animator.update(entity);
		setAngles();
		
		if(hirmode==true){
		 	
		    this.leftleg.rotateAngleX = MathHelper.cos(f * 1.0F) * -1.0F * f1;
		    this.rightleg.rotateAngleX = MathHelper.cos(f * 1.0F) * 1.0F * f1;
		    this.rightarm.rotateAngleX = MathHelper.cos(f * 0.6662F + (float)Math.PI) * 2.0F * f1 * 0.5F;
		    this.leftarm.rotateAngleX = MathHelper.cos(f * 0.6662F) * 2.0F * f1 * 0.5F;
		}
		    this.head.rotateAngleY = f3 / (180F / (float)Math.PI);
		    this.head.rotateAngleX = f4 / (180F / (float)Math.PI);    
		    
		    animator.setAnim(1);
			animator.startPhase(10);
			animator.rotate(A2, 0.7F, 0F, 0F);
			animator.rotate(B2, 0.2F, 0F, 0F);
			animator.rotate(C3, -0.3F, 0F, 0F);
			animator.endPhase();
		    animator.setStationaryPhase(20);
		    animator.resetPhase(5);
		    
		    animator.setAnim(2);
			animator.startPhase(10);
			animator.rotate(C3, -0.5F, 0F, 0F);
			animator.endPhase();
			animator.resetPhase(5);
			
			animator.setAnim(3);
			animator.startPhase(5);
			animator.rotate(A2, 1.5F, 0F, 0.6F);
			animator.rotate(B2, -0.5F, 0F, 0F);
			animator.rotate(C3, 0.3F, 0F, 0F);
			animator.endPhase();
		    animator.setStationaryPhase(5);
		    animator.resetPhase(5);
		    
		    animator.setAnim(4);
			animator.startPhase(5);
			animator.rotate(A2, 1.5F, 0F, -0.6F);
			animator.rotate(B2, -0.5F, 0F, 0F);
			animator.rotate(C3, 0.3F, 0F, 0F);
			animator.endPhase();
		    animator.setStationaryPhase(5);
		    animator.resetPhase(5);
		    
		    animator.setAnim(5);
			animator.startPhase(5);
			animator.rotate(A2, 1.7F, 0F, 0F);
			animator.rotate(A3, -0.5F, 0F, 0F);
			animator.rotate(B2, -1F, 0F, 0F);
			animator.rotate(C3, 0F, 0F, 0F);
			animator.endPhase();
		    animator.setStationaryPhase(5);
		    animator.resetPhase(5);
		    
    }

    private void setAngles() {
    	 
         this.setRotateAngle(rightleg, 0.0F, 0.0F, 0.6981317007977318F);       
         this.setRotateAngle(rbp, 0.0F, 0.0F, -0.12217304763960307F);   
         this.setRotateAngle(B2, 0.1228711793404008F, 0.0F, 0.0F);       
         this.setRotateAngle(leftleg1, 0.8726646259971648F, 0.0F, 0.0F);
         this.setRotateAngle(leftarm1, -0.8726646259971648F, 0.0F, 0.0F);
         this.setRotateAngle(rightarm1, -0.8726646259971648F, 0.0F, 0.0F);
         this.setRotateAngle(SL, 0.0F, -0.3141592653589793F, 0.0F);
         this.setRotateAngle(B3, 0.296705972839036F, 0.0F, 0.0F);
         this.setRotateAngle(lbp, 0.0F, 0.0F, 0.12217304763960307F);
         this.setRotateAngle(A3, 0.12217304763960307F, 0.0F, 0.0F); 
         this.setRotateAngle(SR, 0.0F, 0.3141592653589793F, 0.0F);
         this.setRotateAngle(A2, 0.12217304763960307F, 0.0F, 0.0F);

         this.setRotateAngle(leftleg, 0.0F, 0.0F, -0.6981317007977318F);
         this.setRotateAngle(B1, 0.091106186954104F, 0.0F, 0.0F);
         this.setRotateAngle(C1, -0.9250245035569946F, 0.0F, -0.006283185307179587F);
         this.setRotateAngle(rightarm, 0.0F, 0.0F, 0.6981317007977318F);
         this.setRotateAngle(leftarm, 0.0F, 0.0F, -0.6981317007977318F);
         this.setRotateAngle(A1, -0.017453292519943295F, 0.0F, 0.0F);
         this.setRotateAngle(C3, 0.33161255787892263F, 0.0F, 0.0F);
         this.setRotateAngle(C2, 0.2617993877991494F, 0.0F, 0.0F);
         this.setRotateAngle(rightleg1, 0.8726646259971648F, 0.0F, 0.0F);
         
         if(hirmode==false){
                  this.setRotateAngle(body, -0.9105382707654417F, 0.0F, 0.0F);
         }
         else
         {
             this.setRotateAngle(body, 0.0F, 0.0F, 0.0F);

         }
		
		if(attackmode==true){
        	 A1.rotateAngleX = 1F;
        	 B1.rotateAngleX = 0.8F;
        	 C1.rotateAngleX = 0.5F;
         }
         else
         {
        	 A1.rotateAngleX = 0F;
        	 B1.rotateAngleX = -0.3F;
        	 C1.rotateAngleX = -0.4F;
         }
		
	}

	/**
     * This is a helper function from Tabula to set the rotation of model parts
     */
    public void setRotateAngle(ModelRenderer modelRenderer, float x, float y, float z) {
        modelRenderer.rotateAngleX = x;
        modelRenderer.rotateAngleY = y;
        modelRenderer.rotateAngleZ = z;
    }
}
