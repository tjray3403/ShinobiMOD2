package Shinobi.Entitys.Models;

import net.minecraft.client.model.ModelBase;
import net.minecraft.client.model.ModelRenderer;
import net.minecraft.entity.Entity;
import net.minecraft.util.MathHelper;
import thehippomasterAPI.AnimationAPI.IAnimatedEntity;
import thehippomasterAPI.AnimationAPI.client.Animator;

import org.lwjgl.opengl.GL11;

/**
 * ModelBiped - Either Mojang or a mod author
 * Created using Tabula 4.1.1
 */
public class ModelSusanooItachi extends ModelBase {
    
	public ModelRenderer ribcage3;
    public ModelRenderer ribcage;
    public ModelRenderer sec1;
    public ModelRenderer sec2;
    public ModelRenderer sec4;
    public ModelRenderer sec3;
    public ModelRenderer leftarm1;
    public ModelRenderer rightarm1;
    public ModelRenderer sec5;
    public ModelRenderer HEAD;
    public ModelRenderer f4th;
    public ModelRenderer f4th1;
    public ModelRenderer f4th3;
    public ModelRenderer f4th2;
    public ModelRenderer ribcage2;
    public ModelRenderer leftarm11;
    public ModelRenderer lefttarm2;
    public ModelRenderer leftarm22;
    public ModelRenderer lefthand;
    public ModelRenderer shape43;
    public ModelRenderer rightarm11;
    public ModelRenderer rightarm2;
    public ModelRenderer rightarm22;
    public ModelRenderer righthand;
    public ModelRenderer blade1;
    public ModelRenderer blade2;
    public ModelRenderer head4th;
    public ModelRenderer nose;
    public ModelRenderer hair;
    
    private Animator animator;
    
    public static final float PI = (float)Math.PI;

    public ModelSusanooItachi() {
        this.textureWidth = 500;
        this.textureHeight = 500;
        this.f4th = new ModelRenderer(this, 45, 422);
        this.f4th.setRotationPoint(0.0F, -25.0F, 0.0F);
        this.f4th.addBox(-22.0F, -11.0F, -22.0F, 44, 30, 44, 0.0F);
        
        this.righthand = new ModelRenderer(this, 150, 235);
        this.righthand.setRotationPoint(0.0F, 30.0F, 4.5F);
        this.righthand.addBox(-5.0F, 0.0F, -7.0F, 10, 16, 16, 0.0F);
        
        this.shape43 = new ModelRenderer(this, 0, 300);
        this.shape43.setRotationPoint(4.0F, 20.0F, 1.0F);
        this.shape43.addBox(-38.5F, -2.0F, -38.5F, 75, 2, 75, 0.0F);
        this.sec1 = new ModelRenderer(this, 100, 90);
        this.sec1.setRotationPoint(0.0F, -10.0F, 0.0F);
        this.sec1.addBox(-12.5F, 0.0F, -11.0F, 25, 10, 22, 0.0F);
        this.leftarm11 = new ModelRenderer(this, 0, 180);
        this.leftarm11.setRotationPoint(0.0F, 0.0F, 0.0F);
        this.leftarm11.addBox(0.0F, 0.0F, -10.0F, 16, 26, 20, 0.0F);
        this.ribcage = new ModelRenderer(this, 0, 85);
        this.ribcage.setRotationPoint(0.0F, 8.0F, 0.0F);
        this.ribcage.addBox(-10.0F, 0.0F, -10.0F, 20, 5, 20, 0.0F);
        this.ribcage3 = new ModelRenderer(this, 0, 430);
        this.ribcage3.setRotationPoint(0.0F, -8.0F, 0.0F);
        this.ribcage3.addBox(-8.0F, 0.0F, -8.0F, 16, 8, 16, 0.0F);
        this.hair = new ModelRenderer(this, 310, 0);
        this.hair.setRotationPoint(0.0F, -30.0F, -5.0F);
        this.hair.addBox(-22.5F, -30.0F, -17.5F, 45, 36, 38, 0.0F);
        this.setRotateAngle(hair, -0.5410520681182421F, 0.0F, 0.0F);
        this.rightarm11 = new ModelRenderer(this, 0, 180);
        this.rightarm11.mirror = true;
        this.rightarm11.setRotationPoint(0.0F, 0.0F, 0.0F);
        this.rightarm11.addBox(-16.0F, 0.0F, -10.0F, 16, 26, 20, 0.0F);
        this.blade1 = new ModelRenderer(this, 400, 400);
        this.blade1.setRotationPoint(0.0F, 0.0F, 0.0F);
        this.blade1.addBox(0.0F, 0.0F, 0.0F, 20, 70, 20, 0.0F);
        this.blade2 = new ModelRenderer(this, 260, 390);
        this.blade2.setRotationPoint(10.0F, 70.0F, 10.0F);
        this.blade2.addBox(-12.5F, 0.0F, -12.5F, 25, 74, 25, 0.0F);
        this.f4th2 = new ModelRenderer(this, 87, 174);
        this.f4th2.setRotationPoint(0.0F, -70.0F, 0.0F);
        this.f4th2.addBox(-27.5F, 0.0F, -9.0F, 55, 16, 37, 0.0F);
        this.nose = new ModelRenderer(this, 0, 300);
        this.nose.setRotationPoint(0.0F, -23.0F, -22.8F);
        this.nose.addBox(-2.0F, -2.0F, -15.0F, 4, 4, 15, 0.0F);
        this.sec4 = new ModelRenderer(this, 0, 379);
        this.sec4.setRotationPoint(0.0F, -54.0F, 0.0F);
        this.sec4.addBox(-15.0F, 0.0F, -15.0F, 30, 4, 30, 0.0F);
        this.leftarm1 = new ModelRenderer(this, 0, 115);
        this.leftarm1.setRotationPoint(27.5F, -45.0F, 0.0F);
        this.leftarm1.addBox(0.0F, -6.5F, -15.0F, 12, 30, 30, 0.0F);
        this.setRotateAngle(leftarm1, 0.0F, 0.0F, -0.4363323129985824F);
        this.f4th1 = new ModelRenderer(this, 240, 280);
        this.f4th1.setRotationPoint(0.0F, -55.0F, -5.0F);
        this.f4th1.addBox(-30.0F, -0.2F, -30.0F, 60, 25, 60, 0.0F);
        this.setRotateAngle(f4th1, 0.3141592653589793F, -0.7853981633974483F, -0.22689280275926282F);
        this.lefttarm2 = new ModelRenderer(this, 0, 230);
        this.lefttarm2.setRotationPoint(8.5F, 26.0F, 0.0F);
        this.lefttarm2.addBox(-7.5F, 0.0F, -9.0F, 14, 30, 18, 0.0F);
        this.setRotateAngle(lefttarm2, -0.7853981633974483F, 0.0F, 0.0F);
        this.lefthand = new ModelRenderer(this, 150, 235);
        this.lefthand.mirror = true;
        this.lefthand.setRotationPoint(0.0F, 30.0F, 4.0F);
        this.lefthand.addBox(-5.0F, 0.0F, -7.0F, 10, 16, 16, 0.0F);
        this.setRotateAngle(lefthand, -0.6981317007977318F, 0.0F, 0.0F);
        this.f4th3 = new ModelRenderer(this, 215, 185);
        this.f4th3.setRotationPoint(0.0F, -64.0F, -7.0F);
        this.f4th3.addBox(-35.0F, -7.0F, -31.0F, 70, 20, 70, 0.0F);
        this.setRotateAngle(f4th3, 0.3490658503988659F, 0.0F, 0.0F);
        this.head4th = new ModelRenderer(this, 300, 100);
        this.head4th.setRotationPoint(0.0F, 4.5F, 2.5F);
        this.head4th.addBox(-17.5F, -35.0F, -22.0F, 35, 35, 35, 0.0F);
        this.setRotateAngle(head4th, -0.12217304763960307F, 0.0F, 0.0F);
        this.HEAD = new ModelRenderer(this, 0, 0);
        this.HEAD.setRotationPoint(0.0F, -60.0F, 0.0F);
        this.HEAD.addBox(-12.5F, -25.0F, -12.5F, 25, 25, 25, 0.0F);
        this.sec2 = new ModelRenderer(this, 90, 125);
        this.sec2.setRotationPoint(0.0F, -25.0F, 0.0F);
        this.sec2.addBox(-15.0F, 0.0F, -15.0F, 30, 15, 30, 0.0F);
        this.setRotateAngle(sec2, 0.0F, 0.7853981633974483F, 0.0F);
        this.sec3 = new ModelRenderer(this, 95, 8);
        this.sec3.setRotationPoint(0.0F, -50.0F, 0.0F);
        this.sec3.addBox(-27.5F, 0.0F, -22.0F, 55, 25, 44, 0.0F);
        this.leftarm22 = new ModelRenderer(this, 70, 240);
        this.leftarm22.setRotationPoint(0.0F, 0.0F, 0.0F);
        this.leftarm22.addBox(-9.5F, 0.0F, -12.0F, 14, 27, 24, 0.0F);
        this.rightarm22 = new ModelRenderer(this, 70, 240);
        this.rightarm22.setRotationPoint(0.0F, 0.0F, 0.0F);
        this.rightarm22.addBox(-4.5F, 0.0F, -12.0F, 14, 27, 24, 0.0F);
        this.rightarm1 = new ModelRenderer(this, 0, 115);
        this.rightarm1.setRotationPoint(-27.5F, -45.0F, 0.0F);
        this.rightarm1.addBox(-12.0F, -6.5F, -15.0F, 12, 30, 30, 0.0F);
        this.setRotateAngle(rightarm1, 0.0F, 0.0F, 0.4363323129985824F);
        this.rightarm2 = new ModelRenderer(this, 0, 230);
        this.rightarm2.setRotationPoint(-8.5F, 26.0F, 0.0F);
        this.rightarm2.addBox(-7.5F, 0.0F, -9.0F, 14, 30, 18, 0.0F);
        this.setRotateAngle(rightarm2, -0.7853981633974483F, 0.0F, 0.0F);
        this.ribcage2 = new ModelRenderer(this, 0, 54);
        this.ribcage2.setRotationPoint(0.0F, 0.0F, 0.0F);
        this.ribcage2.addBox(-9.0F, 0.0F, -9.0F, 18, 8, 18, 0.0F);
        this.setRotateAngle(ribcage2, 0.0F, 0.7853981633974483F, 0.0F);
        this.sec5 = new ModelRenderer(this, 0, 340);
        this.sec5.setRotationPoint(0.0F, -63.0F, 0.0F);
        this.sec5.addBox(-7.5F, 0.0F, -7.5F, 15, 9, 15, 0.0F);
        
        animator = new Animator(this);
        
        this.rightarm2.addChild(this.righthand);
        this.lefthand.addChild(this.shape43);
        this.leftarm1.addChild(this.leftarm11);
        this.head4th.addChild(this.hair);
        this.rightarm1.addChild(this.rightarm11);
        this.righthand.addChild(this.blade1);
        this.blade1.addChild(this.blade2);
        this.head4th.addChild(this.nose);
        this.leftarm1.addChild(this.lefttarm2);
        this.lefttarm2.addChild(this.lefthand);
        this.HEAD.addChild(this.head4th);
        this.lefttarm2.addChild(this.leftarm22);
        this.rightarm2.addChild(this.rightarm22);
        this.rightarm1.addChild(this.rightarm2);
    }

    @Override
    public void render(Entity entity, float f, float f1, float f2, float f3, float f4, float f5) { 
    	animate((IAnimatedEntity)entity, f, f1, f2, f3, f4, f5);
    	GL11.glEnable(GL11.GL_BLEND);
        GL11.glBlendFunc(GL11.GL_SRC_ALPHA, GL11.GL_ONE_MINUS_SRC_ALPHA);
        GL11.glColor4f(1.0F, 1.0F, 1.0F, 0.5F);
        this.f4th.render(f5);
        GL11.glDisable(GL11.GL_BLEND);
        GL11.glEnable(GL11.GL_BLEND);
        GL11.glBlendFunc(GL11.GL_SRC_ALPHA, GL11.GL_ONE_MINUS_SRC_ALPHA);
        GL11.glColor4f(1.0F, 1.0F, 1.0F, 0.5F);
        this.sec1.render(f5);
        GL11.glDisable(GL11.GL_BLEND);
        GL11.glEnable(GL11.GL_BLEND);
        GL11.glBlendFunc(GL11.GL_SRC_ALPHA, GL11.GL_ONE_MINUS_SRC_ALPHA);
        GL11.glColor4f(1.0F, 1.0F, 1.0F, 0.5F);
        this.ribcage.render(f5);
        GL11.glDisable(GL11.GL_BLEND);
        GL11.glEnable(GL11.GL_BLEND);
        GL11.glBlendFunc(GL11.GL_SRC_ALPHA, GL11.GL_ONE_MINUS_SRC_ALPHA);
        GL11.glColor4f(1.0F, 1.0F, 1.0F, 0.5F);
        this.ribcage3.render(f5);
        GL11.glDisable(GL11.GL_BLEND);
        GL11.glEnable(GL11.GL_BLEND);
        GL11.glBlendFunc(GL11.GL_SRC_ALPHA, GL11.GL_ONE_MINUS_SRC_ALPHA);
        GL11.glColor4f(1.0F, 1.0F, 1.0F, 0.5F);
        this.f4th2.render(f5);
        GL11.glDisable(GL11.GL_BLEND);
        GL11.glEnable(GL11.GL_BLEND);
        GL11.glBlendFunc(GL11.GL_SRC_ALPHA, GL11.GL_ONE_MINUS_SRC_ALPHA);
        GL11.glColor4f(1.0F, 1.0F, 1.0F, 0.5F);
        this.sec4.render(f5);
        GL11.glDisable(GL11.GL_BLEND);
        GL11.glEnable(GL11.GL_BLEND);
        GL11.glBlendFunc(GL11.GL_SRC_ALPHA, GL11.GL_ONE_MINUS_SRC_ALPHA);
        GL11.glColor4f(1.0F, 1.0F, 1.0F, 0.5F);
        this.leftarm1.render(f5);
        GL11.glDisable(GL11.GL_BLEND);
        GL11.glEnable(GL11.GL_BLEND);
        GL11.glBlendFunc(GL11.GL_SRC_ALPHA, GL11.GL_ONE_MINUS_SRC_ALPHA);
        GL11.glColor4f(1.0F, 1.0F, 1.0F, 0.5F);
        this.f4th1.render(f5);
        GL11.glDisable(GL11.GL_BLEND);
        GL11.glEnable(GL11.GL_BLEND);
        GL11.glBlendFunc(GL11.GL_SRC_ALPHA, GL11.GL_ONE_MINUS_SRC_ALPHA);
        GL11.glColor4f(1.0F, 1.0F, 1.0F, 0.5F);
        this.f4th3.render(f5);
        GL11.glDisable(GL11.GL_BLEND);
        GL11.glEnable(GL11.GL_BLEND);
        GL11.glBlendFunc(GL11.GL_SRC_ALPHA, GL11.GL_ONE_MINUS_SRC_ALPHA);
        GL11.glColor4f(1.0F, 1.0F, 1.0F, 0.5F);
        this.HEAD.render(f5);
        GL11.glDisable(GL11.GL_BLEND);
        GL11.glEnable(GL11.GL_BLEND);
        GL11.glBlendFunc(GL11.GL_SRC_ALPHA, GL11.GL_ONE_MINUS_SRC_ALPHA);
        GL11.glColor4f(1.0F, 1.0F, 1.0F, 0.5F);
        this.sec2.render(f5);
        GL11.glDisable(GL11.GL_BLEND);
        GL11.glEnable(GL11.GL_BLEND);
        GL11.glBlendFunc(GL11.GL_SRC_ALPHA, GL11.GL_ONE_MINUS_SRC_ALPHA);
        GL11.glColor4f(1.0F, 1.0F, 1.0F, 0.5F);
        this.sec3.render(f5);
        GL11.glDisable(GL11.GL_BLEND);
        GL11.glEnable(GL11.GL_BLEND);
        GL11.glBlendFunc(GL11.GL_SRC_ALPHA, GL11.GL_ONE_MINUS_SRC_ALPHA);
        GL11.glColor4f(1.0F, 1.0F, 1.0F, 0.5F);
        this.rightarm1.render(f5);
        GL11.glDisable(GL11.GL_BLEND);
        GL11.glEnable(GL11.GL_BLEND);
        GL11.glBlendFunc(GL11.GL_SRC_ALPHA, GL11.GL_ONE_MINUS_SRC_ALPHA);
        GL11.glColor4f(1.0F, 1.0F, 1.0F, 0.5F);
        this.ribcage2.render(f5);
        GL11.glDisable(GL11.GL_BLEND);
        GL11.glEnable(GL11.GL_BLEND);
        GL11.glBlendFunc(GL11.GL_SRC_ALPHA, GL11.GL_ONE_MINUS_SRC_ALPHA);
        GL11.glColor4f(1.0F, 1.0F, 1.0F, 0.5F);
        this.sec5.render(f5);
        GL11.glDisable(GL11.GL_BLEND);
    }
    
    private void animate(IAnimatedEntity entity, float f, float f1, float f2, float f3, float f4, float f5) {
    	animator.update(entity);
		setAngles();
		
		this.HEAD.rotateAngleY = f3 / (180F / (float)Math.PI);
        this.HEAD.rotateAngleX = f4 / (180F / (float)Math.PI);    
		
		animator.setAnim(1);
		animator.startPhase(10);
		animator.rotate(rightarm1, 1F, 0F, 0.5F);
		animator.rotate(rightarm2, -1F, 0F, 0F);
		animator.rotate(leftarm1, 0F, 0F, -0.5F);
		animator.endPhase();
		animator.startPhase(10);
		animator.rotate(rightarm1, -1F, -0.7F, 0.5F);
		animator.rotate(rightarm2, 0.5F, 0F, 0F);
		animator.rotate(leftarm1, 0F, 0F, 0F);
		animator.endPhase();;
        animator.setStationaryPhase(25);
        
        animator.setAnim(2);
		animator.startPhase(10);
		animator.rotate(rightarm1, -1.8F, 0F, 0.2F);
		animator.rotate(rightarm2, -0.7F, 0F, 0F);
		animator.rotate(leftarm1, -1.8F, 0F, -0.2F);
		animator.rotate(lefttarm2, -0.7F, 0F, 0F);
		animator.endPhase();
		animator.startPhase(10);
		animator.rotate(rightarm1, 1.1F, 0F, -0.5F);
		animator.rotate(leftarm1, 1.1F, 0F, 0.5F);
		animator.endPhase();
		 animator.setStationaryPhase(25);
		 
		 animator.setAnim(3);
			animator.startPhase(10);
			animator.rotate(rightarm1, -0.8F, 1.5F, 1F);
			animator.rotate(rightarm2, -0.7F, 0F, 0F);
			animator.endPhase();
			animator.startPhase(10);
			animator.rotate(rightarm1, -2F, -0.7F, 1F);
			animator.endPhase();
			 animator.setStationaryPhase(25);
			 
			 animator.setAnim(4);
				animator.startPhase(10);
				animator.rotate(rightarm1, 1F, 0F, 0F);
				animator.rotate(rightarm2, -0.5F, 0F, 0F);
				animator.endPhase();
				animator.startPhase(10);
				animator.rotate(rightarm1, -1F, 0F, 0F);
				animator.rotate(rightarm2, 0.5F, 0F, 0F);
				animator.rotate(righthand, 0.3F, 0F, 0F);
				animator.endPhase();
				 animator.setStationaryPhase(25);
				 
				 animator.setAnim(5);
				 animator.startPhase(10);
					animator.rotate(rightarm1, 1F, 0F, 0F);
					animator.rotate(rightarm2, -0.5F, 0F, 0F);
					animator.rotate(leftarm1, 0F, 0F, -0.5F);
					animator.endPhase();
					animator.startPhase(7);
					animator.rotate(rightarm1, -2F, -0.7F, 1F);
					animator.endPhase();
					animator.startPhase(10);
					animator.rotate(rightarm1, 2F, -0.7F, 0F);
					animator.endPhase();
					 animator.setStationaryPhase(25);
					 
					 animator.setAnim(6);
					 animator.startPhase(10);
						animator.rotate(leftarm1, -0.4F, 0.3F, 1F);
						animator.rotate(lefthand, 0.3F, 0F, 0F);
						animator.rotate(rightarm1, 0.5F, 0F, -0.5F);
						animator.endPhase();
						 animator.setStationaryPhase(25);

        
    }

    private void setAngles() {
		this.setRotateAngle(f4th, 0.0F, -0.7853981633974483F, 0.0F);
		this.setRotateAngle(righthand, -0.6981317007977318F, 0.0F, 0.0F);
		this.setRotateAngle(hair, -0.5410520681182421F, 0.0F, 0.0F);
        this.setRotateAngle(leftarm1, 0.0F, 0.0F, -0.4363323129985824F);
        this.setRotateAngle(f4th1, 0.3141592653589793F, -0.7853981633974483F, -0.22689280275926282F);
        this.setRotateAngle(lefttarm2, -0.7853981633974483F, 0.0F, 0.0F);
        this.setRotateAngle(lefthand, -0.6981317007977318F, 0.0F, 0.0F);
        this.setRotateAngle(f4th3, 0.3490658503988659F, 0.0F, 0.0F);
        this.setRotateAngle(head4th, -0.12217304763960307F, 0.0F, 0.0F);
        this.setRotateAngle(sec2, 0.0F, 0.7853981633974483F, 0.0F);
        this.setRotateAngle(rightarm1, 0.0F, 0.0F, 0.4363323129985824F);
        this.setRotateAngle(rightarm2, -0.7853981633974483F, 0.0F, 0.0F);
        this.setRotateAngle(ribcage2, 0.0F, 0.7853981633974483F, 0.0F);
        
		
	}

	/**
     * This is a helper function from Tabula to set the rotation of model parts
     */
    public void setRotateAngle(ModelRenderer modelRenderer, float x, float y, float z) {
        modelRenderer.rotateAngleX = x;
        modelRenderer.rotateAngleY = y;
        modelRenderer.rotateAngleZ = z;
    }
}
