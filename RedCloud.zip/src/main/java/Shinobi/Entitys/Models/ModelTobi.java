package Shinobi.Entitys.Models;

import net.minecraft.client.model.ModelBase;
import net.minecraft.client.model.ModelRenderer;
import net.minecraft.entity.Entity;
import net.minecraft.util.MathHelper;
import thehippomasterAPI.AnimationAPI.IAnimatedEntity;
import thehippomasterAPI.AnimationAPI.client.Animator;

/**
 * ModelBiped - Either Mojang or a mod author
 * Created using Tabula 4.1.1
 */
public class ModelTobi extends ModelBase {
    public ModelRenderer rightarm;
    public ModelRenderer leftleg;
    public ModelRenderer head;
    public ModelRenderer body;
    public ModelRenderer leftarm;
    public ModelRenderer rightleg;
    public ModelRenderer aka;
    public ModelRenderer mask;
    public ModelRenderer hair;
    
	private Animator animator;
	
	public static final float PI = (float)Math.PI;
  

    public ModelTobi() {
        this.textureWidth = 64;
        this.textureHeight = 64;
        this.rightarm = new ModelRenderer(this, 40, 16);
        this.rightarm.setRotationPoint(-5.0F, 2.0F, 0.0F);
        this.rightarm.addBox(-3.0F, -2.0F, -2.0F, 4, 12, 4, 0.0F);
        this.leftleg = new ModelRenderer(this, 0, 16);
        this.leftleg.setRotationPoint(1.9F, 12.0F, 0.0F);
        this.leftleg.addBox(-2.0F, 0.0F, -2.0F, 4, 12, 4, 0.0F);
        this.mask = new ModelRenderer(this, 0, 35);
        this.mask.setRotationPoint(0.0F, 0.0F, 0.0F);
        this.mask.addBox(-4.0F, -8.4F, -4.5F, 8, 8, 1, 0.0F);
        this.hair = new ModelRenderer(this, 19, 34);
        this.hair.setRotationPoint(0.0F, 0.0F, 0.0F);
        this.hair.addBox(-4.5F, -8.7F, -3.8F, 9, 2, 8, 0.0F);
        this.leftarm = new ModelRenderer(this, 40, 16);
        this.leftarm.mirror = true;
        this.leftarm.setRotationPoint(5.0F, 2.0F, 0.0F);
        this.leftarm.addBox(-1.0F, -2.0F, -2.0F, 4, 12, 4, 0.0F);
        this.aka = new ModelRenderer(this, 0, 47);
        this.aka.setRotationPoint(0.0F, 0.1F, 0.0F);
        this.aka.addBox(-4.5F, -2.9F, -4.6F, 9, 3, 9, 0.0F);
        this.rightleg = new ModelRenderer(this, 0, 16);
        this.rightleg.mirror = true;
        this.rightleg.setRotationPoint(-1.9F, 12.0F, 0.0F);
        this.rightleg.addBox(-2.0F, 0.0F, -2.0F, 4, 12, 4, 0.0F);
        this.head = new ModelRenderer(this, 0, 0);
        this.head.setRotationPoint(0.0F, 0.0F, 0.0F);
        this.head.addBox(-4.0F, -8.0F, -4.0F, 8, 8, 8, 0.0F);
        this.body = new ModelRenderer(this, 16, 16);
        this.body.setRotationPoint(0.0F, 0.0F, 0.0F);
        this.body.addBox(-4.0F, 0.0F, -2.0F, 8, 12, 4, 0.0F);
        
        animator = new Animator(this);

        
        this.head.addChild(this.mask);
        this.head.addChild(this.hair);
        this.head.addChild(this.aka);
    }

    @Override
    public void render(Entity entity, float f, float f1, float f2, float f3, float f4, float f5) { 
        animate((IAnimatedEntity)entity, f, f1, f2, f3, f4, f5);
    	this.rightarm.render(f5);
        this.leftleg.render(f5);
        this.leftarm.render(f5);
        this.rightleg.render(f5);
        this.head.render(f5);
        this.body.render(f5);
    }
    
    private void animate(IAnimatedEntity entity, float f, float f1, float f2, float f3, float f4, float f5) {
  	  animator.update(entity);
  		setAngles();
  		this.head.rotateAngleY = f3 / (180F / (float)Math.PI);
	    this.head.rotateAngleX = f4 / (180F / (float)Math.PI);    
	    this.leftleg.rotateAngleX = MathHelper.cos(f * 1.0F) * -1.0F * f1;
	    this.rightleg.rotateAngleX = MathHelper.cos(f * 1.0F) * 1.0F * f1;
	    this.rightarm.rotateAngleX = MathHelper.cos(f * 0.6662F + (float)Math.PI) * 2.0F * f1 * 0.5F;
	    this.leftarm.rotateAngleX = MathHelper.cos(f * 0.6662F) * 2.0F * f1 * 0.5F;
	    
	    animator.setAnim(1);
        animator.startPhase(20);
        animator.rotate(rightarm, -1.8F, -0.9F, 0);
        animator.rotate(leftarm, -1.8F, 0.9F, 0);
        animator.endPhase();
  		animator.setStationaryPhase(20);
  		
    }

    private void setAngles() {
		// TODO Auto-generated method stub
		
	}

	/**
     * This is a helper function from Tabula to set the rotation of model parts
     */
    public void setRotateAngle(ModelRenderer modelRenderer, float x, float y, float z) {
        modelRenderer.rotateAngleX = x;
        modelRenderer.rotateAngleY = y;
        modelRenderer.rotateAngleZ = z;
    }
}
