package Shinobi.Entitys.Models;

import net.minecraft.client.model.ModelBase;
import net.minecraft.client.model.ModelRenderer;
import net.minecraft.entity.Entity;
import net.minecraft.util.MathHelper;
import thehippomasterAPI.AnimationAPI.IAnimatedEntity;
import thehippomasterAPI.AnimationAPI.client.Animator;

import org.lwjgl.opengl.GL11;

/**
 * ModelBiped - Either Mojang or a mod author
 * Created using Tabula 4.1.1
 */
public class ModelZetsu extends ModelBase {
    public ModelRenderer rightarm;
    public ModelRenderer leftleg;
    public ModelRenderer head;
    public ModelRenderer body;
    public ModelRenderer leftarm;
    public ModelRenderer rightleg;
    public ModelRenderer leftshell;
    public ModelRenderer rshell;
    public ModelRenderer shell;
    public ModelRenderer aka;
    public ModelRenderer aka2;
    public ModelRenderer aka3;
    
	private Animator animator;
	
	public static final float PI = (float)Math.PI;
  

    public ModelZetsu() {
        this.textureWidth = 64;
        this.textureHeight = 100;
        this.leftshell = new ModelRenderer(this, 0, 35);
        this.leftshell.setRotationPoint(0.0F, 0.0F, 0.0F);
        this.leftshell.addBox(0.0F, -13.0F, -5.0F, 5, 13, 10, 0.0F);
        this.rightleg = new ModelRenderer(this, 0, 16);
        this.rightleg.mirror = true;
        this.rightleg.setRotationPoint(-1.9F, 12.0F, 0.0F);
        this.rightleg.addBox(-2.0F, 0.0F, -2.0F, 4, 12, 4, 0.0F);
        this.body = new ModelRenderer(this, 16, 16);
        this.body.setRotationPoint(0.0F, 0.0F, 0.0F);
        this.body.addBox(-4.0F, 0.0F, -2.0F, 8, 12, 4, 0.0F);
        this.head = new ModelRenderer(this, 0, 0);
        this.head.setRotationPoint(0.0F, 0.0F, 0.0F);
        this.head.addBox(-4.0F, -8.0F, -4.0F, 8, 8, 8, 0.0F);
        this.aka2 = new ModelRenderer(this, 0, 60);
        this.aka2.setRotationPoint(0.0F, 2.2F, -5.5F);
        this.aka2.addBox(-5.5F, 0.0F, 0.0F, 11, 4, 5, 0.0F);
        this.shell = new ModelRenderer(this, 33, 35);
        this.shell.setRotationPoint(0.0F, 0.0F, 0.0F);
        this.shell.addBox(-3.5F, 0.0F, -4.0F, 7, 5, 8, 0.0F);
        this.rightarm = new ModelRenderer(this, 40, 16);
        this.rightarm.setRotationPoint(-5.0F, 2.0F, 0.0F);
        this.rightarm.addBox(-3.0F, -2.0F, -2.0F, 4, 12, 4, 0.0F);
        this.rshell = new ModelRenderer(this, 0, 35);
        this.rshell.mirror = true;
        this.rshell.setRotationPoint(0.0F, 0.0F, 0.0F);
        this.rshell.addBox(-5.0F, -13.0F, -5.0F, 5, 13, 10, 0.0F);
        this.leftleg = new ModelRenderer(this, 0, 16);
        this.leftleg.setRotationPoint(1.9F, 12.0F, 0.0F);
        this.leftleg.addBox(-2.0F, 0.0F, -2.0F, 4, 12, 4, 0.0F);
        this.leftarm = new ModelRenderer(this, 40, 16);
        this.leftarm.mirror = true;
        this.leftarm.setRotationPoint(5.0F, 2.0F, 0.0F);
        this.leftarm.addBox(-1.0F, -2.0F, -2.0F, 4, 12, 4, 0.0F);
        this.aka = new ModelRenderer(this, 0, 70);
        this.aka.setRotationPoint(0.0F, 0.0F, 0.0F);
        this.aka.addBox(-8.0F, -2.0F, -3.5F, 16, 4, 12, 0.0F);
        this.aka3 = new ModelRenderer(this, 33, 55);
        this.aka3.setRotationPoint(0.0F, -1.4F, 0.0F);
        this.aka3.addBox(-5.0F, -1.0F, 0.5F, 10, 7, 5, 0.0F);
        
        animator = new Animator(this);

        
    }

    @Override
    public void render(Entity entity, float f, float f1, float f2, float f3, float f4, float f5) { 
        animate((IAnimatedEntity)entity, f, f1, f2, f3, f4, f5);
    	this.leftshell.render(f5);
        this.rightleg.render(f5);
        this.body.render(f5);
        this.head.render(f5);
        this.aka2.render(f5);
        this.shell.render(f5);
        this.rightarm.render(f5);
        this.rshell.render(f5);
        this.leftleg.render(f5);
        this.leftarm.render(f5);
        this.aka.render(f5);
        GL11.glPushMatrix();
        GL11.glTranslatef(this.aka3.offsetX, this.aka3.offsetY, this.aka3.offsetZ);
        GL11.glTranslatef(this.aka3.rotationPointX * f5, this.aka3.rotationPointY * f5, this.aka3.rotationPointZ * f5);
        GL11.glScaled(1.1D, 1.0D, 1.0D);
        GL11.glTranslatef(-this.aka3.offsetX, -this.aka3.offsetY, -this.aka3.offsetZ);
        GL11.glTranslatef(-this.aka3.rotationPointX * f5, -this.aka3.rotationPointY * f5, -this.aka3.rotationPointZ * f5);
        this.aka3.render(f5);
        GL11.glPopMatrix();
    }
    
    private void animate(IAnimatedEntity entity, float f, float f1, float f2, float f3, float f4, float f5) {
    	animator.update(entity);
    		setAngles();
    		this.head.rotateAngleY = f3 / (180F / (float)Math.PI);
    	    this.head.rotateAngleX = f4 / (180F / (float)Math.PI);    
    	    this.leftleg.rotateAngleX = MathHelper.cos(f * 1.0F) * -1.0F * f1;
    	    this.rightleg.rotateAngleX = MathHelper.cos(f * 1.0F) * 1.0F * f1;
    	    this.rightarm.rotateAngleX = MathHelper.cos(f * 0.6662F + (float)Math.PI) * 2.0F * f1 * 0.5F;
    	    this.leftarm.rotateAngleX = MathHelper.cos(f * 0.6662F) * 2.0F * f1 * 0.5F;
    	    
    	    
    	    
    	    
    		
    		
      }

      private void setAngles() {
  		        this.setRotateAngle(aka3, -0.22689280275926282F, 0.0F, 0.0F);
  		        this.setRotateAngle(aka, 0.5410520681182421F, 0.0F, 0.0F);
  		        this.setRotateAngle(rshell, 0.0F, 0.0F, -0.12217304763960307F);
  		        this.setRotateAngle(aka2, 0.3490658503988659F, 0.0F, 0.0F);
  		        this.setRotateAngle(leftshell, 0.0F, 0.0F, 0.12217304763960307F);

  		        
  		        
  		        
  	}

    /**
     * This is a helper function from Tabula to set the rotation of model parts
     */
    public void setRotateAngle(ModelRenderer modelRenderer, float x, float y, float z) {
        modelRenderer.rotateAngleX = x;
        modelRenderer.rotateAngleY = y;
        modelRenderer.rotateAngleZ = z;
    }
}
