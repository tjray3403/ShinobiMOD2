package Shinobi.Entitys.Models;


import net.minecraft.client.model.ModelBase;
import net.minecraft.client.model.ModelRenderer;
import net.minecraft.entity.Entity;
import net.minecraft.util.MathHelper;
import thehippomasterAPI.AnimationAPI.IAnimatedEntity;
import thehippomasterAPI.AnimationAPI.client.Animator;


/**
 * Modelkakuzu - Either Mojang or a mod author
 * Created using Tabula 4.1.1
 */
public class Modelkakuzu extends ModelBase {
    public ModelRenderer rightarm;
    public ModelRenderer leftleg;
    public ModelRenderer body;
    public ModelRenderer head;
    public ModelRenderer rightleg;
    public ModelRenderer leftarm;
    public ModelRenderer right1;
    public ModelRenderer right2;
    public ModelRenderer right3;
    public ModelRenderer right4;
    public ModelRenderer rightarmChild;
    public ModelRenderer headChild;
    public ModelRenderer left1;
    public ModelRenderer left2;
    public ModelRenderer left3;
    public ModelRenderer left4;
    public ModelRenderer leftarmChild;
    
    private Animator animator;
    
    public static final float PI = (float)Math.PI;

    public Modelkakuzu() {
    	
        this.textureWidth = 64;
        this.textureHeight = 64;
        
        this.headChild = new ModelRenderer(this, 15, 35);
        this.headChild.setRotationPoint(0.0F, 0.0F, 0.0F);
        this.headChild.addBox(-5.0F, -2.0F, -5.0F, 10, 3, 10, 0.0F);
        
        this.right2 = new ModelRenderer(this, 0, 38);
        this.right2.setRotationPoint(0.0F, -10.0F, 0.0F);
        this.right2.addBox(-1.5F, 0.0F, -1.5F, 3, 10, 3, 0.0F);
        
        this.right3 = new ModelRenderer(this, 0, 38);
        this.right3.setRotationPoint(0.0F, 10.0F, 0.0F);
        this.right3.addBox(-1.5F, -10.0F, -1.5F, 3, 10, 3, 0.0F);
        
        this.head = new ModelRenderer(this, 0, 0);
        this.head.setRotationPoint(0.0F, 0.0F, 0.0F);
        this.head.addBox(-4.0F, -8.0F, -4.0F, 8, 8, 8, 0.0F);
        
        this.body = new ModelRenderer(this, 16, 16);
        this.body.setRotationPoint(0.0F, 24.0F, 0.0F);
        this.body.addBox(-4.0F, -24.0F, -2.0F, 8, 12, 4, 0.0F);
        
        this.left1 = new ModelRenderer(this, 0, 38);
        this.left1.setRotationPoint(1.0F, 8.7F, 0.0F);
        this.left1.addBox(-1.5F, -10.0F, -1.5F, 3, 10, 3, 0.0F);
        
        this.left2 = new ModelRenderer(this, 0, 38);
        this.left2.setRotationPoint(0.0F, -10.0F, 0.0F);
        this.left2.addBox(-1.5F, 0.0F, -1.5F, 3, 10, 3, 0.0F);
        
        this.rightleg = new ModelRenderer(this, 0, 16);
        this.rightleg.setRotationPoint(-2.0F, 12.0F, 0.0F);
        this.rightleg.addBox(-2.0F, 0.0F, -2.0F, 4, 12, 4, 0.0F);
        
        this.right1 = new ModelRenderer(this, 0, 38);
        this.right1.setRotationPoint(-1.0F, 8.7F, 0.0F);
        this.right1.addBox(-1.5F, -10.0F, -1.5F, 3, 10, 3, 0.0F);
        
        this.rightarm = new ModelRenderer(this, 40, 16);
        this.rightarm.setRotationPoint(-5.0F, 2.0F, 0.0F);
        this.rightarm.addBox(-3.0F, -2.0F, -2.0F, 4, 11, 4, 0.0F);
        
        this.right4 = new ModelRenderer(this, 0, 38);
        this.right4.setRotationPoint(0.0F, -10.0F, 0.0F);
        this.right4.addBox(-1.5F, 0.0F, -1.5F, 3, 10, 3, 0.0F);
        
        this.leftarmChild = new ModelRenderer(this, 0, 55);
        this.leftarmChild.setRotationPoint(0.0F, 10.3F, 0.0F);
        this.leftarmChild.addBox(-2.0F, 0.0F, -2.0F, 4, 1, 4, 0.0F);
        
        this.leftarm = new ModelRenderer(this, 40, 16);
        this.leftarm.setRotationPoint(5.0F, 2.0F, 0.0F);
        this.leftarm.addBox(-1.0F, -2.0F, -2.0F, 4, 11, 4, 0.0F);
        
        this.leftleg = new ModelRenderer(this, 35, 0);
        this.leftleg.setRotationPoint(2.0F, 12.0F, 0.0F);
        this.leftleg.addBox(-2.0F, 0.0F, -2.0F, 4, 12, 4, 0.0F);
        
        this.left3 = new ModelRenderer(this, 0, 38);
        this.left3.setRotationPoint(0.0F, 10.0F, 0.0F);
        this.left3.addBox(-1.5F, -10.0F, -1.5F, 3, 10, 3, 0.0F);
        
        this.left4 = new ModelRenderer(this, 0, 38);
        this.left4.setRotationPoint(0.0F, -10.0F, 0.0F);
        this.left4.addBox(-1.5F, 0.0F, -1.5F, 3, 10, 3, 0.0F);
        
        this.rightarmChild = new ModelRenderer(this, 0, 56);
        this.rightarmChild.setRotationPoint(0.0F, 10.3F, 0.0F);
        this.rightarmChild.addBox(-2.0F, 0.0F, -2.0F, 4, 1, 4, 0.0F);
        
        animator = new Animator(this);
        
        this.head.addChild(this.headChild);
        this.right1.addChild(this.right2);
        this.right2.addChild(this.right3);
        this.leftarm.addChild(this.left1);
        this.left1.addChild(this.left2);
        this.rightarm.addChild(this.right1);
        this.right3.addChild(this.right4);
        this.left4.addChild(this.leftarmChild);
        this.left2.addChild(this.left3);
        this.left3.addChild(this.left4);
        this.right4.addChild(this.rightarmChild);
    }
public void animate(IAnimatedEntity entity, float f, float f1, float f2, float f3, float f4, float f5) {
		animator.update(entity);
		setAngles();
		
		this.head.rotateAngleY = f3 / (180F / (float)Math.PI);
        this.head.rotateAngleX = f4 / (180F / (float)Math.PI);    
        this.leftleg.rotateAngleX = MathHelper.cos(f * 1.0F) * -1.0F * f1;
        this.rightleg.rotateAngleX = MathHelper.cos(f * 1.0F) * 1.0F * f1;
        this.rightarm.rotateAngleX = MathHelper.cos(f * 0.6662F + (float)Math.PI) * 2.0F * f1 * 0.5F;
        this.leftarm.rotateAngleX = MathHelper.cos(f * 0.6662F) * 2.0F * f1 * 0.5F;
		
		animator.setAnim(1);
	animator.startPhase(25);
		animator.rotate(rightarm, -3F, 0F, 0.3F);
		animator.rotate(right1, 4F, 0F, 0F);
		animator.rotate(right2, 4F, 0F, 0F);
		animator.rotate(right3, 4F, 0F, 0F);
		animator.rotate(right4, 3F, 0F, 0F);
		animator.rotate(leftarm, -3F, 0F, -0.3F);
		animator.rotate(left1, 4F, 0F, 0F);
		animator.rotate(left2, 4F, 0F, 0F);
		animator.rotate(left3, 4F, 0F, 0F);
		animator.rotate(left4, 3F, 0F, 0F);
	animator.endPhase();
	animator.startPhase(10);
		animator.rotate(rightarm, -2F, 0F, 0F);
		animator.rotate(leftarm, -2F, 0F, 0F);
	animator.endPhase();
	animator.setStationaryPhase(20);
	animator.resetPhase(5);
	
		animator.setAnim(2);
	animator.startPhase(15);
		animator.rotate(rightarm, -2F, 0, 1.5F);
	animator.endPhase();
	animator.setStationaryPhase(20);
	animator.resetPhase(5);
	
	animator.setAnim(3);
	animator.rotate(rightarm, -2F, 0, 1.1F);
	animator.rotate(leftarm, -2F, 0, -1.1F);
	animator.endPhase();
	animator.setStationaryPhase(100);
	animator.resetPhase(5);
//	((Math.random() * 100) <= 10)
		animator.setAnim(4);
	animator.startPhase(9);
		animator.rotate(leftarm, -2F, 0F, -0.3F);
		animator.rotate(left1, 3F, 0F, 0F);
		animator.rotate(left2, 4F, 0F, 1F);
		animator.rotate(left3, 4F, 0F, 1F);
		animator.rotate(left4, 1F, 0F, 3F);
	animator.endPhase();
	animator.setStationaryPhase(100);
	animator.resetPhase(5);
	
}

public void setAngles() {
		//reset the rotation point each render tick
		//body.rotationPointY = 24F;
	//rightarm.rotateAngleZ = 2F;
	}

    @Override
    public void render(Entity entity, float f, float f1, float f2, float f3, float f4, float f5) { 
    	animate((IAnimatedEntity)entity, f, f1, f2, f3, f4, f5);
		setRotationAngles(f, f1, f2, f3, f4, f5, entity);
    	this.head.render(f5);
        this.body.render(f5);
        this.rightleg.render(f5);
        this.rightarm.render(f5);
        this.leftarm.render(f5);
        this.leftleg.render(f5);
    }

    /**
     * This is a helper function from Tabula to set the rotation of model parts
     */
    private void setRotation(ModelRenderer model, float x, float y, float z) {
		model.rotateAngleX = x;
		model.rotateAngleY = y;
		model.rotateAngleZ = z;
	}
    
	
	
	
	
	}
