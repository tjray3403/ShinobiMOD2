package Shinobi.Entitys.Models;

import net.minecraft.client.model.ModelBase;
import net.minecraft.client.model.ModelRenderer;
import net.minecraft.entity.Entity;
import net.minecraft.util.MathHelper;
import thehippomasterAPI.AnimationAPI.IAnimatedEntity;
import thehippomasterAPI.AnimationAPI.client.Animator;


/**
 * Modellightning - Either Mojang or a mod author
 * Created using Tabula 4.1.1
 */
public class Modellightning extends ModelBase {
    public ModelRenderer head;
    public ModelRenderer rightleg;
    public ModelRenderer rightarm;
    public ModelRenderer Shape2;
    public ModelRenderer leftleg;
    public ModelRenderer Shape1;
    public ModelRenderer Shape4;
    public ModelRenderer leftarm;
    public ModelRenderer Shape3;
    public ModelRenderer body;
    public ModelRenderer nody2;
    public ModelRenderer shape14;
    public ModelRenderer shape16;
    public ModelRenderer shape18;
    public ModelRenderer shape19;
    public ModelRenderer shape20;
    public ModelRenderer shape15;
    public ModelRenderer shape12;
    public ModelRenderer shape17;
    public ModelRenderer shape13;
    
    private Animator animator;
	
	public static final float PI = (float)Math.PI;

    public Modellightning() {
    	
        this.textureWidth = 64;
        this.textureHeight = 64;
        
        this.Shape1 = new ModelRenderer(this, 0, 16);
        this.Shape1.setRotationPoint(0.0F, -8.5F, 0.0F);
        this.Shape1.addBox(-9.0F, -5.5F, -3.5F, 18, 9, 7, 0.0F);
        
        this.leftarm = new ModelRenderer(this, 40, 16);
        this.leftarm.setRotationPoint(12.0F, -11.9F, 0.0F);
        this.leftarm.addBox(-1.0F, -2.0F, -2.5F, 5, 10, 5, 0.0F);
        
        this.shape14 = new ModelRenderer(this, 0, 9);
        this.shape14.setRotationPoint(0.0F, 8.0F, 0.0F);
        this.shape14.addBox(-1.3F, 0.0F, -1.5F, 3, 9, 3, 0.0F);
        
        this.shape20 = new ModelRenderer(this, 0, 9);
        this.shape20.setRotationPoint(0.0F, 0.5F, 5.0F);
        this.shape20.addBox(-0.5F, 0.0F, 0.0F, 1, 3, 5, 0.0F);
        
        this.head = new ModelRenderer(this, 0, 39);
        this.head.setRotationPoint(0.0F, -13.0F, -1.0F);
        this.head.addBox(-4.0F, -8.0F, -4.0F, 8, 8, 1, 0.0F);
        
        this.nody2 = new ModelRenderer(this, 0, 7);
        this.nody2.setRotationPoint(0.0F, -3.6F, -1.0F);
        this.nody2.addBox(-5.5F, -1.5F, -1.5F, 11, 7, 5, 0.0F);
        
        this.Shape4 = new ModelRenderer(this, 0, 0);
        this.Shape4.setRotationPoint(11.0F, -25.3F, 0.0F);
        this.Shape4.addBox(0.0F, 0.0F, -1.9F, 7, 10, 4, 0.0F);
        
        this.shape18 = new ModelRenderer(this, 16, 5);
        this.shape18.setRotationPoint(0.0F, 0.0F, 0.0F);
        this.shape18.addBox(-2.5F, 0.0F, 2.0F, 5, 5, 3, 0.0F);
        
        this.rightarm = new ModelRenderer(this, 40, 16);
        this.rightarm.setRotationPoint(-11.0F, -11.9F, 0.0F);
        this.rightarm.addBox(-4.5F, -2.0F, -2.5F, 5, 10, 5, 0.0F);
        
        this.leftleg = new ModelRenderer(this, 0, 16);
        this.leftleg.setRotationPoint(3.0F, 6.9F, 0.0F);
        this.leftleg.addBox(-2.5F, 0.0F, -2.0F, 5, 8, 4, 0.0F);
        
        this.body = new ModelRenderer(this, 1, 15);
        this.body.setRotationPoint(0.0F, -21.0F, 0.0F);
        this.body.addBox(-11.0F, -4.9F, -4.1F, 22, 12, 9, 0.0F);
        
        this.Shape2 = new ModelRenderer(this, 0, 0);
        this.Shape2.setRotationPoint(0.0F, 1.9F, 0.0F);
        this.Shape2.addBox(-4.0F, 0.0F, -2.0F, 8, 5, 4, 0.0F);
        
        this.shape16 = new ModelRenderer(this, 0, 11);
        this.shape16.setRotationPoint(-2.0F, 8.0F, 0.0F);
        this.shape16.addBox(-1.5F, 0.0F, -1.5F, 3, 9, 3, 0.0F);
        
        this.shape13 = new ModelRenderer(this, 0, 6);
        this.shape13.setRotationPoint(-2.8F, 0.2F, 0.0F);
        this.shape13.addBox(0.0F, 0.0F, -1.0F, 3, 6, 2, 0.0F);
        
        this.shape15 = new ModelRenderer(this, 0, 8);
        this.shape15.setRotationPoint(0.0F, 8.0F, 0.0F);
        this.shape15.addBox(-1.5F, 0.0F, -1.5F, 3, 9, 3, 0.0F);
        
        this.shape12 = new ModelRenderer(this, 0, 6);
        this.shape12.setRotationPoint(7.0F, 0.2F, 0.0F);
        this.shape12.addBox(0.0F, 0.0F, -1.0F, 3, 6, 2, 0.0F);
        
        this.shape17 = new ModelRenderer(this, 6, 13);
        this.shape17.setRotationPoint(2.0F, 8.0F, 0.0F);
        this.shape17.addBox(-2.0F, 0.0F, -1.5F, 3, 9, 3, 0.0F);
        
        this.Shape3 = new ModelRenderer(this, 0, 0);
        this.Shape3.setRotationPoint(-18.0F, -25.0F, 0.0F);
        this.Shape3.addBox(0.0F, 0.0F, -1.9F, 7, 10, 4, 0.0F);
        
        this.shape19 = new ModelRenderer(this, 0, 11);
        this.shape19.setRotationPoint(0.0F, 0.9F, 5.0F);
        this.shape19.addBox(-1.5F, 0.0F, 0.0F, 3, 4, 5, 0.0F);
        
        this.rightleg = new ModelRenderer(this, 0, 16);
        this.rightleg.setRotationPoint(-3.0F, 6.9F, 0.0F);
        this.rightleg.addBox(-2.5F, 0.0F, -2.0F, 5, 8, 4, 0.0F);
        
        animator = new Animator(this);
        
        this.rightleg.addChild(this.shape14);
        this.shape19.addChild(this.shape20);
        this.Shape2.addChild(this.shape18);
        this.rightarm.addChild(this.shape16);
        this.Shape3.addChild(this.shape13);
        this.leftleg.addChild(this.shape15);
        this.Shape4.addChild(this.shape12);
        this.leftarm.addChild(this.shape17);
        this.shape18.addChild(this.shape19);
    }

    @Override
    public void render(Entity entity, float f, float f1, float f2, float f3, float f4, float f5) { 
    	animate((IAnimatedEntity)entity, f, f1, f2, f3, f4, f5);
    	setRotationAngles(f, f1, f2, f3, f4, f5, entity);
    	this.Shape1.render(f5);
        this.leftarm.render(f5);
        this.head.render(f5);
        this.nody2.render(f5);
        this.Shape4.render(f5);
        this.rightarm.render(f5);
        this.leftleg.render(f5);
        this.body.render(f5);
        this.Shape2.render(f5);
        this.Shape3.render(f5);
        this.rightleg.render(f5);
    }

    /**
     * This is a helper function from Tabula to set the rotation of model parts
     */
    public void setRotateAngle(ModelRenderer modelRenderer, float x, float y, float z) {
        modelRenderer.rotateAngleX = x;
        modelRenderer.rotateAngleY = y;
        modelRenderer.rotateAngleZ = z;
    }
    
    public void animate(IAnimatedEntity entity, float f, float f1, float f2, float f3, float f4, float f5) {
		animator.update(entity);
		setAngles();
		
			this.leftleg.rotateAngleX = MathHelper.cos(f * 1.0F) * -1.0F * f1;
		    this.rightleg.rotateAngleX = MathHelper.cos(f * 1.0F) * 1.0F * f1;
		    this.rightarm.rotateAngleX = MathHelper.cos(f * 0.6662F + (float)Math.PI) * 2.0F * f1 * 0.5F;
		    this.leftarm.rotateAngleX = MathHelper.cos(f * 0.6662F) * 2.0F * f1 * 0.5F;
		
		animator.setAnim(4);
		animator.startPhase(4);
			animator.rotate(head, .1F, 0F, 0F);
			

		animator.endPhase();
  }
  
  public void setAngles() {
		//reset the rotation point each render tick
		
	}
  
}
