package Shinobi.Entitys.Models;

import net.minecraft.client.model.ModelBase;
import net.minecraft.client.model.ModelRenderer;
import net.minecraft.entity.Entity;
import net.minecraft.util.MathHelper;
import thehippomasterAPI.AnimationAPI.IAnimatedEntity;
import thehippomasterAPI.AnimationAPI.client.Animator;


/**
 * Modelwind - Either Mojang or a mod author
 * Created using Tabula 4.1.1
 */
public class Modelwind extends ModelBase {
	
    public ModelRenderer head;
    public ModelRenderer rightarm;
    public ModelRenderer Shape2;
    public ModelRenderer Shape1;
    public ModelRenderer Shape4;
    public ModelRenderer leftarm;
    public ModelRenderer Shape3;
    public ModelRenderer body;
    public ModelRenderer Shape6;
    public ModelRenderer Shape5;
    public ModelRenderer shape15;
    public ModelRenderer shape13;
    public ModelRenderer Shape2Child;
    public ModelRenderer shape14;
    public ModelRenderer Shape3Child;
    public ModelRenderer shape16;
    public ModelRenderer shape17;
   
    private Animator animator;
	
	public static final float PI = (float)Math.PI;

    public Modelwind() {
    	
        this.textureWidth = 128;
        this.textureHeight = 64;
        
        this.Shape3Child = new ModelRenderer(this, 0, 10);
        this.Shape3Child.setRotationPoint(-6.5F, 5.0F, -2.3F);
        this.Shape3Child.addBox(-2.5F, 0.0F, -2.0F, 5, 7, 5, 0.0F);
        
        this.shape13 = new ModelRenderer(this, 35, 7);
        this.shape13.setRotationPoint(0.0F, 12.0F, 2.0F);
        this.shape13.addBox(-2.0F, 0.0F, -2.0F, 4, 10, 4, 0.0F);
        
        this.Shape6 = new ModelRenderer(this, 90, 0);
        this.Shape6.setRotationPoint(7.0F, -2.0F, 11.0F);
        this.Shape6.addBox(0.0F, -20.0F, 0.0F, 1, 20, 9, 0.0F);
        this.setRotateAngle(Shape6, -0.6108652381980153F, 0.6108652381980153F, 0.2617993877991494F);
       
        this.Shape2Child = new ModelRenderer(this, 0, 16);
        this.Shape2Child.setRotationPoint(4.0F, 5.0F, -2.3F);
        this.Shape2Child.addBox(-2.5F, 0.0F, -2.0F, 5, 7, 5, 0.0F);
        
        this.Shape1 = new ModelRenderer(this, 0, 0);
        this.Shape1.setRotationPoint(0.0F, 2.0F, 18.0F);
        this.Shape1.addBox(-10.0F, 0.0F, 0.0F, 20, 9, 13, 0.0F);
        this.setRotateAngle(Shape1, -0.8203047484373349F, 0.0F, 0.0F);
        
        this.Shape4 = new ModelRenderer(this, 0, 0);
        this.Shape4.setRotationPoint(0.0F, -6.0F, 0.0F);
        this.Shape4.addBox(-12.0F, 0.0F, 0.0F, 24, 10, 7, 0.0F);
        
        this.leftarm = new ModelRenderer(this, 0, 32);
        this.leftarm.setRotationPoint(9.0F, 2.0F, 0.0F);
        this.leftarm.addBox(-1.0F, -2.0F, -2.0F, 7, 14, 8, 0.0F);
        
        this.Shape3 = new ModelRenderer(this, 0, 0);
        this.Shape3.setRotationPoint(0.0F, 12.0F, 16.0F);
        this.Shape3.addBox(-11.5F, 0.0F, -2.0F, 9, 8, 9, 0.0F);
        
        this.shape16 = new ModelRenderer(this, 0, 0);
        this.shape16.setRotationPoint(0.0F, 0.5F, 7.0F);
        this.shape16.addBox(-2.5F, 0.0F, 0.0F, 5, 4, 5, 0.0F);
        
        this.body = new ModelRenderer(this, 2, 15);
        this.body.setRotationPoint(0.0F, -3.0F, 2.0F);
        this.body.addBox(-12.0F, -3.0F, 0.0F, 24, 11, 17, 0.0F);
        this.setRotateAngle(body, -0.47123889803846897F, 0.0F, 0.0F);
        
        this.Shape2 = new ModelRenderer(this, 0, 0);
        this.Shape2.setRotationPoint(2.0F, 12.0F, 16.0F);
        this.Shape2.addBox(0.0F, 0.0F, 0.0F, 9, 8, 7, 0.0F);
        
        this.shape14 = new ModelRenderer(this, 23, 0);
        this.shape14.setRotationPoint(2.0F, 12.0F, 0.0F);
        this.shape14.addBox(-2.0F, 0.0F, 0.0F, 4, 10, 4, 0.0F);
        
        this.shape17 = new ModelRenderer(this, 0, 10);
        this.shape17.setRotationPoint(0.0F, 0.0F, 5.0F);
        this.shape17.addBox(-1.5F, 0.0F, 0.0F, 3, 4, 5, 0.0F);
        
        this.shape15 = new ModelRenderer(this, 0, 0);
        this.shape15.setRotationPoint(0.0F, 12.0F, 22.7F);
        this.shape15.addBox(-3.5F, 0.0F, 0.1F, 7, 5, 7, 0.0F);
        this.setRotateAngle(shape15, -0.06771877497737998F, 0.0F, 0.0F);
        
        this.Shape5 = new ModelRenderer(this, 90, 0);
        this.Shape5.setRotationPoint(-7.0F, -2.0F, 11.0F);
        this.Shape5.addBox(0.0F, -20.0F, 0.0F, 1, 20, 9, 0.0F);
        this.setRotateAngle(Shape5, -0.6108652381980153F, -0.4363323129985824F, -0.2617993877991494F);
        
        this.head = new ModelRenderer(this, 45, 50);
        this.head.setRotationPoint(0.0F, 0.0F, 3.0F);
        this.head.addBox(-3.0F, -5.0F, -4.0F, 6, 7, 1, 0.0F);
        
        this.rightarm = new ModelRenderer(this, 0, 32);
        this.rightarm.setRotationPoint(-12.0F, 2.0F, 0.0F);
        this.rightarm.addBox(-3.0F, -2.0F, -2.0F, 7, 14, 8, 0.0F);
        
        animator = new Animator(this);
        
        this.Shape3.addChild(this.Shape3Child);
        this.rightarm.addChild(this.shape13);
        this.Shape2.addChild(this.Shape2Child);
        this.shape15.addChild(this.shape16);
        this.leftarm.addChild(this.shape14);
        this.shape16.addChild(this.shape17);
    }

    @Override
    public void render(Entity entity, float f, float f1, float f2, float f3, float f4, float f5) { 
    	 animate((IAnimatedEntity)entity, f, f1, f2, f3, f4, f5);
    	 setRotationAngles(f, f1, f2, f3, f4, f5, entity);
    	this.Shape6.render(f5);
        this.Shape1.render(f5);
        this.Shape4.render(f5);
        this.leftarm.render(f5);
        this.Shape3.render(f5);
        this.body.render(f5);
        this.Shape2.render(f5);
        this.shape15.render(f5);
        this.Shape5.render(f5);
        this.head.render(f5);
        this.rightarm.render(f5);
    }

    /**
     * This is a helper function from Tabula to set the rotation of model parts
     */
    public void setRotateAngle(ModelRenderer modelRenderer, float x, float y, float z) {
        modelRenderer.rotateAngleX = x;
        modelRenderer.rotateAngleY = y;
        modelRenderer.rotateAngleZ = z;
    }
    
    public void animate(IAnimatedEntity entity, float f, float f1, float f2, float f3, float f4, float f5) {
		animator.update(entity);
		setAngles();
		
			this.Shape2.rotateAngleX = MathHelper.cos(f * 1.0F) * -1.0F * f1;
		    this.Shape3.rotateAngleX = MathHelper.cos(f * 1.0F) * 1.0F * f1;
		    this.rightarm.rotateAngleX = MathHelper.cos(f * 0.6662F + (float)Math.PI) * 2.0F * f1 * 0.5F;
		    this.leftarm.rotateAngleX = MathHelper.cos(f * 0.6662F) * 2.0F * f1 * 0.5F;
		
		animator.setAnim(2);
		animator.startPhase(4);
			animator.rotate(head, .1F, 0F, 0F);
			

		animator.endPhase();
  }
  
    public void setAngles() {
        this.setRotateAngle(Shape5, -0.6108652381980153F, -0.4363323129985824F, -0.2617993877991494F);
        this.setRotateAngle(shape15, -0.06771877497737998F, 0.0F, 0.0F);
        this.setRotateAngle(body, -0.47123889803846897F, 0.0F, 0.0F);
        this.setRotateAngle(Shape1, -0.8203047484373349F, 0.0F, 0.0F);
        this.setRotateAngle(Shape6, -0.6108652381980153F, 0.6108652381980153F, 0.2617993877991494F);

	}
  
  
}
