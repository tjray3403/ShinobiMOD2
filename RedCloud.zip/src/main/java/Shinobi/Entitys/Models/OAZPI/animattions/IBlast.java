package Shinobi.Entitys.Models.OAZPI.animattions;

import net.minecraft.entity.IProjectile;

public interface IBlast extends IProjectile{

}
