package Shinobi.Entitys.Models.OAZPI.models;

import net.minecraft.client.model.ModelBase;
import net.minecraft.client.model.ModelRenderer;
import net.minecraft.entity.Entity;
import org.lwjgl.opengl.GL11;

/**
 * chibaku - beee
 * Created using Tabula 4.1.1
 */
public class ModelChibakuTn extends ModelBase {
    public ModelRenderer shape1;
    public ModelRenderer shape2;
    public ModelRenderer shape19;
    public ModelRenderer shape22;
    public ModelRenderer shape3;
    public ModelRenderer shape4;
    public ModelRenderer shape5;
    public ModelRenderer shape20;
    public ModelRenderer shape18;
    public ModelRenderer shape21;
    public ModelRenderer shape23;
    public ModelRenderer shape24;
    public ModelRenderer shape25;

    public ModelChibakuTn() {
        this.textureWidth = 110;
        this.textureHeight = 110;
        this.shape22 = new ModelRenderer(this, 0, 65);
        this.shape22.setRotationPoint(0.0F, 0.0F, 0.0F);
        this.shape22.addBox(-5.0F, -5.0F, -5.0F, 10, 10, 10, 0.0F);
        this.shape20 = new ModelRenderer(this, 80, 22);
        this.shape20.setRotationPoint(0.0F, 0.0F, 0.0F);
        this.shape20.addBox(-3.5F, -6.0F, -3.5F, 7, 12, 7, 0.0F);
        this.shape25 = new ModelRenderer(this, 71, 67);
        this.shape25.setRotationPoint(0.0F, 0.0F, 0.0F);
        this.shape25.addBox(-6.0F, -3.5F, -3.5F, 12, 7, 7, 0.0F);
        this.shape5 = new ModelRenderer(this, 70, 90);
        this.shape5.setRotationPoint(0.0F, 0.0F, 0.0F);
        this.shape5.addBox(-6.0F, -3.5F, -3.5F, 12, 7, 7, 0.0F);
        this.shape19 = new ModelRenderer(this, 68, 0);
        this.shape19.setRotationPoint(0.0F, 0.0F, 0.0F);
        this.shape19.addBox(-5.0F, -5.0F, -5.0F, 10, 10, 10, 0.0F);
        this.shape24 = new ModelRenderer(this, 0, 87);
        this.shape24.setRotationPoint(0.0F, 0.0F, 0.0F);
        this.shape24.addBox(-3.5F, -3.5F, -6.0F, 7, 7, 12, 0.0F);
        this.shape1 = new ModelRenderer(this, 0, 0);
        this.shape1.setRotationPoint(0.0F, 0.0F, 0.0F);
        this.shape1.addBox(-3.5F, -3.5F, -3.5F, 7, 7, 7, 0.0F);
        this.shape3 = new ModelRenderer(this, 0, 24);
        this.shape3.setRotationPoint(0.0F, 0.0F, 0.0F);
        this.shape3.addBox(-3.5F, -6.0F, -3.5F, 7, 12, 7, 0.0F);
        this.shape21 = new ModelRenderer(this, 40, 45);
        this.shape21.setRotationPoint(0.0F, 0.0F, 0.0F);
        this.shape21.addBox(-6.0F, -3.5F, -3.5F, 12, 7, 7, 0.0F);
        this.shape2 = new ModelRenderer(this, 0, 44);
        this.shape2.setRotationPoint(0.0F, 0.0F, 0.0F);
        this.shape2.addBox(-5.0F, -5.0F, -5.0F, 10, 10, 10, 0.0F);
        this.shape18 = new ModelRenderer(this, 35, 25);
        this.shape18.setRotationPoint(0.0F, 0.0F, 0.0F);
        this.shape18.addBox(-3.5F, -3.5F, -6.0F, 7, 7, 12, 0.0F);
        this.shape23 = new ModelRenderer(this, 42, 65);
        this.shape23.setRotationPoint(0.0F, 0.0F, 0.0F);
        this.shape23.addBox(-3.5F, -6.0F, -3.5F, 7, 12, 7, 0.0F);
        this.shape4 = new ModelRenderer(this, 26, 3);
        this.shape4.setRotationPoint(0.0F, 0.0F, 0.0F);
        this.shape4.addBox(-3.5F, -3.5F, -6.0F, 7, 7, 12, 0.0F);
        this.shape19.addChild(this.shape20);
        this.shape22.addChild(this.shape25);
        this.shape2.addChild(this.shape5);
        this.shape22.addChild(this.shape24);
        this.shape2.addChild(this.shape3);
        this.shape19.addChild(this.shape21);
        this.shape19.addChild(this.shape18);
        this.shape22.addChild(this.shape23);
        this.shape2.addChild(this.shape4);
    }

    @Override
    public void render(Entity entity, float f, float f1, float f2, float f3, float f4, float f5) { 
        GL11.glPushMatrix();
        GL11.glTranslatef(this.shape22.offsetX, this.shape22.offsetY, this.shape22.offsetZ);
        GL11.glTranslatef(this.shape22.rotationPointX * f5, this.shape22.rotationPointY * f5, this.shape22.rotationPointZ * f5);
        GL11.glScaled(15.0D, 15.0D, 15.0D);
        GL11.glTranslatef(-this.shape22.offsetX, -this.shape22.offsetY, -this.shape22.offsetZ);
        GL11.glTranslatef(-this.shape22.rotationPointX * f5, -this.shape22.rotationPointY * f5, -this.shape22.rotationPointZ * f5);
        this.shape22.render(f5);
        GL11.glPopMatrix();
        GL11.glPushMatrix();
        GL11.glTranslatef(this.shape19.offsetX, this.shape19.offsetY, this.shape19.offsetZ);
        GL11.glTranslatef(this.shape19.rotationPointX * f5, this.shape19.rotationPointY * f5, this.shape19.rotationPointZ * f5);
        GL11.glScaled(9.0D, 9.0D, 9.0D);
        GL11.glTranslatef(-this.shape19.offsetX, -this.shape19.offsetY, -this.shape19.offsetZ);
        GL11.glTranslatef(-this.shape19.rotationPointX * f5, -this.shape19.rotationPointY * f5, -this.shape19.rotationPointZ * f5);
        this.shape19.render(f5);
        GL11.glPopMatrix();
        this.shape1.render(f5);
        GL11.glPushMatrix();
        GL11.glTranslatef(this.shape2.offsetX, this.shape2.offsetY, this.shape2.offsetZ);
        GL11.glTranslatef(this.shape2.rotationPointX * f5, this.shape2.rotationPointY * f5, this.shape2.rotationPointZ * f5);
        GL11.glScaled(5.0D, 5.0D, 5.0D);
        GL11.glTranslatef(-this.shape2.offsetX, -this.shape2.offsetY, -this.shape2.offsetZ);
        GL11.glTranslatef(-this.shape2.rotationPointX * f5, -this.shape2.rotationPointY * f5, -this.shape2.rotationPointZ * f5);
        this.shape2.render(f5);
        GL11.glPopMatrix();
    }

    /**
     * This is a helper function from Tabula to set the rotation of model parts
     */
    public void setRotateAngle(ModelRenderer modelRenderer, float x, float y, float z) {
        modelRenderer.rotateAngleX = x;
        modelRenderer.rotateAngleY = y;
        modelRenderer.rotateAngleZ = z;
    }
}
