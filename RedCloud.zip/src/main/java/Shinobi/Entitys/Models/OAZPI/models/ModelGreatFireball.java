package Shinobi.Entitys.Models.OAZPI.models;

import net.minecraft.client.model.ModelBase;
import net.minecraft.client.model.ModelRenderer;
import net.minecraft.entity.Entity;
import org.lwjgl.opengl.GL11;

/**
 * greatfireball - nee
 * Created using Tabula 4.1.1
 */
public class ModelGreatFireball extends ModelBase {
    public ModelRenderer shape1;
    public ModelRenderer shape2;
    public ModelRenderer shape3;
    public ModelRenderer shape4;

    public ModelGreatFireball() {
        this.textureWidth = 450;
        this.textureHeight = 450;
        this.shape1 = new ModelRenderer(this, 0, 0);
        this.shape1.setRotationPoint(0.0F, -30.0F, 0.0F);
        this.shape1.addBox(-50.0F, -50.0F, -50.0F, 100, 100, 100, 0.0F);
        this.shape4 = new ModelRenderer(this, 0, 0);
        this.shape4.setRotationPoint(0.0F, 0.0F, 0.0F);
        this.shape4.addBox(-55.0F, -45.0F, -45.0F, 110, 90, 90, 0.0F);
        this.shape2 = new ModelRenderer(this, 0, 0);
        this.shape2.setRotationPoint(0.0F, -10.0F, 0.0F);
        this.shape2.addBox(-45.0F, -45.0F, -45.0F, 90, 110, 90, 0.0F);
        this.shape3 = new ModelRenderer(this, 0, 0);
        this.shape3.setRotationPoint(0.0F, 10.0F, -1.3F);
        this.shape3.addBox(-45.0F, -45.0F, -55.0F, 90, 90, 110, 0.0F);
        this.shape3.addChild(this.shape4);
        this.shape1.addChild(this.shape2);
        this.shape2.addChild(this.shape3);
    }

    @Override
    public void render(Entity entity, float f, float f1, float f2, float f3, float f4, float f5) { 
        GL11.glEnable(GL11.GL_BLEND);
        GL11.glBlendFunc(GL11.GL_SRC_ALPHA, GL11.GL_ONE_MINUS_SRC_ALPHA);
        GL11.glColor4f(1.0F, 1.0F, 1.0F, 0.55F);
        this.shape1.render(f5);
        GL11.glDisable(GL11.GL_BLEND);
    }

    /**
     * This is a helper function from Tabula to set the rotation of model parts
     */
    public void setRotateAngle(ModelRenderer modelRenderer, float x, float y, float z) {
        modelRenderer.rotateAngleX = x;
        modelRenderer.rotateAngleY = y;
        modelRenderer.rotateAngleZ = z;
    }
}
