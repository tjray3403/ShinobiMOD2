package Shinobi.Entitys.Models.OAZPI.models;

import net.minecraft.client.model.ModelBase;
import net.minecraft.client.model.ModelRenderer;
import net.minecraft.entity.Entity;

/**
 * MagCube - bee
 * Created using Tabula 4.1.1
 */
public class ModelMagSpread extends ModelBase {
	
    public ModelRenderer shape1;
    public ModelRenderer shape5;

    public ModelMagSpread() {
    	
        this.textureWidth = 550;
        this.textureHeight = 550;
        
        this.shape1 = new ModelRenderer(this, 0, 0);
        this.shape1.setRotationPoint(0.0F, -2.0F, 0.0F);
        this.shape1.addBox(-62.5F, -100.0F, -62.5F, 125, 125, 125, 0.0F);
        
        this.shape5 = new ModelRenderer(this, 0, 255);
        this.shape5.setRotationPoint(0.0F, 0.0F, 0.0F);
        this.shape5.addBox(-37.5F, -55.0F, -37.5F, 75, 75, 75, 0.0F);
    }

    @Override
    public void render(Entity entity, float f, float f1, float f2, float f3, float f4, float f5) { 
        this.shape1.render(f5);
        this.shape5.render(f5);
    }

    /**
     * This is a helper function from Tabula to set the rotation of model parts
     */
    public void setRotateAngle(ModelRenderer modelRenderer, float x, float y, float z) {
        modelRenderer.rotateAngleX = x;
        modelRenderer.rotateAngleY = y;
        modelRenderer.rotateAngleZ = z;
    }
}
