package Shinobi.Entitys.Models.OAZPI.models;

import net.minecraft.client.model.ModelBase;
import net.minecraft.client.model.ModelRenderer;
import net.minecraft.entity.Entity;

/**
 * MagCube - bee
 * Created using Tabula 4.1.1
 */
public class ModelMagTriangle extends ModelBase {
    public ModelRenderer shape1;
    public ModelRenderer shape2;
    public ModelRenderer shape3;
    public ModelRenderer shape4;

    public ModelMagTriangle() {
        this.textureWidth = 550;
        this.textureHeight = 550;
        this.shape1 = new ModelRenderer(this, 0, 0);
        this.shape1.setRotationPoint(0.0F, -30.0F, 0.0F);
        this.shape1.addBox(-50.0F, -100.0F, -50.0F, 100, 25, 100, 0.0F);
        this.setRotateAngle(shape1, 1.5707963267948966F, 0.0F, 0.0F);
        this.shape3 = new ModelRenderer(this, 0, 0);
        this.shape3.setRotationPoint(0.0F, 0.0F, 0.0F);
        this.shape3.addBox(-25.0F, -50.0F, -25.0F, 50, 25, 50, 0.0F);
        this.shape4 = new ModelRenderer(this, 0, 0);
        this.shape4.setRotationPoint(0.0F, 0.0F, 0.0F);
        this.shape4.addBox(-12.5F, -25.0F, -12.5F, 25, 19, 25, 0.0F);
        this.shape2 = new ModelRenderer(this, 0, 0);
        this.shape2.setRotationPoint(0.0F, 0.0F, 0.0F);
        this.shape2.addBox(-37.5F, -75.0F, -37.5F, 75, 25, 75, 0.0F);
        this.shape2.addChild(this.shape3);
        this.shape3.addChild(this.shape4);
        this.shape1.addChild(this.shape2);
    }

    @Override
    public void render(Entity entity, float f, float f1, float f2, float f3, float f4, float f5) { 
        this.shape1.render(f5);
    }

    /**
     * This is a helper function from Tabula to set the rotation of model parts
     */
    public void setRotateAngle(ModelRenderer modelRenderer, float x, float y, float z) {
        modelRenderer.rotateAngleX = x;
        modelRenderer.rotateAngleY = y;
        modelRenderer.rotateAngleZ = z;
    }
}
