package Shinobi.Entitys.Models.OAZPI.models;

import net.minecraft.client.model.ModelBase;
import net.minecraft.client.model.ModelRenderer;
import net.minecraft.entity.Entity;
import net.minecraft.util.MathHelper;

/**
 * ModelBiped - Either Mojang or a mod author
 * Created using Tabula 4.1.1
 */
public class ModelPaperWings extends ModelBase {
    public ModelRenderer rwing;
    public ModelRenderer lwing;
    public ModelRenderer rwing2;
    public ModelRenderer rwing3;
    public ModelRenderer lwing2;
    public ModelRenderer lwing3;

    public ModelPaperWings() {
        this.textureWidth = 75;
        this.textureHeight = 64;
        this.lwing3 = new ModelRenderer(this, 30, 35);
        this.lwing3.setRotationPoint(15.0F, 0.0F, -0.5F);
        this.lwing3.addBox(0.0F, -5.5F, -1.0F, 12, 11, 2, 0.0F);
        this.setRotateAngle(lwing3, 0.2617993877991494F, 0.4363323129985824F, 0.0F);
        this.lwing = new ModelRenderer(this, 0, 35);
        this.lwing.setRotationPoint(1.0F, 5.5F, 2.0F);
        this.lwing.addBox(0.0F, -4.5F, -1.5F, 12, 9, 2, 0.0F);
        this.setRotateAngle(lwing, -0.0F, -0.6981317007977318F, -0.17453292519943295F);
        this.rwing2 = new ModelRenderer(this, 0, 51);
        this.rwing2.setRotationPoint(-12.0F, 0.0F, 0.0F);
        this.rwing2.addBox(-15.0F, -5.0F, -1.5F, 15, 10, 2, 0.0F);
        this.setRotateAngle(rwing2, 0.2617993877991494F, -0.5235987755982988F, 0.0F);
        this.rwing3 = new ModelRenderer(this, 30, 35);
        this.rwing3.setRotationPoint(-15.0F, 0.0F, -0.5F);
        this.rwing3.addBox(-12.0F, -5.5F, -1.0F, 12, 11, 2, 0.0F);
        this.setRotateAngle(rwing3, 0.2617993877991494F, -0.4363323129985824F, 0.0F);
        this.rwing = new ModelRenderer(this, 0, 35);
        this.rwing.setRotationPoint(-1.0F, 5.5F, 2.0F);
        this.rwing.addBox(-12.0F, -4.5F, -1.5F, 12, 9, 2, 0.0F);
        this.setRotateAngle(rwing, 0.0F, 0.6981317007977318F, 0.17453292519943295F);
        this.lwing2 = new ModelRenderer(this, 0, 51);
        this.lwing2.setRotationPoint(12.0F, 0.0F, 0.0F);
        this.lwing2.addBox(0.0F, -5.0F, -1.5F, 15, 10, 2, 0.0F);
        this.setRotateAngle(lwing2, 0.2617993877991494F, 0.5235987755982988F, 0.0F);
        this.lwing2.addChild(this.lwing3);
        this.rwing.addChild(this.rwing2);
        this.rwing2.addChild(this.rwing3);
        this.lwing.addChild(this.lwing2);
    }

    @Override
    public void render(Entity entity, float f, float f1, float f2, float f3, float f4, float f5) { 
    	setRotationAngles(f, f1, f2, f3, f4, f5, entity);
    	this.lwing.render(f5);
        this.rwing.render(f5);
    }
    
    public void setRotationAngles(float f, float f1, float f2, float f3, float f4, float f5, Entity entity)
    {
      super.setRotationAngles(f, f1, f2, f3, f4, f5, entity);
      this.rwing.rotateAngleY = MathHelper.cos(f * 0.6662F + (float)Math.PI) * 2.0F * f1 * 0.5F;
      this.lwing.rotateAngleY = MathHelper.cos(f * 0.6662F) * 2.0F * f1 * 0.5F;
      
      }

    /**
     * This is a helper function from Tabula to set the rotation of model parts
     */
    public void setRotateAngle(ModelRenderer modelRenderer, float x, float y, float z) {
        modelRenderer.rotateAngleX = x;
        modelRenderer.rotateAngleY = y;
        modelRenderer.rotateAngleZ = z;
    }
}
