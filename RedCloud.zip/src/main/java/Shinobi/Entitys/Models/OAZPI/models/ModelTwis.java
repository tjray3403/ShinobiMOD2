package Shinobi.Entitys.Models.OAZPI.models;

import net.minecraft.client.model.ModelBase;
import net.minecraft.client.model.ModelRenderer;
import net.minecraft.entity.Entity;
import org.lwjgl.opengl.GL11;

/**
 * ModelChakram - nvb
 * Created using Tabula 4.1.1
 */
public class ModelTwis extends ModelBase {
    public ModelRenderer shape1;
    public ModelRenderer shape2;
    public ModelRenderer shape3;
    public ModelRenderer shape4;
    public ModelRenderer shape5;

    public ModelTwis() {
        this.textureWidth = 125;
        this.textureHeight = 125;
        this.shape5 = new ModelRenderer(this, 0, 0);
        this.shape5.setRotationPoint(0.0F, 15.0F, 0.0F);
        this.shape5.addBox(-15.0F, 0.0F, -15.0F, 30, 10, 30, 0.0F);
        this.shape4 = new ModelRenderer(this, 0, 0);
        this.shape4.setRotationPoint(0.0F, 5.0F, 0.0F);
        this.shape4.addBox(-15.0F, 0.0F, -15.0F, 30, 10, 30, 0.0F);
        this.shape2 = new ModelRenderer(this, 0, 0);
        this.shape2.setRotationPoint(0.0F, -15.0F, 0.0F);
        this.shape2.addBox(-15.0F, 0.0F, -15.0F, 30, 10, 30, 0.0F);
        this.shape1 = new ModelRenderer(this, 0, 0);
        this.shape1.setRotationPoint(0.0F, -25.0F, 0.0F);
        this.shape1.addBox(-15.0F, 0.0F, -15.0F, 30, 10, 30, 0.0F);
        this.shape3 = new ModelRenderer(this, 0, 0);
        this.shape3.setRotationPoint(0.0F, -5.0F, 0.0F);
        this.shape3.addBox(-15.0F, 0.0F, -15.0F, 30, 10, 30, 0.0F);
    }

    @Override
    public void render(Entity entity, float f, float f1, float f2, float f3, float f4, float f5) { 
        this.shape5.render(f5);
        GL11.glEnable(GL11.GL_BLEND);
        GL11.glBlendFunc(GL11.GL_SRC_ALPHA, GL11.GL_ONE_MINUS_SRC_ALPHA);
        GL11.glColor4f(1.0F, 1.0F, 1.0F, 0.9990000000000001F);
        this.shape4.render(f5);
        GL11.glDisable(GL11.GL_BLEND);
        this.shape2.render(f5);
        this.shape1.render(f5);
        this.shape3.render(f5);
    }

    /**
     * This is a helper function from Tabula to set the rotation of model parts
     */
    public void setRotateAngle(ModelRenderer modelRenderer, float x, float y, float z) {
        modelRenderer.rotateAngleX = x;
        modelRenderer.rotateAngleY = y;
        modelRenderer.rotateAngleZ = z;
    }
}
