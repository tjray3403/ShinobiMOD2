package Shinobi.Entitys.Models;

import net.minecraft.client.model.ModelBase;
import net.minecraft.client.model.ModelRenderer;
import net.minecraft.entity.Entity;
import net.minecraft.util.MathHelper;
import thehippomasterAPI.AnimationAPI.IAnimatedEntity;
import thehippomasterAPI.AnimationAPI.client.Animator;

public class kakuzu22 extends ModelBase
{
  //fields
    ModelRenderer head;
    ModelRenderer body;
    ModelRenderer rightarm;
    ModelRenderer leftarm;
    ModelRenderer rightleg;
    ModelRenderer leftleg;
    ModelRenderer R1;
    ModelRenderer R2;
    ModelRenderer R3;
    ModelRenderer R4;
    ModelRenderer R5;
    ModelRenderer L1;
    ModelRenderer L2;
    ModelRenderer L3;
    ModelRenderer L4;
    ModelRenderer L5;
    ModelRenderer Shape1;
    ModelRenderer Shape2;

    
    private Animator animator;
    
    public static final float PI = (float)Math.PI;
  
  public kakuzu22()
  {
    textureWidth = 64;
    textureHeight = 64;
    
      head = new ModelRenderer(this, 0, 0);
      head.addBox(-4F, -8F, -4F, 8, 8, 8);
      head.setRotationPoint(0F, 0F, 0F);
      head.setTextureSize(64, 64);
      head.mirror = true;
      setRotation(head, 0F, 0F, 0F);
      body = new ModelRenderer(this, 16, 16);
      body.addBox(-4F, -24F, -2F, 8, 12, 4);
      body.setRotationPoint(0F, 0F, 0F);
      body.setTextureSize(64, 64);
      body.mirror = true;
      setRotation(body, 0F, 0F, 0F);
      rightarm = new ModelRenderer(this, 40, 16);
      rightarm.addBox(-3F, -2F, -2F, 4, 11, 4);
      rightarm.setRotationPoint(-5F, 2F, 0F);
      rightarm.setTextureSize(64, 64);
      rightarm.mirror = true;
      setRotation(rightarm, 0F, 0F, 0F);
      leftarm = new ModelRenderer(this, 40, 16);
      leftarm.addBox(-1F, -2F, -2F, 4, 11, 4);
      leftarm.setRotationPoint(5F, 2F, 0F);
      leftarm.setTextureSize(64, 64);
      leftarm.mirror = true;
      setRotation(leftarm, 0F, 0F, 0F);
      rightleg = new ModelRenderer(this, 0, 16);
      rightleg.addBox(-2F, 0F, -2F, 4, 12, 4);
      rightleg.setRotationPoint(-2F, 12F, 0F);
      rightleg.setTextureSize(64, 64);
      rightleg.mirror = true;
      setRotation(rightleg, 0F, 0F, 0F);
      leftleg = new ModelRenderer(this, 35, 0);
      leftleg.addBox(-2F, 0F, -2F, 4, 12, 4);
      leftleg.setRotationPoint(2F, 12F, 0F);
      leftleg.setTextureSize(64, 64);
      leftleg.mirror = true;
      setRotation(leftleg, 0F, 0F, 0F);
      R1 = new ModelRenderer(this, 0, 38);
      R1.addBox(-1.5F, 0F, -1.5F, 3, 10, 3);
      R1.setRotationPoint(-6F, 1F, 0F);
      R1.setTextureSize(64, 64);
      R1.mirror = true;
      setRotation(R1, 0F, 0F, 0F);
      R2 = new ModelRenderer(this, 0, 38);
      R2.addBox(-1.5F, 0F, -1.5F, 3, 10, 3);
      R2.setRotationPoint(-6F, 1F, 0F);
      R2.setTextureSize(64, 64);
      R2.mirror = true;
      setRotation(R2, 0F, 0F, 0F);
      R3 = new ModelRenderer(this, 0, 38);
      R3.addBox(-1.5F, 0F, -1.5F, 3, 10, 3);
      R3.setRotationPoint(-6F, 1F, 0F);
      R3.setTextureSize(64, 64);
      R3.mirror = true;
      setRotation(R3, 0F, 0F, 0F);
      R4 = new ModelRenderer(this, 0, 38);
      R4.addBox(-1.5F, 0F, -1.5F, 3, 10, 3);
      R4.setRotationPoint(-6F, 1F, 0F);
      R4.setTextureSize(64, 64);
      R4.mirror = true;
      setRotation(R4, 0F, 0F, 0F);
      R5 = new ModelRenderer(this, 0, 38);
      R5.addBox(-1.5F, 0F, -1.5F, 3, 10, 3);
      R5.setRotationPoint(-6F, 1F, 0F);
      R5.setTextureSize(64, 64);
      R5.mirror = true;
      setRotation(R5, 0F, 0F, 0F);
      L1 = new ModelRenderer(this, 0, 38);
      L1.addBox(-1.5F, 0F, -1.5F, 3, 10, 3);
      L1.setRotationPoint(11F, 3F, 0F);
      L1.setTextureSize(64, 64);
      L1.mirror = true;
      setRotation(L1, 0F, 0F, 0F);
      L2 = new ModelRenderer(this, 0, 38);
      L2.addBox(-1.5F, 0F, -1.5F, 3, 10, 3);
      L2.setRotationPoint(6F, 1F, 0F);
      L2.setTextureSize(64, 64);
      L2.mirror = true;
      setRotation(L2, 0F, 0F, 0F);
      L3 = new ModelRenderer(this, 0, 38);
      L3.addBox(-1.5F, 0F, -1.5F, 3, 10, 3);
      L3.setRotationPoint(6F, 1F, 0F);
      L3.setTextureSize(64, 64);
      L3.mirror = true;
      setRotation(L3, 0F, 0F, 0F);
      L4 = new ModelRenderer(this, 0, 38);
      L4.addBox(-1.5F, 0F, -1.5F, 3, 10, 3);
      L4.setRotationPoint(6F, 1F, 0F);
      L4.setTextureSize(64, 64);
      L4.mirror = true;
      setRotation(L4, 0F, 0F, 0F);
      L5 = new ModelRenderer(this, 0, 38);
      L5.addBox(-1.5F, 0F, -1.5F, 3, 10, 3);
      L5.setRotationPoint(6F, 1F, 0F);
      L5.setTextureSize(64, 64);
      L5.mirror = true;
      setRotation(L5, 0F, 0F, 0F);
      Shape1 = new ModelRenderer(this, 0, 56);
      Shape1.addBox(-2F, 0F, -2F, 4, 1, 4);
      Shape1.setRotationPoint(-6F, 11F, 0F);
      Shape1.setTextureSize(64, 64);
      Shape1.mirror = true;
      setRotation(Shape1, 0F, 0F, 0F);
      Shape2 = new ModelRenderer(this, 0, 55);
      Shape2.addBox(-2F, 0F, -2F, 4, 1, 4);
      Shape2.setRotationPoint(6F, 11F, 0F);
      Shape2.setTextureSize(64, 64);
      Shape2.mirror = true;
      setRotation(Shape2, 0F, 0F, 0F);
      
      
      animator = new Animator(this);
      
      convertToChild(rightarm, Shape1);
      convertToChild(rightarm, R1);
      convertToChild(rightarm, R2);
      convertToChild(rightarm, R3);
      convertToChild(rightarm, R4);
      convertToChild(rightarm, R5);
      convertToChild(leftarm, Shape2);
      convertToChild(leftarm, L1);
      convertToChild(leftarm, L1);
      convertToChild(leftarm, L2);
      convertToChild(leftarm, L3);
      convertToChild(leftarm, L4);
      convertToChild(leftarm, L5);

      
      
  }
  
  protected void convertToChild(ModelRenderer parParent, ModelRenderer parChild)
	{
	   // move child rotation point to be relative to parent
	   parChild.rotationPointX -= parParent.rotationPointX;
	   parChild.rotationPointY -= parParent.rotationPointY;
	   parChild.rotationPointZ -= parParent.rotationPointZ;
	   // make rotations relative to parent
	   parChild.rotateAngleX -= parParent.rotateAngleX;
	   parChild.rotateAngleY -= parParent.rotateAngleY;
	   parChild.rotateAngleZ -= parParent.rotateAngleZ;
	   // create relationship
	   parParent.addChild(parChild);
	}

  
  public void animate(IAnimatedEntity entity, float f, float f1, float f2, float f3, float f4, float f5) {
		animator.update(entity);
		setAngles();
		
		animator.setAnim(1);
		animator.startPhase(40);
			animator.rotate(rightarm, -PI / 2F, 0F, 0F);
			animator.rotate(leftarm, -PI / 2F, 0F, 0F);
			animator.rotate(R1, 0F, 0F, -11F);
			animator.rotate(L1, 0F, 0F, -11F);
			animator.rotate(R2, 0F, 0F, -22F);
			animator.rotate(L2, 0F, 0F, -22F);
			animator.rotate(R3, 0F, 0F, -33F);
			animator.rotate(L3, 0F, 0F, -33F);
			animator.rotate(R4, 0F, 0F, -44F);
			animator.rotate(L4, 0F, 0F, -44F);
			animator.rotate(R5, 0F, 0F, -55F);
			animator.rotate(L5, 0F, 0F, -55F);
			animator.rotate(Shape1, 0F, 0F, -55F);
			animator.rotate(Shape2, 0F, 0F, -55F);
			animator.endPhase();
			
		animator.startPhase(40);
		animator.rotate(rightarm, -PI / 2F, PI / 2F, 0F);
		animator.rotate(leftarm, PI / 2F, -PI / 2F, 0F);
		animator.rotate(R1, -PI / 4F, PI / 4F, 0F);
		animator.rotate(L1, PI / 4F, -PI / 4F, 0F);
		animator.rotate(R2, -PI / 2F, PI / 2F, 10F);
		animator.rotate(L2, PI / 2F, -PI / 2F, 10F);
		animator.rotate(R3, -PI / 12F, PI / 2F, 0F);
		animator.rotate(L3, PI / 12F, -PI / 2F, 0F);
		animator.rotate(R4, -PI / 2F, PI / 22F, 0F);
		animator.rotate(L4, PI / 2F, -PI / 22F, 0F);
		animator.rotate(rightarm, 2F, 2F, 2F);
		animator.rotate(leftarm, 2F, 2F, 2F);
			animator.endPhase();
			
			animator.startPhase(40);
			animator.rotate(rightarm, -PI / 2F, 2F, 0F);
			animator.rotate(leftarm, PI / 2F, 2F, 0F);
			animator.rotate(R1, -PI / 4F, 4F, 0F);
			animator.rotate(L1, PI / 4F, 4F, 0F);
			animator.rotate(R2, -PI / 2F, 2F, 10F);
			animator.rotate(L2, PI / 2F, 2F, 10F);
			animator.rotate(R3, -PI / 12F, 2F, 0F);
			animator.rotate(L3, PI / 12F, 2F, 0F);
			animator.rotate(R4, -PI / 2F, 22F, 0F);
			animator.rotate(L4, PI / 2F, 22F, 0F);
			animator.rotate(rightarm, 2F, 2F, 2F);
			animator.rotate(leftarm, 2F, 2F, 2F);
				animator.endPhase();
			
		animator.setStationaryPhase(20);
			animator.resetPhase(10);
			
			animator.setAnim(2);
			animator.startPhase(20);
				animator.rotate(rightarm, -PI / 2F, PI / 2F, 0F);
				animator.rotate(leftarm, PI / 2F, -PI / 2F, 0F);
				animator.rotate(R1, -PI / 4F, PI / 4F, 0F);
				animator.rotate(L1, PI / 4F, -PI / 4F, 0F);
				animator.rotate(R2, -PI / 2F, PI / 2F, 10F);
				animator.rotate(L2, PI / 2F, -PI / 2F, 10F);
				animator.rotate(R3, -PI / 12F, PI / 2F, 0F);
				animator.rotate(L3, PI / 12F, -PI / 2F, 0F);
				animator.rotate(R4, -PI / 2F, PI / 22F, 0F);
				animator.rotate(L4, PI / 2F, -PI / 22F, 0F);
				animator.rotate(rightarm, 2F, 2F, 2F);
				animator.rotate(leftarm, 2F, 2F, 2F);
				
				animator.endPhase();
			animator.setStationaryPhase(10);
				animator.resetPhase(10);
			
	}
  
  private void setAngles() {
	  body.rotationPointY = 24F;
	
}

public void render(Entity entity, float f, float f1, float f2, float f3, float f4, float f5)
  {
    super.render(entity, f, f1, f2, f3, f4, f5);
    animate((IAnimatedEntity)entity, f, f1, f2, f3, f4, f5);
    setRotationAngles(f, f1, f2, f3, f4, f5, entity);
    head.render(f5);
    body.render(f5);
    rightarm.render(f5);
    leftarm.render(f5);
    rightleg.render(f5);
    leftleg.render(f5);
    
  }
  
  private void setRotation(ModelRenderer model, float x, float y, float z)
  {
    model.rotateAngleX = x;
    model.rotateAngleY = y;
    model.rotateAngleZ = z;
  }
  
  public void setRotationAngles(float f, float f1, float f2, float f3, float f4, float f5, Entity entity)
  {
    super.setRotationAngles(f, f1, f2, f3, f4, f5, entity);
    this.head.rotateAngleY = f3 / (180F / (float)Math.PI);
    this.head.rotateAngleX = f4 / (180F / (float)Math.PI);    
    this.leftleg.rotateAngleX = MathHelper.cos(f * 1.0F) * -1.0F * f1;
    this.rightleg.rotateAngleX = MathHelper.cos(f * 1.0F) * 1.0F * f1;
    this.rightarm.rotateAngleX = MathHelper.cos(f * 0.6662F + (float)Math.PI) * 2.0F * f1 * 0.5F;
    this.leftarm.rotateAngleX = MathHelper.cos(f * 0.6662F) * 2.0F * f1 * 0.5F;
  }

}
