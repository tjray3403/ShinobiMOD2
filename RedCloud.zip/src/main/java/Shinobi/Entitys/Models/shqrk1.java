package Shinobi.Entitys.Models;

import net.minecraft.client.model.ModelBase;
import net.minecraft.client.model.ModelRenderer;
import net.minecraft.entity.Entity;
import org.lwjgl.opengl.GL11;

/**
 * shqrk - bee
 * Created using Tabula 4.1.1
 */
public class shqrk1 extends ModelBase {
    public ModelRenderer body;
    public ModelRenderer body2;
    public ModelRenderer body3;
    public ModelRenderer fin1;
    public ModelRenderer fin2;
    public ModelRenderer fin3;
    public ModelRenderer lfin;
    public ModelRenderer rfin;
    public ModelRenderer top;
    public ModelRenderer h1;
    public ModelRenderer head;
    public ModelRenderer nose;
    public ModelRenderer fin;
    
    public static final float PI = (float)Math.PI;

    public shqrk1() {
        this.textureWidth = 64;
        this.textureHeight = 64;
        this.body = new ModelRenderer(this, 16, 16);
        this.body.setRotationPoint(0.0F, 4.0F, 0.0F);
        this.body.addBox(-4.0F, 4.0F, -2.0F, 8, 8, 8, 0.0F);
        this.body.rotateAngleX = 3F;
        this.fin1 = new ModelRenderer(this, 0, 0);
        this.fin1.setRotationPoint(0.0F, 6.0F, 18.0F);
        this.fin1.addBox(-1.0F, 0.0F, 0.0F, 2, 3, 4, 0.0F);
        this.nose = new ModelRenderer(this, 34, 0);
        this.nose.setRotationPoint(0.0F, 4.5F, -12.0F);
        this.nose.addBox(-2.0F, 0.0F, -2.0F, 4, 3, 2, 0.0F);
        this.h1 = new ModelRenderer(this, 0, 35);
        this.h1.setRotationPoint(0.0F, 5.5F, -12.0F);
        this.h1.addBox(-3.0F, -1.0F, 0.0F, 6, 5, 3, 0.0F);
        this.fin2 = new ModelRenderer(this, 0, 0);
        this.fin2.setRotationPoint(0.0F, 6.0F, 21.0F);
        this.fin2.addBox(-1.5F, 0.0F, 0.0F, 3, 3, 6, 0.0F);
        this.setRotateAngle(fin2, 0.6806784082777886F, 0.0F, 0.0F);
        this.fin3 = new ModelRenderer(this, 0, 0);
        this.fin3.setRotationPoint(0.0F, 7.0F, 21.0F);
        this.fin3.addBox(-1.0F, -1.0F, 0.0F, 2, 3, 7, 0.0F);
        this.setRotateAngle(fin3, -0.7155849933176751F, 0.0F, 0.0F);
        this.body3 = new ModelRenderer(this, 0, 16);
        this.body3.setRotationPoint(0.0F, 5.0F, 13.0F);
        this.body3.addBox(-2.0F, 0.0F, -2.0F, 4, 5, 7, 0.0F);
        this.fin = new ModelRenderer(this, 0, 0);
        this.fin.setRotationPoint(0.0F, 0.0F, 0.0F);
        this.fin.addBox(-0.5F, 0.0F, 0.0F, 1, 5, 3, 0.0F);
        this.setRotateAngle(fin, -0.8203047484373349F, 0.0F, 0.0F);
        this.rfin = new ModelRenderer(this, 0, 0);
        this.rfin.setRotationPoint(-4.0F, 11.0F, 0.0F);
        this.rfin.addBox(-5.0F, -2.0F, -2.0F, 6, 2, 5, 0.0F);
        this.setRotateAngle(rfin, 0.0F, 0.0F, -0.15707963267948966F);
        this.head = new ModelRenderer(this, 0, 45);
        this.head.setRotationPoint(0.0F, 8.5F, -2.0F);
        this.head.addBox(-3.5F, -4.0F, -7.0F, 7, 7, 7, 0.0F);
        this.body2 = new ModelRenderer(this, 0, 16);
        this.body2.setRotationPoint(0.0F, 4.5F, 8.0F);
        this.body2.addBox(-3.0F, 0.0F, -2.0F, 6, 7, 5, 0.0F);
        this.top = new ModelRenderer(this, 25, 45);
        this.top.setRotationPoint(0.0F, 3.5F, -12.0F);
        this.top.addBox(-2.0F, 0.0F, 0.0F, 4, 3, 15, 0.0F);
        this.setRotateAngle(top, 0.03490658503988659F, 0.0F, 0.0F);
        this.lfin = new ModelRenderer(this, 0, 0);
        this.lfin.setRotationPoint(4.0F, 11.0F, 0.0F);
        this.lfin.addBox(-1.0F, -2.0F, -2.0F, 6, 2, 5, 0.0F);
        this.setRotateAngle(lfin, 0.0F, 0.0F, 0.15707963267948966F);
        this.body.addChild(this.fin1);
        this.body.addChild(this.nose);
        this.body.addChild(this.h1);
        this.body.addChild(this.fin2);
        this.body.addChild(this.fin3);
        this.body.addChild(this.body3);
        this.body.addChild(this.fin);
        this.body.addChild(this.rfin);
        this.body.addChild(this.head);
        this.body.addChild(this.body2);
        this.body.addChild(this.top);
        this.body.addChild(this.lfin);
    }

    @Override
    public void render(Entity entity, float f, float f1, float f2, float f3, float f4, float f5) { 
        GL11.glEnable(GL11.GL_BLEND);
        GL11.glBlendFunc(GL11.GL_SRC_ALPHA, GL11.GL_ONE_MINUS_SRC_ALPHA);
        GL11.glColor4f(1.0F, 1.0F, 1.0F, 0.7F);
        this.body.render(f5);
        GL11.glDisable(GL11.GL_BLEND);
    }

    /**
     * This is a helper function from Tabula to set the rotation of model parts
     */
    public void setRotateAngle(ModelRenderer modelRenderer, float x, float y, float z) {
        modelRenderer.rotateAngleX = x;
        modelRenderer.rotateAngleY = y;
        modelRenderer.rotateAngleZ = z;
    }
}
