package Shinobi.Entitys.Projectiles;

import java.util.List;
import java.util.Random;

import Shinobi.ShinobiDS;
import Shinobi.Entitys.Entitys.EntityFire;
import Shinobi.Entitys.Entitys.EntityItachi;
import Shinobi.Entitys.Entitys.EntityPainAsura;
import Shinobi.Entitys.Entitys.EntitySusanooItachi;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLiving;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.effect.EntityLightningBolt;
import net.minecraft.entity.projectile.EntityThrowable;
import net.minecraft.init.Blocks;
import net.minecraft.util.DamageSource;
import net.minecraft.util.MovingObjectPosition;
import net.minecraft.util.ResourceLocation;
import net.minecraft.world.World;

public class EntityAsuraHand extends EntityThrowable
{

	private static ResourceLocation texture = new ResourceLocation("ninja:textures/models/AsuraHand.png");

	public int ticksE = 0;


    public EntityAsuraHand(World w)
    {
        super(w);
        this.setSize(1, 1);
    }
    
    public ResourceLocation getTexture()
    {
        return this.texture;
    }


    public EntityAsuraHand(World ww, EntityLivingBase ent)
    {
        super(ww, ent);
    }

    public EntityAsuraHand(World www, double aa, double ss, double dd)
    {
        super(www, aa, ss, dd);
    }

    /**
     * Called when this EntityThrowable hits a block or entity.
     */
    protected void onImpact(MovingObjectPosition mop) {
    	Random rnd =  new Random();
        int i = (int) this.posX;
		int j = (int) this.posY;
		int k = (int) this.posZ;
		int rr = rnd.nextInt(5);
        this.worldObj.spawnParticle("largesmoke", i+rr, j+rr, k+rr, 0.0D, 0.0D, 0.0D);
        if (mop.entityHit != null)
        {
            

        	double offsetX = Math.cos(this.rotationYaw) * 2;
    		double offsetZ = Math.sin(this.rotationYaw) * 2;
    		List<EntityLivingBase> Entities = this.worldObj.getEntitiesWithinAABB(EntityLivingBase.class, this.boundingBox.getOffsetBoundingBox(offsetX, 0, offsetZ).expand(5, 5, 5));
    		for (Entity ent : Entities){
				if (ent == this) continue;
    			this.worldObj.createExplosion((Entity) null, i, j, k, 2F, true);
            ent.attackEntityFrom(DamageSource.generic, 15);
			//worldObj.setBlock(i, j, k, Blocks.water);
        }
        }
        
        	
        

       
        
        
    }
    
    @Override
    public void updateRiderPosition() {
    	super.updateRiderPosition();
    	if (this.riddenByEntity != null)
        {
            this.riddenByEntity.setPosition(this.posX, this.posY, this.posZ);
        }
    	
    }
    
    @Override
	public void onUpdate(){
		super.onUpdate();
		Random rnd =  new Random();
        int i = (int) this.posX;
		int j = (int) this.posY;
		int k = (int) this.posZ;
		int rr = rnd.nextInt(5);
		for (int ii = 0; ii < 20; ++ii) {
            double d0 = this.rand.nextGaussian() * 0.02D;
            double d1 = this.rand.nextGaussian() * 0.02D;
            double d2 = this.rand.nextGaussian() * 1.02D;
            //this.worldObj.spawnParticle("reddust", this.posX + (double) (this.rand.nextFloat() * this.width * 2.0F) - (double) this.width, this.posY + (double) (this.rand.nextFloat() * this.height), this.posZ + (double) (this.rand.nextFloat() * this.width * 2.0F) - (double) this.width, 10, 0, 0);           
            this.worldObj.spawnParticle("flame", this.posX + (double) (this.rand.nextFloat() * this.width * 2.0F) - (double) this.width, this.posY + (double) (this.rand.nextFloat() * this.height), this.posZ + (double) (this.rand.nextFloat() * this.width * 2.0F) - (double) this.width, 0, 0, 0);
		}
		ticksE++;
		
		double offsetX = Math.cos(this.rotationYaw) * 2;
		double offsetZ = Math.sin(this.rotationYaw) * 2;
		
		List<EntityLivingBase> Entities1 = this.worldObj.getEntitiesWithinAABB(EntityPainAsura.class, this.boundingBox.getOffsetBoundingBox(offsetX, 0, offsetZ).expand(2, 2, 2));
		for (Entity ent1 : Entities1){
			if (ent1 == this) continue;
		
		List<EntityLivingBase> Entities = this.worldObj.getEntitiesWithinAABBExcludingEntity(ent1, this.boundingBox.getOffsetBoundingBox(offsetX, 0, offsetZ).expand(2, 2, 2));
		for (Entity ent : Entities){
			if (ent == this) continue;
			
			
			
			//if(){
			 ent.attackEntityFrom(DamageSource.generic, 5);
			 if(ticksE>5)
			ent.mountEntity(this);
			//}
			
		}			
		}
		
		
		
		if(this.ticksE==150) {
			this.setDead();
		}
		
   if(this.isInWater())  {
	   this.setDead();
   }
    
    }
    
    @Override
    protected float getGravityVelocity()
    {
    	 return 0.00F;
    }
    
    
    
    
}