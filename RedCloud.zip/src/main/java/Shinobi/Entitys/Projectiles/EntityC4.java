package Shinobi.Entitys.Projectiles;

import java.util.List;
import java.util.Random;

import Shinobi.ShinobiDS;
import Shinobi.ShinobiMod;
import Shinobi.Entitys.EntityProjectile;
import Shinobi.Entitys.Entitys.EntityFire;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLiving;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.projectile.EntityArrow;
import net.minecraft.entity.projectile.EntityThrowable;
import net.minecraft.init.Blocks;
import net.minecraft.potion.PotionEffect;
import net.minecraft.util.DamageSource;
import net.minecraft.util.MovingObjectPosition;
import net.minecraft.util.ResourceLocation;
import net.minecraft.world.World;

public class EntityC4 extends EntityLiving
{


	public int ticksE = 0;

	private int cooldown;


	

    public EntityC4(World w)
    {
        super(w);
        this.setSize(10, 10);
    }
    
    


    public EntityC4(World ww, EntityLivingBase ent, float spd)
    {
        super(ww);

        ent = this;
        
    }

    
    

    /**
     * Called when this EntityThrowable hits a block or entity.
     */
   

        
		

		
		
        
    
    
    @Override
	public void onUpdate(){
		super.onUpdate();
		Random rnd =  new Random();
        int i = (int) this.posX;
		int j = (int) this.posY;
		int k = (int) this.posZ;
		int rr = rnd.nextInt(5);
		ticksE++;
		
		if(ticksE==100){
        worldObj.createExplosion(this, this.posX, this.posY, this.posZ, 30F, true);
       
		}
		if(this.ticksE==101) {
			this.setDead();
		}
   
		
		
    }
    
    
  
    
    
}