package Shinobi.Entitys.Projectiles;

import java.util.Random;

import Shinobi.ShinobiDS;
import Shinobi.Entitys.Entitys.EntityFire;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.projectile.EntityThrowable;
import net.minecraft.init.Blocks;
import net.minecraft.util.MovingObjectPosition;
import net.minecraft.util.ResourceLocation;
import net.minecraft.world.World;

public class EntityFireBlast extends EntityThrowable
{

	private static ResourceLocation texture = new ResourceLocation("ninja:textures/models/mobs/FireBlast.png");

	public int ticksE = 0;
	
    public EntityFireBlast(World w)
    {
        super(w);
        this.setSize(2, 2);
    }
    
    public ResourceLocation getTexture()
    {
        return this.texture;
    }


    public EntityFireBlast(World ww, EntityLivingBase ent)
    {
        super(ww, ent);

    }

    public EntityFireBlast(World www, double aa, double ss, double dd)
    {
        super(www, aa, ss, dd);
    }

    /**
     * Called when this EntityThrowable hits a block or entity.
     */
    protected void onImpact(MovingObjectPosition mop)
    {
    	Random rnd =  new Random();
        int i = (int) this.posX;
		int j = (int) this.posY;
		int k = (int) this.posZ;
		int rr = rnd.nextInt(5);
        if (mop.entityHit != null)
        {
            byte b0 = 20;

            if (mop.entityHit instanceof EntityFire)
            {
                b0 = 0;
            }
            
            mop.entityHit.attackEntityFrom(ShinobiDS.fireBlast(this, this.getThrower()), (float)b0);
            mop.entityHit.setFire(20);
        }

        
            this.worldObj.spawnParticle("smoke", this.posX, this.posY, this.posZ, 0.0D, 0.0D, 0.0D);
        

        if (!this.worldObj.isRemote)
        {
            this.setDead();
        }
        worldObj.setBlock(i+rr, j, k+rr, Blocks.fire);
        
    }
    
    @Override
	public void onUpdate(){
		super.onUpdate();
		Random rnd =  new Random();
        int i = (int) this.posX;
		int j = (int) this.posY;
		int k = (int) this.posZ;
		int rr = rnd.nextInt(5);
        this.worldObj.spawnParticle("smoke", i+rr, j+rr, k+rr, 0.0D, 0.0D, 0.0D);
    	ticksE++;
    	
    	if(this.ticksE==250) {
    		worldObj.setBlock(i+rr, j, k+rr, Blocks.fire);
    		this.setDead();
    	}

   if(this.isInWater())  {
	   this.setDead();
   }
    
    }
    
    @Override
    protected float getGravityVelocity()
    {
    	 return 0.00F;
    }
    
    
    
    
}