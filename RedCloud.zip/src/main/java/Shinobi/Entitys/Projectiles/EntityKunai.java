package Shinobi.Entitys.Projectiles;

import java.util.Random;

import Shinobi.ShinobiDS;
import Shinobi.ShinobiMod;
import Shinobi.Entitys.EntityProjectile;
import Shinobi.Entitys.Entitys.EntityFire;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.projectile.EntityArrow;
import net.minecraft.entity.projectile.EntityThrowable;
import net.minecraft.init.Blocks;
import net.minecraft.potion.PotionEffect;
import net.minecraft.util.MovingObjectPosition;
import net.minecraft.util.ResourceLocation;
import net.minecraft.world.World;

public class EntityKunai extends EntityArrow
{

	private static ResourceLocation texture = new ResourceLocation("ninja:textures/models/Kunai.png");

	public int ticksE = 0;


	

    public EntityKunai(World w)
    {
        super(w);
        this.setSize(2, 2);
    }
    
    public ResourceLocation getTexture()
    {
        return this.texture;
    }


    public EntityKunai(World ww, EntityLivingBase ent, float spd)
    {
        super(ww, ent, spd);
        
    }
    
    @Override
	public void onUpdate(){
		super.onUpdate();
		Random rnd =  new Random();
        int i = (int) this.posX;
		int j = (int) this.posY;
		int k = (int) this.posZ;
		int rr = rnd.nextInt(5);
		ticksE++;
		if(this.ticksE==250) {
			this.setDead();
		}
   
		
		
    }
    
    
  
    
    
}