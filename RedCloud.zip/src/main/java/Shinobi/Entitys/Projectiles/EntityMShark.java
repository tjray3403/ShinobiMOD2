package Shinobi.Entitys.Projectiles;

import java.util.List;
import java.util.Random;

import Shinobi.ShinobiDS;
import Shinobi.ShinobiMod;
import Shinobi.Entitys.EntityProjectile;
import Shinobi.Entitys.Entitys.EntityFire;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.projectile.EntityArrow;
import net.minecraft.entity.projectile.EntityThrowable;
import net.minecraft.init.Blocks;
import net.minecraft.potion.PotionEffect;
import net.minecraft.util.DamageSource;
import net.minecraft.util.MovingObjectPosition;
import net.minecraft.util.ResourceLocation;
import net.minecraft.world.World;

public class EntityMShark extends EntityThrowable
{

	private static ResourceLocation texture = new ResourceLocation("ninja:textures/models/shqrk.png");

	public int ticksE = 0;

	private int cooldown;


	

    public EntityMShark(World w)
    {
        super(w);
        this.setSize(10, 10);
    }
    
    public ResourceLocation getTexture()
    {
        return this.texture;
    }


    public EntityMShark(World ww, EntityLivingBase ent)
    {
        super(ww, ent);

    }

    
    

    /**
     * Called when this EntityThrowable hits a block or entity.
     */
    @Override
    protected void onImpact(MovingObjectPosition mop){
    	Random rnd =  new Random();
        int i = (int) this.posX;
		int j = (int) this.posY;
		int k = (int) this.posZ;
		int rr = rnd.nextInt(5);
		cooldown++;
        if (mop.entityHit != null)
        {
            byte b0 = 20;

           

            mop.entityHit.attackEntityFrom(ShinobiDS.causeNinjaDamage(this), 15);
           // ((EntityLivingBase) mop.entityHit).addPotionEffect(new PotionEffect(ShinobiMod.SPoison.id, 900, 1));
			//worldObj.setBlock(i, j, k, Blocks.water);
        }

        double offsetX = Math.cos(this.rotationYaw) * 2;
		double offsetZ = Math.sin(this.rotationYaw) * 2;;
		List<EntityLivingBase> Entities = this.worldObj.getEntitiesWithinAABB(EntityLivingBase.class, this.boundingBox.getOffsetBoundingBox(offsetX, 0, offsetZ).expand(7.0, 7, 7.0));
		for (Entity ent : Entities){
			if (ent == this) continue;
			ent.attackEntityFrom(ShinobiDS.causeNinjaDamage(this), 15);
			ent.worldObj.spawnParticle("smoke", i + rr, j + rr, k + rr, 0.0D, 0.0D, 0.0D);
			this.worldObj.spawnParticle("splash", i + rr, j + rr, k + rr, 0.0D, 0.0D, 0.0D);
		}

		
		
        
    }
    
    @Override
	public void onUpdate(){
		super.onUpdate();
		Random rnd =  new Random();
        int i = (int) this.posX;
		int j = (int) this.posY;
		int k = (int) this.posZ;
		int rr = rnd.nextInt(5);
		ticksE++;
		if(this.ticksE==250) {
			this.setDead();
		}
   
		
		
    }
    
    @Override
    protected float getGravityVelocity()
    {
    	 return 0.00F;
    }
  
    
    
}