package Shinobi.Entitys.Projectiles;

import java.util.Random;

import Shinobi.ShinobiDS;
import Shinobi.ShinobiMod;
import Shinobi.Entitys.EntityProjectile;
import Shinobi.Entitys.Entitys.EntityFire;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.projectile.EntityArrow;
import net.minecraft.entity.projectile.EntityThrowable;
import net.minecraft.init.Blocks;
import net.minecraft.potion.PotionEffect;
import net.minecraft.util.MovingObjectPosition;
import net.minecraft.util.ResourceLocation;
import net.minecraft.world.World;

public class EntityNeedles extends EntityProjectile
{

	private static ResourceLocation texture = new ResourceLocation("ninja:textures/models/needle.png");

	public int ticksE = 0;


	

    public EntityNeedles(World w)
    {
        super(w);
        this.setSize(2, 2);
    }
    
    public ResourceLocation getTexture()
    {
        return this.texture;
    }


    public EntityNeedles(World ww, EntityLivingBase ent, float spd)
    {
        super(ww, ent, spd);

    }

    
    

    /**
     * Called when this EntityThrowable hits a block or entity.
     */
    @Override
    protected void HitObject(MovingObjectPosition mop){
    	Random rnd =  new Random();
        int i = (int) this.posX;
		int j = (int) this.posY;
		int k = (int) this.posZ;
		int rr = rnd.nextInt(5);
        if (mop.entityHit != null)
        {
            byte b0 = 20;

           

            mop.entityHit.attackEntityFrom(ShinobiDS.causeNinjaDamage(this), 10);
            ((EntityLivingBase) mop.entityHit).addPotionEffect(new PotionEffect(ShinobiMod.SPoison.id, 900, 1));
			//worldObj.setBlock(i, j, k, Blocks.water);
        }

        
        	
			//this.worldObj.spawnParticle("dripWater", i + rr, j + rr, k + rr, 0.0D, 0.0D, 0.0D);
			//this.worldObj.spawnParticle("splash", i + rr, j + rr, k + rr, 0.0D, 0.0D, 0.0D);


        this.setDead();
        
        
    }
    
    @Override
	public void onUpdate(){
		super.onUpdate();
		Random rnd =  new Random();
        int i = (int) this.posX;
		int j = (int) this.posY;
		int k = (int) this.posZ;
		int rr = rnd.nextInt(5);
		ticksE++;
		if(this.ticksE==250) {
			this.setDead();
		}
   
		
		
    }
    
    
  
    
    
}