package Shinobi.Entitys.Projectiles;

import java.util.List;
import java.util.Random;

import Shinobi.ShinobiDS;
import Shinobi.ShinobiMod;
import Shinobi.Entitys.EntityProjectile;
import Shinobi.Entitys.Entitys.EntityFire;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.projectile.EntityArrow;
import net.minecraft.entity.projectile.EntityThrowable;
import net.minecraft.init.Blocks;
import net.minecraft.potion.PotionEffect;
import net.minecraft.util.DamageSource;
import net.minecraft.util.MovingObjectPosition;
import net.minecraft.util.ResourceLocation;
import net.minecraft.world.World;

public class EntityParticleX extends EntityThrowable
{

	private static ResourceLocation texture = new ResourceLocation("ninja:textures/blocks/notexture.png");

	public int ticksE = 0;

	private int cooldown;


	

    public EntityParticleX(World w)
    {
        super(w);
    }
    
    public ResourceLocation getTexture()
    {
        return this.texture;
    }


    public EntityParticleX(World ww, EntityLivingBase ent)
    {
        super(ww, ent);

    }

    
    

    /**
     * Called when this EntityThrowable hits a block or entity.
     */
    @Override
    protected void onImpact(MovingObjectPosition mop){
    	Random rnd =  new Random();
        int i = (int) this.posX;
		int j = (int) this.posY;
		int k = (int) this.posZ;
		int rr = rnd.nextInt(5);
		cooldown++;
        if (mop.entityHit != null)
        {
            byte b0 = 20;

           this.worldObj.createExplosion(this, i, j, k, 1F, true);
            mop.entityHit.attackEntityFrom(ShinobiDS.causeNinjaDamage(this), 15);
           // ((EntityLivingBase) mop.entityHit).addPotionEffect(new PotionEffect(ShinobiMod.SPoison.id, 900, 1));
			//worldObj.setBlock(i, j, k, Blocks.water);
        }

        double offsetX = Math.cos(this.rotationYaw) * 2;
		double offsetZ = Math.sin(this.rotationYaw) * 2;;
		List<EntityLivingBase> Entities = this.worldObj.getEntitiesWithinAABB(EntityLivingBase.class, this.boundingBox.getOffsetBoundingBox(offsetX, 0, offsetZ).expand(7.0, 7, 7.0));
		for (Entity ent : Entities){
			if (ent == this) continue;
			ent.attackEntityFrom(ShinobiDS.causeNinjaDamage(this), 15);
			//ent.worldObj.spawnParticle("smoke", i + rr, j + rr, k + rr, 0.0D, 0.0D, 0.0D);
			//this.worldObj.spawnParticle("enchantmenttable", i + rr, j + rr, k + rr, 0.0D, 0.0D, 0.0D);
		}

		
		
        
    }
    
    @Override
	public void onUpdate(){
		super.onUpdate();
		Random rnd =  new Random();
        int i = (int) this.posX;
		int j = (int) this.posY;
		int k = (int) this.posZ;
		int rr = rnd.nextInt(5);
		ticksE++;
		if(this.ticksE==50) {
			this.setDead();
		}
   
		this.worldObj.spawnParticle("enchantmenttable", i + rr, j + rr, k + rr, 0.0D, 0.0D, 0.0D);
		for (int ii = 0; ii < 20; ++ii) {
            double d0 = this.rand.nextGaussian() * 0.02D;
            double d1 = this.rand.nextGaussian() * 0.02D;
            double d2 = this.rand.nextGaussian() * 1.02D;
            this.worldObj.spawnParticle("reddust", this.posX + (double) (this.rand.nextFloat() * this.width * 2.0F) - (double) this.width, this.posY + (double) (this.rand.nextFloat() * this.height), this.posZ + (double) (this.rand.nextFloat() * this.width * 2.0F) - (double) this.width, d0, d1, d2); 
            this.worldObj.spawnParticle("enchantmenttable", this.posX + (double) (this.rand.nextFloat() * this.width * 2.0F) - (double) this.width, this.posY + (double) (this.rand.nextFloat() * this.height), this.posZ + (double) (this.rand.nextFloat() * this.width * 2.0F) - (double) this.width, d0, d1, d2); 

		}
    }

    @Override
    protected float getGravityVelocity()
    {
    	 return 0.03F;
    }
    
    
  
    
    
}