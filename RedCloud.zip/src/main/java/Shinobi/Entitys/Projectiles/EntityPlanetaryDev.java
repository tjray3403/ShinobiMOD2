package Shinobi.Entitys.Projectiles;

import java.util.List;
import java.util.Random;

import Shinobi.ShinobiDS;
import Shinobi.ShinobiMod;
import Shinobi.Entitys.EntityNin;
import Shinobi.Entitys.EntityPain;
import Shinobi.Entitys.EntityProjectile;
import Shinobi.Entitys.Entitys.EntityFire;
import Shinobi.Entitys.Entitys.EntityPainDeva;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityFlying;
import net.minecraft.entity.EntityLiving;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.projectile.EntityArrow;
import net.minecraft.entity.projectile.EntityThrowable;
import net.minecraft.init.Blocks;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.potion.PotionEffect;
import net.minecraft.util.DamageSource;
import net.minecraft.util.MovingObjectPosition;
import net.minecraft.util.ResourceLocation;
import net.minecraft.world.World;

public class EntityPlanetaryDev extends EntityFlying {

	private static ResourceLocation texture = new ResourceLocation("ninja:textures/models/chibakuTensei1.png");
	private static ResourceLocation texture1 = new ResourceLocation("ninja:textures/models/chibakuTensei2.png");
	private static ResourceLocation texture2 = new ResourceLocation("ninja:textures/models/chibakuTensei3.png");
	private static ResourceLocation texture3 = new ResourceLocation("ninja:textures/models/chibakuTensei.png");

	
	
	
	public int ticksE = 0;

	private int cooldown;


	

    public EntityPlanetaryDev(World w)
    {
        super(w);
        this.setSize(4, 5);
    }
    
    public ResourceLocation getTexture()
    {
    	if(ticksE>300 && ticksE<500)return this.texture1;
    	if(ticksE>500 && ticksE<700)return this.texture2;
    	if(ticksE>700 && ticksE<1200)return this.texture3;
    	else
        return this.texture;
    }
    
    public boolean canBeCollidedWith() {
		return false;
	}

    
   
    
		public boolean isEntityAlive() {
			return false;
			
			
		}
		
        public boolean canBePushed(){
			return false;
        	
        }
    
    
    @Override
    public void onUpdate(){
		super.onUpdate();
		Random rnd =  new Random();
        int i = (int) this.posX;
		int j = (int) this.posY;
		int k = (int) this.posZ;
		int rr = rnd.nextInt(5);
		ticksE++;
		if(ticksE==250) {
			this.worldObj.createExplosion(this, i,this.posY - this.height*10, k, 7F, true);
		}
		if(ticksE==1200)this.setDead();
		if(ticksE<90){
        this.motionY += (0.30000001192092896D - this.motionY) * 0.30000001192092896D;
		}
		
        
			if(this.ticksE>100) {
				this.motionX = 0;
				this.motionY = 0;
				this.motionZ = 0;
			}
		if(this.ticksE>200 && this.ticksE<210) {
				
		this.worldObj.createExplosion(this, i, this.posY - this.height*5, k, 5F, true);
		}
		if(this.ticksE>210 && this.ticksE<300) {
			
			this.worldObj.createExplosion(this, i, this.posY - this.height*5, k, 1.5F, true);
			}
		if(this.ticksE==701) {
			
			this.worldObj.createExplosion(this, i, this.posY - this.height*5, k, 10F, true);
			}
		double offsetX = Math.cos(this.rotationYaw) * 2;
		double offsetZ = Math.sin(this.rotationYaw) * 2;;
		List<EntityLivingBase> Entities1 = this.worldObj.getEntitiesWithinAABB(EntityPain.class, this.boundingBox.getOffsetBoundingBox(offsetX, 0, offsetZ).expand(20.0, 25, 20.0));
		for (Entity ent1 : Entities1){
			if (ent1 == this) continue;
		List<EntityLivingBase> Entities = this.worldObj.getEntitiesWithinAABBExcludingEntity(ent1, this.boundingBox.getOffsetBoundingBox(offsetX, 0, offsetZ).expand(20.0, 25, 20.0));
		for (Entity ent : Entities){
			if (ent == this) continue;
			if(ticksE>150){
			ent.attackEntityFrom(ShinobiDS.causeNinjaDamage(this), 3);
			ent.setPosition(i, j, k);
			}
			
			ent.worldObj.spawnParticle("smoke", i + rr, j + rr, k + rr, 0.0D, 0.0D, 0.0D);
			this.worldObj.spawnParticle("splash", i + rr, j + rr, k + rr, 0.0D, 0.0D, 0.0D);
		}
		
		if(Entities.contains(ent1)) {
			Entities.remove(ent1);
		}
	//	EntityPainDeva ee =  new EntityPainDeva(worldObj);
		//if(Entities.contains(ee)) {
		//	Entities.remove(ee);
		//}
		
		
		
   
		
		
    }
    
    
    }
    
    
    
    public void writeEntityToNBT(NBTTagCompound nbt) {
	       super.writeEntityToNBT(nbt);
	      nbt.setInteger("ticksE", ticksE);
	      
	   }

	   public void readEntityFromNBT(NBTTagCompound nbtt) {
	       super.readEntityFromNBT(nbtt);
     this.ticksE = nbtt.getInteger("ticksE");
	           
	   }
   }
    
    
