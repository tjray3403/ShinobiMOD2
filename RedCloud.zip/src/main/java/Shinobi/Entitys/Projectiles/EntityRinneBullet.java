package Shinobi.Entitys.Projectiles;

import java.util.Random;

import Shinobi.ShinobiDS;
import Shinobi.Entitys.Entitys.EntityFire;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.effect.EntityLightningBolt;
import net.minecraft.entity.projectile.EntityThrowable;
import net.minecraft.init.Blocks;
import net.minecraft.util.DamageSource;
import net.minecraft.util.MovingObjectPosition;
import net.minecraft.util.ResourceLocation;
import net.minecraft.world.World;

public class EntityRinneBullet extends EntityThrowable
{

	private static ResourceLocation texture = new ResourceLocation("ninja:textures/models/rinnebullet.png");

	public int ticksE = 0;


    public EntityRinneBullet(World w)
    {
        super(w);
        this.setSize(2, 2);
    }
    
    public ResourceLocation getTexture()
    {
        return this.texture;
    }


    public EntityRinneBullet(World ww, EntityLivingBase ent)
    {
        super(ww, ent);

    }

    public EntityRinneBullet(World www, double aa, double ss, double dd)
    {
        super(www, aa, ss, dd);
    }

    /**
     * Called when this EntityThrowable hits a block or entity.
     */
    protected void onImpact(MovingObjectPosition mop) {
    	Random rnd =  new Random();
        int i = (int) this.posX;
		int j = (int) this.posY;
		int k = (int) this.posZ;
		int rr = rnd.nextInt(5);
        this.worldObj.spawnParticle("largesmoke", i+rr, j+rr, k+rr, 0.0D, 0.0D, 0.0D);
        if (mop.entityHit != null)
        {
            byte b0 = 20;

            if (mop.entityHit instanceof EntityFire)
            {
                b0 = 0;
            }

            mop.entityHit.attackEntityFrom(DamageSource.generic, (float)b0);
            
			//worldObj.setBlock(i, j, k, Blocks.water);
        }

        
        	this.worldObj.createExplosion((Entity) null, i, j, k, 0.5F, true);
			this.worldObj.spawnParticle("enchantmenttable", i + rr, j + rr, k + rr, 0.0D, 0.0D, 0.0D);
        

        if (!this.worldObj.isRemote)
        {
            this.setDead();
        }
        
        
    }
    
    @Override
	public void onUpdate(){
		super.onUpdate();
		Random rnd =  new Random();
        int i = (int) this.posX;
		int j = (int) this.posY;
		int k = (int) this.posZ;
		int rr = rnd.nextInt(5);
		this.worldObj.spawnParticle("enchantmenttable", i + rr, j + rr, k + rr, 0.0D, 0.0D, 0.0D);
		ticksE++;
		
		if(this.ticksE==250) {
			this.setDead();
		}
		
   if(this.isInWater())  {
	   
   }
    
    }
    
    @Override
    protected float getGravityVelocity()
    {
    	 return 0.05F;
    }
    
    
    
    
}