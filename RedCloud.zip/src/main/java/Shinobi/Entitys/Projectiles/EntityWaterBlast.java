package Shinobi.Entitys.Projectiles;

import java.util.Random;

import Shinobi.ShinobiDS;
import Shinobi.Entitys.Entitys.EntityFire;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.projectile.EntityThrowable;
import net.minecraft.init.Blocks;
import net.minecraft.util.MovingObjectPosition;
import net.minecraft.util.ResourceLocation;
import net.minecraft.world.World;

public class EntityWaterBlast extends EntityThrowable
{

	private static ResourceLocation texture = new ResourceLocation("ninja:textures/models/mobs/WaterBlast.png");

	public int ticksE = 0;


    public EntityWaterBlast(World w)
    {
        super(w);
        this.setSize(2, 2);
    }
    
    public ResourceLocation getTexture()
    {
        return this.texture;
    }


    public EntityWaterBlast(World ww, EntityLivingBase ent)
    {
        super(ww, ent);

    }

    public EntityWaterBlast(World www, double aa, double ss, double dd)
    {
        super(www, aa, ss, dd);
    }

    /**
     * Called when this EntityThrowable hits a block or entity.
     */
    protected void onImpact(MovingObjectPosition mop) {
    	Random rnd =  new Random();
        int i = (int) this.posX;
		int j = (int) this.posY;
		int k = (int) this.posZ;
		int rr = rnd.nextInt(5);
        if (mop.entityHit != null)
        {
            byte b0 = 20;

            if (mop.entityHit instanceof EntityFire)
            {
                b0 = 0;
            }

            mop.entityHit.attackEntityFrom(ShinobiDS.waterBlast(this, this.getThrower()), (float)b0);
            
			//worldObj.setBlock(i, j, k, Blocks.water);
        }

        
        	
			this.worldObj.spawnParticle("dripWater", i + rr, j + rr, k + rr, 0.0D, 0.0D, 0.0D);
			this.worldObj.spawnParticle("splash", i + rr, j + rr, k + rr, 0.0D, 0.0D, 0.0D);


        if (!this.worldObj.isRemote)
        {
            this.setDead();
        }
        
        
    }
    
    @Override
	public void onUpdate(){
		super.onUpdate();
		Random rnd =  new Random();
        int i = (int) this.posX;
		int j = (int) this.posY;
		int k = (int) this.posZ;
		int rr = rnd.nextInt(5);
		this.worldObj.spawnParticle("dripWater", i + rr, j + rr, k + rr, 0.0D, 0.0D, 0.0D);
		ticksE++;
		if(this.ticksE==250) {
			this.worldObj.spawnParticle("splash", i + rr, j + rr, k + rr, 0.0D, 0.0D, 0.0D);
			this.setDead();
		}
   if(this.isBurning())  {
	   this.setFire(0);
   }
    
    }
    
    @Override
    protected float getGravityVelocity()
    {
    	 return 0.05F;
    }
    
    
    
    
}