package Shinobi.Entitys.Projectiles;

import java.util.List;
import java.util.Random;

import Shinobi.ShinobiDS;
import Shinobi.ShinobiMod;
import Shinobi.Entitys.EntityNin;
import Shinobi.Entitys.EntityPain;
import Shinobi.Entitys.EntityProjectile;
import Shinobi.Entitys.Entitys.EntityFire;
import Shinobi.Entitys.Entitys.EntityZetsu;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLiving;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.projectile.EntityArrow;
import net.minecraft.entity.projectile.EntityThrowable;
import net.minecraft.init.Blocks;
import net.minecraft.potion.PotionEffect;
import net.minecraft.util.DamageSource;
import net.minecraft.util.MovingObjectPosition;
import net.minecraft.util.ResourceLocation;
import net.minecraft.world.World;

public class EntityWoodVines extends EntityNin
{

	private static ResourceLocation texture = new ResourceLocation("ninja:textures/models/WVines.png");

	public int ticksE = 0;

	private int cooldown;


	

    public EntityWoodVines(World w)
    {
        super(w);
        this.setSize(2, 2);
    }
    
    public ResourceLocation getTexture()
    {
        return this.texture;
    }
    
    public boolean canBeCollidedWith() {
		return false;
	}

    
   
    
		public boolean isEntityAlive() {
			return false;
			
			
		}
		
        
    
    
    @Override
    public void onUpdate(){
		super.onUpdate();
		Random rnd =  new Random();
        int i = (int) this.posX;
		int j = (int) this.posY;
		int k = (int) this.posZ;
		int rr = rnd.nextInt(5);
		ticksE++;
		if(this.ticksE==100) {
			this.setDead();
		}
		
		double offsetX = Math.cos(this.rotationYaw) * 2;
		double offsetZ = Math.sin(this.rotationYaw) * 2;;
		List<EntityLivingBase> Entities1 = this.worldObj.getEntitiesWithinAABB(EntityZetsu.class, this.boundingBox.getOffsetBoundingBox(offsetX, 0, offsetZ).expand(20.0, 25, 20.0));
		for (Entity ent1 : Entities1){
			if (ent1 == this) continue;
		List<EntityLivingBase> Entities = this.worldObj.getEntitiesWithinAABBExcludingEntity(ent1, this.boundingBox.getOffsetBoundingBox(offsetX, 0, offsetZ).expand(20.0, 25, 20.0));
		for (Entity ent : Entities){
			if (ent == this) continue;
		
		ent.attackEntityFrom(DamageSource.cactus, 4);
		
    }
    
    
    }
		
    }
    
}
   
    
    
