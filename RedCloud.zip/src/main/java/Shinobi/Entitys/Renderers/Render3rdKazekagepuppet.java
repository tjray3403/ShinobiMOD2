package Shinobi.Entitys.Renderers;

import Shinobi.Entitys.Entitys.Entity3rdKazekagePuppet;
import Shinobi.Entitys.Entitys.EntityCrow;
import Shinobi.Entitys.Models.Model3rdKazePuppet;
import Shinobi.Entitys.Models.ModelCrow;
import net.minecraft.client.model.ModelBase;
import net.minecraft.client.renderer.entity.Render;
import net.minecraft.client.renderer.entity.RenderLiving;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLiving;
import net.minecraft.util.ResourceLocation;

public class Render3rdKazekagepuppet extends RenderLiving {
	
	private static final ResourceLocation texture = new ResourceLocation("ninja:textures/models/Mobs/3rdkazepuppet.png");

	protected Model3rdKazePuppet modelEntity;
	
	public Render3rdKazekagepuppet(ModelBase par1ModelBase, float par2) {
		super(par1ModelBase, par2);
		modelEntity = ((Model3rdKazePuppet) mainModel);
	}
	
	public void renderpuppet(Entity3rdKazekagePuppet entity, double x, double y, double z, float u, float v) {
		super.doRender(entity, x, y, z, u, v);
	}
	
	public void doRenderLiving(EntityLiving entityLiving, double x, double y, double z, float u, float v) {
		renderpuppet((Entity3rdKazekagePuppet)entityLiving, x, y, z, u, v);
	}
	
	public void doRenderLiving(Entity entity, double x, double y, double z, float u, float v) {
		renderpuppet((Entity3rdKazekagePuppet)entity, x, y, z, u, v);
	}

	@Override
	protected ResourceLocation getEntityTexture(Entity var1) {
		return texture;
	}

}
