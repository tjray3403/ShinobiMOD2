package Shinobi.Entitys.Renderers;

import Shinobi.Entitys.Entitys.EntityClayBird;
import Shinobi.Entitys.Models.ModelClayBird;
import net.minecraft.client.model.ModelBase;
import net.minecraft.client.renderer.entity.Render;
import net.minecraft.client.renderer.entity.RenderLiving;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLiving;
import net.minecraft.util.ResourceLocation;

public class RenderClayBird extends RenderLiving{
	
	private static final ResourceLocation texture = new ResourceLocation("ninja:textures/models/Mobs/ClayBird.png");

	protected ModelClayBird modelEntity;
	
	public RenderClayBird(ModelBase par1ModelBase, float par2) {
		super(par1ModelBase, par2);
		modelEntity = ((ModelClayBird) mainModel);
	}
	
	public void renderClayBird(EntityClayBird entity, double x, double y, double z, float u, float v) {
		super.doRender(entity, x, y, z, u, v);
	}
	
	public void doRenderLiving(EntityLiving entityLiving, double x, double y, double z, float u, float v) {
		renderClayBird((EntityClayBird)entityLiving, x, y, z, u, v);
	}
	
	public void doRenderLiving(Entity entity, double x, double y, double z, float u, float v) {
		renderClayBird((EntityClayBird)entity, x, y, z, u, v);
	}

	@Override
	protected ResourceLocation getEntityTexture(Entity var1) {
		return texture;
	}

}
