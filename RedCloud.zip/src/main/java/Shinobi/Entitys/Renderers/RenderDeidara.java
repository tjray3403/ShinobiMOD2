package Shinobi.Entitys.Renderers;

import Shinobi.Entitys.Entitys.EntityDeidara;
import Shinobi.Entitys.Models.ModelDeidara;
import net.minecraft.client.model.ModelBase;
import net.minecraft.client.renderer.entity.RenderLiving;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLiving;
import net.minecraft.util.ResourceLocation;

public class RenderDeidara extends RenderLiving{
	
	private static final ResourceLocation Mtexture = new ResourceLocation("ninja:textures/models/Mobs/Deidara.png");
	private static final ResourceLocation texture2 = new ResourceLocation("ninja:textures/models/Mobs/DeidaraBomb.png");

	
	protected ModelDeidara modelEntity1;
	
	public RenderDeidara(ModelBase par1ModelBase, float par2) {
		super(par1ModelBase, par2);
		modelEntity1 = ((ModelDeidara) mainModel);
	}
	
	

	public void renderKakuzu(EntityDeidara entity, double x, double y, double z, float u, float v) {
		super.doRender(entity, x, y, z, u, v);
	}
	
	public void doRenderLiving(EntityLiving entityLiving, double x, double y, double z, float u, float v) {
		renderKakuzu((EntityDeidara)entityLiving, x, y, z, u, v);
	}
	
	public void doRenderLiving(Entity entity, double x, double y, double z, float u, float v) {
		renderKakuzu((EntityDeidara)entity, x, y, z, u, v);
	}

	protected ResourceLocation getEntityTexture(EntityDeidara entity) {
		
		if(entity.bomb==true){
			return texture2;
		}
		else
		{
			return Mtexture;
		}
		}
	
	@Override
	protected ResourceLocation getEntityTexture(Entity p_110775_1_) {
		// TODO Auto-generated method stub
		return this.getEntityTexture((EntityDeidara)p_110775_1_);
	}

}
