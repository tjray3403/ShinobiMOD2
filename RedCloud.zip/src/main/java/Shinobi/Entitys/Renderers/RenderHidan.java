package Shinobi.Entitys.Renderers;

import Shinobi.Entitys.Entitys.EntityHidan;
import Shinobi.Entitys.Models.ModelHidan;
import net.minecraft.client.model.ModelBase;
import net.minecraft.client.renderer.entity.Render;
import net.minecraft.client.renderer.entity.RenderLiving;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLiving;
import net.minecraft.entity.passive.EntityWolf;
import net.minecraft.util.ResourceLocation;

public class RenderHidan extends RenderLiving{
	
	private static final ResourceLocation texture1 = new ResourceLocation("ninja:textures/models/Mobs/HidanTexture2.png");
	private static final ResourceLocation Curse2 = new ResourceLocation("ninja:textures/models/Mobs/HidanCurse2.png");

    private EntityHidan eH;
	protected ModelHidan modelEntity;
	public boolean i = false;
	
	public RenderHidan(ModelBase par1ModelBase, float par2) {
		super(par1ModelBase, par2);
		modelEntity = ((ModelHidan) mainModel);
	}
	
	public void renderHidan(EntityHidan entity, double x, double y, double z, float u, float v) {
		super.doRender(entity, x, y, z, u, v);
	}
	
	public void doRenderLiving(EntityLiving entityLiving, double x, double y, double z, float u, float v) {
		renderHidan((EntityHidan)entityLiving, x, y, z, u, v);
	}
	
	public void doRenderLiving(Entity entity, double x, double y, double z, float u, float v) {
		renderHidan((EntityHidan)entity, x, y, z, u, v);
	}
	
	
	protected ResourceLocation getEntityTexture(EntityHidan entity) {

		if(entity.cursed==true) {
	return Curse2;
	}
	else
	{
	return texture1;
	}
	}

	@Override
	protected ResourceLocation getEntityTexture(Entity p_110775_1_) {
		// TODO Auto-generated method stub
		return this.getEntityTexture((EntityHidan)p_110775_1_);
	}
	
	
	
	}