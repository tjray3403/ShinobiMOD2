package Shinobi.Entitys.Renderers;

import Shinobi.Entitys.Entitys.EntityItachi;
import Shinobi.Entitys.Models.ModelItachi;
import Shinobi.Entitys.Models.Modelkakuzu;
import net.minecraft.client.model.ModelBase;
import net.minecraft.client.renderer.entity.RenderLiving;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLiving;
import net.minecraft.util.ResourceLocation;

public class RenderItachi extends RenderLiving{
	
	private static final ResourceLocation Mtexture = new ResourceLocation("ninja:textures/models/Mobs/Itachitexture1.png");
	private static final ResourceLocation texture2 = new ResourceLocation("ninja:textures/models/Mobs/Itachitexture2.png");
	private static final ResourceLocation texture3 = new ResourceLocation("ninja:textures/models/Mobs/Itachitexture3.png");

	
	protected ModelItachi modelEntity;
	
	public RenderItachi(ModelBase par1ModelBase, float par2) {
		super(par1ModelBase, par2);
		modelEntity = ((ModelItachi) mainModel);
	}
	
	

	public void renderItachi(EntityItachi entity, double x, double y, double z, float u, float v) {
		super.doRender(entity, x, y, z, u, v);
	}
	
	public void doRenderLiving(EntityLiving entityLiving, double x, double y, double z, float u, float v) {
		renderItachi((EntityItachi)entityLiving, x, y, z, u, v);
	}
	
	public void doRenderLiving(Entity entity, double x, double y, double z, float u, float v) {
		renderItachi((EntityItachi)entity, x, y, z, u, v);
	}

	protected ResourceLocation getEntityTexture(EntityItachi entity) {
		if(entity.sharingan==2)return texture2;
		if(entity.sharingan==0)return texture3;
		else
			return Mtexture;
		}
		
	
	@Override
	protected ResourceLocation getEntityTexture(Entity p_110775_1_) {
		// TODO Auto-generated method stub
		return this.getEntityTexture((EntityItachi)p_110775_1_);
	}

}
