package Shinobi.Entitys.Renderers;

import Shinobi.Entitys.Entitys.EntityKakuzu;
import Shinobi.Entitys.Models.Modelkakuzu;
import net.minecraft.client.model.ModelBase;
import net.minecraft.client.renderer.entity.RenderLiving;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLiving;
import net.minecraft.util.ResourceLocation;

public class RenderKakuzu extends RenderLiving{
	
	private static final ResourceLocation Mtexture = new ResourceLocation("ninja:textures/models/Mobs/kakuzu.png");
	private static final ResourceLocation texture2 = new ResourceLocation("ninja:textures/models/Mobs/kakuzu22.png");

	
	protected Modelkakuzu modelEntity1;
	
	public RenderKakuzu(ModelBase par1ModelBase, float par2) {
		super(par1ModelBase, par2);
		modelEntity1 = ((Modelkakuzu) mainModel);
	}
	
	

	public void renderKakuzu(EntityKakuzu entity, double x, double y, double z, float u, float v) {
		super.doRender(entity, x, y, z, u, v);
	}
	
	public void doRenderLiving(EntityLiving entityLiving, double x, double y, double z, float u, float v) {
		renderKakuzu((EntityKakuzu)entityLiving, x, y, z, u, v);
	}
	
	public void doRenderLiving(Entity entity, double x, double y, double z, float u, float v) {
		renderKakuzu((EntityKakuzu)entity, x, y, z, u, v);
	}

	protected ResourceLocation getEntityTexture(EntityKakuzu entity) {
		if(entity.kakuzu==1){
			return texture2;
	}
		else
		{
			return Mtexture;
		}
		}
	
	@Override
	protected ResourceLocation getEntityTexture(Entity p_110775_1_) {
		// TODO Auto-generated method stub
		return this.getEntityTexture((EntityKakuzu)p_110775_1_);
	}

}
