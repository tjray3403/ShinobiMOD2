package Shinobi.Entitys.Renderers;

import Shinobi.Entitys.Entitys.EntityKisame;
import Shinobi.Entitys.Models.ModelKisame;
import net.minecraft.client.model.ModelBase;
import net.minecraft.client.renderer.entity.RenderLiving;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLiving;
import net.minecraft.util.ResourceLocation;

public class RenderKisame extends RenderLiving{
	
	private static final ResourceLocation Mtexture = new ResourceLocation("ninja:textures/models/Mobs/Kisametexture1.png");
	private static final ResourceLocation Mtexture2 = new ResourceLocation("ninja:textures/models/Mobs/Kisametexture2.png");
	private static final ResourceLocation Mtexture3 = new ResourceLocation("ninja:textures/models/Mobs/Kisametexture3.png");
	private static final ResourceLocation Mtexture4 = new ResourceLocation("ninja:textures/models/Mobs/Kisametexture4.png");
	

	
	protected ModelKisame modelEntity1;
	
	public RenderKisame(ModelBase par1ModelBase, float par2) {
		super(par1ModelBase, par2);
		modelEntity1 = ((ModelKisame) mainModel);
	}
	
	

	public void renderKakuzu(EntityKisame entity, double x, double y, double z, float u, float v) {
		super.doRender(entity, x, y, z, u, v);
	}
	
	public void doRenderLiving(EntityLiving entityLiving, double x, double y, double z, float u, float v) {
		renderKakuzu((EntityKisame)entityLiving, x, y, z, u, v);
	}
	
	public void doRenderLiving(Entity entity, double x, double y, double z, float u, float v) {
		renderKakuzu((EntityKisame)entity, x, y, z, u, v);
	}

	protected ResourceLocation getEntityTexture(EntityKisame entity) {
		if(entity.SharkSkin==1)return Mtexture2;
		if(entity.SharkSkin==2)return Mtexture;
		if(entity.SharkSkin==3)return Mtexture4;
		else
			return Mtexture3;
		}
		
	
	@Override
	protected ResourceLocation getEntityTexture(Entity p_110775_1_) {
		// TODO Auto-generated method stub
		return this.getEntityTexture((EntityKisame)p_110775_1_);
	}

}
