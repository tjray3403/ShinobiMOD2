package Shinobi.Entitys.Renderers;

import Shinobi.Entitys.Entitys.EntityPainAsura;
import Shinobi.Entitys.Models.ModelPain;
import Shinobi.Entitys.Models.ModelPainAsura;
import net.minecraft.client.model.ModelBase;
import net.minecraft.client.renderer.entity.RenderLiving;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLiving;
import net.minecraft.util.ResourceLocation;

public class RenderPainAsura extends RenderLiving{
	
	private static final ResourceLocation texture = new ResourceLocation("ninja:textures/models/Mobs/PainAsura.png");
	private static final ResourceLocation texture2 = new ResourceLocation("ninja:textures/models/Mobs/PainAsura2.png");

	
	protected ModelPainAsura modelEntity;
	
	public RenderPainAsura(ModelBase par1ModelBase, float par2) {
		super(par1ModelBase, par2);
		modelEntity = ((ModelPainAsura) mainModel);
	}
	
	public void renderWater(EntityPainAsura entity, double x, double y, double z, float u, float v) {
		super.doRender(entity, x, y, z, u, v);
	}
	
	public void doRenderLiving(EntityLiving entityLiving, double x, double y, double z, float u, float v) {
		renderWater((EntityPainAsura)entityLiving, x, y, z, u, v);
	}
	
	public void doRenderLiving(Entity entity, double x, double y, double z, float u, float v) {
		renderWater((EntityPainAsura)entity, x, y, z, u, v);
	}

	protected ResourceLocation getEntityTexture(EntityPainAsura entity) {
		
		if(entity.getHealth()<2000)return texture2;
		else
			return texture;
		}
		
	
	@Override
	protected ResourceLocation getEntityTexture(Entity p_110775_1_) {
		// TODO Auto-generated method stub
		return this.getEntityTexture((EntityPainAsura)p_110775_1_);
	}

}
