package Shinobi.Entitys.Renderers;

import java.util.Random;

import Shinobi.Entitys.Entitys.EntityPuppetSasori;
import Shinobi.Entitys.Models.ModelPuppet;
import cpw.mods.fml.common.registry.VillagerRegistry;
import net.minecraft.client.model.ModelBase;
import net.minecraft.client.renderer.entity.RenderLiving;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLiving;
import net.minecraft.util.ResourceLocation;

public class RenderPuppetSasori extends RenderLiving {
	
	private static final ResourceLocation texture1 = new ResourceLocation("ninja:textures/models/mobs/Puppet1.png");
	private static final ResourceLocation texture2 = new ResourceLocation("ninja:textures/models/mobs/Puppet2.png");
	private static final ResourceLocation texture3 = new ResourceLocation("ninja:textures/models/mobs/Puppet3.png");

	protected ModelPuppet modelEntity;
	
	public RenderPuppetSasori(ModelBase par1ModelBase, float par2) {
		super(par1ModelBase, par2);
		modelEntity = ((ModelPuppet) mainModel);
	}
	
	public void renderSasori(EntityPuppetSasori entity, double x, double y, double z, float u, float v) {
		super.doRender(entity, x, y, z, u, v);
	}
	
	public void doRenderLiving(EntityLiving entityLiving, double x, double y, double z, float u, float v) {
		renderSasori((EntityPuppetSasori)entityLiving, x, y, z, u, v);
	}
	
	public void doRenderLiving(Entity entity, double x, double y, double z, float u, float v) {
		renderSasori((EntityPuppetSasori)entity, x, y, z, u, v);
	}
	
	
	protected ResourceLocation getEntityTexture(EntityPuppetSasori entity) {
		return texture2;
	
		
	}
	
	

	@Override
	protected ResourceLocation getEntityTexture(Entity p_110775_1_) {
		// TODO Auto-generated method stub
		return this.getEntityTexture((EntityPuppetSasori)p_110775_1_);
	}
	
	
	
	}