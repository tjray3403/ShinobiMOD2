package Shinobi.Entitys.Renderers;

import Shinobi.Entitys.Entitys.EntitySMChimera3;
import Shinobi.Entitys.Models.ModelChimera3h;
import net.minecraft.client.model.ModelBase;
import net.minecraft.client.renderer.entity.RenderLiving;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLiving;
import net.minecraft.util.ResourceLocation;

public class RenderSMChimera3 extends RenderLiving{
	
	private static final ResourceLocation texture = new ResourceLocation("ninja:textures/models/Mobs/SummonDog2.png");

	protected ModelChimera3h modelEntity;
	
	public RenderSMChimera3(ModelBase par1ModelBase, float par2) {
		super(par1ModelBase, par2);
		modelEntity = ((ModelChimera3h) mainModel);
	}
	
	public void renderWater(EntitySMChimera3 entity, double x, double y, double z, float u, float v) {
		super.doRender(entity, x, y, z, u, v);
	}
	
	public void doRenderLiving(EntityLiving entityLiving, double x, double y, double z, float u, float v) {
		renderWater((EntitySMChimera3)entityLiving, x, y, z, u, v);
	}
	
	public void doRenderLiving(Entity entity, double x, double y, double z, float u, float v) {
		renderWater((EntitySMChimera3)entity, x, y, z, u, v);
	}

	@Override
	protected ResourceLocation getEntityTexture(Entity var1) {
		return texture;
	}

}
