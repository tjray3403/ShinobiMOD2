package Shinobi.Entitys.Renderers;

import Shinobi.Entitys.Entitys.EntitySasori;
import Shinobi.Entitys.Models.ModelSasori;
import net.minecraft.client.model.ModelBase;
import net.minecraft.client.renderer.entity.RenderLiving;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLiving;
import net.minecraft.util.ResourceLocation;

public class RenderSasori extends RenderLiving {
	
	private static final ResourceLocation texture1 = new ResourceLocation("ninja:textures/models/mobs/sasori1.png");
	private static final ResourceLocation texture2 = new ResourceLocation("ninja:textures/models/mobs/sasori2.png");

	protected ModelSasori modelEntity;
	public boolean i = false;
	
	public RenderSasori(ModelBase par1ModelBase, float par2) {
		super(par1ModelBase, par2);
		modelEntity = ((ModelSasori) mainModel);
	}
	
	public void renderSasori(EntitySasori entity, double x, double y, double z, float u, float v) {
		super.doRender(entity, x, y, z, u, v);
	}
	
	public void doRenderLiving(EntityLiving entityLiving, double x, double y, double z, float u, float v) {
		renderSasori((EntitySasori)entityLiving, x, y, z, u, v);
	}
	
	public void doRenderLiving(Entity entity, double x, double y, double z, float u, float v) {
		renderSasori((EntitySasori)entity, x, y, z, u, v);
	}
	
	
	protected ResourceLocation getEntityTexture(EntitySasori entity) {

		if(entity.puppetmode==false) {
	return texture1;
	}
	else
	{
	return texture2;
	}
	}

	@Override
	protected ResourceLocation getEntityTexture(Entity p_110775_1_) {
		// TODO Auto-generated method stub
		return this.getEntityTexture((EntitySasori)p_110775_1_);
	}
	
	
	
	}