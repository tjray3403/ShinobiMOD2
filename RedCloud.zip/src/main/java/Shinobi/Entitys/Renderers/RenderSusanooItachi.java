package Shinobi.Entitys.Renderers;

import Shinobi.Entitys.Entitys.EntitySusanooItachi;
import Shinobi.Entitys.Models.ModelSusanooItachi;
import net.minecraft.client.model.ModelBase;
import net.minecraft.client.renderer.entity.RenderLiving;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLiving;
import net.minecraft.util.ResourceLocation;

public class RenderSusanooItachi extends RenderLiving{
	
	private static final ResourceLocation Mtexture = new ResourceLocation("ninja:textures/models/Mobs/itachiSusanoo1.png");
	private static final ResourceLocation Mtexture2 = new ResourceLocation("ninja:textures/models/Mobs/itachiSusanoo2.png");
	private static final ResourceLocation Mtexture3 = new ResourceLocation("ninja:textures/models/Mobs/itachiSusanoo3.png");
	private static final ResourceLocation Mtexture4 = new ResourceLocation("ninja:textures/models/Mobs/itachiSusanoo4.png");
	

	
	protected ModelSusanooItachi modelEntity1;
	
	public RenderSusanooItachi(ModelBase par1ModelBase, float par2) {
		super(par1ModelBase, par2);
		modelEntity1 = ((ModelSusanooItachi) mainModel);
	}
	
	

	public void renderKakuzu(EntitySusanooItachi entity, double x, double y, double z, float u, float v) {
		super.doRender(entity, x, y, z, u, v);
	}
	
	public void doRenderLiving(EntityLiving entityLiving, double x, double y, double z, float u, float v) {
		renderKakuzu((EntitySusanooItachi)entityLiving, x, y, z, u, v);
	}
	
	public void doRenderLiving(Entity entity, double x, double y, double z, float u, float v) {
		renderKakuzu((EntitySusanooItachi)entity, x, y, z, u, v);
	}

	protected ResourceLocation getEntityTexture(EntitySusanooItachi entity) {
		if(entity.Susanoo==1)return Mtexture2;
		if(entity.Susanoo==2)return Mtexture3;
		if(entity.Susanoo==3)return Mtexture4;
		else
			return Mtexture;
		}
		
	
	@Override
	protected ResourceLocation getEntityTexture(Entity p_110775_1_) {
		// TODO Auto-generated method stub
		return this.getEntityTexture((EntitySusanooItachi)p_110775_1_);
	}

}
