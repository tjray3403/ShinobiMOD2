package Shinobi.Entitys.Renderers;

import Shinobi.Entitys.Entitys.EntityTobi;
import Shinobi.Entitys.Models.ModelTobi;
import net.minecraft.client.model.ModelBase;
import net.minecraft.client.renderer.entity.RenderLiving;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLiving;
import net.minecraft.util.ResourceLocation;

public class RenderTobi extends RenderLiving{
	
	private static final ResourceLocation texture = new ResourceLocation("ninja:textures/models/Mobs/Tobitex.png");

	protected ModelTobi modelEntity;
	
	public RenderTobi(ModelBase par1ModelBase, float par2) {
		super(par1ModelBase, par2);
		modelEntity = ((ModelTobi) mainModel);
	}
	
	public void renderWater(EntityTobi entity, double x, double y, double z, float u, float v) {
		super.doRender(entity, x, y, z, u, v);
	}
	
	public void doRenderLiving(EntityLiving entityLiving, double x, double y, double z, float u, float v) {
		renderWater((EntityTobi)entityLiving, x, y, z, u, v);
	}
	
	public void doRenderLiving(Entity entity, double x, double y, double z, float u, float v) {
		renderWater((EntityTobi)entity, x, y, z, u, v);
	}

	@Override
	protected ResourceLocation getEntityTexture(Entity var1) {
		return texture;
	}

}
