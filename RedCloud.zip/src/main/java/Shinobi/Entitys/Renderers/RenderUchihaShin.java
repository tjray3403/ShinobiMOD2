package Shinobi.Entitys.Renderers;

import Shinobi.Entitys.Entitys.EntityHidan;
import Shinobi.Entitys.Entitys.EntityShinUchiha;
import Shinobi.Entitys.Entitys.EntityUchihaShin;
import Shinobi.Entitys.Models.ModelHidan;
import Shinobi.Entitys.Models.ModelShinUchiha;
import Shinobi.Entitys.Models.ShinUchihaB;
import net.minecraft.client.model.ModelBase;
import net.minecraft.client.renderer.entity.Render;
import net.minecraft.client.renderer.entity.RenderLiving;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLiving;
import net.minecraft.util.ResourceLocation;

public class RenderUchihaShin extends RenderLiving{
	
	private static final ResourceLocation texture = new ResourceLocation("ninja:textures/models/Mobs/ShinUchihaB.png");

	protected ShinUchihaB modelEntity;
	
	public RenderUchihaShin(ModelBase par1ModelBase, float par2) {
		super(par1ModelBase, par2);
		modelEntity = ((ShinUchihaB) mainModel);
	}
	
	public void renderUchihaShin(EntityUchihaShin entity, double x, double y, double z, float u, float v) {
		super.doRender(entity, x, y, z, u, v);
	}
	
	public void doRenderLiving(EntityLiving entityLiving, double x, double y, double z, float u, float v) {
		renderUchihaShin((EntityUchihaShin)entityLiving, x, y, z, u, v);
	}
	
	public void doRenderLiving(Entity entity, double x, double y, double z, float u, float v) {
		renderUchihaShin((EntityUchihaShin)entity, x, y, z, u, v);
	}

	@Override
	protected ResourceLocation getEntityTexture(Entity var1) {
		return texture;
	}

}
