package Shinobi.Entitys.Renderers;

import Shinobi.Entitys.Entitys.EntityLightning;
import Shinobi.Entitys.Entitys.EntityWater;
import Shinobi.Entitys.Entitys.EntityWind;
import Shinobi.Entitys.Models.Modellightning;
import Shinobi.Entitys.Models.Modelwaterandfire;
import Shinobi.Entitys.Models.Modelwind;
import net.minecraft.client.model.ModelBase;
import net.minecraft.client.renderer.entity.RenderLiving;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLiving;
import net.minecraft.util.ResourceLocation;

public class RenderWind extends RenderLiving{
	
	private static final ResourceLocation texture = new ResourceLocation("ninja:textures/models/Mobs/wind.png");

	protected Modelwind modelEntity;
	
	public RenderWind(ModelBase par1ModelBase, float par2) {
		super(par1ModelBase, par2);
		modelEntity = ((Modelwind) mainModel);
	}
	
	public void renderWind(EntityWind entity, double x, double y, double z, float u, float v) {
		super.doRender(entity, x, y, z, u, v);
	}
	
	public void doRenderLiving(EntityLiving entityLiving, double x, double y, double z, float u, float v) {
		renderWind((EntityWind)entityLiving, x, y, z, u, v);
	}
	
	public void doRenderLiving(Entity entity, double x, double y, double z, float u, float v) {
		renderWind((EntityWind)entity, x, y, z, u, v);
	}

	@Override
	protected ResourceLocation getEntityTexture(Entity var1) {
		return texture;
	}

}
