package Shinobi.Entitys.Renderers.projectiles;

import Shinobi.Entitys.Models.ModelC4;
import Shinobi.Entitys.Projectiles.EntityC4;
import net.minecraft.client.model.ModelBase;
import net.minecraft.client.renderer.entity.RenderLiving;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLiving;
import net.minecraft.util.ResourceLocation;

public class RenderEntityC4 extends RenderLiving{
	
	private static final ResourceLocation texture = new ResourceLocation("ninja:textures/models/C4.png");

	protected ModelC4 modelEntity;
	
	public RenderEntityC4(ModelBase par1ModelBase, float par2) {
		super(par1ModelBase, par2);
		modelEntity = ((ModelC4) mainModel);
	}
	
	public void renderC4Entity(EntityC4 entity, double x, double y, double z, float u, float v) {
		super.doRender(entity, x, y, z, u, v);
	}
	
	public void doRenderLiving(EntityLiving entityLiving, double x, double y, double z, float u, float v) {
		renderC4Entity((EntityC4)entityLiving, x, y, z, u, v);
	}
	
	public void doRenderLiving(Entity entity, double x, double y, double z, float u, float v) {
		renderC4Entity((EntityC4)entity, x, y, z, u, v);
	}

	@Override
	protected ResourceLocation getEntityTexture(Entity var1) {
		return texture;
	}

}
