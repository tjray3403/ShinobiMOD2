package Shinobi;

import cpw.mods.fml.common.eventhandler.SubscribeEvent;
import cpw.mods.fml.common.gameevent.TickEvent;
import ibxm.Player;
import net.minecraft.client.Minecraft;

public class EventHandler {
	
	@SubscribeEvent
	 public void onPlayerTick(TickEvent.PlayerTickEvent event) {
		
		
	}
}
