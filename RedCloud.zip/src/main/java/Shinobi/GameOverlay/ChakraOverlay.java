package Shinobi.GameOverlay;

import Shinobi.ShinobiVariables;
import cpw.mods.fml.common.FMLCommonHandler;
import cpw.mods.fml.common.eventhandler.EventPriority;
import cpw.mods.fml.common.eventhandler.SubscribeEvent;
import net.minecraft.client.Minecraft;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.server.MinecraftServer;
import net.minecraft.world.World;
import net.minecraftforge.client.event.RenderGameOverlayEvent;

public class ChakraOverlay {
	
	@SubscribeEvent(priority = EventPriority.NORMAL)
	public void eventHandler(RenderGameOverlayEvent event){

		int posX = (event.resolution.getScaledWidth()) /2;
	    int posY = (event.resolution.getScaledHeight()) /2;

	    EntityPlayer entity = Minecraft.getMinecraft().thePlayer;
		int i = (int)entity.posX;
		int j = (int)entity.posY;
		int k = (int)entity.posZ;
		MinecraftServer server = FMLCommonHandler.instance().getMinecraftServerInstance();
		World world = server.worldServers[0];

		

			Minecraft.getMinecraft().fontRenderer.drawString("Chakra lvl"+ShinobiVariables.MangekyoSharingan1+"", posX+(-88), posY+(67), 0xffffff);

		

	}

}
