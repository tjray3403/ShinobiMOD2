package Shinobi.Items;

import Shinobi.ShinobiMod;
import Shinobi.ShinobiVariables;
import Shinobi.Entitys.Entitys.EntityShadowClone;
import Shinobi.Overlay.RenderCurseMark;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityList;
import net.minecraft.entity.EntityLiving;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.potion.PotionEffect;
import net.minecraft.world.World;

public class ItemCurseMark extends Item{
	

	public ItemCurseMark() {
		this.setFull3D();
		this.setMaxStackSize(1);
		this.setMaxDamage(1);
	}
	
	public ItemStack onItemRightClick(ItemStack itemstack, World world, EntityPlayer entity) {
		float var4 = 1.0F;
		int i = (int) (entity.prevPosX + (entity.posX - entity.prevPosX) * (double) var4);
		int j = (int) (entity.prevPosY + (entity.posY - entity.prevPosY) * (double) var4 + 1.62D - (double) entity.yOffset);
		int k = (int) (entity.prevPosZ + (entity.posZ - entity.prevPosZ) * (double) var4);

		if (true) {
			if (entity instanceof EntityLivingBase)
				((EntityLivingBase) entity).addPotionEffect(new PotionEffect(1, 70*20, 5));
			if (entity instanceof EntityLivingBase)
				((EntityLivingBase) entity).addPotionEffect(new PotionEffect(5, 70*20, 7));
			if (entity instanceof EntityLivingBase)
				((EntityLivingBase) entity).addPotionEffect(new PotionEffect(10, 70*20, 5));
			if (entity instanceof EntityLivingBase)
				((EntityLivingBase) entity).addPotionEffect(new PotionEffect(11, 70*20, 5));
			if (entity instanceof EntityLivingBase)
				((EntityLivingBase) entity).addPotionEffect(new PotionEffect(8, 70*20, 3));

		}
		return itemstack;
	}
}



