package Shinobi.Items;

import Shinobi.ShinobiMod;
import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.item.ItemPickaxe;
import net.minecraft.item.ItemStack;
import net.minecraft.item.ItemSword;
import net.minecraft.potion.PotionEffect;
import net.minecraft.world.World;

public class ItemHiramekarei extends ItemSword{

	public ItemHiramekarei(ToolMaterial material) {
		super(material);
	}
	
	@SideOnly(Side.CLIENT)
	public boolean isFull3D(){
		return true;
	}
	
	public void onUpdate(ItemStack itemstack, World world, Entity entity, int par4, boolean par5) {
		int i = (int) entity.posX;
		int j = (int) entity.posY;
		int k = (int) entity.posZ;

		if (true) {
			if (((EntityLivingBase) entity).getHeldItem() != null && ((EntityLivingBase) entity).getHeldItem().getItem() == ShinobiMod.ItemHiramekarei) {
				if (entity instanceof EntityLivingBase)
					((EntityLivingBase) entity).addPotionEffect(new PotionEffect(2, 3, 2));
		}

	}

}

}
