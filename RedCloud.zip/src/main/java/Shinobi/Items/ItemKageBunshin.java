package Shinobi.Items;

import Shinobi.Entitys.Entitys.EntityShadowClone;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityList;
import net.minecraft.entity.EntityLiving;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.world.World;

public class ItemKageBunshin extends Item{
	

	public ItemKageBunshin() {
		this.setFull3D();
		this.setMaxStackSize(1);
		this.setMaxDamage(1);
	}
	
	public ItemStack onItemRightClick(ItemStack itemstack, World world, EntityPlayer entity) {
		float var4 = 1.0F;
		int i = (int) (entity.prevPosX + (entity.posX - entity.prevPosX) * (double) var4);
		int j = (int) (entity.prevPosY + (entity.posY - entity.prevPosY) * (double) var4 + 1.62D - (double) entity.yOffset);
		int k = (int) (entity.prevPosZ + (entity.posZ - entity.prevPosZ) * (double) var4);

		if (true) {
			if(!world.isRemote) {
			Entity shadowClone = EntityList.createEntityByName("34Bunshin", world);
			if (shadowClone != null) {
				shadowClone.setLocationAndAngles(i, j, k+1, world.rand.nextFloat() * 360F, 0.0F);
				world.spawnEntityInWorld(shadowClone);
				((EntityLiving) shadowClone).playLivingSound();
				((EntityLiving) shadowClone).setCustomNameTag(entity.getCommandSenderName());

                shadowClone.setCurrentItemOrArmor(1, entity.getCurrentArmor(3));
                shadowClone.setCurrentItemOrArmor(2, entity.getCurrentArmor(2));
                shadowClone.setCurrentItemOrArmor(3, entity.getCurrentArmor(1));
                shadowClone.setCurrentItemOrArmor(4, entity.getCurrentArmor(0));

			}
			
			Entity b1 = EntityList.createEntityByName("34Bunshin", world);
			if (b1 != null) {
				b1.setLocationAndAngles(i+1, j, k, world.rand.nextFloat() * 360F, 0.0F);
				world.spawnEntityInWorld(b1);
				((EntityLiving) b1).playLivingSound();
				((EntityLiving) b1).setCustomNameTag(entity.getCommandSenderName());

                b1.setCurrentItemOrArmor(1, entity.getCurrentArmor(3));
                b1.setCurrentItemOrArmor(2, entity.getCurrentArmor(2));
                b1.setCurrentItemOrArmor(3, entity.getCurrentArmor(1));
                b1.setCurrentItemOrArmor(4, entity.getCurrentArmor(0));

			}
			
			Entity b2 = EntityList.createEntityByName("34Bunshin", world);
			if (b2 != null) {
				b2.setLocationAndAngles(i+1, j, k+1, world.rand.nextFloat() * 360F, 0.0F);
				world.spawnEntityInWorld(b2);
				((EntityLiving) b2).playLivingSound();
				((EntityLiving) b2).setCustomNameTag(entity.getCommandSenderName());

                b2.setCurrentItemOrArmor(1, entity.getCurrentArmor(3));
                b2.setCurrentItemOrArmor(2, entity.getCurrentArmor(2));
                b2.setCurrentItemOrArmor(3, entity.getCurrentArmor(1));
                b2.setCurrentItemOrArmor(4, entity.getCurrentArmor(0));

			}
			
		}
		}
		return itemstack;
	}
}



