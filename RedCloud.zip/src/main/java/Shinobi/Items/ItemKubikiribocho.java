package Shinobi.Items;

import Shinobi.ShinobiMod;
import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.effect.EntityLightningBolt;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.ItemPickaxe;
import net.minecraft.item.ItemStack;
import net.minecraft.item.ItemSword;
import net.minecraft.potion.PotionEffect;
import net.minecraft.util.MathHelper;
import net.minecraft.util.Vec3;
import net.minecraft.world.World;

public class ItemKubikiribocho extends ItemSword{

	private World worldObj;

	public ItemKubikiribocho(ToolMaterial material) {
		super(material);
	}
	
	@SideOnly(Side.CLIENT)
	public boolean isFull3D(){
		return true;
	}
	
	/**public ItemStack onItemRightClick(ItemStack itemstack, World world, EntityPlayer entity) {
		Vec3 playerLookVector = entity.getLookVec();
		float var4 = 1.0F;
		double i = entity.posX+2*playerLookVector.xCoord;
		double k = entity.posZ+2*playerLookVector.zCoord;
		double j = entity.posY+1*playerLookVector.yCoord;
		
		

		return itemstack;
	}*/

   public void onUpdate(ItemStack itemstack, World world, Entity entity, int par4, boolean par5) {
			int i = (int) entity.posX;
			int j = (int) entity.posY;
			int k = (int) entity.posZ;

			
    
}
   
   /**public boolean hitEntity(ItemStack p_77644_1_, EntityLivingBase p_77644_2_, EntityLivingBase p_77644_3_, EntityPlayer entity) {
	  super.hitEntity(p_77644_1_, p_77644_2_, p_77644_3_);
	  if(true) {
				if (entity instanceof EntityLivingBase)
					((EntityLivingBase) entity).addPotionEffect(new PotionEffect(12, 3, 1));
	  }
	  return true;
   }
   **/
}