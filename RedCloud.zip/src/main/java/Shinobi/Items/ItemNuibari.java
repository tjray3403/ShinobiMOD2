package Shinobi.Items;

import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;
import net.minecraft.item.ItemPickaxe;
import net.minecraft.item.ItemSword;

public class ItemNuibari extends ItemSword{

	public ItemNuibari(ToolMaterial material) {
		super(material);
	}
	
	@SideOnly(Side.CLIENT)
	public boolean isFull3D(){
		return true;
	}

}
