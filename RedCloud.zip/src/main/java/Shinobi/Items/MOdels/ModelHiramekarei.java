package Shinobi.Items.MOdels;

import net.minecraft.client.model.ModelBase;
import net.minecraft.client.model.ModelRenderer;
import net.minecraft.entity.Entity;

/**
 * ModelKubikiribocho - Either Mojang or a mod author
 * Created using Tabula 4.1.1
 */
public class ModelHiramekarei extends ModelBase {
    public ModelRenderer Blade_Top_L;
    public ModelRenderer Outside_Hole;
    public ModelRenderer Inside_Hole;
    public ModelRenderer Hilt;
    public ModelRenderer Blade_Top;
    public ModelRenderer Handle;
    public ModelRenderer Indent_Side;
    public ModelRenderer Blade_Base;
    public ModelRenderer Blade_Majority;
    public ModelRenderer Top;
    public ModelRenderer mid;
    public ModelRenderer side1;
    public ModelRenderer side2;
    public ModelRenderer b1;
    public ModelRenderer b2;
    public ModelRenderer b3;
    public ModelRenderer b4;
    public ModelRenderer b5;
    public ModelRenderer b6;
    public ModelRenderer b7;
    public ModelRenderer b8;
    public ModelRenderer bt1;
    public ModelRenderer bt2;
    public ModelRenderer btm;
    public ModelRenderer handle2;

    public ModelHiramekarei() {
        this.textureWidth = 64;
        this.textureHeight = 32;
        this.b2 = new ModelRenderer(this, 0, 0);
        this.b2.setRotationPoint(3.1F, -29.0F, -1.0F);
        this.b2.addBox(-1.0F, -1.0F, 0.0F, 2, 2, 3, 0.0F);
        this.setRotateAngle(b2, 0.0F, 0.0F, 0.7853981633974483F);
        this.Blade_Top_L = new ModelRenderer(this, 0, 0);
        this.Blade_Top_L.setRotationPoint(-4.5F, -36.6F, -1.0F);
        this.Blade_Top_L.addBox(0.0F, 0.0F, 0.0F, 12, 4, 3, 0.0F);
        this.b8 = new ModelRenderer(this, 0, 0);
        this.b8.setRotationPoint(6.0F, -32.6F, -1.0F);
        this.b8.addBox(-1.0F, -1.0F, 0.0F, 2, 2, 3, 0.0F);
        this.setRotateAngle(b8, 0.0F, 0.0F, 0.7853981633974483F);
        this.b4 = new ModelRenderer(this, 0, 0);
        this.b4.setRotationPoint(6.4F, -29.0F, -1.0F);
        this.b4.addBox(-1.0F, -1.0F, 0.0F, 2, 2, 3, 0.0F);
        this.setRotateAngle(b4, 0.0F, 0.0F, 0.7853981633974483F);
        this.handle2 = new ModelRenderer(this, 40, 15);
        this.handle2.setRotationPoint(1.0F, -5.2F, -1.3F);
        this.handle2.addBox(0.0F, 0.0F, 0.0F, 1, 8, 1, 0.0F);
        this.Blade_Top = new ModelRenderer(this, 0, 0);
        this.Blade_Top.setRotationPoint(-2.5F, -38.6F, -0.5F);
        this.Blade_Top.addBox(0.0F, 0.0F, 0.0F, 8, 2, 2, 0.0F);
        this.b1 = new ModelRenderer(this, 0, 0);
        this.b1.setRotationPoint(0.0F, -29.0F, -1.0F);
        this.b1.addBox(-1.0F, -1.0F, 0.0F, 2, 2, 3, 0.0F);
        this.setRotateAngle(b1, 0.0F, -0.0F, -0.7853981633974483F);
        this.Hilt = new ModelRenderer(this, 0, 23);
        this.Hilt.setRotationPoint(-6.0F, -8.5F, -1.0F);
        this.Hilt.addBox(0.0F, 0.0F, 0.0F, 15, 5, 3, 0.0F);
        this.setRotateAngle(Hilt, 0.0F, 0.0F, 0.0017453292519943296F);
        this.Handle = new ModelRenderer(this, 40, 15);
        this.Handle.setRotationPoint(1.0F, -5.2F, 1.3F);
        this.Handle.addBox(0.0F, 0.0F, 0.0F, 1, 8, 1, 0.0F);
        this.Outside_Hole = new ModelRenderer(this, 0, 0);
        this.Outside_Hole.setRotationPoint(-8.0F, -31.0F, -0.5F);
        this.Outside_Hole.addBox(0.0F, 0.0F, 0.0F, 2, 12, 2, 0.0F);
        this.Top = new ModelRenderer(this, 0, 0);
        this.Top.setRotationPoint(0.0F, -40.5F, 0.0F);
        this.Top.addBox(0.0F, 0.0F, 0.0F, 3, 2, 1, 0.0F);
        this.btm = new ModelRenderer(this, 0, 0);
        this.btm.setRotationPoint(0.0F, -3.6F, -0.5F);
        this.btm.addBox(-3.6F, 0.0F, 0.0F, 10, 1, 2, 0.0F);
        this.b7 = new ModelRenderer(this, 0, 0);
        this.b7.setRotationPoint(3.5F, -32.6F, -1.0F);
        this.b7.addBox(-1.0F, -1.0F, 0.0F, 2, 2, 3, 0.0F);
        this.setRotateAngle(b7, 0.0F, 0.0F, 0.7853981633974483F);
        this.b6 = new ModelRenderer(this, 0, 0);
        this.b6.setRotationPoint(-3.1F, -32.6F, -1.0F);
        this.b6.addBox(-1.0F, -1.0F, 0.0F, 2, 2, 3, 0.0F);
        this.setRotateAngle(b6, 0.0F, 0.0F, 0.7853981633974483F);
        this.Indent_Side = new ModelRenderer(this, 0, 0);
        this.Indent_Side.setRotationPoint(1.0F, -15.0F, -0.5F);
        this.Indent_Side.addBox(-5.0F, 0.0F, 0.0F, 11, 4, 2, 0.0F);
        this.mid = new ModelRenderer(this, 0, 0);
        this.mid.setRotationPoint(1.6F, -34.0F, -1.0F);
        this.mid.addBox(-2.0F, 0.0F, 0.0F, 4, 5, 3, 0.0F);
        this.bt2 = new ModelRenderer(this, 0, 0);
        this.bt2.setRotationPoint(7.4F, -8.6F, -0.5F);
        this.bt2.addBox(-1.7F, 0.0F, 0.0F, 5, 5, 2, 0.0F);
        this.setRotateAngle(bt2, 0.0F, 0.0F, -0.6108652381980153F);
        this.Blade_Base = new ModelRenderer(this, 0, 0);
        this.Blade_Base.setRotationPoint(-3.0F, -11.0F, -0.5F);
        this.Blade_Base.addBox(0.0F, 0.0F, 0.0F, 9, 3, 2, 0.0F);
        this.Blade_Majority = new ModelRenderer(this, 0, 0);
        this.Blade_Majority.setRotationPoint(-6.0F, -29.1F, -1.0F);
        this.Blade_Majority.addBox(0.0F, 0.0F, 0.0F, 15, 14, 3, 0.0F);
        this.side2 = new ModelRenderer(this, 0, 0);
        this.side2.setRotationPoint(6.0F, -34.0F, -1.0F);
        this.side2.addBox(0.0F, 0.0F, 0.0F, 3, 5, 3, 0.0F);
        this.Inside_Hole = new ModelRenderer(this, 2, 4);
        this.Inside_Hole.setRotationPoint(7.0F, -31.0F, -0.5F);
        this.Inside_Hole.addBox(2.0F, 0.0F, 0.0F, 2, 12, 2, 0.0F);
        this.b3 = new ModelRenderer(this, 0, 0);
        this.b3.setRotationPoint(-3.4F, -29.0F, -1.0F);
        this.b3.addBox(-1.0F, -1.0F, 0.0F, 2, 2, 3, 0.0F);
        this.setRotateAngle(b3, 0.0F, 0.0F, -0.7853981633974483F);
        this.b5 = new ModelRenderer(this, 0, 0);
        this.b5.setRotationPoint(-0.4F, -32.6F, -1.0F);
        this.b5.addBox(-1.0F, -1.0F, 0.0F, 2, 2, 3, 0.0F);
        this.setRotateAngle(b5, 0.0F, 0.0F, 0.7853981633974483F);
        this.bt1 = new ModelRenderer(this, 0, 0);
        this.bt1.setRotationPoint(-5.6F, -9.4F, -0.5F);
        this.bt1.addBox(-1.9F, 0.0F, 0.0F, 5, 5, 2, 0.0F);
        this.setRotateAngle(bt1, 0.0F, 0.0F, 0.6108652381980153F);
        this.side1 = new ModelRenderer(this, 0, 0);
        this.side1.setRotationPoint(-6.0F, -34.0F, -1.0F);
        this.side1.addBox(0.0F, 0.0F, 0.0F, 3, 5, 3, 0.0F);
    }

    @Override
    public void render(Entity entity, float f, float f1, float f2, float f3, float f4, float f5) { 
        this.b2.render(f5);
        this.Blade_Top_L.render(f5);
        this.b8.render(f5);
        this.b4.render(f5);
        this.handle2.render(f5);
        this.Blade_Top.render(f5);
        this.b1.render(f5);
        this.Hilt.render(f5);
        this.Handle.render(f5);
        this.Outside_Hole.render(f5);
        this.Top.render(f5);
        this.btm.render(f5);
        this.b7.render(f5);
        this.b6.render(f5);
        this.Indent_Side.render(f5);
        this.mid.render(f5);
        this.bt2.render(f5);
        this.Blade_Base.render(f5);
        this.Blade_Majority.render(f5);
        this.side2.render(f5);
        this.Inside_Hole.render(f5);
        this.b3.render(f5);
        this.b5.render(f5);
        this.bt1.render(f5);
        this.side1.render(f5);
    }

    /**
     * This is a helper function from Tabula to set the rotation of model parts
     */
    public void setRotateAngle(ModelRenderer modelRenderer, float x, float y, float z) {
        modelRenderer.rotateAngleX = x;
        modelRenderer.rotateAngleY = y;
        modelRenderer.rotateAngleZ = z;
    }
}
