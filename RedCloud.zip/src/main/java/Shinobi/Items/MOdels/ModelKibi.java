package Shinobi.Items.MOdels;

import net.minecraft.client.model.ModelBase;
import net.minecraft.client.model.ModelRenderer;
import net.minecraft.entity.Entity;
import org.lwjgl.opengl.GL11;

/**
 * ModelKubikiribocho - Either Mojang or a mod author
 * Created using Tabula 4.1.1
 */
public class ModelKibi extends ModelBase {
    public ModelRenderer Top_Smooth_Corner;
    public ModelRenderer Bottom_Smooth_Corner;
    public ModelRenderer Hilt;
    public ModelRenderer Handle;
    public ModelRenderer Blade_Base;
    public ModelRenderer Top;
    public ModelRenderer hilt2;
    public ModelRenderer hilt3;
    public ModelRenderer hilt1;
    public ModelRenderer shape21;
    public ModelRenderer shape22;

    public ModelKibi() {
        this.textureWidth = 64;
        this.textureHeight = 32;
        this.hilt3 = new ModelRenderer(this, 0, 0);
        this.hilt3.setRotationPoint(-1.0F, -8.3F, -2.0F);
        this.hilt3.addBox(0.0F, 0.0F, 0.0F, 5, 2, 2, 0.0F);
        this.setRotateAngle(hilt3, 0.6544984694978736F, 0.0F, 0.0F);
        this.Bottom_Smooth_Corner = new ModelRenderer(this, 0, 10);
        this.Bottom_Smooth_Corner.setRotationPoint(1.3F, -14.0F, 0.05F);
        this.Bottom_Smooth_Corner.addBox(0.0F, 0.0F, 0.0F, 3, 2, 1, 0.0F);
        this.setRotateAngle(Bottom_Smooth_Corner, 0.0F, 0.0F, -0.5235987755982988F);
        this.hilt1 = new ModelRenderer(this, 0, 0);
        this.hilt1.setRotationPoint(-1.0F, -9.25F, -0.5F);
        this.hilt1.addBox(0.0F, 0.0F, 0.0F, 5, 1, 2, 0.0F);
        this.Blade_Base = new ModelRenderer(this, 40, 0);
        this.Blade_Base.setRotationPoint(0.5F, -38.3F, 0.0F);
        this.Blade_Base.addBox(0.0F, 0.0F, 0.0F, 2, 30, 1, 0.0F);
        this.shape22 = new ModelRenderer(this, 0, 20);
        this.shape22.setRotationPoint(4.7F, -15.2F, 0.05F);
        this.shape22.addBox(-1.0F, -1.0F, 0.0F, 2, 2, 1, 0.0F);
        this.setRotateAngle(shape22, 0.0F, 0.0F, 0.6108652381980153F);
        this.hilt2 = new ModelRenderer(this, 0, 0);
        this.hilt2.setRotationPoint(-1.0F, -8.3F, 3.0F);
        this.hilt2.addBox(0.0F, 0.0F, -2.0F, 5, 2, 2, 0.0F);
        this.setRotateAngle(hilt2, -0.6544984694978736F, 0.0F, 0.0F);
        this.Top_Smooth_Corner = new ModelRenderer(this, 0, 10);
        this.Top_Smooth_Corner.setRotationPoint(-0.5F, -27.9F, 0.05F);
        this.Top_Smooth_Corner.addBox(0.0F, 0.0F, 0.0F, 3, 2, 1, 0.0F);
        this.setRotateAngle(Top_Smooth_Corner, 0.0F, 0.0F, 0.5235987755982988F);
        this.Hilt = new ModelRenderer(this, 8, 25);
        this.Hilt.setRotationPoint(-1.0F, -8.3F, -2.0F);
        this.Hilt.addBox(0.0F, 0.0F, 0.0F, 5, 2, 5, 0.0F);
        this.shape21 = new ModelRenderer(this, 0, 20);
        this.shape21.setRotationPoint(-1.2F, -27.5F, 0.05F);
        this.shape21.addBox(-1.0F, -1.0F, 0.0F, 2, 2, 1, 0.0F);
        this.setRotateAngle(shape21, 0.0F, 0.0F, -0.6108652381980153F);
        this.Top = new ModelRenderer(this, 0, 5);
        this.Top.setRotationPoint(1.5F, -38.3F, 0.05F);
        this.Top.addBox(-1.0F, -1.0F, 0.0F, 2, 2, 1, 0.0F);
        this.setRotateAngle(Top, 0.0F, -0.0F, 0.7853981633974483F);
        this.Handle = new ModelRenderer(this, 28, 15);
        this.Handle.setRotationPoint(0.5F, -6.5F, -0.5F);
        this.Handle.addBox(0.0F, 0.0F, 0.0F, 2, 10, 2, 0.0F);
    }

    @Override
    public void render(Entity entity, float f, float f1, float f2, float f3, float f4, float f5) { 
        GL11.glPushMatrix();
        GL11.glTranslatef(this.hilt3.offsetX, this.hilt3.offsetY, this.hilt3.offsetZ);
        GL11.glTranslatef(this.hilt3.rotationPointX * f5, this.hilt3.rotationPointY * f5, this.hilt3.rotationPointZ * f5);
        GL11.glScaled(1.0D, 0.8D, 1.0D);
        GL11.glTranslatef(-this.hilt3.offsetX, -this.hilt3.offsetY, -this.hilt3.offsetZ);
        GL11.glTranslatef(-this.hilt3.rotationPointX * f5, -this.hilt3.rotationPointY * f5, -this.hilt3.rotationPointZ * f5);
        this.hilt3.render(f5);
        GL11.glPopMatrix();
        GL11.glPushMatrix();
        GL11.glTranslatef(this.Bottom_Smooth_Corner.offsetX, this.Bottom_Smooth_Corner.offsetY, this.Bottom_Smooth_Corner.offsetZ);
        GL11.glTranslatef(this.Bottom_Smooth_Corner.rotationPointX * f5, this.Bottom_Smooth_Corner.rotationPointY * f5, this.Bottom_Smooth_Corner.rotationPointZ * f5);
        GL11.glScaled(1.0D, 1.0D, 0.9D);
        GL11.glTranslatef(-this.Bottom_Smooth_Corner.offsetX, -this.Bottom_Smooth_Corner.offsetY, -this.Bottom_Smooth_Corner.offsetZ);
        GL11.glTranslatef(-this.Bottom_Smooth_Corner.rotationPointX * f5, -this.Bottom_Smooth_Corner.rotationPointY * f5, -this.Bottom_Smooth_Corner.rotationPointZ * f5);
        this.Bottom_Smooth_Corner.render(f5);
        GL11.glPopMatrix();
        this.hilt1.render(f5);
        this.Blade_Base.render(f5);
        GL11.glPushMatrix();
        GL11.glTranslatef(this.shape22.offsetX, this.shape22.offsetY, this.shape22.offsetZ);
        GL11.glTranslatef(this.shape22.rotationPointX * f5, this.shape22.rotationPointY * f5, this.shape22.rotationPointZ * f5);
        GL11.glScaled(1.0D, 1.0D, 0.9D);
        GL11.glTranslatef(-this.shape22.offsetX, -this.shape22.offsetY, -this.shape22.offsetZ);
        GL11.glTranslatef(-this.shape22.rotationPointX * f5, -this.shape22.rotationPointY * f5, -this.shape22.rotationPointZ * f5);
        this.shape22.render(f5);
        GL11.glPopMatrix();
        GL11.glPushMatrix();
        GL11.glTranslatef(this.hilt2.offsetX, this.hilt2.offsetY, this.hilt2.offsetZ);
        GL11.glTranslatef(this.hilt2.rotationPointX * f5, this.hilt2.rotationPointY * f5, this.hilt2.rotationPointZ * f5);
        GL11.glScaled(1.0D, 0.8D, 1.0D);
        GL11.glTranslatef(-this.hilt2.offsetX, -this.hilt2.offsetY, -this.hilt2.offsetZ);
        GL11.glTranslatef(-this.hilt2.rotationPointX * f5, -this.hilt2.rotationPointY * f5, -this.hilt2.rotationPointZ * f5);
        this.hilt2.render(f5);
        GL11.glPopMatrix();
        GL11.glPushMatrix();
        GL11.glTranslatef(this.Top_Smooth_Corner.offsetX, this.Top_Smooth_Corner.offsetY, this.Top_Smooth_Corner.offsetZ);
        GL11.glTranslatef(this.Top_Smooth_Corner.rotationPointX * f5, this.Top_Smooth_Corner.rotationPointY * f5, this.Top_Smooth_Corner.rotationPointZ * f5);
        GL11.glScaled(1.0D, 1.0D, 0.9D);
        GL11.glTranslatef(-this.Top_Smooth_Corner.offsetX, -this.Top_Smooth_Corner.offsetY, -this.Top_Smooth_Corner.offsetZ);
        GL11.glTranslatef(-this.Top_Smooth_Corner.rotationPointX * f5, -this.Top_Smooth_Corner.rotationPointY * f5, -this.Top_Smooth_Corner.rotationPointZ * f5);
        this.Top_Smooth_Corner.render(f5);
        GL11.glPopMatrix();
        this.Hilt.render(f5);
        GL11.glPushMatrix();
        GL11.glTranslatef(this.shape21.offsetX, this.shape21.offsetY, this.shape21.offsetZ);
        GL11.glTranslatef(this.shape21.rotationPointX * f5, this.shape21.rotationPointY * f5, this.shape21.rotationPointZ * f5);
        GL11.glScaled(1.0D, 1.0D, 0.9D);
        GL11.glTranslatef(-this.shape21.offsetX, -this.shape21.offsetY, -this.shape21.offsetZ);
        GL11.glTranslatef(-this.shape21.rotationPointX * f5, -this.shape21.rotationPointY * f5, -this.shape21.rotationPointZ * f5);
        this.shape21.render(f5);
        GL11.glPopMatrix();
        GL11.glPushMatrix();
        GL11.glTranslatef(this.Top.offsetX, this.Top.offsetY, this.Top.offsetZ);
        GL11.glTranslatef(this.Top.rotationPointX * f5, this.Top.rotationPointY * f5, this.Top.rotationPointZ * f5);
        GL11.glScaled(0.7D, 1.0D, 0.9D);
        GL11.glTranslatef(-this.Top.offsetX, -this.Top.offsetY, -this.Top.offsetZ);
        GL11.glTranslatef(-this.Top.rotationPointX * f5, -this.Top.rotationPointY * f5, -this.Top.rotationPointZ * f5);
        this.Top.render(f5);
        GL11.glPopMatrix();
        this.Handle.render(f5);
    }

    /**
     * This is a helper function from Tabula to set the rotation of model parts
     */
    public void setRotateAngle(ModelRenderer modelRenderer, float x, float y, float z) {
        modelRenderer.rotateAngleX = x;
        modelRenderer.rotateAngleY = y;
        modelRenderer.rotateAngleZ = z;
    }
}
