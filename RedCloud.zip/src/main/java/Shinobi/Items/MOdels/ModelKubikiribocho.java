package Shinobi.Items.MOdels;

import net.minecraft.client.model.ModelBase;
import net.minecraft.client.model.ModelRenderer;
import net.minecraft.entity.Entity;
import org.lwjgl.opengl.GL11;

/**
 * ModelKubikiribocho - Either Mojang or a mod author
 * Created using Tabula 4.1.1
 */
public class ModelKubikiribocho extends ModelBase {
    public ModelRenderer T3;
    public ModelRenderer B5;
    public ModelRenderer T1;
    public ModelRenderer q1;
    public ModelRenderer B3;
    public ModelRenderer b4;
    public ModelRenderer T2;
    public ModelRenderer q2;
    public ModelRenderer Hilt;
    public ModelRenderer Blade2;
    public ModelRenderer Handle;
    public ModelRenderer H2;
    public ModelRenderer B2;
    public ModelRenderer H1;
    public ModelRenderer BladeB;
    public ModelRenderer Blade1;
    public ModelRenderer B6;
    public ModelRenderer T4;
    public ModelRenderer p1;
    public ModelRenderer shape20;

    public ModelKubikiribocho() {
        this.textureWidth = 64;
        this.textureHeight = 32;
        this.b4 = new ModelRenderer(this, 2, 4);
        this.b4.setRotationPoint(1.0F, -13.0F, 0.0F);
        this.b4.addBox(2.0F, -29.2F, 0.0F, 3, 4, 1, 0.0F);
        this.T4 = new ModelRenderer(this, 18, 16);
        this.T4.setRotationPoint(0.7F, 5.8F, -0.3F);
        this.T4.addBox(0.0F, 0.0F, 0.0F, 2, 3, 2, 0.0F);
        this.Hilt = new ModelRenderer(this, 0, 23);
        this.Hilt.setRotationPoint(-6.0F, -6.4F, -1.0F);
        this.Hilt.addBox(0.0F, 0.0F, 0.0F, 15, 1, 3, 0.0F);
        this.shape20 = new ModelRenderer(this, 40, 10);
        this.shape20.setRotationPoint(-3.0F, -23.2F, 0.0F);
        this.shape20.addBox(0.0F, 0.0F, 0.0F, 9, 7, 1, 0.0F);
        this.q1 = new ModelRenderer(this, 20, 10);
        this.q1.setRotationPoint(0.53F, -17.0F, 0.0F);
        this.q1.addBox(0.0F, 0.0F, 0.0F, 2, 1, 1, 0.0F);
        this.setRotateAngle(q1, 0.0F, 0.0F, 0.7853981633974483F);
        this.H1 = new ModelRenderer(this, 48, 5);
        this.H1.setRotationPoint(-1.0F, -8.0F, -0.48F);
        this.H1.addBox(0.0F, 0.0F, 0.0F, 5, 2, 2, 0.0F);
        this.p1 = new ModelRenderer(this, 0, 17);
        this.p1.setRotationPoint(5.6F, -47.05F, 0.0F);
        this.p1.addBox(0.0F, 0.0F, 0.0F, 1, 1, 1, 0.0F);
        this.setRotateAngle(p1, 0.0F, 0.0F, -0.13962634015954636F);
        this.T2 = new ModelRenderer(this, 18, 16);
        this.T2.setRotationPoint(0.7F, -1.9F, -0.3F);
        this.T2.addBox(0.0F, 0.0F, 0.0F, 2, 3, 2, 0.0F);
        this.Blade1 = new ModelRenderer(this, 40, 10);
        this.Blade1.setRotationPoint(-3.0F, -39.1F, 0.0F);
        this.Blade1.addBox(0.0F, 0.0F, 0.0F, 9, 16, 1, 0.0F);
        this.q2 = new ModelRenderer(this, 20, 10);
        this.q2.setRotationPoint(0.0F, -12.2F, 0.0F);
        this.q2.addBox(0.0F, 0.0F, 0.0F, 2, 1, 1, 0.0F);
        this.setRotateAngle(q2, 0.0F, 0.0F, -0.7853981633974483F);
        this.H2 = new ModelRenderer(this, 11, 5);
        this.H2.setRotationPoint(-0.5F, -9.0F, -0.5F);
        this.H2.addBox(0.0F, 0.0F, 0.0F, 4, 1, 2, 0.0F);
        this.B3 = new ModelRenderer(this, 0, 10);
        this.B3.setRotationPoint(-3.0F, -44.0F, 0.0F);
        this.B3.addBox(0.0F, 0.0F, 0.0F, 2, 5, 1, 0.0F);
        this.Blade2 = new ModelRenderer(this, 0, 20);
        this.Blade2.setRotationPoint(-1.0F, -46.1F, 0.0F);
        this.Blade2.addBox(0.0F, 0.0F, 0.0F, 7, 2, 1, 0.0F);
        this.setRotateAngle(Blade2, 0.0F, 0.0F, -0.13962634015954636F);
        this.B5 = new ModelRenderer(this, 0, 0);
        this.B5.setRotationPoint(-2.0F, -45.1F, 0.0F);
        this.B5.addBox(0.0F, 0.0F, 0.0F, 8, 3, 1, 0.0F);
        this.Handle = new ModelRenderer(this, 28, 15);
        this.Handle.setRotationPoint(1.0F, -5.4F, 0.0F);
        this.Handle.addBox(0.0F, 0.0F, 0.0F, 1, 14, 1, 0.0F);
        this.BladeB = new ModelRenderer(this, 25, 0);
        this.BladeB.setRotationPoint(-3.0F, -12.2F, 0.0F);
        this.BladeB.addBox(0.0F, 0.0F, 0.0F, 9, 6, 1, 0.0F);
        this.T1 = new ModelRenderer(this, 18, 16);
        this.T1.setRotationPoint(0.7F, -5.5F, -0.3F);
        this.T1.addBox(0.0F, 0.0F, 0.0F, 2, 3, 2, 0.0F);
        this.T3 = new ModelRenderer(this, 18, 16);
        this.T3.setRotationPoint(0.7F, 2.0F, -0.3F);
        this.T3.addBox(0.0F, 0.0F, 0.0F, 2, 3, 2, 0.0F);
        this.B2 = new ModelRenderer(this, 48, 0);
        this.B2.setRotationPoint(1.0F, -16.2F, 0.0F);
        this.B2.addBox(0.0F, 0.0F, 0.0F, 5, 4, 1, 0.0F);
        this.B6 = new ModelRenderer(this, 10, 10);
        this.B6.setRotationPoint(-1.0F, -46.1F, 0.0F);
        this.B6.addBox(0.0F, 0.0F, 0.0F, 1, 3, 1, 0.0F);
        this.setRotateAngle(B6, -0.0F, 0.0F, 0.8377580409572781F);
    }

    @Override
    public void render(Entity entity, float f, float f1, float f2, float f3, float f4, float f5) { 
        this.b4.render(f5);
        GL11.glPushMatrix();
        GL11.glTranslatef(this.T4.offsetX, this.T4.offsetY, this.T4.offsetZ);
        GL11.glTranslatef(this.T4.rotationPointX * f5, this.T4.rotationPointY * f5, this.T4.rotationPointZ * f5);
        GL11.glScaled(0.8D, 0.8D, 0.8D);
        GL11.glTranslatef(-this.T4.offsetX, -this.T4.offsetY, -this.T4.offsetZ);
        GL11.glTranslatef(-this.T4.rotationPointX * f5, -this.T4.rotationPointY * f5, -this.T4.rotationPointZ * f5);
        this.T4.render(f5);
        GL11.glPopMatrix();
        this.Hilt.render(f5);
        this.shape20.render(f5);
        this.q1.render(f5);
        this.H1.render(f5);
        this.p1.render(f5);
        GL11.glPushMatrix();
        GL11.glTranslatef(this.T2.offsetX, this.T2.offsetY, this.T2.offsetZ);
        GL11.glTranslatef(this.T2.rotationPointX * f5, this.T2.rotationPointY * f5, this.T2.rotationPointZ * f5);
        GL11.glScaled(0.8D, 0.8D, 0.8D);
        GL11.glTranslatef(-this.T2.offsetX, -this.T2.offsetY, -this.T2.offsetZ);
        GL11.glTranslatef(-this.T2.rotationPointX * f5, -this.T2.rotationPointY * f5, -this.T2.rotationPointZ * f5);
        this.T2.render(f5);
        GL11.glPopMatrix();
        this.Blade1.render(f5);
        this.q2.render(f5);
        this.H2.render(f5);
        this.B3.render(f5);
        GL11.glPushMatrix();
        GL11.glTranslatef(this.Blade2.offsetX, this.Blade2.offsetY, this.Blade2.offsetZ);
        GL11.glTranslatef(this.Blade2.rotationPointX * f5, this.Blade2.rotationPointY * f5, this.Blade2.rotationPointZ * f5);
        GL11.glScaled(0.97D, 1.0D, 1.0D);
        GL11.glTranslatef(-this.Blade2.offsetX, -this.Blade2.offsetY, -this.Blade2.offsetZ);
        GL11.glTranslatef(-this.Blade2.rotationPointX * f5, -this.Blade2.rotationPointY * f5, -this.Blade2.rotationPointZ * f5);
        this.Blade2.render(f5);
        GL11.glPopMatrix();
        this.B5.render(f5);
        this.Handle.render(f5);
        this.BladeB.render(f5);
        GL11.glPushMatrix();
        GL11.glTranslatef(this.T1.offsetX, this.T1.offsetY, this.T1.offsetZ);
        GL11.glTranslatef(this.T1.rotationPointX * f5, this.T1.rotationPointY * f5, this.T1.rotationPointZ * f5);
        GL11.glScaled(0.8D, 0.8D, 0.8D);
        GL11.glTranslatef(-this.T1.offsetX, -this.T1.offsetY, -this.T1.offsetZ);
        GL11.glTranslatef(-this.T1.rotationPointX * f5, -this.T1.rotationPointY * f5, -this.T1.rotationPointZ * f5);
        this.T1.render(f5);
        GL11.glPopMatrix();
        GL11.glPushMatrix();
        GL11.glTranslatef(this.T3.offsetX, this.T3.offsetY, this.T3.offsetZ);
        GL11.glTranslatef(this.T3.rotationPointX * f5, this.T3.rotationPointY * f5, this.T3.rotationPointZ * f5);
        GL11.glScaled(0.8D, 0.8D, 0.8D);
        GL11.glTranslatef(-this.T3.offsetX, -this.T3.offsetY, -this.T3.offsetZ);
        GL11.glTranslatef(-this.T3.rotationPointX * f5, -this.T3.rotationPointY * f5, -this.T3.rotationPointZ * f5);
        this.T3.render(f5);
        GL11.glPopMatrix();
        this.B2.render(f5);
        GL11.glPushMatrix();
        GL11.glTranslatef(this.B6.offsetX, this.B6.offsetY, this.B6.offsetZ);
        GL11.glTranslatef(this.B6.rotationPointX * f5, this.B6.rotationPointY * f5, this.B6.rotationPointZ * f5);
        GL11.glScaled(0.9D, 1.0D, 1.0D);
        GL11.glTranslatef(-this.B6.offsetX, -this.B6.offsetY, -this.B6.offsetZ);
        GL11.glTranslatef(-this.B6.rotationPointX * f5, -this.B6.rotationPointY * f5, -this.B6.rotationPointZ * f5);
        this.B6.render(f5);
        GL11.glPopMatrix();
    }

    /**
     * This is a helper function from Tabula to set the rotation of model parts
     */
    public void setRotateAngle(ModelRenderer modelRenderer, float x, float y, float z) {
        modelRenderer.rotateAngleX = x;
        modelRenderer.rotateAngleY = y;
        modelRenderer.rotateAngleZ = z;
    }
}
