package Shinobi.Items.MOdels;

import net.minecraft.client.model.ModelBase;
import net.minecraft.client.model.ModelRenderer;
import net.minecraft.entity.Entity;
import org.lwjgl.opengl.GL11;

/**
 * ModelSamehada - Either Mojang or a mod author
 * Created using Tabula 4.1.1
 */
public class ModelShibuki extends ModelBase {
    public ModelRenderer Shape18;
    public ModelRenderer Shape10;
    public ModelRenderer Shape11;
    public ModelRenderer Shape12;
    public ModelRenderer Shape13;
    public ModelRenderer Shape15;
    public ModelRenderer Shape9;
    public ModelRenderer Shape1;
    public ModelRenderer Shape22;
    public ModelRenderer Shape23;
    public ModelRenderer shape26;

    public ModelShibuki() {
        this.textureWidth = 256;
        this.textureHeight = 256;
        this.Shape10 = new ModelRenderer(this, 0, 0);
        this.Shape10.setRotationPoint(4.0F, 17.5F, 4.5F);
        this.Shape10.addBox(0.6F, -55.0F, -5.0F, 2, 30, 2, 0.0F);
        this.Shape12 = new ModelRenderer(this, 0, 55);
        this.Shape12.setRotationPoint(1.1F, 25.2F, 0.0F);
        this.Shape12.addBox(-1.53F, -65.0F, -0.5F, 2, 2, 2, 0.0F);
        this.Shape1 = new ModelRenderer(this, 45, 0);
        this.Shape1.setRotationPoint(1.0F, 12.1F, 1.0F);
        this.Shape1.addBox(-1.0F, -19.0F, -1.0F, 1, 17, 1, 0.0F);
        this.Shape22 = new ModelRenderer(this, 0, 100);
        this.Shape22.setRotationPoint(-1.9F, 15.0F, -0.2F);
        this.Shape22.addBox(1.2F, -52.5F, 0.0F, 1, 30, 16, 0.0F);
        this.setRotateAngle(Shape22, 0.0F, -1.6318828506146983F, 0.0F);
        this.Shape11 = new ModelRenderer(this, 70, 0);
        this.Shape11.setRotationPoint(0.0F, 11.8F, 0.0F);
        this.Shape11.addBox(-2.0F, -49.6F, -2.0F, 5, 31, 5, 0.0F);
        this.Shape9 = new ModelRenderer(this, 0, 100);
        this.Shape9.setRotationPoint(-2.0F, 15.0F, 0.0F);
        this.Shape9.addBox(0.0F, -52.5F, 0.0F, 1, 30, 16, 0.0F);
        this.setRotateAngle(Shape9, 0.0F, -1.5707963267948966F, 0.0F);
        this.Shape13 = new ModelRenderer(this, 0, 0);
        this.Shape13.setRotationPoint(7.5F, 26.7F, -4.5F);
        this.Shape13.addBox(-1.0F, -63.87F, 5.1F, 2, 29, 2, 0.0F);
        this.Shape23 = new ModelRenderer(this, 0, 0);
        this.Shape23.setRotationPoint(5.0F, 15.5F, 0.0F);
        this.Shape23.addBox(0.0F, -25.0F, 0.0F, 1, 2, 2, 0.0F);
        this.setRotateAngle(Shape23, 0.0F, -1.5707963267948966F, 0.0F);
        this.Shape15 = new ModelRenderer(this, 0, 0);
        this.Shape15.setRotationPoint(5.0F, 22.6F, 0.0F);
        this.Shape15.addBox(0.0F, -60.0F, 0.0F, 1, 2, 2, 0.0F);
        this.setRotateAngle(Shape15, 0.0F, -1.5707963267948966F, 0.0F);
        this.Shape18 = new ModelRenderer(this, 0, 100);
        this.Shape18.setRotationPoint(-1.9F, 15.0F, 0.2F);
        this.Shape18.addBox(-1.2F, -52.5F, 0.0F, 1, 30, 16, 0.0F);
        this.setRotateAngle(Shape18, 0.0F, -1.5114551322270893F, 0.0F);
        this.shape26 = new ModelRenderer(this, 70, 2);
        this.shape26.setRotationPoint(0.5F, 11.8F, 0.5F);
        this.shape26.addBox(-3.0F, -49.6F, -1.5F, 6, 31, 3, 0.0F);
        this.setRotateAngle(shape26, 0.0F, 1.5707963267948966F, 0.0F);
    }

    @Override
    public void render(Entity entity, float f, float f1, float f2, float f3, float f4, float f5) { 
        this.Shape10.render(f5);
        this.Shape12.render(f5);
        this.Shape1.render(f5);
        this.Shape22.render(f5);
        this.Shape11.render(f5);
        this.Shape9.render(f5);
        GL11.glPushMatrix();
        GL11.glTranslatef(this.Shape13.offsetX, this.Shape13.offsetY, this.Shape13.offsetZ);
        GL11.glTranslatef(this.Shape13.rotationPointX * f5, this.Shape13.rotationPointY * f5, this.Shape13.rotationPointZ * f5);
        GL11.glScaled(1.0D, 1.0D, 0.8D);
        GL11.glTranslatef(-this.Shape13.offsetX, -this.Shape13.offsetY, -this.Shape13.offsetZ);
        GL11.glTranslatef(-this.Shape13.rotationPointX * f5, -this.Shape13.rotationPointY * f5, -this.Shape13.rotationPointZ * f5);
        this.Shape13.render(f5);
        GL11.glPopMatrix();
        this.Shape23.render(f5);
        this.Shape15.render(f5);
        this.Shape18.render(f5);
        this.shape26.render(f5);
    }

    /**
     * This is a helper function from Tabula to set the rotation of model parts
     */
    public void setRotateAngle(ModelRenderer modelRenderer, float x, float y, float z) {
        modelRenderer.rotateAngleX = x;
        modelRenderer.rotateAngleY = y;
        modelRenderer.rotateAngleZ = z;
    }
}
