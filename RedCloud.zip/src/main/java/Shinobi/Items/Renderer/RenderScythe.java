package Shinobi.Items.Renderer;

import org.lwjgl.opengl.GL11;

import Shinobi.Items.MOdels.SCYTHE;
import net.minecraft.client.Minecraft;
import net.minecraft.entity.Entity;
import net.minecraft.item.ItemStack;
import net.minecraft.util.ResourceLocation;
import net.minecraftforge.client.IItemRenderer;


public class RenderScythe implements IItemRenderer {
		private SCYTHE customModel;
		private ResourceLocation textures = (new ResourceLocation(""));

		public RenderScythe() {
			customModel = new SCYTHE();
		}

		@Override
		public boolean handleRenderType(ItemStack item, ItemRenderType type) {
			return true;
		}

		@Override
		public boolean shouldUseRenderHelper(ItemRenderType type, ItemStack item, ItemRendererHelper helper) {
			return true;
		}

		@Override
		public void renderItem(ItemRenderType type, ItemStack item, Object... data) {
			switch (type) {
				case ENTITY : {
					renderCustomModel(0.5F, 0.5F, 0.5F);
					break;
				}
				case EQUIPPED : {
					renderCustomModel(1.0F, 1.0F, 1.0F);
					break;
				}
				case EQUIPPED_FIRST_PERSON : {
					renderCustomModel(1.0F, 1.0F, 1.0F);
					break;
				}
				case INVENTORY : {
					renderCustomModel(0.0F, 0.8F, 0.0F);
					break;
				}
				default :
					break;
			}
		}

		private void renderCustomModel(float x, float y, float z) {
			Minecraft.getMinecraft().renderEngine.bindTexture(textures);
			GL11.glPushMatrix();
			GL11.glTranslatef(x, y, z);
			GL11.glRotatef(180, 1, 0, 0);
			GL11.glRotatef(-90, 0, 1, 0);
			customModel.render((Entity) null, 0.0F, 0.0F, -0.1F, 0.0F, 0.0F, 0.0625F);
			GL11.glPopMatrix();
		}

}