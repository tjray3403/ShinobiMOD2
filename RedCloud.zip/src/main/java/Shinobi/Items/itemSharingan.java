package Shinobi.Items;

import Shinobi.ShinobiVariables;
import net.minecraft.client.Minecraft;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.potion.PotionEffect;
import net.minecraft.world.World;

public class itemSharingan extends Item{
	private float width;
	private float height;
	private float eyeHeight;
	public itemSharingan() {
		this.setFull3D();
		this.setMaxStackSize(1);
		this.setMaxDamage(1);
	}
	
	public ItemStack onItemRightClick(ItemStack itemstack, World world, EntityPlayer entity){
		float var4 = 1.0F;
		int i = (int)(entity.prevPosX + (entity.posX - entity.prevPosX) * (double)var4);
		int j = (int)(entity.prevPosY + (entity.posY - entity.prevPosY) * (double)var4 + 1.62D - (double)entity.yOffset);
		int k = (int)(entity.prevPosZ + (entity.posZ - entity.prevPosZ) * (double)var4);

		if(ShinobiVariables.Sharingan==false){
		ShinobiVariables.Sharingan = true;
		
		width = ( Minecraft.getMinecraft().thePlayer.width * (1 / 3) );
		height = ( Minecraft.getMinecraft().thePlayer.height * (1 / 3) );
		eyeHeight = (Minecraft.getMinecraft().thePlayer.eyeHeight - 2.42F);

		}
		
		
		

			
			
					 
		
			
			

		return itemstack;
		}
	public void onUpdate(ItemStack itemstack, World world, Entity entity, int par4, boolean par5) {
		int i = (int)entity.posX;
		int j = (int)entity.posY;
		int k = (int)entity.posZ;

		if(ShinobiVariables.Sharingan==true){
		if(entity instanceof EntityLivingBase) ((EntityLivingBase)entity).addPotionEffect(new PotionEffect(1, 1, 5));
		if(entity instanceof EntityLivingBase) ((EntityLivingBase)entity).addPotionEffect(new PotionEffect(5, 1, 3));
		if(entity instanceof EntityLivingBase) ((EntityLivingBase)entity).addPotionEffect(new PotionEffect(10, 1, 3));
		if(entity instanceof EntityLivingBase) ((EntityLivingBase)entity).addPotionEffect(new PotionEffect(16, 1, 4));
		}

}
	

}
