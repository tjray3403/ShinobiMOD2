package Shinobi.Keys;

import org.lwjgl.input.Keyboard;

import Shinobi.ShinobiMod;
import Shinobi.ShinobiVariables;
import cpw.mods.fml.client.FMLClientHandler;
import cpw.mods.fml.client.registry.ClientRegistry;
import cpw.mods.fml.common.FMLCommonHandler;
import cpw.mods.fml.common.eventhandler.SubscribeEvent;
import cpw.mods.fml.common.gameevent.InputEvent;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiChat;
import net.minecraft.client.settings.KeyBinding;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.server.MinecraftServer;
import net.minecraft.util.Vec3;
import net.minecraft.world.World;

public class KeyCHandler {
	
	private static final String desc2 = "key.tut_inventory.desc2";
	private static final int keyValues2 = Keyboard.KEY_C;
	static KeyBinding keys2;

	public KeyCHandler() {
		keys2 = new KeyBinding(desc2, keyValues2, "key.tutorial.category2");
		ClientRegistry.registerKeyBinding(keys2);
	}
	
	@SubscribeEvent
	public void onKeyInput(InputEvent.KeyInputEvent event) {
		if (!FMLClientHandler.instance().isGUIOpen(GuiChat.class)) {
			if (keys2.isPressed()) {
				EntityPlayer entity = Minecraft.getMinecraft().thePlayer;
				Vec3 playerLookVector = entity.getLookVec();
				float var4 = 1.0F;
				int i = (int) (entity.posX+10*playerLookVector.xCoord);
				int k = (int) (entity.posZ+10*playerLookVector.zCoord);
				int j = (int) (entity.posY+1*playerLookVector.yCoord);
				/*World world = null;
				WorldServer[] list = MinecraftServer.getServer().worldServers;
				for(WorldServer ins : list){
				if(ins.provider.dimensionId==entity.worldObj.provider.dimensionId)
					world = ins;
				}
				if(world==null)
					world = list[0];
				*/
				MinecraftServer server = FMLCommonHandler.instance().getMinecraftServerInstance();
				World world = server.worldServers[0];
            	if(ShinobiVariables.MangekyoSharingan1==true){
            		if (true) {
						world.setBlock(i, j-1, k, ShinobiMod.blockBlackFlame, 0, 2);
					}

            	}
            	
            	
            	
}

			}
		}
	}


