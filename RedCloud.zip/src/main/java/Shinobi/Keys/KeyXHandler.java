package Shinobi.Keys;

import org.lwjgl.input.Keyboard;

import Shinobi.ShinobiVariables;
import cpw.mods.fml.client.FMLClientHandler;
import cpw.mods.fml.client.registry.ClientRegistry;
import cpw.mods.fml.common.FMLCommonHandler;
import cpw.mods.fml.common.eventhandler.SubscribeEvent;
import cpw.mods.fml.common.gameevent.InputEvent;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiChat;
import net.minecraft.client.settings.KeyBinding;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.server.MinecraftServer;
import net.minecraft.world.World;

public class KeyXHandler {
	
	private static final String desc1 = "key.tut_inventory.desc1";
	private static final int keyValues1 = Keyboard.KEY_X;
	static KeyBinding keys1;

	public KeyXHandler() {
		keys1 = new KeyBinding(desc1, keyValues1, "key.tutorial.category1");
		ClientRegistry.registerKeyBinding(keys1);
	}
	
	@SubscribeEvent
	public void onKeyInput(InputEvent.KeyInputEvent event) {
		if (!FMLClientHandler.instance().isGUIOpen(GuiChat.class)) {
			if (keys1.isPressed()) {
				EntityPlayer entity = Minecraft.getMinecraft().thePlayer;
				int i = (int)entity.posX;
				int j = (int)entity.posY;
				int k = (int)entity.posZ;
				/*World world = null;
				WorldServer[] list = MinecraftServer.getServer().worldServers;
				for(WorldServer ins : list){
				if(ins.provider.dimensionId==entity.worldObj.provider.dimensionId)
					world = ins;
				}
				if(world==null)
					world = list[0];
				*/
				MinecraftServer server = FMLCommonHandler.instance().getMinecraftServerInstance();
				World world = server.worldServers[0];

            	if(ShinobiVariables.Sharingan==true){
        			ShinobiVariables.MangekyoSharingan1 = true;

            	}
            	
            	
            	
}

			}
		}
	}


