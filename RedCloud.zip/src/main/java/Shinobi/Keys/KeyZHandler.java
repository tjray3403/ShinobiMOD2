package Shinobi.Keys;

import org.lwjgl.input.Keyboard;

import Shinobi.ShinobiVariables;
import cpw.mods.fml.client.FMLClientHandler;
import cpw.mods.fml.client.registry.ClientRegistry;
import cpw.mods.fml.common.FMLCommonHandler;
import cpw.mods.fml.common.eventhandler.SubscribeEvent;
import cpw.mods.fml.common.gameevent.InputEvent;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiChat;
import net.minecraft.client.settings.KeyBinding;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.server.MinecraftServer;
import net.minecraft.world.World;

public class KeyZHandler {
	
	private static final String desc = "key.tut_inventory.desc";
	private static final int keyValues = Keyboard.KEY_Z;
	static KeyBinding keys;

	public KeyZHandler() {
		keys = new KeyBinding(desc, keyValues, "key.tutorial.category");
		ClientRegistry.registerKeyBinding(keys);
	}
	
	@SubscribeEvent
	public void onKeyInput(InputEvent.KeyInputEvent event) {
		if (!FMLClientHandler.instance().isGUIOpen(GuiChat.class)) {
			if (keys.isPressed()) {
				EntityPlayer entity = Minecraft.getMinecraft().thePlayer;
				int i = (int)entity.posX;
				int j = (int)entity.posY;
				int k = (int)entity.posZ;
				/*World world = null;
				WorldServer[] list = MinecraftServer.getServer().worldServers;
				for(WorldServer ins : list){
				if(ins.provider.dimensionId==entity.worldObj.provider.dimensionId)
					world = ins;
				}
				if(world==null)
					world = list[0];
				*/
				MinecraftServer server = FMLCommonHandler.instance().getMinecraftServerInstance();
				World world = server.worldServers[0];

            	if(true){
            		ShinobiVariables.Sharingan = false;
            		ShinobiVariables.MangekyoSharingan1 = false;
            		ShinobiVariables.RedSusanoo = false;
            		ShinobiVariables.RedSusanoo2 = false;
            		ShinobiVariables.RedSusanoo3 = false;
            		ShinobiVariables.RedSusanoo3shield = false;
            		ShinobiVariables.RedSusanoo4 = false;
            		ShinobiVariables.RedSusanoo5 = false;
            		ShinobiVariables.Paperninjutsu = false;
            		ShinobiVariables.PaperWings = false;


}
            	
}

			}
		}
	}


