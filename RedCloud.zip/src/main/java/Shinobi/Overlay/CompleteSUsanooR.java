 /** package Shinobi.Overlay;

import Shinobi.ShinobiVariables;
import Shinobi.Overlay.Models.ModelRedCompleteSUsanoo;
import net.minecraft.client.entity.AbstractClientPlayer;
import net.minecraft.client.model.ModelBlaze;
import net.minecraft.client.renderer.entity.RenderPlayer;
import net.minecraft.util.ResourceLocation;

public class CompleteSUsanooR extends RenderPlayer
{
    public CompleteSUsanooR(){
        super();
        if(ShinobiVariables.RedCompleteSusanoo==true) {
        this.mainModel = new ModelRedCompleteSUsanoo();
    }
    }
    protected ResourceLocation getEntityTexture(AbstractClientPlayer player)
    {
        return new ResourceLocation("ninja:textures/entity/RedCompleteSUsanoo.png");
    }
}

**/