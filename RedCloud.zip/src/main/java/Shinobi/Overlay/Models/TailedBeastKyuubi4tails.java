package Shinobi.Overlay.Models;

import net.minecraft.client.model.ModelBase;
import net.minecraft.client.model.ModelRenderer;
import net.minecraft.entity.Entity;
import net.minecraft.util.MathHelper;

public class TailedBeastKyuubi4tails extends ModelBase
{
  //fields
    ModelRenderer head;
    ModelRenderer body;
    ModelRenderer rightarm;
    ModelRenderer leftarm;
    ModelRenderer rightleg;
    ModelRenderer leftleg;
    ModelRenderer T1;
    ModelRenderer T2;
    ModelRenderer T3;
    ModelRenderer T4;
    ModelRenderer M1;
    ModelRenderer M2;
    ModelRenderer RIGHTARM2;
    ModelRenderer LEFTARM2;
    ModelRenderer M3;
    ModelRenderer M4;
    ModelRenderer RE1;
    ModelRenderer LE2;
    ModelRenderer RE2;
    ModelRenderer LEE2;
    ModelRenderer RE3;
    ModelRenderer LE3;
    ModelRenderer RIGHTLEG2;
    ModelRenderer LEFTLEG2;
  
  public TailedBeastKyuubi4tails()
  {
    textureWidth = 128;
    textureHeight = 128;
    
      head = new ModelRenderer(this, 0, 74);
      head.addBox(-4F, -8F, -4F, 8, 8, 8);
      head.setRotationPoint(0F, 0F, 0F);
      head.setTextureSize(128, 128);
      head.mirror = true;
      setRotation(head, 0F, 0F, 0F);
      body = new ModelRenderer(this, 16, 16);
      body.addBox(-4F, 0F, -2F, 8, 14, 4);
      body.setRotationPoint(0F, 0F, 0F);
      body.setTextureSize(128, 128);
      body.mirror = true;
      setRotation(body, 0.4363323F, 0F, 0F);
      rightarm = new ModelRenderer(this, 40, 16);
      rightarm.addBox(-3F, -2F, -2F, 4, 6, 4);
      rightarm.setRotationPoint(-5F, 2F, 0F);
      rightarm.setTextureSize(128, 128);
      rightarm.mirror = true;
      setRotation(rightarm, 0F, 0F, 0F);
      leftarm = new ModelRenderer(this, 40, 16);
      leftarm.addBox(-1F, -2F, -2F, 4, 6, 4);
      leftarm.setRotationPoint(5F, 2F, 0F);
      leftarm.setTextureSize(128, 128);
      leftarm.mirror = true;
      setRotation(leftarm, 0F, 0F, 0F);
      rightleg = new ModelRenderer(this, 0, 16);
      rightleg.addBox(-2F, 0F, -2F, 4, 6, 4);
      rightleg.setRotationPoint(-2F, 12F, 6F);
      rightleg.setTextureSize(128, 128);
      rightleg.mirror = true;
      setRotation(rightleg, -0.5235988F, 0F, 0.1745329F);
      leftleg = new ModelRenderer(this, 0, 16);
      leftleg.addBox(-2F, 0F, -2F, 4, 6, 4);
      leftleg.setRotationPoint(2F, 12F, 6F);
      leftleg.setTextureSize(128, 128);
      leftleg.mirror = true;
      setRotation(leftleg, -0.5235988F, 0F, -0.1745329F);
      T1 = new ModelRenderer(this, 0, 51);
      T1.addBox(-2.5F, -2.5F, 0F, 5, 5, 17);
      T1.setRotationPoint(-2F, 11F, 6F);
      T1.setTextureSize(128, 128);
      T1.mirror = true;
      setRotation(T1, 0.1047198F, -0.3141593F, 0F);
      T2 = new ModelRenderer(this, 0, 0);
      T2.addBox(-2.5F, -2.5F, 0F, 5, 5, 17);
      T2.setRotationPoint(2F, 11F, 6F);
      T2.setTextureSize(128, 128);
      T2.mirror = true;
      setRotation(T2, -0.0872665F, 0.3665191F, 0F);
      T3 = new ModelRenderer(this, 0, 0);
      T3.addBox(-2.5F, -2.5F, 1F, 5, 5, 15);
      T3.setRotationPoint(0F, 10F, 5F);
      T3.setTextureSize(128, 128);
      T3.mirror = true;
      setRotation(T3, 0.3839724F, 0F, 0F);
      T4 = new ModelRenderer(this, 0, 0);
      T4.addBox(-2.5F, -2.5F, 0F, 5, 5, 17);
      T4.setRotationPoint(0F, 12F, 7F);
      T4.setTextureSize(128, 128);
      T4.mirror = true;
      setRotation(T4, -0.1396263F, 0.0174533F, 0F);
      M1 = new ModelRenderer(this, 0, 0);
      M1.addBox(-2.5F, -2.5F, 0F, 5, 5, 20);
      M1.setRotationPoint(0F, 4F, 19F);
      M1.setTextureSize(128, 128);
      M1.mirror = true;
      setRotation(M1, 0.6457718F, -0.122173F, -0.2792527F);
      M2 = new ModelRenderer(this, 0, 0);
      M2.addBox(-2.5F, -2.5F, 0F, 5, 5, 20);
      M2.setRotationPoint(-7F, 9F, 21F);
      M2.setTextureSize(128, 128);
      M2.mirror = true;
      setRotation(M2, -0.1570796F, -0.418879F, 0F);
      RIGHTARM2 = new ModelRenderer(this, 0, 0);
      RIGHTARM2.addBox(-2F, 0F, -2F, 4, 6, 4);
      RIGHTARM2.setRotationPoint(-6F, 6F, 0F);
      RIGHTARM2.setTextureSize(128, 128);
      RIGHTARM2.mirror = true;
      setRotation(RIGHTARM2, -0.8726646F, 0F, 0F);
      LEFTARM2 = new ModelRenderer(this, 0, 0);
      LEFTARM2.addBox(-2F, 0F, -2F, 4, 6, 4);
      LEFTARM2.setRotationPoint(6F, 6F, 0F);
      LEFTARM2.setTextureSize(128, 128);
      LEFTARM2.mirror = true;
      setRotation(LEFTARM2, -0.8726646F, 0F, 0F);
      M3 = new ModelRenderer(this, 0, 0);
      M3.addBox(-2.5F, -2.5F, 0F, 5, 5, 20);
      M3.setRotationPoint(8F, 12F, 21F);
      M3.setTextureSize(128, 128);
      M3.mirror = true;
      setRotation(M3, 0.3665191F, 0.2094395F, 0F);
      M4 = new ModelRenderer(this, 0, 0);
      M4.addBox(-2.5F, -2.5F, 0F, 5, 5, 20);
      M4.setRotationPoint(0F, 14F, 23F);
      M4.setTextureSize(128, 128);
      M4.mirror = true;
      setRotation(M4, -0.2268928F, 0.1047198F, -0.2268928F);
      RE1 = new ModelRenderer(this, 0, 0);
      RE1.addBox(-5F, -9F, 4F, 3, 4, 3);
      RE1.setRotationPoint(0F, 0F, 0F);
      RE1.setTextureSize(128, 128);
      RE1.mirror = true;
      setRotation(RE1, 0F, 0F, 0F);
      LE2 = new ModelRenderer(this, 0, 0);
      LE2.addBox(2F, -9F, 4F, 3, 4, 3);
      LE2.setRotationPoint(0F, 0F, 0F);
      LE2.setTextureSize(128, 128);
      LE2.mirror = true;
      setRotation(LE2, 0F, 0F, 0F);
      RE2 = new ModelRenderer(this, 0, 0);
      RE2.addBox(-6F, -10F, 7F, 4, 4, 8);
      RE2.setRotationPoint(0F, 0F, 0F);
      RE2.setTextureSize(128, 128);
      RE2.mirror = true;
      setRotation(RE2, 0F, 0F, 0F);
      LEE2 = new ModelRenderer(this, 0, 0);
      LEE2.addBox(2F, -10F, 7F, 4, 4, 8);
      LEE2.setRotationPoint(0F, 0F, 0F);
      LEE2.setTextureSize(128, 128);
      LEE2.mirror = true;
      setRotation(LEE2, 0F, 0F, 0F);
      RE3 = new ModelRenderer(this, 0, 0);
      RE3.addBox(-4F, -10F, 15F, 2, 2, 2);
      RE3.setRotationPoint(0F, 0F, 0F);
      RE3.setTextureSize(128, 128);
      RE3.mirror = true;
      setRotation(RE3, 0F, 0F, 0F);
      LE3 = new ModelRenderer(this, 0, 0);
      LE3.addBox(2F, -10F, 15F, 2, 2, 2);
      LE3.setRotationPoint(0F, 0F, 0F);
      LE3.setTextureSize(128, 128);
      LE3.mirror = true;
      setRotation(LE3, 0F, 0F, 0F);
      RIGHTLEG2 = new ModelRenderer(this, 0, 0);
      RIGHTLEG2.addBox(-2F, 0F, -2F, 4, 8, 4);
      RIGHTLEG2.setRotationPoint(-3F, 16F, 3F);
      RIGHTLEG2.setTextureSize(128, 128);
      RIGHTLEG2.mirror = true;
      setRotation(RIGHTLEG2, 0F, 0F, 0F);
      LEFTLEG2 = new ModelRenderer(this, 0, 12);
      LEFTLEG2.addBox(-2F, 0F, -2F, 4, 8, 4);
      LEFTLEG2.setRotationPoint(3F, 16F, 3F);
      LEFTLEG2.setTextureSize(128, 128);
      LEFTLEG2.mirror = true;
      setRotation(LEFTLEG2, 0F, 0F, 0F);
      
     
    
      
  }
  
  public void render(Entity entity, float f, float f1, float f2, float f3, float f4, float f5)
  {
    super.render(entity, f, f1, f2, f3, f4, f5);
    setRotationAngles(f, f1, f2, f3, f4, f5, entity);
    head.render(f5);
    body.render(f5);
    rightarm.render(f5);
    leftarm.render(f5);
    rightleg.render(f5);
    leftleg.render(f5);
    T1.render(f5);
    T2.render(f5);
    T3.render(f5);
    T4.render(f5);
    M1.render(f5);
    M2.render(f5);
    RIGHTARM2.render(f5);
    LEFTARM2.render(f5);
    M3.render(f5);
    M4.render(f5);
    RE1.render(f5);
    LE2.render(f5);
    RE2.render(f5);
    LEE2.render(f5);
    RE3.render(f5);
    LE3.render(f5);
    RIGHTLEG2.render(f5);
    LEFTLEG2.render(f5);
    
  }
  
  private void setRotation(ModelRenderer model, float x, float y, float z)
  {
    model.rotateAngleX = x;
    model.rotateAngleY = y;
    model.rotateAngleZ = z;
  }
  
  public void setRotationAngles(float f, float f1, float f2, float f3, float f4, float f5, Entity entity)
  {
    super.setRotationAngles(f, f1, f2, f3, f4, f5, entity);
    this.head.rotateAngleY = f3 / (180F / (float)Math.PI);
    this.head.rotateAngleX = f4 / (180F / (float)Math.PI);
    this.RE1.rotateAngleY = f3 / (180F / (float)Math.PI);
    this.RE1.rotateAngleX = f4 / (180F / (float)Math.PI);
    this.LE2.rotateAngleY = f3 / (180F / (float)Math.PI);
    this.LE2.rotateAngleX = f4 / (180F / (float)Math.PI);
    this.RE2.rotateAngleY = f3 / (180F / (float)Math.PI);
    this.RE2.rotateAngleX = f4 / (180F / (float)Math.PI);
    this.LEE2.rotateAngleY = f3 / (180F / (float)Math.PI);
    this.LEE2.rotateAngleX = f4 / (180F / (float)Math.PI);
    this.RE3.rotateAngleY = f3 / (180F / (float)Math.PI);
    this.RE3.rotateAngleX = f4 / (180F / (float)Math.PI);
    this.LE3.rotateAngleY = f3 / (180F / (float)Math.PI);
    this.LE3.rotateAngleX = f4 / (180F / (float)Math.PI);
    this.leftleg.rotateAngleX = MathHelper.cos(f * 1.0F) * -1.0F * f1;
    this.rightleg.rotateAngleX = MathHelper.cos(f * 1.0F) * 1.0F * f1;
    this.rightarm.rotateAngleX = MathHelper.cos(f * 0.6662F + (float)Math.PI) * 2.0F * f1 * 0.5F;
    this.leftarm.rotateAngleX = MathHelper.cos(f * 0.6662F) * 2.0F * f1 * 0.5F;

  }

}
