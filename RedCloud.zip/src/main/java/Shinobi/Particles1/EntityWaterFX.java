package Shinobi.Particles1;


import net.minecraft.client.particle.EntityAuraFX;
import net.minecraft.world.World;

public class EntityWaterFX extends EntityAuraFX
{
    public EntityWaterFX(World parWorld,
            double parX, double parY, double parZ,
            double parMotionX, double parMotionY, double parMotionZ) 
    {
        super(parWorld, parX, parY, parZ, parMotionX, parMotionY, parMotionZ);
        setParticleTextureIndex(0);
        particleScale = 2.0F;
        setRBGColorF(0x1e74ff, 0x1e74ff, 0x1e74ff);
    }
}