package Shinobi.Proxy;

import java.util.HashMap;
import java.util.Map;

import Shinobi.ShinobiMod;
import Shinobi.Blocks.Models.Modeldeathpos;
import Shinobi.Blocks.Renderers.RenderBlockDeathPos;
import Shinobi.Blocks.TileEntity.DeathPoss;
import Shinobi.Entitys.EntityDeathPos;
import Shinobi.Entitys.Entitys.Entity3rdKazekagePuppet;
import Shinobi.Entitys.Entitys.EntityClayBird;
import Shinobi.Entitys.Entitys.EntityClayDragon;
import Shinobi.Entitys.Entitys.EntityClaySpider;
import Shinobi.Entitys.Entitys.EntityCrow;
import Shinobi.Entitys.Entitys.EntityDeidara;
import Shinobi.Entitys.Entitys.EntityFire;
import Shinobi.Entitys.Entitys.EntityHidan;
import Shinobi.Entitys.Entitys.EntityHidanHurt;
import Shinobi.Entitys.Entitys.EntityItachi;
import Shinobi.Entitys.Entitys.EntityKakuzu;
import Shinobi.Entitys.Entitys.EntityKakuzu3;
import Shinobi.Entitys.Entitys.EntityKisame;
import Shinobi.Entitys.Entitys.EntityKonan;
import Shinobi.Entitys.Entitys.EntityLightning;
import Shinobi.Entitys.Entitys.EntityPainAnimal;
import Shinobi.Entitys.Entitys.EntityPainAsura;
import Shinobi.Entitys.Entitys.EntityPainDeva;
import Shinobi.Entitys.Entitys.EntityPainHuman;
import Shinobi.Entitys.Entitys.EntityPainNaraka;
import Shinobi.Entitys.Entitys.EntityPainPreta;
import Shinobi.Entitys.Entitys.EntityPaperWings;
import Shinobi.Entitys.Entitys.EntityPuppetSasori;
import Shinobi.Entitys.Entitys.EntitySMChameleon;
import Shinobi.Entitys.Entitys.EntitySMChimera;
import Shinobi.Entitys.Entitys.EntitySMChimera3;
import Shinobi.Entitys.Entitys.EntitySMDrillBird;
import Shinobi.Entitys.Entitys.EntitySMKoH;
import Shinobi.Entitys.Entitys.EntitySMRhino;
import Shinobi.Entitys.Entitys.EntitySasori;
import Shinobi.Entitys.Entitys.EntitySasoriHiruko;
import Shinobi.Entitys.Entitys.EntityShadowClone;
import Shinobi.Entitys.Entitys.EntityShinUchiha;
import Shinobi.Entitys.Entitys.EntityShuriken;
import Shinobi.Entitys.Entitys.EntitySusanooItachi;
import Shinobi.Entitys.Entitys.EntityTobi;
import Shinobi.Entitys.Entitys.EntityUchihaShin;
import Shinobi.Entitys.Entitys.EntityUchihaclone;
import Shinobi.Entitys.Entitys.EntityWater;
import Shinobi.Entitys.Entitys.EntityWhiteZetsu;
import Shinobi.Entitys.Entitys.EntityWind;
import Shinobi.Entitys.Entitys.EntityZetsu;
import Shinobi.Entitys.Models.Model3rdKazePuppet;
import Shinobi.Entitys.Models.ModelC3;
import Shinobi.Entitys.Models.ModelC4;
import Shinobi.Entitys.Models.ModelChameleonS;
import Shinobi.Entitys.Models.ModelChimera;
import Shinobi.Entitys.Models.ModelChimera3h;
import Shinobi.Entitys.Models.ModelClayBird;
import Shinobi.Entitys.Models.ModelClayDRagon;
import Shinobi.Entitys.Models.ModelCloneUchihA;
import Shinobi.Entitys.Models.ModelCrow;
import Shinobi.Entitys.Models.ModelDeidara;
import Shinobi.Entitys.Models.ModelDrillBeakBird;
import Shinobi.Entitys.Models.ModelHidan;
import Shinobi.Entitys.Models.ModelHurtHidan;
import Shinobi.Entitys.Models.ModelItachi;
import Shinobi.Entitys.Models.ModelKakuzuEGF;
import Shinobi.Entitys.Models.ModelKisame;
import Shinobi.Entitys.Models.ModelKoh;
import Shinobi.Entitys.Models.ModelKonan;
import Shinobi.Entitys.Models.ModelPain;
import Shinobi.Entitys.Models.ModelPainAsura;
import Shinobi.Entitys.Models.ModelPuppet;
import Shinobi.Entitys.Models.ModelRhinoSum;
import Shinobi.Entitys.Models.ModelSasori;
import Shinobi.Entitys.Models.ModelSasoriHiruko;
import Shinobi.Entitys.Models.ModelShinUchiha;
import Shinobi.Entitys.Models.ModelStar;
import Shinobi.Entitys.Models.ModelSusanooItachi;
import Shinobi.Entitys.Models.ModelTobi;
import Shinobi.Entitys.Models.ModelZetsu;
import Shinobi.Entitys.Models.Modelkakuzu;
import Shinobi.Entitys.Models.Modellightning;
import Shinobi.Entitys.Models.Modelwaterandfire;
import Shinobi.Entitys.Models.Modelwind;
import Shinobi.Entitys.Models.ShinUchihaB;
import Shinobi.Entitys.Models.OAZPI.models.ModelPaperWings;
import Shinobi.Entitys.Projectiles.EntityAsuraHand;
import Shinobi.Entitys.Projectiles.EntityC2;
import Shinobi.Entitys.Projectiles.EntityC3;
import Shinobi.Entitys.Projectiles.EntityC4;
import Shinobi.Entitys.Projectiles.EntityChakraRod;
import Shinobi.Entitys.Projectiles.EntityFireBlast;
import Shinobi.Entitys.Projectiles.EntityGreatFireball;
import Shinobi.Entitys.Projectiles.EntityKunai;
import Shinobi.Entitys.Projectiles.EntityLShark;
import Shinobi.Entitys.Projectiles.EntityLightningBlast;
import Shinobi.Entitys.Projectiles.EntityMShark;
import Shinobi.Entitys.Projectiles.EntityMagnetCube;
import Shinobi.Entitys.Projectiles.EntityMagnetSpread;
import Shinobi.Entitys.Projectiles.EntityMagnetTriangle;
import Shinobi.Entitys.Projectiles.EntityNeedles;
import Shinobi.Entitys.Projectiles.EntityPaperBomb;
import Shinobi.Entitys.Projectiles.EntityPaperChakram;
import Shinobi.Entitys.Projectiles.EntityPaperPerson;
import Shinobi.Entitys.Projectiles.EntityPaperTwister;
import Shinobi.Entitys.Projectiles.EntityParticleX;
import Shinobi.Entitys.Projectiles.EntityPlanetaryDev;
import Shinobi.Entitys.Projectiles.EntityPuppetArmattack;
import Shinobi.Entitys.Projectiles.EntityRinneBullet;
import Shinobi.Entitys.Projectiles.EntitySShark;
import Shinobi.Entitys.Projectiles.EntityWaterBlast;
import Shinobi.Entitys.Projectiles.EntityWindBlast;
import Shinobi.Entitys.Projectiles.EntityWoodVines;
import Shinobi.Entitys.Projectiles.EntityYasaka;
import Shinobi.Entitys.Renderers.Render3rdKazekagepuppet;
import Shinobi.Entitys.Renderers.RenderClayBird;
import Shinobi.Entitys.Renderers.RenderClayDragon;
import Shinobi.Entitys.Renderers.RenderClaySpider;
import Shinobi.Entitys.Renderers.RenderCloneUchiha;
import Shinobi.Entitys.Renderers.RenderCrow;
import Shinobi.Entitys.Renderers.RenderDeathPoss;
import Shinobi.Entitys.Renderers.RenderDeidara;
import Shinobi.Entitys.Renderers.RenderFireEntity;
import Shinobi.Entitys.Renderers.RenderHidan;
import Shinobi.Entitys.Renderers.RenderHurtHidan;
import Shinobi.Entitys.Renderers.RenderItachi;
import Shinobi.Entitys.Renderers.RenderKakuzu;
import Shinobi.Entitys.Renderers.RenderKakuzu3;
import Shinobi.Entitys.Renderers.RenderKisame;
import Shinobi.Entitys.Renderers.RenderKonan;
import Shinobi.Entitys.Renderers.RenderLightning;
import Shinobi.Entitys.Renderers.RenderPainAnimal;
import Shinobi.Entitys.Renderers.RenderPainAsura;
import Shinobi.Entitys.Renderers.RenderPainDeva;
import Shinobi.Entitys.Renderers.RenderPainHuman;
import Shinobi.Entitys.Renderers.RenderPainNaraka;
import Shinobi.Entitys.Renderers.RenderPainPreta;
import Shinobi.Entitys.Renderers.RenderPaperWings;
import Shinobi.Entitys.Renderers.RenderPuppetSasori;
import Shinobi.Entitys.Renderers.RenderSMChameleon;
import Shinobi.Entitys.Renderers.RenderSMChimera;
import Shinobi.Entitys.Renderers.RenderSMChimera3;
import Shinobi.Entitys.Renderers.RenderSMDrillBird;
import Shinobi.Entitys.Renderers.RenderSMKoh;
import Shinobi.Entitys.Renderers.RenderSMRhino;
import Shinobi.Entitys.Renderers.RenderSasori;
import Shinobi.Entitys.Renderers.RenderSasoriHiruko;
import Shinobi.Entitys.Renderers.RenderShadowClone;
import Shinobi.Entitys.Renderers.RenderShinUchiha;
import Shinobi.Entitys.Renderers.RenderShuriken;
import Shinobi.Entitys.Renderers.RenderSusanooItachi;
import Shinobi.Entitys.Renderers.RenderTobi;
import Shinobi.Entitys.Renderers.RenderUchihaShin;
import Shinobi.Entitys.Renderers.RenderWater;
import Shinobi.Entitys.Renderers.RenderWhiteZetsu;
import Shinobi.Entitys.Renderers.RenderWind;
import Shinobi.Entitys.Renderers.RenderZetsu;
import Shinobi.Entitys.Renderers.projectiles.RenderArmsAttck;
import Shinobi.Entitys.Renderers.projectiles.RenderAsuraHand;
import Shinobi.Entitys.Renderers.projectiles.RenderChakraRod;
import Shinobi.Entitys.Renderers.projectiles.RenderEntityC2;
import Shinobi.Entitys.Renderers.projectiles.RenderEntityC3;
import Shinobi.Entitys.Renderers.projectiles.RenderEntityC4;
import Shinobi.Entitys.Renderers.projectiles.RenderEntityGFireball;
import Shinobi.Entitys.Renderers.projectiles.RenderFirebll;
import Shinobi.Entitys.Renderers.projectiles.RenderKunai;
import Shinobi.Entitys.Renderers.projectiles.RenderLShark;
import Shinobi.Entitys.Renderers.projectiles.RenderLightningbll;
import Shinobi.Entitys.Renderers.projectiles.RenderMShark;
import Shinobi.Entitys.Renderers.projectiles.RenderMagnetCube;
import Shinobi.Entitys.Renderers.projectiles.RenderMagnetSpread;
import Shinobi.Entitys.Renderers.projectiles.RenderMagnetTriangle;
import Shinobi.Entitys.Renderers.projectiles.RenderNeedles;
import Shinobi.Entitys.Renderers.projectiles.RenderPD;
import Shinobi.Entitys.Renderers.projectiles.RenderPaperBomb;
import Shinobi.Entitys.Renderers.projectiles.RenderPaperChakram;
import Shinobi.Entitys.Renderers.projectiles.RenderPaperPerson;
import Shinobi.Entitys.Renderers.projectiles.RenderPaperTwister;
import Shinobi.Entitys.Renderers.projectiles.RenderParticleX;
import Shinobi.Entitys.Renderers.projectiles.RenderRinneBullet;
import Shinobi.Entitys.Renderers.projectiles.RenderSShark;
import Shinobi.Entitys.Renderers.projectiles.RenderWaterbll;
import Shinobi.Entitys.Renderers.projectiles.RenderWindbll;
import Shinobi.Entitys.Renderers.projectiles.RenderWoodVines;
import Shinobi.Entitys.Renderers.projectiles.RenderYasaka;
import Shinobi.Items.Renderer.RenderHiramekarei;
import Shinobi.Items.Renderer.RenderKibi;
import Shinobi.Items.Renderer.RenderKubikiribocho;
import Shinobi.Items.Renderer.RenderNuibari;
import Shinobi.Items.Renderer.RenderSamehada;
import cpw.mods.fml.client.registry.ClientRegistry;
import cpw.mods.fml.client.registry.RenderingRegistry;
import net.minecraft.client.model.ModelBiped;
import net.minecraft.client.model.ModelDragon;
import net.minecraft.client.model.ModelSpider;
import net.minecraft.item.Item;
import net.minecraftforge.client.IItemRenderer;
import net.minecraftforge.client.MinecraftForgeClient;

public class CommonProxy {
	
	public static final Map<Item, ModelBiped> armorModels = new HashMap<Item, ModelBiped>();


	public static void registerRenderers() {
		
		
		//blocks
		ClientRegistry.bindTileEntitySpecialRenderer(DeathPoss.class, new RenderBlockDeathPos());

		
		//Entities
		RenderingRegistry.registerEntityRenderingHandler(EntityCrow.class, new RenderCrow(new ModelCrow(), 0.3F));
		RenderingRegistry.registerEntityRenderingHandler(EntityShadowClone.class, new RenderShadowClone(new ModelBiped(), 0.3F));
		RenderingRegistry.registerEntityRenderingHandler(EntityHidan.class, new RenderHidan(new ModelHidan(), 0.25F));
		RenderingRegistry.registerEntityRenderingHandler(EntityHidanHurt.class, new RenderHurtHidan(new ModelHurtHidan(), 0.25F));
		//RenderingRegistry.registerEntityRenderingHandler(EntityHidanCurse.class, new RenderHidanBLack(new ModelCurseHidan(), 0.25F));
		RenderingRegistry.registerEntityRenderingHandler(EntityKakuzu.class, new RenderKakuzu(new Modelkakuzu(), 0.25F));
		RenderingRegistry.registerEntityRenderingHandler(EntityFire.class, new RenderFireEntity(new Modelwaterandfire(), 0.25F));
		RenderingRegistry.registerEntityRenderingHandler(EntityWater.class, new RenderWater(new Modelwaterandfire(), 0.25F));
		RenderingRegistry.registerEntityRenderingHandler(EntityLightning.class, new RenderLightning(new Modellightning(), 0.25F));
		RenderingRegistry.registerEntityRenderingHandler(EntityWind.class, new RenderWind(new Modelwind(), 0.25F));
		//RenderingRegistry.registerEntityRenderingHandler(EntityKakuzu2.class, new RenderKakuzu2(new kakuzu22(), 0.25F));
		RenderingRegistry.registerEntityRenderingHandler(EntityKakuzu3.class, new RenderKakuzu3(new ModelKakuzuEGF(), 0.25F));
		RenderingRegistry.registerEntityRenderingHandler(EntityShinUchiha.class, new RenderShinUchiha(new ModelShinUchiha(), 0.25F));
		RenderingRegistry.registerEntityRenderingHandler(EntityUchihaShin.class, new RenderUchihaShin(new ShinUchihaB(), 0.25F));
		RenderingRegistry.registerEntityRenderingHandler(EntityUchihaclone.class, new RenderCloneUchiha(new ModelCloneUchihA(), 0.25F));
		RenderingRegistry.registerEntityRenderingHandler(EntityShuriken.class, new RenderShuriken(new ModelStar(), 0.25F));
		RenderingRegistry.registerEntityRenderingHandler(EntityDeathPos.class, new RenderDeathPoss(new Modeldeathpos(), 0F));
		//RenderingRegistry.registerEntityRenderingHandler(EntitySusanoo.class, new RenderSusanoo(new ModelBonesusanoo(), 0.25F));
		RenderingRegistry.registerEntityRenderingHandler(EntitySasoriHiruko.class, new RenderSasoriHiruko(new ModelSasoriHiruko(), 0.25F));
		RenderingRegistry.registerEntityRenderingHandler(EntitySasori.class, new RenderSasori(new ModelSasori(), 0.25F));
		RenderingRegistry.registerEntityRenderingHandler(Entity3rdKazekagePuppet.class, new Render3rdKazekagepuppet(new Model3rdKazePuppet(), 0.25F));
		RenderingRegistry.registerEntityRenderingHandler(EntityPuppetSasori.class, new RenderPuppetSasori(new ModelPuppet(), 0.25F));
		RenderingRegistry.registerEntityRenderingHandler(EntityDeidara.class, new RenderDeidara(new ModelDeidara(), 0.25F));
		RenderingRegistry.registerEntityRenderingHandler(EntityClayDragon.class, new RenderClayDragon(new ModelClayDRagon(), 0.25F));
		RenderingRegistry.registerEntityRenderingHandler(EntityClaySpider.class, new RenderClaySpider(new ModelSpider(), 0.25F));
		RenderingRegistry.registerEntityRenderingHandler(EntityClayBird.class, new RenderClayBird(new ModelClayBird(), 0.25F));
		RenderingRegistry.registerEntityRenderingHandler(EntityKisame.class, new RenderKisame(new ModelKisame(), 0.25F));
		RenderingRegistry.registerEntityRenderingHandler(EntityItachi.class, new RenderItachi(new ModelItachi(), 0.25F));
		RenderingRegistry.registerEntityRenderingHandler(EntitySusanooItachi.class, new RenderSusanooItachi(new ModelSusanooItachi(), 0.25F));
		RenderingRegistry.registerEntityRenderingHandler(EntityKonan.class, new RenderKonan(new ModelKonan(), 0.25F));
		RenderingRegistry.registerEntityRenderingHandler(EntityPaperWings.class, new RenderPaperWings(new ModelPaperWings(), 0.25F));
		RenderingRegistry.registerEntityRenderingHandler(EntityPainDeva.class, new RenderPainDeva(new ModelPain(), 0.25F));
		RenderingRegistry.registerEntityRenderingHandler(EntityPainAnimal.class, new RenderPainAnimal(new ModelPain(), 0.25F));
		RenderingRegistry.registerEntityRenderingHandler(EntityPainPreta.class, new RenderPainPreta(new ModelPain(), 0.25F));
		RenderingRegistry.registerEntityRenderingHandler(EntityPainHuman.class, new RenderPainHuman(new ModelPain(), 0.25F));
		RenderingRegistry.registerEntityRenderingHandler(EntityPainNaraka.class, new RenderPainNaraka(new ModelPain(), 0.25F));
		RenderingRegistry.registerEntityRenderingHandler(EntityPainAsura.class, new RenderPainAsura(new ModelPainAsura(), 0.25F));
		RenderingRegistry.registerEntityRenderingHandler(EntitySMChimera.class, new RenderSMChimera(new ModelChimera(), 0.25F));
		RenderingRegistry.registerEntityRenderingHandler(EntitySMChimera3.class, new RenderSMChimera3(new ModelChimera3h(), 0.25F));
		RenderingRegistry.registerEntityRenderingHandler(EntitySMChameleon.class, new RenderSMChameleon(new ModelChameleonS(), 0.25F));
		RenderingRegistry.registerEntityRenderingHandler(EntitySMDrillBird.class, new RenderSMDrillBird(new ModelDrillBeakBird(), 0.25F));
		RenderingRegistry.registerEntityRenderingHandler(EntitySMRhino.class, new RenderSMRhino(new ModelRhinoSum(), 0.25F));
		RenderingRegistry.registerEntityRenderingHandler(EntitySMKoH.class, new RenderSMKoh(new ModelKoh(), 0.25F));
		RenderingRegistry.registerEntityRenderingHandler(EntityTobi.class, new RenderTobi(new ModelTobi(), 0.25F));
		RenderingRegistry.registerEntityRenderingHandler(EntityZetsu.class, new RenderZetsu(new ModelZetsu(), 0.25F));
		RenderingRegistry.registerEntityRenderingHandler(EntityWhiteZetsu.class, new RenderWhiteZetsu(new ModelBiped(), 0.25F));

		
		//RenderingRegistry.registerEntityRenderingHandler(EntityArrowCustom.class, new RenderCustom());
//
		RenderingRegistry.registerEntityRenderingHandler(EntityFireBlast.class, new RenderFirebll());
		RenderingRegistry.registerEntityRenderingHandler(EntityWaterBlast.class, new RenderWaterbll());
		RenderingRegistry.registerEntityRenderingHandler(EntityLightningBlast.class, new RenderLightningbll());
		RenderingRegistry.registerEntityRenderingHandler(EntityWindBlast.class, new RenderWindbll());
		RenderingRegistry.registerEntityRenderingHandler(EntityNeedles.class, new RenderNeedles());
		RenderingRegistry.registerEntityRenderingHandler(EntityPuppetArmattack.class, new RenderArmsAttck());
		RenderingRegistry.registerEntityRenderingHandler(EntityMagnetCube.class, new RenderMagnetCube());
		RenderingRegistry.registerEntityRenderingHandler(EntityMagnetTriangle.class, new RenderMagnetTriangle());
		RenderingRegistry.registerEntityRenderingHandler(EntityMagnetSpread.class, new RenderMagnetSpread());
		RenderingRegistry.registerEntityRenderingHandler(EntityC2.class, new RenderEntityC2());
		RenderingRegistry.registerEntityRenderingHandler(EntityC3.class, new RenderEntityC3(new ModelC3(), 0.25F));
		RenderingRegistry.registerEntityRenderingHandler(EntityC4.class, new RenderEntityC4(new ModelC4(), 0.25F));
		RenderingRegistry.registerEntityRenderingHandler(EntitySShark.class, new RenderSShark());
		RenderingRegistry.registerEntityRenderingHandler(EntityMShark.class, new RenderMShark());
		RenderingRegistry.registerEntityRenderingHandler(EntityLShark.class, new RenderLShark());
		RenderingRegistry.registerEntityRenderingHandler(EntityGreatFireball.class, new RenderEntityGFireball());
		RenderingRegistry.registerEntityRenderingHandler(EntityKunai.class, new RenderKunai());
		RenderingRegistry.registerEntityRenderingHandler(EntityYasaka.class, new RenderYasaka());
		RenderingRegistry.registerEntityRenderingHandler(EntityPaperBomb.class, new RenderPaperBomb());
		RenderingRegistry.registerEntityRenderingHandler(EntityPaperChakram.class, new RenderPaperChakram());
		RenderingRegistry.registerEntityRenderingHandler(EntityPaperTwister.class, new RenderPaperTwister());
		RenderingRegistry.registerEntityRenderingHandler(EntityPaperPerson.class, new RenderPaperPerson());
		RenderingRegistry.registerEntityRenderingHandler(EntityChakraRod.class, new RenderChakraRod());
		RenderingRegistry.registerEntityRenderingHandler(EntityAsuraHand.class, new RenderAsuraHand());
		RenderingRegistry.registerEntityRenderingHandler(EntityRinneBullet.class, new RenderRinneBullet());
		RenderingRegistry.registerEntityRenderingHandler(EntityParticleX.class, new RenderParticleX());
		RenderingRegistry.registerEntityRenderingHandler(EntityPlanetaryDev.class, new RenderPD());
		RenderingRegistry.registerEntityRenderingHandler(EntityWoodVines.class, new RenderWoodVines());

		//Overlays
		//RenderingRegistry.registerEntityRenderingHandler(EntityPlayer.class, new CompleteSUsanooR());
		
		
		//ITEMS
			       MinecraftForgeClient.registerItemRenderer(ShinobiMod.ItemHiramekarei, (IItemRenderer) new RenderHiramekarei());
			       MinecraftForgeClient.registerItemRenderer(ShinobiMod.ItemKibi, (IItemRenderer) new RenderKibi());
			       MinecraftForgeClient.registerItemRenderer(ShinobiMod.ItemNuibari, (IItemRenderer) new RenderNuibari());
			       MinecraftForgeClient.registerItemRenderer(ShinobiMod.ItemKubikiribocho, (IItemRenderer) new RenderKubikiribocho());
			       MinecraftForgeClient.registerItemRenderer(ShinobiMod.ItemSamehada, (IItemRenderer) new RenderSamehada());

			       
		//tileentity
			       
			       //armor
					/*ModelAkatsukirobe akatchest = new ModelAkatsukirobe(1F);
					ModelAkatsukirobe akatrobe = new ModelAkatsukirobe(0.5F);
					
					armorModels.put(ShinobiMod.akatchest, akatchest);
					armorModels.put(ShinobiMod.akatrobe, akatrobe);
				*/
				}

			       
			       
	
	

		
		//animatedmobs
		//particles
		
	

}
