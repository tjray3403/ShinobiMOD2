package Shinobi;

public class References {
	
	public final static String name = "Shinobi";
	public final static String version = "2.0.0";
	public final static String MODID = "ShinobiMod";
	public final static String proxy_client = "ClientProxy";
	public final static String proxy_common = "CommonProxy";
	
}
