package Shinobi;

public class Resource {
	public static final String RESOURCE_PREFIX = References.MODID+":";
}
