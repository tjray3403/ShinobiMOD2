package Shinobi;


import Shinobi.Blocks.BlockMagnetRelease;
import Shinobi.Entitys.Projectiles.EntityFireBlast;
import Shinobi.Entitys.Projectiles.EntityLightningBlast;
import Shinobi.Entitys.Projectiles.EntityMagnetSpread;
import Shinobi.Entitys.Projectiles.EntityNeedles;
import Shinobi.Entitys.Projectiles.EntityWaterBlast;
import Shinobi.Entitys.Projectiles.EntityWindBlast;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.util.DamageSource;
import net.minecraft.util.EntityDamageSource;
import net.minecraft.util.EntityDamageSourceIndirect;

public class ShinobiDS extends DamageSource{

    public ShinobiDS(String name)
    {
        super(name);
    }

    public static DamageSource causeCursedDamage(EntityLivingBase cursed)
    {
        return new EntityDamageSource("cursed", cursed);
    }
    
    public static DamageSource CurseDamage = new ShinobiDS("CurseDamage").setDamageBypassesArmor();
    public static DamageSource ScytheSlice = new ShinobiDS("ScytheSlice");
    public static DamageSource sPosionn = (new DamageSource("sPoisonn")).setDamageBypassesArmor();
    public static DamageSource jutsuDMG = (new DamageSource("jutsuDMG")).setDamageBypassesArmor();

    
    public static DamageSource fireBlast (EntityFireBlast entityFireBlst, EntityLivingBase ninja)
    {
        return (new EntityDamageSourceIndirect("fireBlast", entityFireBlst, ninja)).setProjectile();
    }

	public static DamageSource waterBlast(EntityWaterBlast entityWaterBlast, EntityLivingBase ninja)
	{
		return (new EntityDamageSourceIndirect("waterBlast", entityWaterBlast, ninja)).setProjectile();
	}

	public static DamageSource lightningBlast(EntityLightningBlast entityLightningBlast, EntityLivingBase ninja) {
		// TODO Auto-generated method stub
		return (new EntityDamageSourceIndirect("lightningBlast", entityLightningBlast, ninja)).setProjectile();
	}

	public static DamageSource windBlast(EntityWindBlast entityWindBlast, EntityLivingBase ninja) {
		// TODO Auto-generated method stub
		return (new EntityDamageSourceIndirect("windBlast", entityWindBlast, ninja)).setProjectile();
	}

	public static DamageSource ssPosionn(EntityNeedles entityNeedles, EntityLivingBase ninja) {
		// TODO Auto-generated method stub
		 return (new EntityDamageSourceIndirect("ssPosionn", entityNeedles, ninja)).setProjectile();
	}

	public static DamageSource causeNinjaDamage(Entity entityMagnetSpread)
    {
        return new EntityDamageSource("ninja", entityMagnetSpread);
    }
	
	public static DamageSource causeJutsuDamage(EntityLivingBase en)
    {
        return new EntityDamageSource("jutsu", en);
    }

	public static DamageSource causeNinjaDamage(EntityNeedles entityNeedles) {
		// TODO Auto-generated method stub
		return new EntityDamageSource("needlejutsu", entityNeedles);
	}

    

}
