package Shinobi;

import java.util.Random;

import Shinobi.Entitys.EntityUtil;
import Shinobi.Entitys.Entitys.EntityHidan;
import Shinobi.Entitys.Entitys.EntityHidanCurse;
import Shinobi.Entitys.Entitys.EntityKakuzu;
import cpw.mods.fml.common.FMLCommonHandler;
import cpw.mods.fml.common.eventhandler.SubscribeEvent;
import cpw.mods.fml.common.gameevent.TickEvent;
import net.minecraft.client.Minecraft;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityCreature;
import net.minecraft.entity.EntityList;
import net.minecraft.entity.EntityLiving;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.potion.PotionEffect;
import net.minecraft.server.MinecraftServer;
import net.minecraft.util.DamageSource;
import net.minecraft.world.World;
import net.minecraftforge.event.entity.living.LivingAttackEvent;
import net.minecraftforge.event.entity.living.LivingEvent.LivingUpdateEvent;

public class ShinobiGlobal {
	
	private EntityKakuzu entity2;
	private EntityHidan entity1;
	private EntityLivingBase elb;
	private EntityHidanCurse entityHidancurse;


	@SubscribeEvent
	 public void onPlayerTick(TickEvent.PlayerTickEvent event) {
		EntityPlayer entity = Minecraft.getMinecraft().thePlayer;
		int i = (int) entity.posX;
		int j = (int) entity.posY;
		int k = (int) entity.posZ;
		MinecraftServer server = FMLCommonHandler.instance().getMinecraftServerInstance();
		World world = server.worldServers[0];
		
		if(ShinobiVariables.CurseMarke==true) {
				
		}
		
	
	}
	@SubscribeEvent
	public void onEntityLiving(LivingUpdateEvent event){
		
		EntityLivingBase ent = event.entityLiving;
	if (!ent.worldObj.isRemote && EntityUtil.isSummon(ent)){
		int owner = EntityUtil.getOwner(ent);
		Entity ownerEnt = ent.worldObj.getEntityByID(owner);
		if (!EntityUtil.decrementSummonDuration(ent)){
			ent.attackEntityFrom(DamageSource.generic, 5000);
		}
		if (owner == -1 || ownerEnt == null || ownerEnt.isDead || ownerEnt.getDistanceSqToEntity(ent) > 900){
			if (ent instanceof EntityLiving && !((EntityLiving)ent).getCustomNameTag().equals("")){
				EntityUtil.setOwner(ent, null);
				EntityUtil.setSummonDuration(ent, -1);
				EntityUtil.revertAI((EntityCreature)ent);
			}else{
				ent.attackEntityFrom(DamageSource.generic, 5000);
			}
		}
	}
	}
	@SubscribeEvent
	 public boolean onWorldTick(TickEvent.WorldTickEvent event) {
		EntityPlayer player = Minecraft.getMinecraft().thePlayer;
		EntityHidan entity = entity1;
		World world = null;
		World par1World = world;
		Random random = null;
		Random par5Random = random;
		
		
		
		return false;
		
		
		
	
	}

	@SubscribeEvent
	public void onEntityAttacked(LivingAttackEvent event) {
		EntityHidan entity = entity1;
		EntityPlayer player = Minecraft.getMinecraft().thePlayer;
		int i = (int) entity.posX;
		int j = (int) entity.posY;
		int k = (int) entity.posZ;
		MinecraftServer server = FMLCommonHandler.instance().getMinecraftServerInstance();
		World world = server.worldServers[0];
			
		if(true) {
			world.setBlock(i, j, k, ShinobiMod.blockDeathPossesion, 0 ,2);
		}


	
	}
	
	
	/**private EntityHidan EntityHidan;

	@SubscribeEvent
	public void onEntityAttacked(LivingAttackEvent event) {
		EntityHidan entity = EntityHidan;
		MinecraftServer server = FMLCommonHandler.instance().getMinecraftServerInstance();
		World world = server.worldServers[0];

		if (true) {
			if(ShinobiVariables.Cursed==true)
				if (entity instanceof EntityLivingBase)
					((EntityLivingBase) entity).addPotionEffect(new PotionEffect(7, 10, 2));
		}
	}
	**/
	

}
