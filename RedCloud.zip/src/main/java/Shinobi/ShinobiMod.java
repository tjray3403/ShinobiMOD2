package Shinobi;

import Shinobi.Blocks.BlockBlackFlame;
import Shinobi.Blocks.BlockDeathPos;
import Shinobi.Blocks.BlockMagnetRelease;
import Shinobi.Blocks.BlockWaterr;
import Shinobi.Blocks.TileEntity.DeathPoss;
import Shinobi.Effects.SPoisonEffect;
import Shinobi.Effects.Events.PotionEffect;
import Shinobi.EntityHandlers.DpEntityHandler;
import Shinobi.EntityHandlers.ModEntities;
import Shinobi.EntityHandlers.ProjectileEntities;
import Shinobi.Items.ItemCurseMark;
import Shinobi.Items.ItemHiramekarei;
import Shinobi.Items.ItemKageBunshin;
import Shinobi.Items.ItemKibi;
import Shinobi.Items.ItemKubikiribocho;
import Shinobi.Items.ItemNuibari;
import Shinobi.Items.ItemSamehada;
import Shinobi.Items.ItemScythe;
import Shinobi.Items.ItemShibuki;
import Shinobi.Keys.KeyCHandler;
import Shinobi.Keys.KeyXHandler;
import Shinobi.Keys.KeyZHandler;
import Shinobi.Proxy.ClientProxy;
import cpw.mods.fml.common.FMLCommonHandler;
import cpw.mods.fml.common.Mod;
import cpw.mods.fml.common.Mod.EventHandler;
import cpw.mods.fml.common.Mod.Instance;
import cpw.mods.fml.common.event.FMLInitializationEvent;
import cpw.mods.fml.common.event.FMLPostInitializationEvent;
import cpw.mods.fml.common.event.FMLPreInitializationEvent;
import cpw.mods.fml.common.registry.GameRegistry;
import cpw.mods.fml.common.registry.LanguageRegistry;
import net.minecraft.block.Block;
import net.minecraft.block.material.Material;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.item.Item;
import net.minecraft.item.ItemArmor.ArmorMaterial;
import net.minecraft.potion.Potion;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.common.util.EnumHelper;
import net.minecraftforge.fluids.Fluid;
import net.minecraftforge.fluids.FluidRegistry;


@Mod(modid = References.MODID, name = "Shinobi Mod", version = "1.0.1")
public class ShinobiMod {
	
	public static final String modid = "ShinobiMod";
	public static final String version = "Alpha v0.1";
	public static ClientProxy proxy;

	
	@Instance(modid)
	public static ShinobiMod Instance;
	
	
	
	public static Item ItemScythe;
	public static Item ItemKageBunshin;
	public static Item ItemHiramekarei;
	public static Item ItemKibi;
	public static Item ItemNuibari;
	public static Item ItemShibuki;
	public static Item ItemCurseMark;
	public static Item ItemKubikiribocho;
	public static Item ItemSamehada;
	public static Item akatchest;
	public static Item akatrobe;


	
	public static Potion SPoison;
	
	public static final Item.ToolMaterial Scythe = EnumHelper.addToolMaterial("Scythe", 4, 2000, 20.0F, 8.0F, 30);
	public static final Item.ToolMaterial Hiramekarei = EnumHelper.addToolMaterial("Hiramekarei", 4, 72000, 9.0F, 4.0F, 30);
	public static final Item.ToolMaterial Kibi = EnumHelper.addToolMaterial("Kibi", 4, 72000, 7.0F, 3.0F, 30);
	public static final Item.ToolMaterial Nuibari = EnumHelper.addToolMaterial("Nuibari", 4, 72000, 7.0F, 3.0F, 30);
	public static final Item.ToolMaterial Shibuki = EnumHelper.addToolMaterial("Shibuki", 4, 72000, 5.0F, 2.0F, 30);
	public static final Item.ToolMaterial Kubikiribocho = EnumHelper.addToolMaterial("Kubikiribocho", 4, 72000, 5.0F, 9.0F, 30);
	public static final Item.ToolMaterial Samehada = EnumHelper.addToolMaterial("Samehada", 4, 72000, 5.0F, 9.0F, 30);

	
	
	public static Block blockBlackFlame;
	public static Block blockSharinganGenjustu;
	public static Block blockDeathPossesion;
	public static Block blockMagnetRelease;
	public static Block blockWaterr;

	
	@EventHandler
	public void PreLoad(FMLPreInitializationEvent event) {
		
		
		
		
		//Item/Block init and registering
		//Config handling
		//itemSharingan = new itemSharingan().setUnlocalizedName("ItemSharingan").setTextureName("ninja:Sharingan").setCreativeTab(CreativeTabs.tabMisc);
		ItemScythe = new ItemScythe(Scythe).setUnlocalizedName("ItemScythe").setTextureName("ninja:scythe").setCreativeTab(CreativeTabs.tabMisc);
		ItemKageBunshin = new ItemKageBunshin().setUnlocalizedName("ItemKageBunshin").setTextureName("ninja:Srcoll").setCreativeTab(CreativeTabs.tabMisc);
		ItemHiramekarei = new ItemHiramekarei(Hiramekarei).setUnlocalizedName("ItemHiramekarei").setTextureName("ninja:himare").setCreativeTab(CreativeTabs.tabMisc);
		ItemKibi = new ItemKibi(Kibi).setUnlocalizedName("ItemKibi").setTextureName("ninja:Kiba").setCreativeTab(CreativeTabs.tabMisc);
		ItemNuibari = new ItemNuibari(Nuibari).setUnlocalizedName("ItemNuibari").setTextureName("ninja:Nuibarri").setCreativeTab(CreativeTabs.tabMisc);
		ItemShibuki = new ItemShibuki(Shibuki).setUnlocalizedName("ItemShibuki").setTextureName("ninja:blastpoi").setCreativeTab(CreativeTabs.tabMisc);
		ItemCurseMark = new ItemCurseMark().setUnlocalizedName("ItemCurseMark").setTextureName("ninja:cursem1").setCreativeTab(CreativeTabs.tabMisc);
		ItemKubikiribocho = new ItemKubikiribocho(Kubikiribocho).setUnlocalizedName("ItemKubikiribocho").setTextureName("ninja:kubikut").setCreativeTab(CreativeTabs.tabMisc);
		ItemSamehada = new ItemSamehada(Samehada).setUnlocalizedName("ItemSamehada").setTextureName("ninja:sameha").setCreativeTab(CreativeTabs.tabMisc);
		
		
		//Fluid fluid = new Fluid("waterr").setLuminosity(20).setDensity(970).setViscosity(950).setGaseous(false);
		//FluidRegistry.registerFluid(fluid);
		
		blockBlackFlame = new BlockBlackFlame(Material.fire).setBlockName("blackflame").setBlockTextureName("ninja:blackflame_layer_0");
		//blockSharinganGenjustu = new BlockSharinganGenjutsu(Material.fire).setBlockName("BlockSharinganGenjutsu").setBlockTextureName("ninja:Sharingan");
		blockDeathPossesion = new BlockDeathPos(Material.carpet).setBlockName("BlockDeathPossesion").setBlockTextureName("ninja:notexture");
		blockMagnetRelease = new BlockMagnetRelease(Material.cactus).setBlockName("MagnetReleaseBlock").setBlockTextureName("ninja:magnet1");
		//blockWaterr = new BlockWaterr(fluid, Material.water).setBlockName("BlockWaterr").setBlockTextureName("ninja:magnet1");

		//potions
		SPoison = new SPoisonEffect(25, true, 0).setIconIndex(0, 0).setPotionName("potion.spoisonEffect");
		
		MinecraftForge.EVENT_BUS.register(new PotionEffect());
		
		GameRegistry.registerItem(ItemScythe, ItemScythe.getUnlocalizedName().substring(5));
		GameRegistry.registerItem(ItemKageBunshin, ItemKageBunshin.getUnlocalizedName().substring(5));
		GameRegistry.registerItem(ItemHiramekarei, ItemHiramekarei.getUnlocalizedName().substring(5));
		GameRegistry.registerItem(ItemKibi, ItemKibi.getUnlocalizedName().substring(5));
		GameRegistry.registerItem(ItemNuibari, ItemNuibari.getUnlocalizedName().substring(5));
		GameRegistry.registerItem(ItemShibuki, ItemShibuki.getUnlocalizedName().substring(5));
		GameRegistry.registerItem(ItemCurseMark, ItemCurseMark.getUnlocalizedName().substring(5));
		GameRegistry.registerItem(ItemKubikiribocho, ItemKubikiribocho.getUnlocalizedName().substring(5));
		GameRegistry.registerItem(ItemSamehada, ItemSamehada.getUnlocalizedName().substring(5));

		
		GameRegistry.registerBlock(blockDeathPossesion, blockDeathPossesion.getUnlocalizedName().substring(5));
		GameRegistry.registerBlock(blockMagnetRelease, blockMagnetRelease.getUnlocalizedName().substring(5));
		//GameRegistry.registerBlock(blockWaterr, blockWaterr.getUnlocalizedName().substring(5));
		GameRegistry.registerBlock(blockBlackFlame, blockBlackFlame.getUnlocalizedName().substring(5));
		//GameRegistry.registerBlock(blockSharinganGenjustu, blockSharinganGenjustu.getUnlocalizedName().substring(5));
		//System.out.println(blockWaterr.getUnlocalizedName().substring(5));
		System.out.println(blockDeathPossesion.getUnlocalizedName().substring(5));
		System.out.println(blockMagnetRelease.getUnlocalizedName().substring(5));
		System.out.println(blockBlackFlame.getUnlocalizedName().substring(5));
		//System.out.println(blockSharinganGenjustu.getUnlocalizedName().substring(5));

		
		
		
		
	ProjectileEntities.registerEntities();
	ModEntities.registerEntities();
	DpEntityHandler.registerEntities();
	
	//TestEntityHandler.registerEntities(EntityTest.class, "Test");
	
	
	//keys
	FMLCommonHandler.instance().bus().register(new KeyZHandler());
	FMLCommonHandler.instance().bus().register(new KeyXHandler());
	FMLCommonHandler.instance().bus().register(new KeyCHandler());
	FMLCommonHandler.instance().bus().register(new ShinobiGlobal());

	
		//GameOverlays
	//armor
	ArmorMaterial Useless = EnumHelper.addArmorMaterial("useless", 0, new int[]{0, 0, 0, 0}, 0);
	
	//akatchest = new ArmorAkatsuki(Useless, 1, 1).setUnlocalizedName("akatchest").setTextureName("ninja:akatchest");
	//akatrobe = new ArmorAkatsuki(Useless, 1, 2).setUnlocalizedName("akatrobe").setTextureName("ninja:akatrobe");
	
	//GameRegistry.registerItem(akatchest, akatchest.getUnlocalizedName().substring(5));
	//GameRegistry.registerItem(akatrobe, akatrobe.getUnlocalizedName().substring(5));

	
	//TIck
	FMLCommonHandler.instance().bus().register(EventHandler.class);
		
		
	}
	
	@EventHandler
	public void init(FMLInitializationEvent event) {
		//Proxy, TileEntity, entity, GUI and Packet Registering
		GameRegistry.registerTileEntity(DeathPoss.class, "DeathPossession");
		

		
		
		
		
		
		
		
		
		
		proxy.registerRenderers();
		
		
	}
	
	

	private static void languageRegisters() {
		LanguageRegistry.instance().addStringLocalization("potion.spoisonEffect", "sPoison");
	}
	
	@EventHandler
	public void postInit(FMLPostInitializationEvent event) {
		
		
	}
	
	
}
