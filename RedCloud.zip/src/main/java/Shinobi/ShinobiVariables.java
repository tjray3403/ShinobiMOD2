package Shinobi;

public class ShinobiVariables {
	
	public static boolean MangekyoSharingan = false;
	public static boolean MangekyoSharingan1 = false;
	public static boolean Sharingan = false;
	public static boolean RedSusanoo = false;
	public static boolean RedSusanoo2 = false;
	public static boolean RedSusanoo3 = false;
	public static boolean RedSusanoo3shield = false;
	public static boolean RedSusanoo4 = false;
	public static boolean RedSusanoo5 = false;
	public static boolean Paperninjutsu = false;
	public static boolean PaperWings = false;
	public static boolean CurseMarke = false;
	public static boolean RedCompleteSusanoo = false;
	public static boolean change = false;
	






}
