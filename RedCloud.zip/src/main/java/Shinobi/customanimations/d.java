package Shinobi.customanimations;

public class d {

}
