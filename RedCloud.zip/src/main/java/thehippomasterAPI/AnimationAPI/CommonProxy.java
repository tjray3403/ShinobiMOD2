package thehippomasterAPI.AnimationAPI;

import net.minecraft.world.World;

public class CommonProxy {
	
	public void initTimer() {
	}
	
	public float getPartialTick() {
		return 1F;
	}
	
	public World getWorldClient() {
		return null;
	}
}
