package thehippomasterAPI.AnimationExample;

public class CommonProxy {
	
	public void registerRenderers() {
	}
}
