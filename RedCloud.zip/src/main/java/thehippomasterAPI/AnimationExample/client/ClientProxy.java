package thehippomasterAPI.AnimationExample.client;

import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;
import thehippomasterAPI.AnimationExample.CommonProxy;

@SideOnly(Side.CLIENT)
public class ClientProxy extends CommonProxy {
	
	public void registerRenderers() {
		//RenderingRegistry.registerEntityRenderingHandler(EntityTest.class, new RenderTest());
	}
}
